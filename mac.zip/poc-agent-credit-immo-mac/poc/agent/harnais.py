"""Harnais : lancer l'agent sur une demande, retrouver ses sessions, garder le lien session → trace d'observabilité.

L'évaluation contre la vérité terrain (lot 1) et les campagnes (lot 5) viendront s'ajouter ici.
"""

from __future__ import annotations

import datetime as dt
import time
from dataclasses import dataclass, field

import polars as pl

from poc.agent.graphe import construire_graphe
from poc.agent.noeud import ContexteAgent
from poc.config import Config
from poc.donnees import SQLiteStore
from poc.etapes import noms_etapes
from poc.llm import ConfigLLM, charger_config_llm, creer_client
from poc.observabilite import obtenir
from poc.outils import Backend, BackendLocal


@dataclass
class ResultatSession:
    session_id: str
    demande_id: str
    statut: str
    bilans: list[dict]
    tokens: int
    cout_euros: float | None
    duree_s: float
    journal: list[str] = field(default_factory=list)
    doutes: list[str] = field(default_factory=list)


def preparer_contexte(
    config: Config,
    config_llm: ConfigLLM | None = None,
    backend: Backend | None = None,
    verbeux: bool = False,
    modele: str | None = None,
    scenario_factice=None,
) -> ContexteAgent:
    config_llm = config_llm or charger_config_llm()
    noms = {config_llm.modele_pour(e, modele).nom_logique for e in noms_etapes()}
    clients = {n: creer_client(config_llm.modeles[n], scenario_factice) for n in noms}
    return ContexteAgent(
        config_llm=config_llm, backend=backend or BackendLocal(config), clients=clients, verbeux=verbeux
    )


def lancer_agent(
    config: Config,
    demande_id: str,
    modele: str | None = None,
    verbeux: bool = False,
    config_llm: ConfigLLM | None = None,
    backend: Backend | None = None,
    scenario_factice=None,
    checkpoints: bool = True,
    mcp: bool | None = None,
) -> ResultatSession:
    debut = time.time()
    config_llm = config_llm or charger_config_llm()
    backend_cree = None
    if backend is None and (mcp or (mcp is None and config_llm.agent.mode_outils == "mcp")):
        from poc.mcp import BackendMCP

        backend = backend_cree = BackendMCP(orchestrateur=BackendLocal(config))
    try:
        return _lancer(config, demande_id, modele, verbeux, config_llm, backend, scenario_factice, checkpoints, debut)
    finally:
        if backend_cree is not None:
            backend_cree.fermer()


def _lancer(
    config, demande_id, modele, verbeux, config_llm, backend, scenario_factice, checkpoints, debut
) -> ResultatSession:
    ctx = preparer_contexte(config, config_llm, backend, verbeux, modele, scenario_factice)
    mode_outils = "mcp" if hasattr(ctx.backend, "appeler_outil") else "direct"
    nom_modele = ctx.config_llm.modele_pour(None, modele).nom_logique + ("+mcp" if mode_outils == "mcp" else "")
    session = ctx.backend.ecrire("sessions", {"demande_id": demande_id, "modele": nom_modele})
    sid = session["session_id"]
    graphe = construire_graphe(ctx, config.checkpoints if checkpoints else None)
    etat_final: dict = {}
    with obtenir().session(sid, demande_id, {"modele": nom_modele, "mode_outils": mode_outils}) as span_session:
        for cle, val in attributs_de_session(config, ctx, demande_id, modele).items():
            span_session.attribut(cle, val)
        try:
            etat_final = graphe.invoke(
                {
                    "demande_id": demande_id,
                    "session_id": sid,
                    "syntheses": {},
                    "bilans": [],
                    "doutes": [],
                    "modele_surcharge": modele,
                    "statut": "EN_COURS",
                    "termine": False,
                },
                config={"configurable": {"thread_id": sid}},
            )
        except BaseException:
            ctx.backend.ecrire("session", {"session_id": sid, "statut": "INTERROMPUE"})
            raise
        resultat = _clore(ctx, sid, demande_id, etat_final, debut)
        conclure_racine(span_session, ctx, sid, resultat)
    if span_session.span_id:
        memoriser_trace(config, sid, span_session.trace_id, span_session.span_id)
    return resultat


def _clore(ctx: ContexteAgent, sid: str, demande_id: str, etat_final: dict, debut: float) -> ResultatSession:
    bilans = etat_final.get("bilans", [])
    statut = etat_final.get("statut") or "EN_COURS"
    if statut == "EN_COURS":
        statut = "ECHEC" if any(b.get("erreurs") for b in bilans) else "INTERROMPUE"
        ctx.backend.ecrire("session", {"session_id": sid, "statut": statut})
    tokens = sum(b["tokens"] for b in bilans)
    couts = [b["cout_euros"] for b in bilans if b.get("cout_euros") is not None]
    return ResultatSession(
        sid,
        demande_id,
        statut,
        bilans,
        tokens,
        round(sum(couts), 4) if couts else None,
        round(time.time() - debut, 1),
        ctx.journal,
        [str(d) for d in etat_final.get("doutes", [])],
    )


def attributs_de_session(config: Config, ctx: ContexteAgent, demande_id: str, modele: str | None) -> dict:
    """Ce que le span racine porte pour être filtré et comparé dans Arize : modèle (nom logique et nom exact, celui de la
    grille de coûts), versions du savoir et du code, et les dimensions du dossier (lot, scénario, difficulté) lues dans la
    vérité terrain. Ces dimensions ne servent qu'à l'observabilité : elles ne sont jamais montrées au modèle."""
    from poc.versions import empreinte_savoir, version_code

    m = ctx.config_llm.modele_pour(None, modele)
    attrs: dict = {
        "poc.modele": m.nom_logique,
        "poc.modele_nom": m.nom,
        "poc.version_savoir": empreinte_savoir(),
        "poc.version_code": version_code(),
    }
    try:
        store = SQLiteStore(config.sqlite_verite_terrain)
        if config.sqlite_verite_terrain.exists() and store.existe("vt_cas"):
            rows = store.requete(
                "SELECT lot, scenario, difficulte FROM vt_cas WHERE demande_id = ?", (demande_id,)
            ).to_dicts()
            if rows:
                attrs.update(
                    {
                        "poc.lot": rows[0]["lot"],
                        "poc.scenario": rows[0]["scenario"],
                        "poc.difficulte": rows[0]["difficulte"],
                    }
                )
    except Exception:  # noqa: BLE001 — une base absente ne doit pas empêcher la session
        pass
    return attrs


def conclure_racine(span, ctx: ContexteAgent, sid: str, resultat: ResultatSession, extra: dict | None = None) -> None:
    """Ferme proprement le span racine. Sa sortie (`output.value`) est la synthèse vérifiée, ce que liraient un juge de trace
    et un relecteur ; à défaut, le bilan de la session. Ses attributs sont les signaux **observables en production**, sans
    vérité terrain : position recommandée, doutes, pièces demandées, refus des garde-fous, verdicts hors norme."""
    try:
        dossier = ctx.backend.lire("dossier_travail", session_id=sid)
    except Exception:  # noqa: BLE001
        dossier = {}
    try:
        journal = ctx.backend.lire("journal", session_id=sid)
    except Exception:  # noqa: BLE001
        journal = []
    bilan = {
        "statut": resultat.statut,
        "etapes": [b["etape"] for b in resultat.bilans],
        "doutes": resultat.doutes,
        "tokens": resultat.tokens,
        **(extra or {}),
    }
    synthese = dossier.get("synthese")
    span.sortie(synthese if synthese else bilan)
    verdicts = dossier.get("verdicts") or []
    reco = dossier.get("recommandation") or {}
    for cle, val in (
        ("metric.tokens", resultat.tokens),
        ("metric.cout_euros", resultat.cout_euros),
        ("metric.duree_s", resultat.duree_s),
        ("metric.doutes", len(dossier.get("doutes") or resultat.doutes)),
        ("metric.pieces_demandees", len(dossier.get("messages_client") or [])),
        ("metric.refus_garde_fous", sum(1 for e in journal if e.get("type") == "garde_fou")),
        ("metric.verdicts_hors_norme", sum(1 for v in verdicts if v.get("verdict") == "HORS_NORME")),
        ("metric.cas_non_couverts", sum(1 for v in verdicts if v.get("verdict") == "CAS_NON_COUVERT")),
        ("poc.statut", resultat.statut),
        ("poc.recommandation", reco.get("position") or "AUCUNE"),
        ("poc.synthese_verifiee", bool(synthese)),
        ("poc.bilan", bilan),
    ):
        if val is not None:
            span.attribut(cle, val)


def memoriser_trace(config: Config, session_id: str, trace_id: str, span_id: str) -> None:
    """Garde le lien session → span racine, pour déposer plus tard évaluations et avis sur la trace."""
    cfg = obtenir().config
    SQLiteStore(config.sqlite_agent).remplacer(
        "agent_observabilite",
        pl.DataFrame(
            [
                {
                    "session_id": session_id,
                    "trace_id": trace_id,
                    "span_id": span_id,
                    "backend": cfg.backend,
                    "projet": cfg.projet,
                    "horodatage": dt.datetime.now().isoformat(timespec="seconds"),
                }
            ]
        ),
        "session_id",
        session_id,
    )


def trace_de_session(config: Config, session_id: str) -> dict | None:
    store = SQLiteStore(config.sqlite_agent)
    if not store.existe("agent_observabilite"):
        return None
    rows = store.requete("SELECT * FROM agent_observabilite WHERE session_id = ?", (session_id,)).to_dicts()
    return rows[0] if rows else None


def sessions_tracees(config: Config, n: int = 20) -> list[dict]:
    store = SQLiteStore(config.sqlite_agent)
    if not store.existe("agent_observabilite"):
        return []
    return store.requete(f"SELECT * FROM agent_observabilite ORDER BY horodatage DESC, rowid DESC LIMIT {int(n)}").to_dicts()
