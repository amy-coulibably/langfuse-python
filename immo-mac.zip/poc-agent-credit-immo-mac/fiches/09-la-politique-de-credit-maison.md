---
titre: La politique de crédit maison
description: Les seuils internes inventés pour le POC et la grille de conformité à remplir, règle par règle, avec les trois verdicts possibles.
---

# La politique de crédit maison

Le texte complet est dans `consulter_politique` (`nom = "politique_credit"`). Lis-le une fois ; cette fiche en est le mode
d'emploi. Les règles sont inventées pour le POC.

## La grille à remplir (un `enregistrer_verdict` par ligne)

| Code de la règle | Ce que tu compares | `DANS_LA_NORME` si… | Sinon |
| --- | --- | --- | --- |
| `HCSF_TAUX_EFFORT` | `taux_effort` et 35 % | ≤ 35 % | `HORS_NORME` (dérogeable) |
| `HCSF_DUREE` | `duree_souhaitee` et 25 ans | ≤ 25 | `HORS_NORME` |
| `SEUIL_RESTE_A_VIVRE` | `reste_a_vivre` et 1 000 € par adulte + 400 € par enfant | ≥ minimum | `HORS_NORME` |
| `SEUIL_APPORT` | `apport` et `frais_acquisition` | apport ≥ frais | `HORS_NORME` |
| `SEUIL_CDI` | chaque salarié en CDI : ancienneté | ≥ 6 mois (période d'essai terminée) | `CAS_NON_COUVERT` |
| `SEUIL_INDEPENDANT` | chaque indépendant : mois d'activité | ≥ 24 mois (deux exercices complets) | `CAS_NON_COUVERT` |
| `SEUIL_PENSION` | chaque retraité : date de liquidation de la pension (attestation) | ≥ 24 mois | `CAS_NON_COUVERT` |
| `SEUIL_INCIDENTS` | `consulter_incidents` pour chaque emprunteur, avec l'identifiant client rappelé dans la consigne (« La demande, en bref ») | aucun incident en cours | `HORS_NORME` si incident en cours ; un incident régularisé se signale sans bloquer |
| `SEUIL_COMPTE` | le résumé de l'étape « extraire » (points clés : signaux d'alerte par compte) ; ne relis pas les relevés | pas de découvert non autorisé répété, pas de rejet sur trois mois | `HORS_NORME` |

Le minimum de reste à vivre se calcule dans l'atelier (`reste_a_vivre_minimum`, constantes justifiées : 1 000 par adulte,
400 par enfant, nombre d'adultes et d'enfants comme constantes issues de la demande).

## Les trois verdicts

- `DANS_LA_NORME` : la règle s'applique et elle est respectée.
- `HORS_NORME` : la règle s'applique et elle n'est pas respectée. La banque peut déroger ; tu ne le décides pas.
- `CAS_NON_COUVERT` : une condition d'application n'est pas remplie (indépendant trop récent, CDI trop récent, pension trop
  récente). **Tu ne poses
  jamais `DANS_LA_NORME` sur un cas non couvert**, même si les chiffres paraissent bons : tu décris, tu signales.

## Ce que la grille prépare

Chaque ligne de la grille devient un motif ou une réserve de la recommandation (fiche « formuler une recommandation ») :
un `HORS_NORME` dérogeable ou un `CAS_NON_COUVERT` est une réserve ; un `HORS_NORME` non dérogeable (incident en cours) pèse
vers une position défavorable. Ne remplis que les lignes qui concernent le dossier : pas de `SEUIL_INDEPENDANT` sans
indépendant, pas de `SEUIL_PENSION` sans retraité, pas de `SEUIL_CDI` sans salarié en CDI.

## Le score de la banque : un indicateur, pas une règle

Après la grille, consulte le score (`consulter_score`) comme tu consultes le fichier d'incidents. Il n'est pas dans la
politique et ne se juge pas : pas de ligne de grille pour lui. Il est calculé sur le seul système d'information de la
banque, sans lire aucune pièce ; la réponse liste ce qu'il ne voit pas (`ne_voit_pas`). Garde trois choses pour la
synthèse : le score et sa classe, ce qu'il ne voit pas **sur ce dossier** (le compte joint tenu ailleurs, la prime, le cas
non couvert, la pièce manquante…), et s'il contredit ton analyse. Un A sur un dossier qui a une réserve, un A ou un B sur
un dossier défavorable ou sans avis possible, un D ou un E sur un dossier sain sont des **divergences** : tu les dis et tu
les expliques. Le texte complet de la grille se
lit avec `consulter_politique` (`grille_score`).
