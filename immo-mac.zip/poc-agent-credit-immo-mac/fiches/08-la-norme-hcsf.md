---
titre: La norme HCSF
description: Les deux plafonds nationaux (35 % de taux d'effort assurance comprise, 25 ans), la marge de dérogation qui n'appartient pas à l'agent, et les deux verdicts à poser.
---

# La norme HCSF

C'est la seule règle **réelle** du POC (vérifiée le 15 septembre 2026). Le texte complet est dans `consulter_politique`
(`nom = "norme_hcsf"`).

## Les deux plafonds

| Règle (code du verdict) | Plafond | Verdict |
| --- | --- | --- |
| `HCSF_TAUX_EFFORT` | taux d'effort ≤ 35 % des revenus nets, assurance comprise | `DANS_LA_NORME` si `taux_effort` ≤ 35, sinon `HORS_NORME` |
| `HCSF_DUREE` | durée ≤ 25 ans (27 avec différé pour travaux importants ou achat sur plan) | `DANS_LA_NORME` si `duree_souhaitee` ≤ 25, sinon `HORS_NORME` |

Le taux d'effort à comparer est `taux_effort` (tous revenus retenus, à la durée souhaitée). Si des revenus ne sont pas
couverts par la règle standard (indépendant récent), **indique aussi** `taux_effort_standard` dans la justification : le
conseiller doit voir les deux.

## La marge de dérogation

La banque peut déroger pour une part limitée de sa production (20 %), en priorité pour les résidences principales et les
primo-accédants. **Ce n'est pas à toi d'en décider ni de la promettre** : un dossier `HORS_NORME` reste `HORS_NORME` dans ta
grille ; tu peux écrire dans la justification qu'il est « dérogeable par la banque ».

## Comment faire

`enregistrer_verdict` pour chacune des deux règles, avec la valeur constatée (ex. « 33,5 % »), le seuil (« 35 % »), une
justification d'une phrase et les références (`taux_effort`, `duree_souhaitee`).
