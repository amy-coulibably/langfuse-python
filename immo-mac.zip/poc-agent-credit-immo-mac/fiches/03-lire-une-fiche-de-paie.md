---
titre: Lire une fiche de paie
description: Où trouver le net payé, comment reconnaître un mois atypique (prime, rappel), quoi enregistrer et sous quel nom, quoi recouper avec les relevés.
---

# Lire une fiche de paie

## Ce que tu cherches

Le **net payé** de chaque mois (ce qui arrive sur le compte), et le salaire **courant** du salarié une fois retirés les
éléments exceptionnels. C'est la politique maison (`REV_SALAIRE`) : on retient le net payé mensuel récurrent, hors prime
annuelle, rappel ou indemnité.

## Où regarder sur la fiche

Une fiche de paie empile : le salaire brut, les éventuelles primes, les cotisations (en négatif), le **net imposable**, le
prélèvement à la source (en négatif), et enfin le **NET PAYÉ**. Le net imposable est plus élevé que le net payé : ne les
confonds pas. Le chiffre à retenir est la ligne « NET PAYÉ ».

Avec `lire_piece`, le texte d'un tableau arrive une cellule par ligne : le libellé « NET PAYÉ » et le montant « 3 200,00 € »
sont sur deux lignes consécutives. Pour citer, copie **le montant tel quel** (« 3 200,00 € ») : c'est ce que `noter_fait`
vérifie dans la pièce.

## Comment faire, pour chaque fiche de paie

1. `lire_piece` sur la fiche (`P03`, `P04`…).
2. Vérifie le nom du salarié, l'employeur, la période, le contrat et la date d'entrée.
3. Repère les lignes inhabituelles : « Prime annuelle », « Prime exceptionnelle », « Rappel », « Indemnité », « Heures
   supplémentaires ». Si l'une d'elles est présente, ce mois n'est pas un mois courant.
4. Enregistre le net payé du mois : `noter_fait` nom `net_paye_<prenom>_<AAAA_MM>` (ex. `net_paye_thomas_2026_07`), valeur
   le net payé, source `{"type": "piece", "piece": "P03", "extrait": "3 200,00 €"}`.
5. Si une prime figure sur la fiche, enregistre-la à part : `prime_annuelle_<prenom>` avec l'extrait de son montant brut, et
   note dans ton résumé que le net payé de ce mois l'inclut.
6. Quand toutes les fiches sont lues, détermine le **net mensuel courant** : le net payé d'un mois sans élément
   exceptionnel (si plusieurs, ils doivent être égaux ou très proches ; sinon, doute). Enregistre-le sous
   `net_mensuel_<prenom>` avec la source de la fiche courante (même extrait).

## Le piège de la prime

Si un mois affiche un net payé bien supérieur aux autres (par exemple 5 600 € contre 3 200 €), cherche la ligne « Prime ».
Le net courant est celui du mois **sans** prime. Ne fais jamais la moyenne des nets payés quand l'un d'eux contient une prime :
tu surestimerais le revenu d'un tiers. Enregistre **toujours** un doute quand tu rencontres ce cas, avec `noter_doute` : objet
« la fiche de paie de juin 2026 (2026-06) inclut une prime annuelle de 3 096 € brut », hypothèses « prime versée une fois par an,
à exclure du revenu mensuel » et « prime régulière, un douzième pourrait être retenu », question « la prime figure-t-elle sur
les deux avis d'imposition ? », `faits_concernes` = le fait du net payé de ce mois. C'est le deuxième moment où tu te relis.

## Recouper avec les relevés

Le net payé doit se retrouver en virement « SALAIRE » sur un compte, le même mois. S'il n'y est pas en entier (par exemple
2 700 € sur le compte au lieu de 3 200 €), ne choisis pas un chiffre : **enregistre un doute** (voir la fiche « lire des relevés
bancaires ») avant toute autre chose.
