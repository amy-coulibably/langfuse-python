---
titre: Lire un avis d'imposition
description: Revenu fiscal de référence, nombre de parts, cohérence entre les revenus annuels déclarés et les fiches de paie ou le chiffre d'affaires.
---

# Lire un avis d'imposition

## Ce que tu cherches

Deux choses : la **cohérence** entre ce que le foyer a déclaré au fisc et ce que disent les fiches de paie ou les déclarations
de chiffre d'affaires ; et la **régularité** d'une prime (présente deux années de suite ou non).

## Où regarder

L'avis donne, par déclarant, les revenus de l'année précédente (« Traitements et salaires », « Bénéfices non commerciaux »),
puis le revenu brut global, le revenu fiscal de référence, le nombre de parts, l'impôt. L'avis émis en 2026 porte sur les
revenus de 2025.

## Comment faire

1. `lire_piece` sur les deux avis.
2. Pour un salarié : les salaires annuels imposables doivent valoir à peu près douze fois le **net imposable** mensuel de sa
   fiche de paie (pas le net payé), plus la prime si elle existe. Un écart de moins de 10 % est normal (augmentation en cours
   d'année, mois incomplets) et ne se signale pas ; seul un écart de plus de 10 % devient un doute (`noter_doute`).
3. Pour un indépendant : le bénéfice déclaré, après abattement, doit correspondre au chiffre d'affaires de l'année
   concernée moins l'abattement de son régime (34 % en micro-BNC). Une activité commencée en cours d'année ne couvre que
   quelques mois : c'est normal, dis-le.
4. Enregistre le revenu fiscal de référence du dernier avis : `noter_fait` nom `revenu_fiscal_reference_<annee>`, source la
   ligne de l'avis (extrait = le montant tel quel).
5. Note le nombre de parts et la situation de famille : ils confirment le foyer.

## Ce que l'avis ne dit pas

Il ne donne pas le net payé mensuel, ni la situation actuelle (un changement d'emploi récent n'y figure pas). Il sert à
confirmer, pas à retenir un revenu.
