---
titre: Lire une pièce numérisée
description: Quand la lecture native échoue, changer de méthode : l'OCR, puis la confiance ligne par ligne, puis le recoupement ou la copie lisible. Dire à chaque fois pourquoi on change.
---

# Lire une pièce numérisée

## Ce que tu cherches

Lire toutes les pièces, y compris celles que le client a déposées scannées ou photographiées. Tu as trois méthodes, de la
plus sûre à la plus fragile ; tu passes à la suivante **seulement quand la précédente échoue**, et tu dis pourquoi dans
ta pensée (« la lecture native ne donne rien, je passe à l'OCR »). C'est ce que le conseiller verra.

## Le plan, dans cet ordre

1. **Lecture native** : `lire_piece`. Rapide et exacte. C'est toujours ton premier essai, même si tu soupçonnes un scan.
2. **Si `lire_piece` échoue** avec `TEXTE_ABSENT` (un PDF scanné, sans couche texte) ou `FORMAT_NON_LISIBLE` (une
   photo, un JPG) : `ocr_piece` sur la même pièce. Ne réessaie pas `lire_piece`, il donnera la même chose.
3. **Lis le statut de l'OCR** :
   - `LISIBLE` : cite les lignes dans `noter_fait` comme pour `lire_piece` (source `piece`, extrait copié tel quel depuis
     le résultat de l'OCR). Chaque ligne a une **confiance** de 0 à 1.
   - `LECTURE_INCERTAINE` : la pièce est inutilisable. Demande au client une copie lisible (`demander_piece`, motif « pièce
     illisible »), note un doute non bloquant si les autres pièces suffisent à établir le chiffre, et poursuis.
4. **Une ligne incertaine** (confiance sous 0,80, listée dans `lignes_incertaines`) : `noter_fait` la refuse
   (`LECTURE_INCERTAINE`). Ne la recopie pas autrement. **Recoupe** : le même montant sur une autre ligne plus sûre de la
   même pièce, sur une autre pièce (une autre fiche de paie, un autre avis), ou sur un mouvement du relevé bancaire ; et
   note le fait depuis cette source sûre.
5. **Un recoupement réussi n'est pas un doute.** Si une source sûre donne le chiffre, le dossier n'a pas de problème :
   c'était ta lecture qui en avait un. Ne note pas de doute, dis-le seulement dans ta pensée. Un doute n'est justifié que si
   aucune source sûre ne donne le chiffre, ou si la pièce entière est `LECTURE_INCERTAINE`.

## Exemple

> `lire_piece P08` → `TEXTE_ABSENT`. « L'avis d'imposition 2025 est un scan sans texte : je passe à l'OCR. »
> `ocr_piece P08` → `LISIBLE`, confiance moyenne 0,90 ; la ligne « Revenu fiscal de référence » est à 0,73.
> « Cette ligne est incertaine ; le même montant, 66 520 €, figure sur la ligne "Revenu brut global" lue à 0,83 : je cite
> celle-là. »

## Pièges connus

- L'OCR ne lit pas toujours les espaces : « 3340,00€ » pour « 3 340,00 € ». Copie l'extrait tel que l'OCR l'a rendu.
- L'OCR peut se tromper d'un chiffre sans baisser beaucoup sa confiance. Un montant lu par OCR qui ne colle pas avec les
  autres pièces mérite un doute, pas une correction de ta part.
- `ocr_piece` sur un PDF qui a du texte renvoie le texte natif : ce n'était pas nécessaire. Essaie toujours `lire_piece`
  d'abord.
- Un OCR lent ou indisponible (`OCR_NON_DISPONIBLE`) : demande une copie lisible, comme pour une lecture incertaine.
