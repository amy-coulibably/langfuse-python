---
titre: Comprendre une demande
description: Reformuler le projet, identifier le foyer et les emprunteurs, enregistrer les faits de la demande, repérer dès le départ ce qui sort de l'ordinaire.
---

# Comprendre une demande

## Ce que tu cherches

Avant de lire une seule pièce, tu dois pouvoir dire en trois phrases : **qui** emprunte, **quoi** (le bien, le prix, l'apport,
la durée souhaitée), et **ce qui mérite attention** dans leur situation.

## Comment faire, dans l'ordre

1. `lire_demande` : le projet (prix, honoraires d'agence inclus, apport, durée souhaitée, type de bien, usage, compromis et sa
   date limite), le foyer (situation familiale, enfants, loyer actuel déclaré), les emprunteurs avec leur **identifiant client**
   (tu en auras besoin pour tous les outils de la banque), et les crédits en cours **déclarés par le client**.
2. `consulter_client` pour chaque emprunteur : situation professionnelle, employeur, poste, date d'entrée ou début d'activité,
   date de naissance, ancienneté dans la banque.
3. Enregistre tout de suite les faits de la demande avec `noter_fait`, source de type `demande` (champ de la demande) ou
   `credit_declare` (organisme). Noms à utiliser, toujours en minuscules :

   | Fait | Nom | Source |
   | --- | --- | --- |
   | prix de vente (honoraires inclus) | `prix_bien` | `{"type": "demande", "champ": "prix"}` |
   | honoraires d'agence inclus dans le prix | `honoraires_agence` | `{"type": "demande", "champ": "honoraires_agence_inclus"}` |
   | apport | `apport` | `{"type": "demande", "champ": "apport"}` |
   | durée souhaitée (années) | `duree_souhaitee` | `{"type": "demande", "champ": "duree_souhaitee_annees"}` |
   | loyer actuel déclaré | `loyer_actuel` | `{"type": "demande", "champ": "loyer_actuel_declare"}` |
   | mensualité d'un crédit déclaré | `credit_<type>_mensualite` (ex. `credit_auto_mensualite`) | `{"type": "credit_declare", "organisme": "<nom de l'organisme>"}` |

   `noter_fait` n'accepte **que des nombres** : les dates (dépôt, compromis, entrée en poste), les textes (adresse, type de
   bien, situation familiale) et les âges ne s'enregistrent pas ; ils sont rappelés dans la consigne de chaque étape
   (« La demande, en bref ») et tu les cites de mémoire sans source. Six faits suffisent ici : ceux du tableau.
4. Repère les **situations à surveiller** et note-les dans ta synthèse de fin d'étape (`points_cles`), pas encore comme des
   doutes : une activité indépendante de moins de deux ans, un CDI de moins de six mois, un CDD, un projet locatif, un apport
   inférieur aux frais d'acquisition, plusieurs crédits en cours, un délai de condition suspensive proche.
5. L'âge et l'ancienneté de chaque emprunteur **au dépôt** figurent dans « La demande, en bref » (calculés par la banque à
   partir des dates) : reprends-les dans tes `points_cles`, ne les recalcule pas, ne les enregistre pas, n'en doute pas.

## Ce que tu ne fais pas ici

Tu ne lis pas encore les pièces, tu ne calcules rien, tu ne juges pas. Tu décris.

## Exemple de fin d'étape

```json
{"resume": "Marie et Thomas, pacsés sans enfant, achètent un appartement ancien à Nantes à 320 000 € (dont 10 000 € d'honoraires) avec 40 000 € d'apport sur 25 ans. Thomas est en CDI depuis 2020 ; Marie est auto-entrepreneuse depuis juillet 2025. Un crédit auto de 210 € par mois est déclaré.",
 "points_cles": ["Marie : activité indépendante depuis 14 mois, à surveiller (règle des deux exercices)", "âges au dépôt : Thomas 36 ans, Marie 34 ans", "condition suspensive au 12/10/2026"],
 "doutes": [], "bloquant": false}
```
