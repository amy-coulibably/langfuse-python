# Les fiches de méthode (skills)

Une fiche de méthode est le savoir-faire d'un conseiller expérimenté, écrit en français, en une ou deux pages : quoi
chercher, dans quel ordre, quelles règles appliquer, quels pièges éviter, quel format produire. L'agent lit en entier les
fiches de l'étape en cours (déclarées dans `config/etapes.yaml`) et peut consulter les autres à la demande avec l'outil
`consulter_fiche`.

Chaque fiche commence par un en-tête :

```
---
titre: Lire une fiche de paie
description: Où trouver le net à payer, comment repérer une prime exceptionnelle, quoi recouper.
---
```

## Fiches prévues (cadrage, section 8), écrites au lot 3

| Fichier | Étapes |
| --- | --- |
| `00-regles-communes.md` (présente dès le lot 0) | toutes |
| `01-comprendre-une-demande.md` | comprendre |
| `02-les-pieces-d-un-dossier.md` | vérifier |
| `03-lire-une-fiche-de-paie.md` | extraire |
| `04-lire-un-avis-d-imposition.md` | extraire |
| `05-lire-des-releves-bancaires.md` | extraire |
| `06-revenus-d-un-independant.md` | extraire, confronter |
| `07-calculer-le-taux-d-effort-et-le-reste-a-vivre.md` | calculer |
| `08-la-norme-hcsf.md` | confronter |
| `09-la-politique-de-credit-maison.md` | confronter |
| `10-rediger-la-synthese-pour-le-conseiller.md` | rédiger |
| `11-formuler-une-recommandation.md` | rédiger |
| `12-se-relire.md` | calculer, rédiger |
| `13-lire-une-piece-numerisee.md` (ajoutée avec le service OCR) | vérifier, extraire |

`poc etapes` montre, pour chaque étape, les fiches présentes et celles qui restent à écrire.
