---
titre: Calculer le taux d'effort et le reste à vivre
description: La méthode maison, pas à pas, dans l'atelier : frais d'acquisition, montant emprunté, mensualités par le simulateur, revenus et charges retenus, taux d'effort, reste à vivre ; et la relecture obligatoire.
---

# Calculer le taux d'effort et le reste à vivre

## Les règles

- **Tout calcul passe par `calculer`** (ou par `simuler_pret` pour les mensualités). Les entrées sont des faits enregistrés
  (`{"type": "fait", "nom": ...}`), des résultats antérieurs (`{"type": "calcul", "nom": ...}`) ou des constantes justifiées
  (`{"type": "constante", "valeur": 0.075, "justification": "frais d'acquisition dans l'ancien, barème"}`). Un montant écrit en
  dur dans le code est refusé.
- `unite` vaut pour toutes les sorties d'un appel ; quand un appel produit des euros et des pourcentages, donne un dictionnaire
  (`"unite": {"charges_retenues": "euros", "taux_effort": "pourcentage"}`) ou fais deux appels. Une unité affichée n'est
  qu'une étiquette : elle ne change pas la valeur calculée.
- Les **noms des résultats** sont imposés, parce que le conseiller et le correcteur les cherchent :

  | Résultat | Nom | Unité |
  | --- | --- | --- |
  | frais d'acquisition (notaire) | `frais_acquisition` | euros |
  | montant emprunté | `montant_emprunte` | euros |
  | mensualité assurance comprise à N ans (par le simulateur) | `mensualite_15`, `mensualite_20`, `mensualite_25` | euros |
  | revenu retenu par personne | `revenu_retenu_<prenom>` | euros |
  | revenus retenus du foyer (tous) | `revenus_retenus` | euros |
  | revenus retenus couverts par la règle standard seulement | `revenus_retenus_standard` | euros |
  | charges retenues à la durée souhaitée | `charges_retenues` | euros |
  | taux d'effort à la durée souhaitée, tous revenus | `taux_effort` | pourcentage |
  | taux d'effort aux autres durées | `taux_effort_15`, `taux_effort_20` | pourcentage |
  | taux d'effort avec les seuls revenus couverts | `taux_effort_standard` | pourcentage |
  | reste à vivre à la durée souhaitée | `reste_a_vivre` | euros |

## La méthode, dans l'ordre

1. `lire_faits` : tu dois avoir `prix_bien`, `honoraires_agence`, `apport`, `duree_souhaitee`, le net mensuel courant de chaque
   salarié (`net_mensuel_<prenom>`), le chiffre d'affaires moyen de chaque indépendant, les mensualités des crédits en cours.
   S'il manque un fait, retourne le chercher : ne le devine pas.
2. `consulter_bareme` : le taux de frais d'acquisition pour le type de bien, les taux par durée, l'assurance par âge.
3. **Frais d'acquisition** : `frais_acquisition = (prix_bien − honoraires_agence) × taux_frais` (les honoraires d'agence ne
   supportent pas les droits).
4. **Montant emprunté** : `montant_emprunte = prix_bien + frais_acquisition − apport`.
5. **Mensualités** : `simuler_pret` pour 15, 20 et 25 ans, avec le montant emprunté ; sans paramètre `ages`, le simulateur prend
   les âges des emprunteurs au dépôt tels que la banque les calcule (il les renvoie dans `ages_utilises`). Il archive
   `mensualite_15`, `mensualite_20`, `mensualite_25` (assurance comprise) dans la feuille de calcul.
6. **Revenus retenus** :
   - salarié : `revenu_retenu_<prenom> = net_mensuel_<prenom>` (hors prime : voir la fiche « lire une fiche de paie ») ;
   - indépendant : `ca_mensuel_moyen × (1 − abattement)` ; si moins de 24 mois d'activité, ce revenu n'est **pas couvert** ;
   - retraité : `revenu_retenu_<prenom> = pension_mensuelle_<prenom>` ; pension liquidée depuis moins de deux ans : **pas couvert** ;
   - CDD : retenu seulement si l'ancienneté dépasse trois ans ; sinon le revenu est **exclu** (`REV_EXCLUS`), il vaut 0 dans la
     somme et tu le dis dans un doute (non bloquant si un autre revenu existe) ;
   - projet locatif : `revenus_locatifs_retenus = loyers_attendus × 0,70` (constante justifiée par la règle `REV_LOCATIF`),
     ajouté aux revenus retenus ;
   - `revenus_retenus` = somme de tous ; `revenus_retenus_standard` = somme des seuls revenus couverts.
7. **Charges retenues** : `charges_retenues = mensualite_<durée souhaitée> + mensualités des crédits en cours` (un crédit qui
   se termine dans moins de six mois après le dépôt ne compte pas ; le loyer actuel ne compte pas pour une résidence principale,
   mais il **compte** pour un projet locatif : le foyer continue de le payer).
8. **Taux d'effort** : `taux_effort = charges_retenues / revenus_retenus × 100` (la constante `100` est un facteur, pas un
   montant). Même chose pour `taux_effort_standard` avec `revenus_retenus_standard`, et pour `taux_effort_15` / `taux_effort_20`
   avec les autres mensualités.
9. **Reste à vivre** : `reste_a_vivre = revenus_retenus − charges_retenues`.

## La relecture obligatoire (fiche « se relire »)

Avant de conclure l'étape, `lire_calculs` et relis chaque entrée :

- le net mensuel retenu est-il bien celui d'un mois **sans prime** ? Si tu as retenu un mois avec prime, ou une moyenne qui en
  contient une, recalcule avec le bon fait et dis-le : « je corrige : le taux d'effort passe de 28 % à 33,5 % » ;
- les mensualités viennent-elles du simulateur, assurance comprise ?
- les crédits en cours sont-ils comptés une seule fois ?
- les unités sont-elles cohérentes (euros par mois partout) ?

Un calcul corrigé s'enregistre à nouveau sous le même nom : la feuille garde l'historique, le dernier l'emporte.

## Exemple de fin d'étape

```json
{"resume": "Montant emprunté 303 250 €. Mensualité à 25 ans 1 571 € assurance comprise. Revenus retenus 5 318 € dont 2 118 € de Marie, non couverts par la règle standard. Taux d'effort 33,5 % tous revenus, 55,7 % sans Marie. Reste à vivre 3 536 €. Je me suis relu : le net de juin incluait la prime, j'ai retenu juillet.",
 "points_cles": ["taux d'effort à 15 ans 44,9 %, à 20 ans 37,6 %"], "doutes": ["revenus de Marie non couverts (14 mois d'activité)"], "bloquant": false}
```
