---
titre: Rédiger la synthèse pour le conseiller
description: Le plan de la synthèse en une page, le ton, l'obligation de source pour chaque chiffre, la place des doutes et des questions ; pas d'avis d'octroi dans le texte.
---

# Rédiger la synthèse pour le conseiller

## Avant d'écrire

`lire_dossier_travail` : tout ce que tu as produit (faits, feuille de calcul, doutes, messages, verdicts). Tu n'écris que ce
qui s'y trouve. Un chiffre qui n'est ni un fait ni un résultat de calcul n'a pas sa place dans la synthèse.

## Le plan (titres Markdown `##`, dans cet ordre)

1. **Foyer et projet** : qui, situation familiale et professionnelle, le bien, le prix, l'apport, la durée souhaitée, la
   date limite du compromis.
2. **Revenus retenus** : par personne, la règle appliquée, le montant retenu ; ce qui a été exclu (prime) et pourquoi ; ce
   qui n'est pas couvert par la règle standard.
3. **Capacité de remboursement** : montant emprunté, mensualité assurance comprise à la durée souhaitée (et aux deux autres
   durées), charges retenues, taux d'effort (tous revenus, et revenus couverts seulement), reste à vivre.
4. **Conformité** : la grille, règle par règle, avec le verdict.
   Puis **Indicateurs de la banque** (sous-titre) : le score et sa classe, ce qu'il ne voit pas sur ce dossier, et s'il
   contredit l'analyse, pourquoi (« le score ne voit pas le compte joint tenu ailleurs ni le cas non couvert de Marie :
   il ne remplace pas l'analyse »). Le score est un résultat de calcul (`score_eligibilite`).
5. **Points forts** : trois au plus, factuels.
6. **Points de vigilance** : ce qui fragilise le dossier, factuel, sans jugement sur les personnes.
7. **Pièces manquantes et questions au client** : ce qui a été demandé, ce qui est attendu.
8. **Questions au conseiller** : les doutes, un par ligne, avec les hypothèses.

Une page : environ 350 à 500 mots. Phrases courtes, à la première personne quand tu décris ce que tu as fait (« j'ai retenu »,
« je n'ai pas pu confirmer »).

## Les chiffres

Chaque montant, pourcentage ou nombre d'au moins 100 que tu écris doit figurer dans la liste `chiffres` de
`enregistrer_synthese`, avec le fait ou le résultat de calcul qui le justifie :

```json
{"texte": "1 571,42 €", "type": "calcul", "nom": "mensualite_25"}
```

Quatre types de source pour un chiffre :

| Type | Quand | Exemple |
| --- | --- | --- |
| `fait` | un chiffre extrait d'une pièce ou de la demande | `{"texte": "40 000 €", "type": "fait", "nom": "apport"}` |
| `calcul` | un résultat de la feuille de calcul | `{"texte": "33,5 %", "type": "calcul", "nom": "taux_effort"}` |
| `regle` | un seuil ou un taux d'une règle | `{"texte": "35 %", "type": "regle", "nom": "HCSF_TAUX_EFFORT_MAX"}` ; aussi `ABATTEMENT_MICRO_BNC` (34), `RESTE_A_VIVRE_PAR_ADULTE` (1 000), `EXERCICES_MINIMUM_INDEPENDANT` (24), `HCSF_DUREE_MAX` (25), `FRAIS_ACQUISITION_ANCIEN_PCT` (7,5), `TAUX_NOMINAL_25_ANS` |
| `doute` | un écart constaté dans un doute enregistré | `{"texte": "500 €", "type": "doute", "nom": "<doute_id ou objet du doute>"}` |

Un chiffre que tu ne peux rattacher à aucune de ces sources **ne va pas dans la synthèse** : retire-le, ou calcule-le dans
l'atelier avant d'écrire. Si le vérificateur refuse deux fois, simplifie le texte plutôt que de le redéposer tel quel.

Écris les chiffres tels qu'ils sont dans la feuille de calcul, à l'arrondi près (« 1 571 € » est accepté pour 1 571,42 ;
« 33,5 % » pour 33,46). Un chiffre **égal à la valeur d'un fait, d'un calcul ou d'une règle de la session** est reconnu
même si tu as oublié de le citer ; ce qui est refusé, c'est un chiffre qui n'existe nulle part (un minimum de reste à vivre
que tu n'as pas calculé, un pourcentage que tu as estimé) et une citation fausse. Les durées (« 25 ans »), les âges, les
comptages (« 3 fiches »), les dates, les années et les codes postaux ne sont pas des chiffres à sourcer. Le vérificateur refuse la synthèse s'il reste un chiffre sans source ou une citation fausse : lis
son message, corrige, redépose.

## Ce qui est interdit dans le texte

Aucun avis d'octroi : ni « avis favorable », ni « je recommande », ni « le prêt peut être accordé ». La recommandation est
un champ à part (fiche suivante). La synthèse décrit, la recommandation prend position.
