---
titre: Revenus d'un indépendant
description: Quelles pièces, quelle moyenne, quel abattement ; et pourquoi une activité de moins de deux exercices sort de la règle standard.
---

# Revenus d'un indépendant

## La règle maison (`REV_INDEPENDANT`, `SEUIL_INDEPENDANT`)

Revenu mensuel retenu = **moyenne mensuelle du chiffre d'affaires des deux derniers exercices complets**, après l'abattement
forfaitaire du régime : 34 % pour un micro-BNC (professions libérales, graphiste, consultant), 50 % pour un micro-BIC de
services, 71 % pour la vente.

**En dessous de deux exercices complets (24 mois d'activité), le cas n'est pas couvert par la règle standard.** Tu ne retiens
pas ces revenus comme acquis, tu ne les écartes pas non plus : tu calcules le taux d'effort **avec et sans**, tu poses le
verdict `CAS_NON_COUVERT` sur `SEUIL_INDEPENDANT`, et tu renvoies la décision au conseiller.

## Comment faire

1. `consulter_client` : activité, régime, date de début. Compte les mois d'activité à la date de dépôt.
2. `lire_piece` sur le relevé des déclarations de chiffre d'affaires : un montant par mois, un total. Enregistre :
   - le chiffre d'affaires mensuel moyen : `ca_mensuel_moyen_<prenom>` — c'est un calcul (`calculer`, entrées = le total
     déclaré enregistré comme fait `ca_total_declare_<prenom>` avec l'extrait de la ligne « Total », et le nombre de mois en
     constante justifiée) ;
   - l'abattement comme constante justifiée dans le calcul (`abattement = 0.34`, justification : « micro-BNC, politique maison »).
3. Vérifie que les encaissements du compte professionnel (`consulter_mouvements` sur le compte pro, filtre `FACTURE`)
   correspondent aux mois déclarés visibles ; une différence notable est un doute.
4. Calcule le revenu retenu : `revenu_retenu_<prenom> = ca_mensuel_moyen × (1 − abattement)`.
5. Si l'activité a moins de 24 mois : `noter_doute`, objet « <prénom> est indépendante depuis N mois : la règle standard
   demande deux exercices complets, cas non couvert », hypothèses (activité en croissance et régulière ; activité trop
   récente pour être retenue), question au conseiller (retient-il tout ou partie de ces revenus ?).

## Ce qu'on ne fait pas

On ne retient pas le chiffre d'affaires brut comme un revenu. On ne retient pas la rémunération que l'indépendant se verse
(le virement du compte pro vers le compte perso) : c'est un choix de trésorerie, pas un revenu.
