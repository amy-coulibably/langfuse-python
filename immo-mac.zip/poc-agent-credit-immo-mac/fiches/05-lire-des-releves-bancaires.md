---
titre: Lire des relevés bancaires
description: Recouper les salaires avec les virements reçus, repérer les charges récurrentes et les crédits non déclarés, lire les signaux d'alerte sans juger, enregistrer un doute quand deux sources divergent.
---

# Lire des relevés bancaires

## Ce que tu cherches

1. **Le recoupement des revenus** : le net payé des fiches de paie arrive-t-il en virement « SALAIRE » ? La rémunération d'un
   indépendant arrive-t-elle de son compte professionnel ?
2. **Les charges récurrentes** : loyer, crédits (prélèvements « ECH »), pensions. Un prélèvement de crédit qui n'est pas dans
   la déclaration du client est un crédit non déclaré.
3. **Les signaux d'alerte**, décrits factuellement : découverts répétés, rejets de prélèvement, commissions d'intervention,
   jeux d'argent en ligne réguliers, retraits d'espèces anormaux.

## Deux façons de lire

- Les comptes tenus **dans la banque** : `consulter_comptes` (identifiant client) puis `consulter_mouvements` (compte, période,
  et un filtre `motif` comme `SALAIRE`, `LOYER`, `PRLV`, `ECH`). Le résultat donne les totaux et chaque ligne avec sa date et
  son montant : c'est la source à citer (`{"type": "mouvement", "compte_id": ..., "date": ..., "montant": ...}`).
- Les comptes tenus **ailleurs** (un compte joint dans une autre banque, par exemple) : seulement par les relevés déposés,
  `lire_piece` sur chaque relevé. Source de type `piece` avec l'extrait de la ligne.

Lis les trois mois ; ne relis pas dix fois le même relevé.

## Comment recouper un salaire

Pour chaque salarié et chaque mois : virement « SALAIRE » reçu sur son compte = net payé de la fiche de paie ?

- **Égal** : enregistre le virement d'un mois comme fait `virement_salaire_<prenom>_<AAAA_MM>` (source mouvement) et dis dans
  ton résumé que les revenus sont confirmés.
- **Différent** (par exemple 2 700 € reçus pour 3 200 € de net payé) : **n'invente pas d'explication et ne choisis pas un
  chiffre**. Fais trois choses, dans cet ordre :
  1. cherche si la différence apparaît sur un autre compte du foyer (un virement « SALAIRE » du même employeur sur le compte
     joint, par exemple) ;
  2. `noter_doute` : objet « écart entre le net payé de la fiche de paie (3 200 €) et les virements de salaire reçus sur le
     compte (2 700 €) », hypothèses (virement scindé sur un autre compte, saisie sur salaire, erreur de période, avance
     remboursée), question au conseiller, `faits_concernes` = le nom du fait de la fiche de paie, `pieces_concernees` ;
  3. enregistre le virement reçu sous son propre nom (`virement_salaire_<prenom>_<AAAA_MM>`), jamais sous le nom du net payé.
  Si tu as trouvé la différence sur un autre compte, dis-le dans le doute (hypothèse confirmée par les relevés) : c'est au
  conseiller de valider.

## Les crédits et le loyer

- Les prélèvements « ECH » d'un organisme de crédit confirment la mensualité déclarée : enregistre-la si ce n'est pas fait
  (`credit_<type>_mensualite`, source mouvement).
- Le loyer : confirme le montant déclaré ; il ne compte pas dans les charges pour une résidence principale (il disparaît).

## Les signaux d'alerte

Pour chaque signal, un fait ou un doute, jamais un jugement sur la personne : « trois mises de jeux en ligne par mois »,
« commission d'intervention le 29 », « solde négatif en fin de mois sur deux mois ». Le fil rouge n'en a pas : ne les invente pas.

## En fin d'étape

Ton résumé de fin d'étape doit dire explicitement, pour chaque compte lu : « aucun signal d'alerte » ou la liste des signaux
(découverts, rejets, commissions, jeux). Les étapes suivantes (« confronter », règle `SEUIL_COMPTE`) s'appuient sur ce résumé
sans relire les relevés. Mets-le dans `points_cles`, par exemple : « relevés CPT-THOMAS, CPT-MARIE, CPT-MARIE-PRO et compte
joint, juin à août 2026 : aucun découvert, aucun rejet, aucune commission, aucune mise de jeu ».
