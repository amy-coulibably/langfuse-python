---
titre: Formuler une recommandation
description: Les quatre positions, ce qui justifie chacune, l'obligation de motifs sourcés, les réserves codées, les cas où l'on ne tranche pas.
---

# Formuler une recommandation

La recommandation est ce que tu ferais à la place du conseiller, avec tes motifs. **Ce n'est pas la décision** : le
conseiller décide, et peut décider autrement.

## Les quatre positions

| Position | Quand |
| --- | --- |
| `FAVORABLE` | tous les verdicts `DANS_LA_NORME`, aucun doute ouvert, dossier complet |
| `FAVORABLE_SOUS_RESERVES` | au moins un `HORS_NORME` dérogeable, un `CAS_NON_COUVERT`, une pièce manquante ou un doute non bloquant : **chacun devient une réserve** |
| `DEFAVORABLE` | un `HORS_NORME` non dérogeable (incident en cours), ou un taux d'effort au-delà de 45 % même avec tous les revenus |
| `NE_SE_PRONONCE_PAS` | un doute bloquant sur un revenu ou une charge empêche tout calcul fiable (aucune fiche de paie d'un salarié ; aucun revenu retenu, par exemple un seul emprunteur en CDD récent) |

Tu ne peux pas poser `FAVORABLE` ni `DEFAVORABLE` tant qu'il reste un `CAS_NON_COUVERT` ou un doute bloquant : le programme le
refuse (`TRANCHE_MALGRE_RESERVE`).

## Les motifs

Au moins un, chacun lié à une source : un fait (`{"type": "fait", "nom": "apport"}`), un résultat de calcul
(`{"type": "calcul", "nom": "taux_effort"}`) ou une règle de la grille (`{"type": "verdict", "nom": "SEUIL_INDEPENDANT"}`).
Un motif sans source est refusé. Trois à cinq motifs suffisent : le taux d'effort, le reste à vivre, l'apport, la stabilité
des revenus, et ce qui fait réserve.

**Le score de la banque n'est jamais un motif**, ni par sa source (`score_eligibilite`), ni dans le texte du motif : le
programme refuse (`SCORE_NON_DECISIONNEL`). Il a sa place dans la synthèse, avec ses limites ; la recommandation repose sur
les faits, les calculs et la grille.

## Les réserves (codes en majuscules)

| Code | Quand |
| --- | --- |
| `REVENUS_NON_COUVERTS` | un revenu retenu sort de la règle standard (indépendant de moins de deux exercices, CDI récent, pension récente) |
| `PIECE_MANQUANTE` | une pièce demandée au client n'est pas encore reçue |
| `ECART_SALAIRE_A_CONFIRMER` | le net payé et les virements reçus divergent, ou l'avis d'imposition s'écarte des fiches de paie de plus de 10 % : explication à confirmer |
| `HORS_NORME_<règle>` | un verdict `HORS_NORME` dérogeable (ex. `HORS_NORME_HCSF_TAUX_EFFORT`) |
| `INCIDENT_REGULARISE` | un incident ancien, régularisé |

Chaque réserve a un texte d'une phrase. Les `conditions` disent ce qui doit être obtenu avant décision (« recevoir la fiche
de paie d'août », « confirmer la destination des 500 € de salaire »).

## Exemple

```json
{"position": "FAVORABLE_SOUS_RESERVES",
 "motifs": [{"texte": "Taux d'effort de 33,5 % à 25 ans, dans la norme HCSF, en retenant les revenus de Marie", "type": "calcul", "nom": "taux_effort"},
            {"texte": "Reste à vivre de 3 536 € pour deux adultes", "type": "calcul", "nom": "reste_a_vivre"},
            {"texte": "Apport de 40 000 € supérieur aux frais d'acquisition", "type": "fait", "nom": "apport"},
            {"texte": "Marie est indépendante depuis 14 mois : cas non couvert par la règle standard ; sans ses revenus le taux d'effort est de 55,7 %", "type": "verdict", "nom": "SEUIL_INDEPENDANT"}],
 "reserves": [{"code": "REVENUS_NON_COUVERTS", "texte": "Les revenus de Marie (14 mois d'activité) sortent de la règle des deux exercices."},
              {"code": "PIECE_MANQUANTE", "texte": "La fiche de paie d'août 2026 de Thomas n'a pas été reçue."},
              {"code": "ECART_SALAIRE_A_CONFIRMER", "texte": "500 € du net payé de Thomas arrivent sur le compte joint tenu ailleurs : à confirmer."}],
 "conditions": ["recevoir la fiche de paie d'août 2026 de Thomas", "décision du conseiller sur les revenus de Marie"]}
```
