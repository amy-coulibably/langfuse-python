---
titre: Se relire
description: La liste de contrôle que l'agent se passe à lui-même avant de valider un calcul ou de rendre une synthèse ; corriger et le dire.
---

# Se relire

Se relire, c'est refaire le chemin à l'envers : du résultat vers ses entrées, de la phrase vers sa source. Tu le fais
**avant** de conclure l'étape « calculer » et **avant** de déposer la synthèse. Quand tu trouves une erreur, tu la corriges et
tu le dis en une phrase (« je corrige : … ») : la correction visible vaut mieux que l'erreur cachée.

## Avant de valider les calculs (`lire_calculs`)

- Le net mensuel retenu pour chaque salarié vient-il d'un mois **sans** prime ni rappel ? Une moyenne de fiches dont l'une
  contient une prime est fausse.
- Le revenu d'un indépendant est-il la moyenne mensuelle du chiffre d'affaires **après abattement**, et non le chiffre
  d'affaires brut ni la rémunération qu'il se verse ?
- Les mensualités viennent-elles du simulateur, assurance comprise, pour le bon montant emprunté (prix + frais − apport) ?
- Les crédits en cours sont-ils comptés une fois, et seulement s'ils durent plus de six mois après le dépôt ?
- Le loyer actuel est-il bien exclu des charges (résidence principale) ?
- Le taux d'effort est-il en pourcentage (33,5), pas en ratio (0,335) ?
- Les deux taux (tous revenus / revenus couverts) existent-ils quand un revenu n'est pas couvert ?

## Avant de déposer la synthèse (`lire_dossier_travail`)

- Chaque chiffre du texte a-t-il sa ligne dans `chiffres`, avec le bon nom de fait ou de calcul ?
- Chaque doute enregistré figure-t-il dans « Questions au conseiller » ?
- Chaque pièce demandée figure-t-elle dans « Pièces manquantes » ?
- Chaque verdict de la grille figure-t-il dans « Conformité », y compris les `CAS_NON_COUVERT` ?
- Ai-je écrit un avis d'octroi quelque part dans le texte ? Si oui, je le retire : il va dans la recommandation.
- Ai-je porté un jugement sur une personne au lieu de décrire un fait ?

## Avant de déposer la recommandation

- Reste-t-il un `CAS_NON_COUVERT` ou un doute bloquant ? Alors la position est « sous réserves » ou « ne se prononce pas ».
- Chaque réserve correspond-elle à un doute, une pièce manquante ou un verdict ?
- Chaque motif a-t-il sa source ?
