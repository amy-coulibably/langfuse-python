---
titre: Les pièces d'un dossier
description: Comparer les pièces déposées à la liste des pièces attendues, repérer ce qui manque ou ne vaut pas, demander au client, continuer sans bloquer.
---

# Les pièces d'un dossier

## Ce que tu cherches

Un dossier complet, ou la liste exacte de ce qui lui manque. Une pièce manquante n'arrête pas l'analyse : on la demande,
on le signale, on poursuit avec ce que l'on a.

## Comment faire, dans l'ordre

1. `consulter_politique` avec `nom = "pieces_attendues"` : la liste de référence, par personne et par situation.
2. `lister_pieces` : l'inventaire déposé. Chaque pièce a un identifiant (`P01`…), un type, une personne, une période.
3. Construis le tableau attendu / trouvé, personne par personne :
   - **salarié** : trois fiches de paie, mois consécutifs, les trois derniers mois avant le mois de dépôt (dépôt en
     septembre : juin, juillet, août) ; un tableau d'amortissement par crédit déclaré ;
   - **indépendant** : les déclarations de chiffre d'affaires depuis le début d'activité (ou 24 mois) ;
   - **chacun** : pièce d'identité, trois mois de relevés de **tous** ses comptes (dans la banque et ailleurs), justificatif
     d'épargne ;
   - **le foyer** : les deux derniers avis d'imposition, un justificatif de domicile, le compromis.
4. Pour un doute sur la lisibilité ou la période d'une pièce, ouvre-la avec `lire_piece` (sans tout lire : la première
   page suffit pour vérifier le nom, la période, la nature).
5. Pour chaque pièce manquante ou inutilisable : `demander_piece` (pièce en clair, prénom, période `AAAA-MM`, motif en une
   phrase) **et** `noter_doute` (objet : « fiche de paie de 2026-08 manquante », hypothèse : « non déposée », question pour le
   conseiller). Le dossier est alors « incomplet » : dis-le dans ton résumé.
6. Ne demande pas une pièce qui est là sous un autre nom : le relevé d'un compte joint tenu dans une autre banque est bien
   un relevé de compte ; un relevé d'épargne vaut justificatif d'épargne.

## Ce qui n'est pas un manque

- Un tableau d'amortissement n'est attendu que pour un crédit **déclaré** par le client ; s'il n'y a pas de crédit déclaré
  pour une personne, il n'y a rien à demander.
- Un justificatif de domicile du mois précédant le dépôt (quittance d'août pour un dépôt en septembre) est valable.
- Un relevé d'épargne vaut justificatif d'épargne ; le relevé d'un compte tenu ailleurs vaut relevé de compte.
- Les avis d'imposition émis l'année du dépôt et l'année précédente sont bien « les deux derniers ».

## Pièges connus

- Deux fiches de paie sur trois : il en manque une, même si les deux présentes suffisent à lire le salaire.
- Une pièce fournie pour une personne et pas pour l'autre (identité, relevés).
- Une pièce hors période (fiche de paie de plus de trois mois, quittance de plus de trois mois, avis d'imposition trop ancien :
  si les avis fournis sont ceux d'il y a deux et trois ans, le dernier avis manque). Une pièce hors période se demande au client
  comme une pièce manquante (`demander_piece`) et se note en doute.
- Aucune fiche de paie pour un salarié : son revenu ne peut pas être établi, même si ses relevés montrent des virements de salaire.
  C'est un doute **bloquant** (`bloquant: true`) : la recommandation sera `NE_SE_PRONONCE_PAS`.
- Une pièce **scannée ou photographiée** : `lire_piece` répond `TEXTE_ABSENT` ou `FORMAT_NON_LISIBLE`. Ce n'est pas une
  pièce manquante : lis-la avec `ocr_piece` (fiche « lire une pièce numérisée ») ; seule une lecture `LECTURE_INCERTAINE`
  fait d'elle une pièce à redemander (copie lisible).
- Un retraité ne fournit pas de fiches de paie mais une attestation de pension (`attestation_pension`) : c'est elle qui porte
  le montant mensuel et la date de liquidation.
- Un projet locatif s'accompagne d'une estimation locative de l'agence (`estimation_locative`) : le loyer attendu y figure.

## Exemple de fin d'étape

```json
{"resume": "Dossier presque complet : 25 pièces. Il manque la fiche de paie d'août 2026 de Thomas, demandée au client ; l'analyse se poursuit avec juin et juillet.",
 "points_cles": ["identités, avis 2025 et 2026, compromis, quittance : présents", "relevés juin-août des quatre comptes présents, dont le compte joint tenu au Crédit Fictif", "fiches de paie de Thomas : juin et juillet seulement"],
 "doutes": ["fiche de paie d'août 2026 de Thomas manquante"], "bloquant": false}
```
