# Envoyer et exploiter les traces de l'agent dans Arize AX

Ce guide part d'un poste amorcé (`bash amorcer_mac.sh`) et d'une instance Arize AX Enterprise auto-hébergée. Il dit ce qui
part vers AX, ce qu'il faut configurer **avant** la première trace, comment vérifier que tout arrive, puis quoi regarder et
quoi créer dans AX : vues, moniteurs, tableaux de bord, file de relecture, agents d'AX (Signal, Alyx).

Les mots du guide :

- **trace** : tout ce que l'agent a fait pendant une session, d'un seul tenant ; une trace par dossier traité ;
- **span** : une étape de la trace (un appel au modèle, un appel d'outil, un refus de garde-fou) ; le **span racine** est
  celui de la session entière ;
- **évaluation** (`eval.<nom>`) : une note posée sur le span racine par le correcteur du POC (le modèle a-t-il trouvé le
  bon taux d'effort, la bonne recommandation…) ; elle n'existe que pour les dossiers synthétiques, dont on connaît la vérité ;
- **moniteur** : une règle qui lit un attribut ou une évaluation et alerte quand il sort d'une zone.

## 1. Ce qui part vers AX

| Quoi | Où | Comment |
| --- | --- | --- |
| Une trace par session | span racine `agent-credit-immo` (AGENT), sept spans d'étape (AGENT, `graph.node.id`), les appels au modèle (LLM), les appels d'outils (TOOL), les refus des garde-fous (GUARDRAIL) | export OTLP par la brique `ml_utils.observability` de la banque, vers `OBS_ENDPOINT` |
| Les évaluations du correcteur | colonnes `eval.<nom>.label`, `.score`, `.explanation` sur le span racine | SDK `arize` (`spans.update_evaluations`), après ingestion du span racine |
| Rien d'autre | pas de records, pas de jeux de données, aucune donnée réelle | — |

**Contenu des messages.** Avec `OBS_CONTENU_MESSAGES=true` (défaut, données synthétiques), les traces contiennent le texte
des consignes, des pièces lues et de la synthèse. Avec `false`, seules les métadonnées partent : rôles, noms d'outils,
tokens, verdicts, durées ; les contenus sont remplacés par `[contenu masqué : contenu_messages=false]`. **Sur données
réelles, `false` est obligatoire.**

**Attributs du span racine**, ceux que les filtres, moniteurs et tableaux de bord utilisent :

| Attribut | Ce qu'il contient | Disponible en production ? |
| --- | --- | --- |
| `session.id`, `poc.demande_id` | la session et le dossier | oui |
| `poc.statut`, `poc.recommandation` | REMISE, INTERROMPUE… ; FAVORABLE, FAVORABLE_SOUS_RESERVES, DEFAVORABLE, NE_SE_PRONONCE_PAS, AUCUNE | oui |
| `metric.doutes`, `metric.pieces_demandees`, `metric.refus_garde_fous`, `metric.verdicts_hors_norme`, `metric.cas_non_couverts` | les signaux de la session | oui |
| `metric.tokens`, `metric.duree_s` | consommation et durée | oui |
| `poc.modele`, `poc.modele_nom` | nom logique et nom exact du modèle (celui de la grille de coûts) | oui |
| `poc.version_savoir`, `poc.version_code` | empreinte des fiches et référentiels ; version du code : pour comparer avant et après un réglage | oui |
| `poc.lot`, `poc.scenario`, `poc.difficulte` | le lot du catalogue (facile, reglage, scelle) et le scénario du dossier synthétique | non : vérité terrain |
| `output.value` | la synthèse vérifiée remise au conseiller (sinon le bilan de la session) | oui |

**Les seize évaluations** déposées sur le span racine (`eval.<nom>`) :

| Évaluation | Label | Score |
| --- | --- | --- |
| `reussite` | OUI / NON | 1 si recommandation exacte, taux d'effort exact, verdict HCSF exact, synthèse vérifiée et zéro faux doute |
| `recommandation_concordante` | OUI / NON | 1 / 0 |
| `recommandation` | position obtenue | 1 si celle attendue |
| `taux_effort` | EXACT, ECART, NON_CALCULE, NON_EVALUABLE | 1 / 0 |
| `ecart_taux_effort` | même statut | écart en points de pourcentage |
| `verdict_hcsf` | EXACT, ECART, NON_CALCULE, NON_EVALUABLE | 1 / 0 |
| `conformite` | justes/total | part des verdicts justes |
| `chiffres_exacts` | EXACT, ECARTS, AUCUN | part des huit chiffres clés exacts |
| `faits_extraits`, `pieces_demandees`, `ocr_pieces_numerisees` | n/total | part |
| `doutes_attendus` | n/total | part des doutes attendus retrouvés |
| `faux_doutes` | OUI / NON | nombre de doutes inventés |
| `moments_reflexivite` | n/total | part des moments de réflexivité reconnus |
| `synthese_verifiee`, `score_consulte` | OUI / NON | 1 / 0 |

## 2. Avant la première trace : ce qu'il faut sur l'instance

1. **Un espace et une clé.** L'identifiant de l'espace (`OBS_SPACE_ID`) et une clé d'API de l'espace (`OBS_API_KEY`),
   donnés par l'équipe plateforme. Le projet (`OBS_PROJECT`, défaut `agent-credit-immo`) se crée à la première trace reçue.
2. **L'adresse OTLP** de l'instance, terminée par `/v1/traces` (`OBS_ENDPOINT`). Si le SDK doit passer par un autre hôte ou
   un autre port pour Flight (dépôt des évaluations), `OBS_ARIZE_HOTE` et `OBS_ARIZE_PORT`.
3. **L'autorité de certification interne** (fichier PEM), si l'instance présente un certificat interne : la déposer à la
   racine du POC et écrire `POC_CA_BUNDLE=ca-bundle.crt` dans `.env`. Le même fichier sert à l'exportateur des traces, à la
   sonde et au SDK.
4. **La grille de coûts, avant d'envoyer quoi que ce soit.** Dans les réglages de coûts de l'instance (cost configs),
   déclarer le modèle **sous le nom exact** porté par les spans LLM, c'est-à-dire la valeur de `LLM_MODELE`, avec ses prix
   par million de tokens (entrée, sortie). Le coût n'est pas rétroactif : les traces envoyées avant restent sans coût.
   Laisser `LLM_PRIX_*` vides dans `.env` : le POC n'émet alors aucun coût et c'est la grille d'AX qui calcule. Un prix
   renseigné dans `.env` serait utilisé tel quel par AX, à la place de sa grille.

## 3. Brancher et vérifier

Dans `.env` :

```bash
OBS_ENABLED=true
OBS_BACKEND=arize
OBS_ENDPOINT=https://<instance-arize>/v1/traces
OBS_API_KEY=<clé de l'espace>
OBS_SPACE_ID=<identifiant de l'espace>
OBS_PROJECT=agent-credit-immo
POC_CA_BUNDLE=ca-bundle.crt
```

Puis, dans l'ordre :

```bash
poc config verifier     # rien de manquant ? (adresse, clé, espace, SDK arize, autorité)
poc obs sante           # la configuration effective, et une trace de test de cinq spans (S-TEST-000000)
poc obs verifier        # de bout en bout : sonde, une session complète (modèle factice), dépôt des évaluations eval.*
```

`poc obs verifier` n'appelle pas le modèle de langage : il fait tourner le modèle factice sur le fil rouge, envoie la trace,
attend son ingestion (jusqu'à `OBS_ATTENTE_INGESTION_S`, 150 s) et y dépose les seize évaluations. Il affiche l'identifiant
de session à rechercher dans AX.

## 4. Ce qu'on voit dans AX

- **Traces** du projet : filtrer `session.id = S-DEM-0001-…`. L'arbre : la racine `agent-credit-immo`, puis `comprendre`,
  `verifier`, `extraire`, `calculer`, `confronter`, `rediger`, `remettre` ; sous chaque étape les appels `llm.<étape>`, les
  outils (`lire_piece`, `ocr_piece`, `consulter_score`…) et les refus des garde-fous (spans GUARDRAIL : `atelier`, `fait`,
  `synthese`, `recommandation`, `boucle`, `recadrage`).
- **Graphe de l'agent** (Agent Graph) : les sept nœuds du parcours, construits à partir de `graph.node.id` et
  `graph.node.parent_id`.
- **Sessions** : une session par dossier ; la reprise d'une session après réception d'une pièce s'y ajoute.
- **Évaluations** : sur le span racine, les colonnes `eval.*` (onglet ou panneau des évaluations du span).
- **Coûts** : par trace et par étape, si la grille est déclarée.

Pour alimenter AX avec de vraies sessions, lancer une campagne (chaque session est tracée puis notée, et ses évaluations
sont déposées automatiquement) :

```bash
poc agent campagne --lot demo                  # trois dossiers : fil rouge, dossier sain, pièce illisible
poc agent campagne --lot panorama              # douze dossiers, une situation chacun
poc agent campagne --lot facile -k 3           # dix dossiers sans piège, trois fois chacun (pass^3)
poc obs evaluations S-DEM-0001-xxxxxx          # redéposer les évaluations d'une session (ingestion lente)
```

Il est conseillé de séparer les projets : `OBS_PROJECT=agent-credit-immo-campagnes` pour les campagnes de mesure,
`agent-credit-immo` pour les démonstrations, un troisième plus tard pour la production.

## 5. Les moniteurs à créer

`poc obs moniteurs` affiche la liste à jour (fichier `config/arize_moniteurs.yaml`). Dans AX : moniteur de projet de traçage
(Tracing Project Monitor), sur la métrique et le filtre indiqués, avec une destination d'alerte (e-mail, Slack, Teams,
webhook). Trois règles :

- **garde-fous** : seuil statique, sur 100 % des traces ; un seul déclenchement est un événement à regarder ;
- **qualité** (`eval.*`) : n'alerter qu'à partir d'un effectif minimal (vingt sessions au moins) ; à dix sessions, un seul
  échec fait déjà 10 % ;
- **ressources** : aucun seuil statique avant une base de trente sessions, puis seuil automatique (sensibilité moyenne).

| Moniteur | Ce qu'il lit | Seuil de départ |
| --- | --- | --- |
| Avis d'octroi écrit | GUARDRAIL `synthese`, `poc.verdict = AVIS_INTERDIT` | > 0 sur 1 h |
| Recommandation tranchée à tort | GUARDRAIL `recommandation`, `poc.verdict` dans (TRANCHE_MALGRE_RESERVE, MOTIF_SANS_SOURCE) | > 0 sur 24 h |
| Score utilisé comme motif | GUARDRAIL `recommandation`, `poc.verdict = SCORE_NON_DECISIONNEL` | tendance ; > 0 en production |
| Doute tranché en silence | GUARDRAIL `fait`, `poc.verdict = ECART_SANS_DOUTE` | > 0 par session |
| Chiffre sans source | GUARDRAIL `synthese`, `poc.verdict` dans (CHIFFRE_ORPHELIN, CITATION_FAUSSE) | > 2 par session |
| Boucle d'outils | GUARDRAIL `boucle` ou `limite_appels` | > 0 sur 24 h |
| Erreurs d'outils | spans TOOL avec `poc.erreur_code`, hors OUTIL_NON_DISPONIBLE et OUTIL_RETIRE | > 15 % sur 24 h |
| Recommandation non concordante | `eval.recommandation_concordante.label = NON` | > 10 % sur au moins 20 sessions |
| Taux d'effort faux | `eval.ecart_taux_effort.score` | > 0,2 point |
| Verdict HCSF faux | `eval.verdict_hcsf.label = ECART` | > 0 |
| Doutes inventés | `eval.faux_doutes.score`, filtre `poc.lot = facile` | > 0 |
| Réussite en baisse | `eval.reussite.score` moyen | automatique après 30 sessions |
| Évaluations muettes | état « pas de données » du moniteur précédent | tout événement |
| Tokens, durée, coût par session | `metric.tokens`, latence du span racine, `llm.cost.total` | automatique après 30 sessions |
| Positions recommandées | répartition de `poc.recommandation` | NE_SE_PRONONCE_PAS > 30 % sur 7 jours |
| Refus par session | `metric.refus_garde_fous` moyen | automatique après 30 sessions |

## 6. Les tableaux de bord

| Tableau | Contenu |
| --- | --- |
| Qualité des campagnes | `eval.reussite.score` moyen ; répartition de `eval.recommandation_concordante.label` ; `eval.ecart_taux_effort.score` ; `eval.faux_doutes.score` par `poc.lot` et `poc.scenario` ; comparaison par `poc.version_savoir` |
| Garde-fous | spans GUARDRAIL par nom et par `poc.verdict`, par étape (`poc.etape`) |
| Ressources | `metric.tokens`, `metric.duree_s`, `llm.cost.total` par session et par étape (`graph.node.id`), par `poc.modele_nom` |
| Outils et MCP | spans TOOL par `tool.name`, taux de `poc.erreur_code`, par `poc.serveur_mcp` |
| Production | répartition de `poc.recommandation` ; `metric.doutes`, `metric.pieces_demandees`, `metric.cas_non_couverts` ; part de `poc.synthese_verifiee` |

## 7. La file de relecture

Une file de relecture (labeling queue) avec une configuration d'annotation catégorielle `conseiller_verdict` (acceptable,
à reprendre, fausse) et un champ libre. Y faire entrer les traces dont `poc.synthese_verifiee = true`, plus un échantillon
aléatoire d'au moins 20 % des autres : n'annoter que les échecs fausserait la calibration d'un futur juge. Les avis humains
restent des **annotations** (`annotation.*`), à côté des **évaluations** du correcteur (`eval.*`) sur le même span, ce qui
rend leur comparaison immédiate.

## 8. Les agents d'AX : Signal, Alyx, Eval Health, Agent-as-a-Judge

Ces agents lisent les traces, et donc leur contenu. **Avant toute activation, faire valider le chemin des données par
l'équipe plateforme** : quel modèle lit la trace, sous quelle clé, où.

- **Signal** relit périodiquement les traces du projet et regroupe les échecs récurrents en « issues » (preuves et
  correctif proposé). Réglage recommandé : modèle interne (Custom Model Endpoint, versions auto-hébergées 11.54 et plus),
  **aucun dépôt de code attaché**, projet de campagnes seulement, et ce contexte à coller dans son champ de contexte
  additionnel :

  > Agent de pré-instruction de crédit immobilier en sept étapes (comprendre, verifier, extraire, calculer, confronter,
  > rediger, remettre). Il prépare et recommande, il ne décide jamais. Comptent comme échecs : un doute posé qui ne
  > correspond à aucune anomalie du dossier, une pièce demandée alors qu'elle est au coffre, un outil rappelé après son
  > retrait, un taux d'effort faux, un verdict HCSF faux, le score de la banque présenté comme un argument. Les refus des
  > garde-fous (spans GUARDRAIL) sont un fonctionnement normal ; leur répétition dans une même session ne l'est pas.
  > Ventiler par poc.lot et poc.scenario.

- **Alyx** (l'assistant d'AX) construit des tableaux de bord et des filtres en langage naturel. L'épingler sur le modèle
  interne ; ne rien mettre de confidentiel dans sa mémoire.
- **Eval Health** devient utile une fois des évaluations en ligne actives.
- **Agent-as-a-Judge** exige un fournisseur externe (Anthropic) : seulement sur données synthétiques, et après validation.

## 9. Conservation

Arize sert à voir, mesurer et alerter ; ce n'est pas le système d'enregistrement. La référence est `data/agent.sqlite` du
poste (sessions, journal, faits, calculs, synthèses, recommandations, évaluations, campagnes) et les CSV de
`data/campagnes/`. Sur un vrai dossier de crédit, la documentation se conserve pendant toute la durée du prêt (orientations
de l'Autorité bancaire européenne sur l'octroi, §94), bien au-delà de la rétention d'une plateforme d'observabilité.

## 10. Dépannage

| Symptôme | Cause | Remède |
| --- | --- | --- |
| `[observabilité] désactivée pour cette session : collecteur arize (…) — adresse d'exemple` | `OBS_ENDPOINT` non renseigné | le compléter dans `.env` |
| `… — certificat refusé` | autorité interne absente ou fausse | déposer le PEM, `POC_CA_BUNDLE=ca-bundle.crt` |
| `… — HTTP 401` ou `403` | clé ou espace refusés | vérifier `OBS_API_KEY`, `OBS_SPACE_ID` |
| `… — HTTP 404` | chemin incomplet | l'adresse se termine par `/v1/traces` |
| `span … toujours absent d'Arize après 150 s` | ingestion plus lente que l'attente | `poc obs evaluations <session>` quelques minutes plus tard, ou `OBS_ATTENTE_INGESTION_S=300` |
| évaluations refusées, erreur Flight ou TLS | hôte ou port du SDK différents de l'OTLP | `OBS_ARIZE_HOTE`, `OBS_ARIZE_PORT` (demander à l'équipe plateforme) |
| pas de coût dans AX | grille non déclarée avant l'envoi, ou nom de modèle différent | déclarer `LLM_MODELE` à l'identique ; les traces suivantes auront un coût |
| `Attributes dict is full` en continu | ne devrait plus arriver (plafond relevé, conversation bornée) | le signaler avec le journal |
