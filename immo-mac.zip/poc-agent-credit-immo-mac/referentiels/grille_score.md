---
titre: La grille du score d'éligibilité de la banque
description: Le score interne préliminaire, critère par critère, ce qu'il voit et ce qu'il ne voit pas. Grille inventée pour le POC ; un indicateur consultatif, jamais une règle.
---

# La grille du score d'éligibilité de la banque

**Grille inventée pour le POC.** Aucun modèle statistique, aucune donnée réelle : une addition de points, que l'on peut
refaire à la main. Le score s'appelle par l'API `api-scoring` (outil `consulter_score`).

**C'est un indicateur, pas une règle.** Il ne figure pas dans la politique de crédit et ne décide de rien. L'agent le
consulte, le restitue avec ses limites, et ne s'en sert jamais comme motif de sa recommandation : le programme refuse
une recommandation dont un motif est le score (`SCORE_NON_DECISIONNEL`). La décision appartient au conseiller.

## Ce que le score regarde

Le score ne lit **aucune pièce**. Il ne voit que le système d'information de la banque : la demande, les fiches clients,
les comptes tenus **dans la banque** et leurs mouvements des trois mois avant le dépôt, les crédits déclarés, le fichier
d'incidents.

| Critère | Ce que la banque voit | Points |
| --- | --- | --- |
| Taux d'endettement estimé | (mensualité du barème à la durée demandée, assurance comprise, + mensualités des crédits déclarés) ÷ revenus constatés | ≤ 30 % : 250 ; ≤ 33 % : 200 ; ≤ 35 % : 150 ; ≤ 40 % : 60 ; au-delà, ou aucun revenu constaté : 0 |
| Apport | apport ÷ prix du bien | ≥ 20 % : 150 ; ≥ 10 % : 110 ; ≥ frais d'acquisition : 70 ; en dessous : 0 |
| Stabilité professionnelle | situation et ancienneté de chaque emprunteur (fiche client), moyenne des emprunteurs | CDI ≥ 24 mois ou retraité : 150 ; CDI de 6 à 24 mois : 100 ; indépendant ≥ 24 mois : 100 ; CDD ≥ 36 mois : 80 ; sinon : 30 |
| Ancienneté dans la banque | le client le plus ancien du foyer | ≥ 5 ans : 100 ; ≥ 2 ans : 60 ; sinon : 20 |
| Incidents | fichier d'incidents, pour chaque emprunteur | aucun : 150 ; régularisé : 60 ; en cours : 0, et le score total est plafonné à 399 (classe E) |
| Tenue de compte | mouvements des comptes de la banque : commission d'intervention, rejet, paris en ligne | aucun signal : 200 ; un signal ou plus : 0 |

Les **revenus constatés** sont la moyenne mensuelle des virements reçus sur les comptes de la banque dont le libellé
contient SALAIRE, PENSION ou REMUNERATION, sur les trois mois avant le dépôt.

Total sur 1 000. Classes : **A** ≥ 850 ; **B** ≥ 700 ; **C** ≥ 550 ; **D** ≥ 400 ; **E** en dessous.

## Ce que le score ne voit pas (et que l'analyse voit)

- **Les comptes tenus ailleurs** : un salaire versé en partie sur un compte d'une autre banque fait baisser les revenus
  constatés ; le score ne le sait pas.
- **Les éléments exceptionnels** : une prime annuelle versée dans les trois mois fait monter les revenus constatés.
- **Les règles de la politique** : un indépendant de moins de deux exercices, un CDD de moins de trois ans, une pension
  récente sont des cas non couverts pour l'analyse ; le score les compte avec quelques points de moins, sans plus.
- **Les loyers attendus** d'un projet locatif, et le loyer actuel qui reste à payer.
- **La fin proche d'un crédit** : le score compte tous les crédits déclarés, même celui qui se termine dans quatre mois.
- **Les pièces** : une fiche de paie manquante, un avis d'imposition en écart, une pièce illisible ; aucun doute du
  dossier n'entre dans le score.

## Comment l'agent s'en sert

1. Il consulte le score à l'étape « confronter », comme il consulte le fichier d'incidents.
2. Il le restitue dans la synthèse, dans une section « indicateurs de la banque », avec la classe et ce que le score ne
   voit pas sur ce dossier.
3. Quand le score et l'analyse divergent nettement (un A sur un dossier qui a une réserve ; un A ou un B sur un dossier
   défavorable ou sur lequel il ne peut pas se prononcer ; un D ou un E sur un dossier sain), il le dit et explique
   pourquoi : c'est le moment où l'on comprend que le score ne remplace pas l'analyse.
4. Il ne cite jamais le score comme motif de sa recommandation.

## Note réglementaire

Évaluer la solvabilité d'une personne physique par un système automatisé est un cas « à haut risque » du règlement
européen sur l'intelligence artificielle. Sur données synthétiques, avec un humain qui décide et un score consultatif, le
POC n'est pas concerné ; un vrai score d'octroi branché sur un vrai agent ferait basculer l'ensemble dans ce régime.
