---
titre: Les pièces attendues dans un dossier de prêt immobilier
description: La liste des pièces à fournir, par personne et par situation, et ce qui rend une pièce inutilisable.
---

# Les pièces attendues dans un dossier de prêt immobilier

Liste usuelle des banques françaises, adaptée au POC. Chaque emprunteur fournit ses propres pièces ; les pièces du foyer
(avis d'imposition commun, compromis) ne sont fournies qu'une fois.

## Pour chaque emprunteur

| Type de pièce (code) | Nombre et période | Pourquoi |
| --- | --- | --- |
| Pièce d'identité (`identite`) | 1, en cours de validité | identité, âge (assurance) |
| Fiches de paie (`fiche_paie`) — salariés | les **3 dernières**, mois consécutifs jusqu'au mois précédant le dépôt | revenus retenus, primes, ancienneté |
| Déclarations de chiffre d'affaires (`declaration_ca`) — indépendants | les 24 derniers mois (ou depuis le début d'activité) | revenus d'indépendant |
| Relevés de comptes (`releve_compte`) | les **3 derniers mois** de **tous** les comptes courants, dans cette banque et ailleurs | recoupement des revenus, charges récurrentes, crédits non déclarés, signaux d'alerte |
| Tableau d'amortissement (`tableau_amortissement`) | 1 par crédit en cours | mensualité et date de fin |

## Pour le foyer

| Type de pièce (code) | Nombre et période | Pourquoi |
| --- | --- | --- |
| Avis d'imposition (`avis_imposition`) | les **2 derniers** | revenus annuels, parts, cohérence avec les fiches de paie |
| Justificatif de domicile (`justificatif_domicile`) | 1, de moins de 3 mois | adresse, loyer actuel |
| Compromis de vente (`compromis`) | 1, signé, avec condition suspensive d'obtention du prêt | prix, bien, délai |
| Justificatif d'épargne (`justificatif_epargne`) | dernier relevé de chaque livret ou contrat | apport |

## Ce qui rend une pièce inutilisable

- **Hors période** : une fiche de paie ou un relevé de plus de trois mois avant le dépôt ; un avis d'imposition qui n'est pas l'un des deux derniers.
- **Illisible** : un scan dont les chiffres ne se lisent pas avec certitude (l'OCR donne une confiance faible).
- **Incomplète** : une fiche de paie sans net payé, un relevé sans solde, un compromis sans condition suspensive.
- **Pas au bon nom** : une pièce qui ne concerne aucun emprunteur du dossier.

## Quand une pièce manque

On ne bloque pas : on demande la pièce au client (`demander_piece`), on marque le dossier « incomplet » et on poursuit
l'analyse avec ce que l'on a, en le signalant dans la synthèse.
