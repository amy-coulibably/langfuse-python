---
titre: La norme HCSF d'octroi des crédits immobiliers
description: Les plafonds nationaux (taux d'effort, durée) et la marge de dérogation, en termes simples. Seule règle réelle du POC, vérifiée le 15 septembre 2026.
---

# La norme HCSF d'octroi des crédits immobiliers

**Règle réelle** (à la différence de la politique de crédit maison, inventée pour le POC). Le Haut Conseil de stabilité
financière fixe les conditions que les banques françaises doivent respecter pour accorder un crédit immobilier. Dernière
vérification : réunion du HCSF du 15 septembre 2026, règles maintenues sans changement.

## Les deux plafonds

| Critère | Plafond | Précision |
| --- | --- | --- |
| **Taux d'effort** | 35 % des revenus nets du foyer | assurance emprunteur comprise ; toutes les mensualités de crédit du foyer sont comptées |
| **Durée du prêt** | 25 ans | jusqu'à 27 ans quand il y a un différé d'amortissement lié à des travaux importants (au moins 10 % du coût de l'opération) ou à un achat sur plan |

## La marge de dérogation

La banque peut s'écarter de ces plafonds pour une part limitée de sa production de crédits (20 % par trimestre), en
priorité pour les résidences principales et les primo-accédants. **Cette décision appartient à la banque, jamais à
l'agent** : l'agent constate qu'un dossier sort de la norme et le signale ; il ne décide pas d'une dérogation.

## Comment l'agent l'applique

- Taux d'effort ≤ 35 % : `DANS_LA_NORME` ; > 35 % : `HORS_NORME` (dérogeable par la banque, à signaler).
- Durée demandée ≤ 25 ans : `DANS_LA_NORME` ; > 25 ans : `HORS_NORME` sauf cas de différé (travaux, achat sur plan).
- Les revenus pris en compte sont ceux que la politique de crédit maison retient (voir cette fiche) ; la norme HCSF ne
  dit pas comment calculer les revenus, elle fixe le plafond.

## Sources

Presse et courtiers, septembre 2026 : Journal de l'Agence, Cafpi, CPIM. La décision officielle du HCSF est à relire
avant toute démonstration à un public bancaire.
