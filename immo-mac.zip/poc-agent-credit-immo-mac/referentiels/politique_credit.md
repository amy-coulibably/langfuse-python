---
titre: La politique de crédit maison
description: Les règles internes de la banque fictive du POC pour retenir les revenus, les charges, et juger un dossier. Règles inventées pour le POC.
---

# La politique de crédit maison

**Règles inventées pour le POC.** Elles ressemblent à ce qu'une banque fait, sans être celles d'une banque réelle. Chaque
règle a un code : c'est lui que l'agent utilise dans sa grille de conformité.

## Les revenus que l'on retient (par mois)

| Code | Règle |
| --- | --- |
| `REV_SALAIRE` | Salarié : le **net payé** mensuel (ce qui arrive sur le compte), moyenne des trois dernières fiches de paie **après avoir retiré les éléments exceptionnels** (prime annuelle, rappel, indemnité). Une prime annuelle régulière peut être ajoutée pour un douzième, à condition qu'elle figure sur deux avis d'imposition. |
| `REV_INDEPENDANT` | Indépendant (auto-entrepreneur, profession libérale) : moyenne mensuelle du chiffre d'affaires des **deux derniers exercices complets**, après l'abattement forfaitaire de son régime (34 % pour un micro-BNC, 50 % pour un micro-BIC services, 71 % pour la vente). **En dessous de deux exercices complets, le cas n'est pas couvert par la règle standard** : l'agent calcule le taux d'effort avec et sans ces revenus, et renvoie la décision au conseiller. |
| `REV_LOCATIF` | Loyers perçus : retenus à 70 % (vacance et charges). |
| `REV_PENSION` | Pensions et rentes : retenues en totalité si elles ont plus de deux ans d'ancienneté. |
| `REV_EXCLUS` | Non retenus : allocations familiales, primes exceptionnelles, heures supplémentaires non récurrentes, revenus d'un CDD de moins de trois ans d'ancienneté. |

## Les charges que l'on retient (par mois)

| Code | Règle |
| --- | --- |
| `CHG_CREDITS` | Toutes les mensualités des crédits en cours (consommation, auto, renouvelable), sauf si le crédit se termine dans moins de six mois après la date de dépôt. |
| `CHG_PENSIONS` | Pensions alimentaires versées. |
| `CHG_LOYER` | Le loyer actuel **n'est pas** compté quand le projet est une résidence principale (il disparaît à l'achat). |
| `CHG_NOUVEAU_PRET` | La mensualité du nouveau prêt, **assurance comprise**, au taux du barème pour la durée demandée. |

## Les seuils maison

| Code | Règle | Verdict si non respecté |
| --- | --- | --- |
| `SEUIL_RESTE_A_VIVRE` | Reste à vivre (revenus retenus − charges retenues) ≥ 1 000 € par adulte + 400 € par enfant | `HORS_NORME` |
| `SEUIL_APPORT` | Apport ≥ frais d'acquisition (notaire) ; les honoraires d'agence inclus dans le prix sont finançables | `HORS_NORME` |
| `SEUIL_CDI` | Un salarié en CDI doit avoir terminé sa période d'essai ; en CDI depuis moins de six mois : `CAS_NON_COUVERT` | `CAS_NON_COUVERT` |
| `SEUIL_INDEPENDANT` | Indépendant : deux exercices complets ; en dessous : `CAS_NON_COUVERT` (voir `REV_INDEPENDANT`) | `CAS_NON_COUVERT` |
| `SEUIL_PENSION` | Retraité : pension liquidée depuis plus de deux ans ; en dessous : `CAS_NON_COUVERT` (voir `REV_PENSION`) | `CAS_NON_COUVERT` |
| `SEUIL_INCIDENTS` | Aucun incident en cours au fichier d'incidents ; un incident régularisé depuis plus de deux ans est signalé, pas bloquant | `HORS_NORME` si incident en cours |
| `SEUIL_COMPTE` | Pas de découvert non autorisé répété (plus d'un mois sur trois), pas de rejet de prélèvement sur les trois derniers mois | `HORS_NORME` |

## Les trois verdicts possibles

- `DANS_LA_NORME` : la règle s'applique et elle est respectée.
- `HORS_NORME` : la règle s'applique et elle n'est pas respectée (la banque peut déroger ; ce n'est pas à l'agent de le décider).
- `CAS_NON_COUVERT` : une condition d'application de la règle n'est pas remplie ; l'agent décrit, il ne tranche pas.

## Ce qui fonde une recommandation

| Position | Quand |
| --- | --- |
| `FAVORABLE` | tous les verdicts `DANS_LA_NORME`, aucun doute ouvert, dossier complet |
| `FAVORABLE_SOUS_RESERVES` | au moins un `HORS_NORME` dérogeable, un `CAS_NON_COUVERT`, une pièce manquante ou un doute non bloquant : chacun devient une réserve |
| `DEFAVORABLE` | un `HORS_NORME` non dérogeable (incident en cours, taux d'effort au-delà de 45 % même avec tous les revenus) |
| `NE_SE_PRONONCE_PAS` | un doute bloquant sur un revenu ou une charge empêche tout calcul fiable (par exemple : aucune fiche de paie d'un salarié, aucun revenu retenu) |

La décision appartient au conseiller.
