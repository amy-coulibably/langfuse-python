# Les référentiels

Les règles et barèmes que l'agent consulte, en texte lisible par tous. Ils sont écrits à la main et versionnés : changer
une règle, c'est changer un fichier, pas du code. Le générateur de données (vérité terrain) lit les mêmes fichiers, pour
que « ce qui est vrai » et « ce que l'agent doit appliquer » viennent d'une seule source.

| Fichier | Contenu | Réel ou inventé |
| --- | --- | --- |
| `norme_hcsf.md` | Les plafonds nationaux d'octroi (35 %, 25 ans, marge de dérogation) | **Réel**, vérifié le 15 septembre 2026 |
| `politique_credit.md` | Les règles internes de la banque fictive : revenus retenus, charges, seuils, verdicts, recommandation | Inventé pour le POC |
| `pieces_attendues.md` | La liste des pièces par personne et par situation | Usuel, adapté |
| `grille_score.md` | La grille du score d'éligibilité de la banque (api-scoring) : critères, points, ce qu'il ne voit pas | Inventé pour le POC |
| `bareme_taux.csv` | Taux nominal par durée | Inventé pour le POC |
| `assurance.csv` | Taux d'assurance emprunteur par tranche d'âge | Inventé pour le POC |
| `frais_notaire.csv` | Frais d'acquisition par type de bien | Ordre de grandeur usuel |
