#!/usr/bin/env bash
# =====================================================================================================================
# Amorçage du POC « agent de pré-instruction crédit immobilier » sur Mac (Apple Silicon ou Intel), Python 3.11 à 3.13.
#
#   bash amorcer_mac.sh                 tout : Python, environnement, dépendances, OCR, .env, données, contrôles, tests
#   bash amorcer_mac.sh --sans-tests    sans la suite de tests (environ trois minutes de moins)
#   bash amorcer_mac.sh --sans-brew     ne pas installer Tesseract (OCR) avec Homebrew
#   bash amorcer_mac.sh --recreer       recrée l'environnement virtuel .venv
#   bash amorcer_mac.sh --regenerer     régénère les données synthétiques même si elles existent
#   bash amorcer_mac.sh --hors-ligne    n'appelle ni la passerelle LLM ni Arize (contrôles locaux seulement)
#   PYTHON=/chemin/vers/python3.12 bash amorcer_mac.sh     interpréteur imposé
#
# Rejouable sans risque : chaque étape regarde ce qui est déjà fait. Journal complet : amorcage.log.
# Après le premier passage : compléter .env (passerelle LLM, Arize AX), puis relancer ce script.
# =====================================================================================================================
set -euo pipefail

ICI="$(cd "$(dirname "$0")" && pwd)"
if [ -f "$ICI/pyproject.toml" ]; then
  RACINE="$ICI"
elif [ -f "$ICI/../../pyproject.toml" ]; then
  RACINE="$(cd "$ICI/../.." && pwd)"
else
  echo "pyproject.toml introuvable à côté de ce script : lancer amorcer_mac.sh depuis le dossier du POC." >&2
  exit 1
fi
cd "$RACINE"
JOURNAL="$RACINE/amorcage.log"
: >"$JOURNAL"
exec > >(tee -a "$JOURNAL") 2>&1

TESTS=1
BREW=1
RECREER=0
REGENERER=0
RESEAU=1
for arg in "$@"; do
  case "$arg" in
    --sans-tests) TESTS=0 ;;
    --sans-brew) BREW=0 ;;
    --recreer) RECREER=1 ;;
    --regenerer) REGENERER=1 ;;
    --hors-ligne) RESEAU=0 ;;
    -h | --help)
      sed -n '2,15p' "$0"
      exit 0
      ;;
    *)
      echo "option inconnue : $arg (voir bash amorcer_mac.sh --help)" >&2
      exit 2
      ;;
  esac
done

GRAS=$'\033[1m'
VERT=$'\033[32m'
JAUNE=$'\033[33m'
ROUGE=$'\033[31m'
FIN=$'\033[0m'
ALERTES=0
ECHECS=0
etape() { printf '\n%s== %s ==%s\n' "$GRAS" "$1" "$FIN"; }
ok() { printf '%s✓%s %s\n' "$VERT" "$FIN" "$1"; }
attention() {
  printf '%s! %s%s\n' "$JAUNE" "$1" "$FIN"
  ALERTES=$((ALERTES + 1))
}
echec() {
  printf '%s✗ %s%s\n' "$ROUGE" "$1" "$FIN" >&2
  exit 1
}

# ---------------------------------------------------------------------------------------------------------------------
etape "1/8 Système"
SYSTEME="$(uname -s)"
if [ "$SYSTEME" = "Darwin" ]; then
  ok "macOS $(sw_vers -productVersion 2>/dev/null || echo '?') sur $(uname -m)"
  if [ "$(sysctl -n sysctl.proc_translated 2>/dev/null || echo 0)" = "1" ]; then
    attention "ce terminal tourne sous Rosetta (Intel émulé) : le verrou Intel sera utilisé ; ouvrir un terminal natif pour Apple Silicon"
  fi
else
  attention "système $SYSTEME : ce script vise macOS (répétition hors Mac : imposer le verrou avec VERROU=…)"
fi

# ---------------------------------------------------------------------------------------------------------------------
etape "2/8 Python 3.11 à 3.13"
version_ok() { "$1" -c 'import sys; sys.exit(0 if (3, 11) <= sys.version_info[:2] <= (3, 13) else 1)' >/dev/null 2>&1; }
trouver_python() {
  local c
  for c in python3.13 python3.12 python3.11 \
    /opt/homebrew/bin/python3.13 /opt/homebrew/bin/python3.12 /opt/homebrew/bin/python3.11 \
    /usr/local/bin/python3.13 /usr/local/bin/python3.12 /usr/local/bin/python3.11 \
    /Library/Frameworks/Python.framework/Versions/3.13/bin/python3.13 \
    /Library/Frameworks/Python.framework/Versions/3.12/bin/python3.12 \
    /Library/Frameworks/Python.framework/Versions/3.11/bin/python3.11 \
    "$HOME"/.pyenv/versions/3.13*/bin/python "$HOME"/.pyenv/versions/3.12*/bin/python "$HOME"/.pyenv/versions/3.11*/bin/python \
    python3; do
    if command -v "$c" >/dev/null 2>&1 && version_ok "$c"; then
      command -v "$c"
      return 0
    fi
  done
  return 1
}
if [ -n "${PYTHON:-}" ]; then
  command -v "$PYTHON" >/dev/null 2>&1 || echec "PYTHON=$PYTHON introuvable"
  version_ok "$PYTHON" || echec "PYTHON=$PYTHON n'est pas un Python 3.11 à 3.13 ($("$PYTHON" --version 2>&1))"
  PY="$(command -v "$PYTHON")"
elif ! PY="$(trouver_python)"; then
  echo "Aucun Python 3.11, 3.12 ou 3.13 trouvé. python3 donne : $(python3 --version 2>&1 || echo 'absent')" >&2
  echo "Installer l'un des deux, puis relancer :" >&2
  echo "  - l'installeur officiel python.org (Python 3.13, paquet macOS) ;" >&2
  echo "  - ou Homebrew : brew install python@3.13" >&2
  echo "Ou indiquer un interpréteur : PYTHON=/chemin/vers/python3.12 bash amorcer_mac.sh" >&2
  exit 1
fi
PY_VERSION="$("$PY" -c 'import sys; print("%d.%d" % sys.version_info[:2])')"
PY_ARCH="$("$PY" -c 'import platform; print(platform.machine())')"
"$PY" -c 'import ssl, sqlite3, venv' 2>/dev/null || echec "$PY n'a pas les modules ssl, sqlite3 et venv : installer un Python complet (python.org ou Homebrew)"
ok "Python $("$PY" -c 'import platform; print(platform.python_version())') ($PY_ARCH) : $PY"

# ---------------------------------------------------------------------------------------------------------------------
etape "3/8 Environnement virtuel .venv"
VENV="$RACINE/.venv"
chemin_vpy() { if [ -x "$VENV/bin/python" ]; then echo "$VENV/bin/python"; elif [ -x "$VENV/Scripts/python.exe" ]; then echo "$VENV/Scripts/python.exe"; fi; }
if [ -n "${VIRTUAL_ENV:-}" ] && [ "$VIRTUAL_ENV" != "$VENV" ]; then
  attention "un autre environnement virtuel est actif ($VIRTUAL_ENV) : il est ignoré, le POC utilise $VENV"
fi
VPY="$(chemin_vpy)"
if [ -n "$VPY" ] && [ "$RECREER" -eq 0 ]; then
  VV="$("$VPY" -c 'import sys, platform; print("%d.%d-%s" % (sys.version_info[0], sys.version_info[1], platform.machine()))' 2>/dev/null || echo "?")"
  if [ "$VV" != "$PY_VERSION-$PY_ARCH" ]; then
    attention ".venv existant en $VV, différent de $PY_VERSION-$PY_ARCH : il est recréé"
    RECREER=1
  fi
fi
if [ "$RECREER" -eq 1 ] && [ -d "$VENV" ]; then rm -rf "$VENV"; fi
if [ -z "$(chemin_vpy)" ]; then "$PY" -m venv "$VENV"; fi
VPY="$(chemin_vpy)"
if [ -x "$VENV/bin/poc" ] || [ -d "$VENV/bin" ]; then BIN="$VENV/bin"; else BIN="$VENV/Scripts"; fi
ok "$VENV (Python $PY_VERSION)"

# ---------------------------------------------------------------------------------------------------------------------
etape "4/8 Dépendances épinglées"
VERROU="${VERROU:-requirements/mac-${PY_ARCH}-py${PY_VERSION/./}.txt}"
[ -f "$VERROU" ] || echec "verrou introuvable : $VERROU (architecture $PY_ARCH, Python $PY_VERSION). Verrous livrés : $(ls requirements 2>/dev/null | tr '\n' ' ')"
echo "verrou : $VERROU (index pip du poste : $("$VPY" -m pip config get global.index-url 2>/dev/null || echo 'PyPI par défaut'))"
"$VPY" -m pip install --quiet --disable-pip-version-check --upgrade pip ||
  echec "pip ne peut pas se mettre à jour : accès à l'index (miroir interne, proxy, certificat) ? Voir README › Dépannage"
JOURNAL_PIP="$(mktemp "${TMPDIR:-/tmp}/amorcer-pip.XXXXXX")"
if ! "$VPY" -m pip install --disable-pip-version-check --only-binary=:all: -r "$VERROU" >"$JOURNAL_PIP" 2>&1; then
  echo "Échec de l'installation des versions épinglées. Lignes qui bloquent :" >&2
  grep -E "Could not find a version|No matching distribution|ResolutionImpossible|conflict|SSLError|CERTIFICATE_VERIFY|ProxyError|Max retries|HTTP error|40[13]|404 " "$JOURNAL_PIP" |
    grep -v "Ignored the following" | cut -c1-300 | head -12 >&2 || tail -8 "$JOURNAL_PIP" >&2
  echo "Journal pip complet : $JOURNAL_PIP" >&2
  echo "Pistes : README › Dépannage (index interne, proxy, certificat de l'autorité pour pip)." >&2
  exit 1
fi
rm -f "$JOURNAL_PIP"
# PYTHONWARNINGS : tait l'avertissement « Editable installation » de setuptools, répété pour chaque paquet local
PYTHONWARNINGS=ignore "$VPY" -m pip install --quiet --disable-pip-version-check --no-deps -e . -e vendor ||
  echec "installation du POC et de la brique d'observabilité impossible (voir ci-dessus)"
"$VPY" -m pip check >/dev/null || echec "dépendances incohérentes : $("$VPY" -m pip check 2>&1 | head -5)"
ok "$(grep -cv '^#' "$VERROU") paquets épinglés, POC et brique installés, pip check sans conflit"

# ---------------------------------------------------------------------------------------------------------------------
etape "5/8 OCR (Tesseract, facultatif)"
trouver_tesseract() {
  local c
  for c in "${POC_TESSERACT:-}" "$(command -v tesseract 2>/dev/null || true)" /opt/homebrew/bin/tesseract /usr/local/bin/tesseract \
    "/c/Program Files/Tesseract-OCR/tesseract.exe"; do
    if [ -n "$c" ] && [ -x "$c" ]; then
      echo "$c"
      return 0
    fi
  done
  return 1
}
BREW_BIN="$(command -v brew 2>/dev/null || true)"
for b in /opt/homebrew/bin/brew /usr/local/bin/brew; do
  if [ -z "$BREW_BIN" ] && [ -x "$b" ]; then BREW_BIN="$b"; fi
done
TESS="$(trouver_tesseract || true)"
if [ -z "$TESS" ] && [ "$SYSTEME" = "Darwin" ] && [ -n "$BREW_BIN" ] && [ "$BREW" -eq 1 ]; then
  echo "Tesseract absent : installation avec Homebrew (tesseract, tesseract-lang)…"
  "$BREW_BIN" install tesseract tesseract-lang || attention "installation Homebrew impossible (réseau, droits) : l'OCR restera indisponible"
  TESS="$(trouver_tesseract || true)"
fi
if [ -n "$TESS" ]; then
  if "$TESS" --list-langs 2>&1 | grep -qx "fra"; then
    ok "$("$TESS" --version 2>&1 | head -1) avec le français : $TESS"
  else
    if [ -n "$BREW_BIN" ] && [ "$BREW" -eq 1 ]; then "$BREW_BIN" install tesseract-lang || true; fi
    if "$TESS" --list-langs 2>&1 | grep -qx "fra"; then ok "Tesseract avec le français : $TESS"; else attention "Tesseract sans le français : brew install tesseract-lang (l'OCR lira en anglais, moins bien)"; fi
  fi
else
  attention "Tesseract absent (brew install tesseract tesseract-lang) : l'agent redemandera les pièces scannées, les tests OCR seront sautés"
fi

# ---------------------------------------------------------------------------------------------------------------------
etape "6/8 Configuration .env"
if [ ! -f .env ]; then
  cp .env.example .env
  chmod 600 .env
  attention ".env créé depuis .env.example : y renseigner la passerelle LLM (LLM_URL, LLM_MODELE, LLM_API_KEY) et Arize AX (OBS_*)"
else
  chmod 600 .env
  ok ".env présent (lisible par vous seul)"
fi
for f in ca-bundle.crt ca-bundle.pem; do
  if [ -f "$f" ]; then ok "autorité interne trouvée à la racine : $f (POC_CA_BUNDLE=$f dans .env)"; fi
done

# ---------------------------------------------------------------------------------------------------------------------
etape "7/8 Données synthétiques (50 dossiers)"
if [ "$REGENERER" -eq 1 ] || [ ! -f data/banque.sqlite ]; then
  "$VPY" scripts/reconstruire_donnees.py | tail -1
else
  ok "données présentes dans data/ (bash amorcer_mac.sh --regenerer pour les refaire à l'identique)"
fi

# ---------------------------------------------------------------------------------------------------------------------
etape "8/8 Contrôles"
"$BIN/poc" sante || {
  attention "poc sante signale un contrôle KO (voir le tableau)"
  ECHECS=$((ECHECS + 1))
}
"$BIN/poc" config verifier || attention "configuration incomplète : compléter .env (voir la colonne détail), puis relancer ce script"
LLM_PRET=0
OBS_ACTIVE=0
OBS_PRET=0
eval "$("$BIN/poc" config verifier --etat | tr -d '\r' | grep -E '^[A-Z_]+=[01]$' || true)"
if [ "$RESEAU" -eq 0 ]; then
  ok "--hors-ligne : passerelle LLM et Arize non appelées"
else
  if [ "$LLM_PRET" = "1" ]; then
    "$BIN/poc" llm tester || attention "la passerelle LLM ne répond pas comme attendu (message ci-dessus ; README › Dépannage)"
  else
    attention "passerelle LLM non testée : configuration du modèle incomplète dans .env"
  fi
  if [ "$OBS_PRET" = "1" ]; then
    "$BIN/poc" obs verifier || attention "Arize AX : vérification de bout en bout incomplète (message ci-dessus ; ARIZE_AX.md › Dépannage)"
  elif [ "$OBS_ACTIVE" = "1" ]; then
    attention "Arize AX non vérifié : OBS_ENDPOINT, OBS_API_KEY, OBS_SPACE_ID à compléter dans .env"
  else
    ok "observabilité inactive (OBS_ENABLED=false) : aucune trace ne part"
  fi
fi
if [ "$TESTS" -eq 1 ]; then
  echo "Suite de tests (quelques minutes ; aucune trace n'est envoyée, aucun modèle réel n'est appelé)…"
  if "$VPY" -m pytest -q -p no:warnings; then ok "tests verts"; else
    attention "des tests échouent (voir ci-dessus)"
    ECHECS=$((ECHECS + 1))
  fi
else
  ok "tests sautés (--sans-tests)"
fi

# ---------------------------------------------------------------------------------------------------------------------
printf '\n%sAmorçage terminé%s : %s alerte(s), %s échec(s). Journal : %s\n' "$GRAS" "$FIN" "$ALERTES" "$ECHECS" "$JOURNAL"
cat <<EOF

Pour la suite, dans ce dossier :
  source .venv/bin/activate                  # une fois par terminal
  poc config verifier                        # ce qui reste à renseigner dans .env
  poc agent lancer -d DEM-0001 -v            # le fil rouge avec le modèle par défaut, raisonnement à l'écran
  poc agent campagne --lot demo              # trois dossiers variés, notés, tracés dans Arize si OBS_ENABLED=true
  poc agent campagne --lot panorama          # douze dossiers, une situation chacun
  poc interface                              # la démonstration : http://localhost:8501
Tout le reste : README.md (commandes) et ARIZE_AX.md (monitoring).
EOF
[ "$ECHECS" -eq 0 ]
