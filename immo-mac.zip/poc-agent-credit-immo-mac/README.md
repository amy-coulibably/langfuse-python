# POC agent de pré-instruction crédit immobilier — poste Mac

Un agent qui prépare un dossier de crédit immobilier pour un conseiller : il vérifie les pièces, les lit (y compris par OCR
quand elles sont scannées), calcule ce que le foyer peut rembourser, confronte aux règles (norme HCSF, politique maison),
rédige une synthèse et formule une recommandation motivée. **Il recommande, il ne décide pas.** Données entièrement
synthétiques (cinquante dossiers générés sur le poste), tout en local, traces et évaluations vers Arize AX.

Ce dossier contient le minimum pour faire tourner l'agent : le code (`poc/`), la configuration (`config/`), le savoir de
l'agent (`fiches/`, `referentiels/`), la brique d'observabilité de la banque (`vendor/`), les verrous de dépendances par
architecture et par version de Python (`requirements/`), les tests (`tests/`) et le script d'amorçage.

## En bref

```bash
bash amorcer_mac.sh                 # environnement, dépendances, OCR, .env, 50 dossiers, contrôles, tests
#   … compléter .env : passerelle LLM (LLM_URL, LLM_MODELE, LLM_API_KEY) et Arize AX (OBS_ENDPOINT, OBS_API_KEY, OBS_SPACE_ID)
bash amorcer_mac.sh                 # relancé : vérifie la passerelle LLM et Arize de bout en bout
source .venv/bin/activate && poc agent lancer -d DEM-0001 -v
```

## 1. Prérequis

| Quoi | Pourquoi | Comment |
| --- | --- | --- |
| macOS 13 ou plus, Apple Silicon ou Intel | les verrous ciblent macOS 13+ | — |
| Python 3.11, 3.12 ou 3.13 | l'agent et ses dépendances | installeur python.org (3.13 recommandé), ou `brew install python@3.13` ; le `python3` d'Apple (3.9) ne convient pas |
| Accès à un index de paquets Python | installation des 110 paquets épinglés | PyPI ou le miroir interne de la banque : pip utilise la configuration du poste (`pip config list`) |
| Tesseract avec le français (facultatif) | lire les pièces scannées (OCR) | installé par le script si Homebrew est présent : `brew install tesseract tesseract-lang` |
| Le fichier PEM de l'autorité interne | joindre la passerelle LLM et l'instance Arize en TLS | à déposer à la racine sous le nom `ca-bundle.crt` |
| Les coordonnées de la passerelle LLM et d'Arize AX | modèle de langage, traces | à écrire dans `.env` (section 2) |

## 2. Installer et configurer

1. Copier le dossier sur le Mac (ou dézipper `poc-agent-credit-immo-mac.zip`), puis dans un terminal :

   ```bash
   cd poc-agent-credit-immo-mac
   bash amorcer_mac.sh
   ```

   Le script trouve un Python 3.11 à 3.13, crée `.venv`, installe les versions épinglées pour votre architecture et votre
   Python (roues binaires uniquement : rien n'est compilé), installe Tesseract si possible, crée `.env` depuis
   `.env.example`, génère les cinquante dossiers (une trentaine de secondes), puis lance les contrôles et la suite de tests.
   Il est rejouable : relancé, il ne refait que ce qui manque. Options : `--sans-tests`, `--sans-brew`, `--recreer`,
   `--regenerer`, `--hors-ligne`, `--help`. Tout est écrit dans `amorcage.log`.

2. Compléter `.env` — c'est le seul fichier à modifier. Les variables utiles :

   | Variable | Exemple | Rôle |
   | --- | --- | --- |
   | `LLM_MODELE_DEFAUT` | `passerelle_banque` | le modèle de toutes les étapes ; `factice` pour essayer sans réseau |
   | `LLM_URL` | `https://<passerelle>/v1` | adresse de la passerelle (API compatible OpenAI) |
   | `LLM_MODELE` | `<nom exact>` | identifiant du modèle exposé par la passerelle |
   | `LLM_API_KEY` | | la clé de la passerelle |
   | `LLM_EN_TETES` | `{"X-Application": "poc"}` | en-têtes exigés par la passerelle (facultatif) |
   | `POC_CA_BUNDLE` | `ca-bundle.crt` | l'autorité interne, pour la passerelle et pour Arize |
   | `OBS_ENABLED` | `true` | envoyer les traces |
   | `OBS_ENDPOINT` | `https://<instance>/v1/traces` | l'adresse OTLP de l'instance Arize AX |
   | `OBS_API_KEY`, `OBS_SPACE_ID` | | clé et espace Arize |
   | `OBS_PROJECT` | `agent-credit-immo` | le projet de traces dans Arize |
   | `OBS_CONTENU_MESSAGES` | `true` | texte des messages dans les traces (false sur données réelles) |

   Toutes les autres variables sont décrites dans `.env.example`.

3. Vérifier, dans cet ordre (le script le fait aussi quand `.env` est complet) :

   ```bash
   source .venv/bin/activate
   poc config verifier        # ce qui manque encore, sans appel réseau
   poc llm tester             # un appel court à la passerelle LLM, avec un appel d'outil
   poc obs verifier           # une session tracée de bout en bout vers Arize AX, évaluations comprises
   ```

Avant la première trace, déclarer le modèle dans la grille de coûts d'Arize : voir **ARIZE_AX.md**, qui décrit aussi les
vues, moniteurs, tableaux de bord et la file de relecture à mettre en place.

## 3. Lancer l'agent

```bash
poc agent lancer -d DEM-0001 -v               # le fil rouge (Marie et Thomas), raisonnement à l'écran
poc agent lancer -d DEM-0001 -m factice       # sans modèle de langage (vérifier la chaîne, aucune donnée ne sort)
poc agent lancer -d DEM-0037 -v               # une fiche de paie illisible : lecture native, OCR, puis copie redemandée
poc agent lancer -d DEM-0001 --pas-a-pas      # s'arrête à chaque étape et avant la remise au conseiller
poc agent lancer -d DEM-0001 --mcp            # les outils passent par trois serveurs MCP séparés
poc agent sessions                            # les dernières sessions
poc agent journal S-DEM-0001-xxxxxx           # le raisonnement d'une session
poc agent evaluer S-DEM-0001-xxxxxx           # la session contre la vérité terrain ; dépose les évaluations dans Arize
poc interface                                 # la démonstration : http://localhost:8501 (rejeu, continu, pas à pas)
```

Une session complète dure de six à vingt minutes et consomme de 600 000 à 1 500 000 tokens selon le modèle.

## 4. Tester sur une diversité de dossiers

```bash
poc donnees catalogue                         # les cinquante dossiers : scénario, lot, recommandation attendue
poc donnees catalogue --lot scelle            # les cinq dossiers scellés
poc donnees inspecter DEM-0019                # un dossier, ses pièges, ce que l'agent devrait trouver
poc donnees pieces DEM-0019                   # les pièces déposées (dont un compromis en photo)
```

Les campagnes lancent l'agent sur une série de dossiers, notent chaque session et gardent le résultat (`agent_campagnes`
en base, CSV dans `data/campagnes/`) ; si `OBS_ENABLED=true`, chaque session est tracée et ses évaluations déposées.

| Commande | Dossiers | Pour quoi |
| --- | --- | --- |
| `poc agent campagne --lot demo` | 3 : fil rouge, dossier sain, pièce illisible | vérifier un réglage rapidement |
| `poc agent campagne --lot panorama` | 12 : une situation chacun (retraités, locatif, prime, CDD seul, photo, incident, taux à 49 %, salarié sans fiche, pension récente…) | une vue d'ensemble |
| `poc agent campagne --lot ocr` | 7 à pièce numérisée | la planification dynamique (lecture native, OCR, recoupement) |
| `poc agent campagne --lot facile -k 3` | 10 sans piège, trois fois | fiabilité (pass^3) sur le chemin nominal |
| `poc agent campagne --lot reglage` | 35 avec pièges | le réglage des fiches |
| `poc agent campagne --lot scelle -k 3` | 5 jamais regardés pendant le réglage | la mesure honnête, à la fin |
| `poc agent campagne -d DEM-0013,DEM-0024` | une sélection | un cas précis |

```bash
poc agent campagnes                           # les campagnes passées : pass@1, pass^k, versions du savoir et du code
poc agent campagnes --detail C-2026…          # une campagne session par session
```

Une session est **réussie** quand la recommandation est celle attendue, le taux d'effort exact, le verdict HCSF exact, la
synthèse vérifiée par le garde-fou et qu'aucun doute n'a été inventé. **pass^k** est la part des dossiers réussis à chacune
des k répétitions : la mesure de fiabilité.

Autres commandes : `poc etapes` (le parcours), `poc llm lister` (les modèles et leurs clés), `poc sante` (contrôle complet),
`poc api lancer tout` (les six guichets HTTP, ports 8001 à 8006, page `/docs` chacun), `poc mcp lister` (les outils servis
par MCP), `poc obs moniteurs` (les moniteurs à créer dans Arize), `python -m pytest -q` (les tests).

## 5. Dépannage

Ces cas viennent du portage du premier POC sur un Mac de la banque.

| Symptôme | Cause | Remède |
| --- | --- | --- |
| `$'\r': command not found` | fins de ligne Windows dans le script | `sed -i '' $'s/\r$//' amorcer_mac.sh` |
| `Aucun Python 3.11, 3.12 ou 3.13 trouvé` | seul le Python 3.9 d'Apple est présent | installeur python.org, ou `brew install python@3.13`, ou `PYTHON=/chemin bash amorcer_mac.sh` |
| `Could not find a version that satisfies …` | le miroir interne n'a pas cette version, ou pip n'atteint pas l'index | `pip config list` ; demander la version au miroir ; `PIP_INDEX_URL=… bash amorcer_mac.sh` |
| `SSLError`, `CERTIFICATE_VERIFY_FAILED` pendant pip | proxy TLS d'entreprise | `pip config set global.cert /chemin/ca-bundle.crt` |
| erreur de compilation (`pkg_resources`, `pyarrow`) | une version sans roue binaire pour ce Mac | ne plus arriver : le script installe en roues binaires uniquement ; ne pas installer le paquet `ml-utils` complet de la banque (il tire mlflow et un pyarrow sans roue en Python 3.13) |
| un autre `venv` est actif | environnement d'un autre projet | sans effet : le script utilise `.venv` du POC |
| `poc: command not found` | environnement non activé | `source .venv/bin/activate` |
| `[observabilité] désactivée pour cette session …` | adresse, clé, autorité ou réseau | le message dit lequel ; `poc obs sante` ; ARIZE_AX.md › Dépannage |
| la passerelle répond `401` ou `403` | clé ou en-têtes | `LLM_API_KEY`, `LLM_EN_TETES` |
| la passerelle répond `404` | adresse ou nom du modèle | `LLM_URL` jusqu'à `/v1` ; `LLM_MODELE` exact |
| `certificat d'autorité introuvable` | chemin de `POC_CA_BUNDLE` | relatif à la racine du POC, ou absolu |
| `ReadTimeout` sur une étape longue | réponse lente du modèle | `LLM_TIMEOUT_S=240` |
| `Address already in use` (`poc api lancer`, `poc interface`) | un autre programme sur le port | `lsof -i :8001` puis arrêter le processus |
| les pièces scannées sont redemandées | Tesseract absent | `brew install tesseract tesseract-lang` |
| les données ne sont plus celles du code | dossier copié d'une version antérieure | `bash amorcer_mac.sh --regenerer` (déterministe) |
