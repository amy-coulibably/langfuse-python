"""Lot 0 : le squelette tient debout. Le parcours se lit, les modèles se configurent, l'atelier calcule et refuse, le graphe
traverse ses sept étapes avec le modèle factice et laisse une session remise, un journal et des traces en base."""

from __future__ import annotations

import pytest

from poc.agent import lancer_agent
from poc.agent.fiches import FICHE_COMMUNE, consigne_systeme, fiches_manquantes, lister_fiches
from poc.config import Config
from poc.etapes import charger_parcours, noms_etapes
from poc.llm import charger_config_llm, config_factice
from poc.outils import (
    OUTILS,
    BackendLocal,
    ErreurOutil,
    executer_outil,
    outils_pour_etape,
    outils_prevus_absents,
    schema_outils,
)


@pytest.fixture()
def config(tmp_path) -> Config:
    return Config(data_dir=tmp_path / "data")


def test_le_parcours_a_sept_etapes_et_finit_par_la_remise():
    p = charger_parcours()
    assert p.noms == ["comprendre", "verifier", "extraire", "calculer", "confronter", "rediger", "remettre"]
    assert p.etape("remettre").type == "code" and p.outils_de("remettre") == []
    assert "consulter_fiche" in p.outils_de("comprendre")  # outil commun
    assert {"calculer", "lire_calculs"} <= set(p.outils_de("calculer"))


def test_la_configuration_des_modeles_connait_les_roles_du_parcours():
    cfg = charger_config_llm()
    assert set(cfg.roles) <= set(noms_etapes())
    assert cfg.modele_pour("calculer").nom_logique == cfg.roles.get("calculer", cfg.defaut)
    assert "factice" in cfg.modeles_disponibles()
    assert cfg.modeles["factice"].prix_connu is False and cfg.modeles["principal"].prix_connu is True


def test_registre_outils_et_visibilite():
    assert {"consulter_fiche", "calculer", "lire_calculs"} <= set(OUTILS)
    assert {"consulter_fiche", "lire_demande"} <= {o.nom for o in outils_pour_etape("comprendre")}
    assert outils_prevus_absents("comprendre") == []  # tout ce que le parcours déclare est livré (lot 2)
    schemas = schema_outils("calculer")
    assert {"calculer", "lire_calculs", "consulter_fiche", "simuler_pret"} <= {s["name"] for s in schemas}
    assert all("input_schema" in s and "description" in s for s in schemas)


def test_fiches_et_consigne():
    assert FICHE_COMMUNE not in fiches_manquantes()
    assert any(f["nom"] == FICHE_COMMUNE for f in lister_fiches())
    etape = charger_parcours().etape("calculer")
    consigne = consigne_systeme(
        etape, "DEM-0001", "S-DEM-0001-abc123", {"comprendre": {"resume": "ok"}}, schema_outils("calculer")
    )
    assert "Tu ne décides pas" in consigne and "S-DEM-0001-abc123" in consigne and '"resume"' in consigne
    assert (
        "Synthèses des étapes précédentes" in consigne and "à écrire" not in consigne
    )  # les douze fiches sont là (lot 3)
    assert "frais_acquisition" in consigne and "Se relire" in consigne  # les fiches de l'étape sont inclues en entier


def test_atelier_calcule_et_refuse(config):
    backend = BackendLocal(config)
    sid = backend.ecrire("sessions", {"demande_id": "DEM-0001", "modele": "test"})["session_id"]
    r = executer_outil(
        backend,
        "calculer",
        {
            "session_id": sid,
            "etape": "calculer",
            "entrees": [
                {"nom": "mensualite", "origine": {"type": "constante", "valeur": 1500, "justification": "test"}},
                {"nom": "revenus", "origine": {"type": "constante", "valeur": 4480, "justification": "test"}},
            ],
            "code": "taux_effort = round(mensualite / revenus * 100, 1)",
            "sorties": ["taux_effort"],
            "unite": "pourcentage",
        },
    )
    assert r[0]["valeur"] == 33.5
    # un résultat antérieur se réutilise par son nom
    r2 = executer_outil(
        backend,
        "calculer",
        {
            "session_id": sid,
            "etape": "confronter",
            "entrees": [{"nom": "taux", "origine": {"type": "calcul", "nom": "taux_effort"}}],
            "code": "dans_la_norme = taux <= 35",
            "sorties": ["dans_la_norme"],
            "unite": "ratio",
        },
    )
    assert r2[0]["valeur"] is True
    assert len(executer_outil(backend, "lire_calculs", {"session_id": sid})) == 2
    for code, attendu in (
        ("import os\nx = 1", "CODE_REFUSE"),
        ("x = 320000 * 0.35", "CHIFFRE_RECOPIE"),
        ("x = open('f')", "CODE_REFUSE"),
        ("x = 1 / 0", "DIVISION_PAR_ZERO"),
    ):
        with pytest.raises(ErreurOutil) as exc:
            executer_outil(
                backend,
                "calculer",
                {"session_id": sid, "etape": "calculer", "entrees": [], "code": code, "sorties": ["x"]},
            )
        assert exc.value.code == attendu, code
    with pytest.raises(ErreurOutil) as exc:
        executer_outil(
            backend,
            "calculer",
            {
                "session_id": sid,
                "etape": "calculer",
                "entrees": [{"nom": "s", "origine": {"type": "fait", "nom": "salaire"}}],
                "code": "x = s",
                "sorties": ["x"],
            },
        )
    assert exc.value.code == "FAIT_INCONNU"


def test_le_graphe_traverse_les_sept_etapes_avec_le_modele_factice(config):
    r = lancer_agent(config, "DEM-0001", config_llm=config_factice(), checkpoints=False)
    assert r.statut == "REMISE"
    assert [b["etape"] for b in r.bilans] == noms_etapes()
    assert all(not b["erreurs"] for b in r.bilans)
    assert r.tokens > 0 and r.cout_euros is None  # factice : prix inconnu, donc pas de coût
    backend = BackendLocal(config)
    session = backend.lire("session", session_id=r.session_id)
    assert session["statut"] == "REMISE" and session["etape_courante"] == "remettre"
    journal = backend.lire("journal", session_id=r.session_id)
    types = {e["type"] for e in journal}
    assert {"etape", "constat", "outil"} <= types
    assert sum(1 for e in journal if e["type"] == "etape") == 7
    assert any("consulter_fiche" in e["texte"] for e in journal if e["type"] == "outil")
    traces = backend.lire("traces", session_id=r.session_id)
    assert {t["type"] for t in traces} == {"modele", "outil"}
    assert all(t["cout_euros"] is None for t in traces if t["type"] == "modele")


def test_checkpoints_et_reprise_d_une_session_interrompue(config):
    """Une session sauvegardée après chaque étape : l'état LangGraph se relit depuis le fichier de checkpoints."""
    r = lancer_agent(config, "DEM-0002", config_llm=config_factice(), checkpoints=True)
    assert config.checkpoints.exists() and r.statut == "REMISE"


def test_garde_fou_boucle(config):
    """Un modèle qui rappelle sans fin le même outil avec les mêmes paramètres est arrêté par le programme."""
    from poc.llm import AppelOutil, ReponseLLM

    def obstine(systeme, messages, outils):
        return ReponseLLM(
            texte="Je relis la fiche.",
            appels=[AppelOutil(id="a", nom="consulter_fiche", parametres={"nom": "00-regles-communes"})],
            tokens_entree=10,
            tokens_sortie=5,
            duree_ms=1,
            modele="factice",
            fin="tool_use",
        )

    r = lancer_agent(
        config,
        "DEM-0003",
        config_llm=config_factice(max_appels_identiques=3),
        scenario_factice=obstine,
        checkpoints=False,
    )
    premier = r.bilans[0]
    assert any("boucle" in e for e in premier["erreurs"]) and premier["appels_outils"] <= 25
    assert any(e["type"] == "garde_fou" for e in BackendLocal(config).lire("journal", session_id=r.session_id))


def test_cli_etapes_et_sante(config, monkeypatch):
    from typer.testing import CliRunner

    from poc.cli import app

    monkeypatch.setenv("POC_DATA_DIR", str(config.data_dir))
    monkeypatch.setenv("COLUMNS", "250")  # tableaux rich non repliés
    from poc.generateur import generer_tout

    generer_tout(config, demandes=["DEM-0001"])  # la santé vérifie aussi les données (lot 1)
    runner = CliRunner()
    res = runner.invoke(app, ["etapes"])
    assert res.exit_code == 0 and "Remettre au conseiller" in res.output
    res = runner.invoke(app, ["sante"])
    assert res.exit_code == 0, res.output
    assert "KO" not in res.output
    res = runner.invoke(app, ["agent", "lancer", "-d", "DEM-0009", "-m", "factice", "--sans-checkpoints"])
    assert res.exit_code == 0 and "REMISE" in res.output, res.output
