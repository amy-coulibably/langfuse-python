"""Observabilité : la brique ml_utils reçoit, pour une session factice, l'arbre de spans attendu par Arize AX (session,
étapes avec graphe, appels LLM avec messages et outils, appels d'outils, garde-fous), sans réseau : exportateur en mémoire.
Inactive, l'observabilité est un passe-plat qui ne change rien au comportement de l'agent."""

from __future__ import annotations

import pytest

from poc.agent import lancer_agent, trace_de_session
from poc.config import Config
from poc.llm import config_factice
from poc.observabilite import (
    ConfigObservabilite,
    Observabilite,
    adaptateur,
    charger_config_observabilite,
    reinitialiser,
)
from poc.observabilite.config import vers_config_ml_utils

ml_utils = pytest.importorskip("ml_utils.observability")
from ml_utils.observability.backends._otel import OtelSpanBackend  # noqa: E402
from opentelemetry.sdk.trace.export import SimpleSpanProcessor  # noqa: E402
from opentelemetry.sdk.trace.export.in_memory_span_exporter import InMemorySpanExporter  # noqa: E402


class BackendMemoire(OtelSpanBackend):
    """Le backend OTel de la brique, dont l'exportateur réseau est remplacé par une mémoire : on relit les spans."""

    def __init__(self) -> None:
        from opentelemetry.sdk.resources import Resource
        from opentelemetry.sdk.trace import TracerProvider

        self.exporteur = InMemorySpanExporter()
        self._provider = TracerProvider(resource=Resource.create({"openinference.project.name": "test"}))
        self._processor = SimpleSpanProcessor(self.exporteur)
        self._provider.add_span_processor(self._processor)
        self._tracer = self._provider.get_tracer("test")

    def emit_records(self, records):
        return None


@pytest.fixture()
def config(tmp_path) -> Config:
    return Config(data_dir=tmp_path / "data")


@pytest.fixture()
def obs_memoire(monkeypatch):
    from ml_utils.observability import ArizeManager

    reinitialiser()
    cfg = ConfigObservabilite(
        active=True, backend="phoenix", endpoint="http://memoire/v1/traces", projet="test", contenu_messages=True
    )
    backend = BackendMemoire()
    manager = ArizeManager(vers_config_ml_utils(cfg), backend=backend)
    obs = Observabilite(cfg, manager)
    monkeypatch.setattr(adaptateur, "_INSTANCE", obs)
    yield obs, backend.exporteur
    manager.close()
    reinitialiser()


def _attrs(span) -> dict:
    return dict(span.attributes or {})


def test_config_du_depot_inactive_par_defaut(monkeypatch):
    for v in ("OBS_ENABLED", "OBS_BACKEND", "OBS_ENDPOINT", "OBS_API_KEY", "OBS_SPACE_ID"):
        monkeypatch.delenv(v, raising=False)
    cfg = charger_config_observabilite()
    assert cfg.active is False and cfg.effective is False and cfg.projet == "agent-credit-immo"
    monkeypatch.setenv("OBS_ENABLED", "true")
    monkeypatch.setenv("OBS_BACKEND", "arize")
    monkeypatch.setenv("OBS_ENDPOINT", "https://arize.interne/v1/traces")
    monkeypatch.setenv("OBS_API_KEY", "secret")
    cfg2 = charger_config_observabilite()
    assert cfg2.effective and cfg2.backend == "arize" and cfg2.api_key == "secret"
    mlc = vers_config_ml_utils(cfg2)
    assert mlc.backend == "arize" and mlc.api_key.get_secret_value() == "secret" and mlc.model_version is None
    assert "secret" not in repr(mlc)


def test_inactive_est_un_passe_plat(config):
    reinitialiser()
    adaptateur._INSTANCE = Observabilite(ConfigObservabilite(), None)
    r = lancer_agent(config, "DEM-0001", config_llm=config_factice(), checkpoints=False)
    assert r.statut == "REMISE" and len(r.bilans) == 7
    assert trace_de_session(config, r.session_id) is None
    reinitialiser()


def test_session_factice_produit_l_arbre_de_spans_attendu(config, obs_memoire):
    obs, exporteur = obs_memoire
    r = lancer_agent(config, "DEM-0001", config_llm=config_factice(), checkpoints=False)
    spans = exporteur.get_finished_spans()
    assert spans, "aucun span exporté"
    par_kind: dict[str, list] = {}
    for s in spans:
        par_kind.setdefault(_attrs(s).get("openinference.span.kind"), []).append(s)
    agents = par_kind.get("AGENT", [])
    racines = [s for s in agents if s.name == "agent-credit-immo"]
    assert len(racines) == 1, "une seule trace par session, avec une racine AGENT"
    racine = racines[0]
    assert _attrs(racine)["session.id"] == r.session_id
    assert _attrs(racine)["graph.node.id"] == "agent" and _attrs(racine)["poc.statut"] == "REMISE"
    etapes = [s for s in agents if s is not racine]
    assert [s.name for s in etapes] == [
        "comprendre",
        "verifier",
        "extraire",
        "calculer",
        "confronter",
        "rediger",
        "remettre",
    ]
    assert all(_attrs(s)["graph.node.parent_id"] == "agent" for s in etapes)
    assert all(s.parent is not None and s.parent.span_id == racine.context.span_id for s in etapes)
    llm = par_kind.get("LLM", [])
    assert llm and all(_attrs(s)["llm.model_name"] == "factice" for s in llm)
    assert all("llm.cost.total" not in _attrs(s) for s in llm), "prix inconnu : aucun coût ne doit être émis"
    assert all(_attrs(s)["llm.input_messages.0.message.role"] == "system" for s in llm)
    outils = par_kind.get("TOOL", [])
    assert outils and {_attrs(s)["tool.name"] for s in outils} >= {"consulter_fiche"}
    assert all(s.context.trace_id == racine.context.trace_id for s in spans)
    lien = trace_de_session(config, r.session_id)
    assert lien and lien["trace_id"] == format(racine.context.trace_id, "032x")


def test_budget_d_attributs_borne_la_conversation(obs_memoire, monkeypatch):
    """Quarante résultats d'outils dans l'historique : le span LLM garde le système, les messages récents et signale les omis."""
    from poc.llm import Message
    from poc.llm.config import ModeleLLM

    obs, exporteur = obs_memoire
    monkeypatch.setenv("OTEL_SPAN_ATTRIBUTE_COUNT_LIMIT", "128")
    modele = ModeleLLM(nom_logique="factice", fournisseur="factice", nom="factice")
    messages = [Message(role="user", contenu="début")] + [
        Message(role="tool", appel_id=f"a{i}", contenu="x" * 50) for i in range(40)
    ]
    with obs.appel_modele(modele, "système", messages, [], "extraire", "S-1"):
        pass
    span = exporteur.get_finished_spans()[-1]
    a = _attrs(span)
    assert a["llm.input_messages.0.message.role"] == "system" and a["poc.messages_omis"] > 0
    assert a["openinference.span.kind"] == "LLM" and a["session.id"] == "S-1"
