"""Lot 4 : la scène. Le pilote fait avancer l'agent étape par étape et s'arrête avant la remise ; une session se reprend depuis
une étape après réception d'une pièce (retour dans le temps LangGraph) ; l'interface se charge et rejoue une session."""

from __future__ import annotations

import json

import pytest

from poc.agent import PiloteSession, lancer_agent, reprendre_session
from poc.config import Config
from poc.generateur import cas_de, deposer_piece, generer_tout
from poc.llm import config_factice
from poc.outils import BackendLocal


@pytest.fixture(scope="module")
def config(tmp_path_factory) -> Config:
    cfg = Config(data_dir=tmp_path_factory.mktemp("lot4") / "data")
    generer_tout(cfg, demandes=["DEM-0001"])
    return cfg


def _derouler(pilote: PiloteSession) -> list[str | None]:
    arrets = []
    for _ in range(12):
        pilote.attendre()
        assert pilote.erreur is None, pilote.erreur
        arrets.append(pilote.prochaine_etape)
        if pilote.termine:
            break
        pilote.continuer()
    return arrets


def test_pas_a_pas_s_arrete_a_chaque_etape_puis_avant_la_remise(config):
    pilote = PiloteSession(config, "DEM-0001", config_llm=config_factice(), pas_a_pas=True, arret_avant_remise=True)
    sid = pilote.demarrer()
    arrets = _derouler(pilote)
    assert arrets == ["verifier", "extraire", "calculer", "confronter", "rediger", "remettre", None]
    assert pilote.termine and pilote.resultat is not None and pilote.resultat.statut == "REMISE"
    session = BackendLocal(config).lire("session", session_id=sid)
    assert session["statut"] == "REMISE"


def test_continu_ne_s_arrete_qu_avant_la_remise(config):
    pilote = PiloteSession(config, "DEM-0001", config_llm=config_factice(), pas_a_pas=False, arret_avant_remise=True)
    pilote.demarrer()
    pilote.attendre()
    assert (
        pilote.prochaine_etape == "remettre" and not pilote.termine
    )  # tout s'est déroulé jusqu'à la porte du conseiller
    statut = BackendLocal(config).lire("session", session_id=pilote.session_id)["statut"]
    assert statut == "EN_COURS"
    pilote.continuer()
    pilote.attendre()
    assert pilote.termine and pilote.resultat.statut == "REMISE"


def test_arret_en_cours_de_route(config):
    pilote = PiloteSession(config, "DEM-0001", config_llm=config_factice(), pas_a_pas=True)
    pilote.demarrer()
    pilote.attendre()
    pilote.arreter()
    assert BackendLocal(config).lire("session", session_id=pilote.session_id)["statut"] == "INTERROMPUE"


def test_recevoir_la_piece_et_reprendre_depuis_verifier(config):
    r = lancer_agent(config, "DEM-0001", config_llm=config_factice(), checkpoints=True)
    cas = cas_de(config, "DEM-0001")
    pid, per = cas.pieges.fiches_paie_manquantes[0]
    piece = deposer_piece(config, cas, "fiche_paie", pid, per)
    inv = json.loads((config.coffre_dir / "DEM-0001" / "inventaire.json").read_text(encoding="utf-8"))
    assert (
        piece["piece_id"] in {p["piece_id"] for p in inv["pieces"]}
        and (config.coffre_dir / "DEM-0001" / piece["fichier"]).exists()
    )
    with pytest.raises(ValueError):
        deposer_piece(config, cas, "fiche_paie", pid, per)  # pas deux fois
    r2 = reprendre_session(config, r.session_id, "verifier", config_llm=config_factice())
    assert r2.statut == "REMISE" and [b["etape"] for b in r2.bilans][-1] == "remettre"
    journal = BackendLocal(config).lire("journal", session_id=r.session_id)
    assert any(e["type"] == "systeme" and "Reprise" in e["texte"] for e in journal)
    assert sum(1 for e in journal if e["type"] == "etape") == 13  # 7 étapes, puis 6 rejouées depuis « verifier »
    with pytest.raises(ValueError):
        reprendre_session(config, r.session_id, "inconnue", config_llm=config_factice())


def test_reprise_impossible_sans_checkpoints(config):
    r = lancer_agent(config, "DEM-0001", config_llm=config_factice(), checkpoints=False)
    with pytest.raises(LookupError):
        reprendre_session(config, r.session_id, "verifier", config_llm=config_factice())


def test_l_interface_se_charge_et_rejoue_une_session(config, monkeypatch):
    pytest.importorskip("streamlit")
    from streamlit.testing.v1 import AppTest

    r = lancer_agent(config, "DEM-0001", config_llm=config_factice(), checkpoints=False)
    monkeypatch.setenv("POC_DATA_DIR", str(config.data_dir))
    from pathlib import Path

    at = AppTest.from_file(
        str(Path(__file__).resolve().parents[1] / "poc" / "interface" / "app.py"), default_timeout=60
    )
    at.run()
    assert not at.exception, at.exception
    assert any("Pré-instruction" in m.value for m in at.markdown)
    # rejeu : on choisit la session et on va à la fin
    choix = [s for s in at.sidebar.selectbox if s.key == "choix_rejeu"]
    assert choix, "sélecteur de session absent"
    at.sidebar.button[2].click().run()  # ⏭ Fin
    assert not at.exception, at.exception
    assert at.session_state["session_id"] == r.session_id
    assert any("Remettre au conseiller" in m.value for m in at.markdown)
