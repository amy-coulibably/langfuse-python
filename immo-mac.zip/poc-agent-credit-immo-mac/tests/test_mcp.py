"""MCP : les trois serveurs démarrent sur stdio, publient les outils de leur maison, se laissent découvrir par le client et
s'arrêtent proprement. Les appels d'outils par MCP sont exercés au lot 5."""

from __future__ import annotations

import pytest

pytest.importorskip("mcp")


def test_les_trois_serveurs_demarrent_et_se_decouvrent(tmp_path, monkeypatch):
    monkeypatch.setenv("POC_DATA_DIR", str(tmp_path / "data"))
    from poc.mcp import SERVEURS, BackendMCP

    with BackendMCP() as b:
        assert sorted(b.serveurs_ouverts()) == sorted(SERVEURS)
        from poc.outils import OUTILS

        attendus = sorted(n for n, o in OUTILS.items() if o.serveur_mcp)
        assert b.outils_decouverts() == attendus and len(attendus) == 24  # 23 + consulter_score
        assert {info["serveur"] for info in b.outils.values()} == set(SERVEURS)
        assert b.lire("sessions") == []  # les opérations de l'orchestrateur passent par le backend local
