"""Lot 5 : le catalogue de cinquante dossiers (dix faciles, cinq scellés), le moteur de vérité sur les nouvelles situations,
les campagnes persistées avec pass^k, les outils servis par MCP de bout en bout, et les évaluations `eval.*` déposées sur la
trace (testées sur un client Arize simulé)."""

from __future__ import annotations

import json
from collections import Counter

import pytest

from poc.config import Config
from poc.donnees import SQLiteStore
from poc.generateur import (
    RECETTES,
    attendu_de,
    calculer_attendu,
    cas_de,
    cas_du_catalogue,
    cas_fil_rouge,
    catalogue,
    generer_tout,
    tous_les_cas,
)
from poc.llm import config_factice

DEMANDES_TEST = ["DEM-0001", "DEM-0018", "DEM-0027", "DEM-0032", "DEM-0048"]


@pytest.fixture(scope="module")
def config(tmp_path_factory) -> Config:
    cfg = Config(data_dir=tmp_path_factory.mktemp("lot5") / "data")
    generer_tout(cfg, demandes=DEMANDES_TEST)
    return cfg


# ---------------------------------------------------------------------------------------------------------------------
# Le catalogue
# ---------------------------------------------------------------------------------------------------------------------
def test_cinquante_dossiers_trois_lots_et_le_fil_rouge_intact():
    cas = tous_les_cas()
    assert len(cas) == 50 and len(RECETTES) == 49
    assert [c.demande_id for c in cas] == [f"DEM-{i:04d}" for i in range(1, 51)]
    lots = Counter(c.lot for c in cas)
    assert lots == {"reglage": 35, "facile": 10, "scelle": 5}
    assert calculer_attendu(cas_fil_rouge()).taux_effort == 33.5  # le fil rouge n'a pas bougé
    assert len({c.scenario for c in cas}) == 50  # un scénario par dossier


def test_le_catalogue_est_deterministe_et_sans_personnes_reelles():
    a, b = cas_du_catalogue(), cas_du_catalogue()
    assert [c.model_dump() for c in a] == [c.model_dump() for c in b]
    for c in a:
        assert all(p.id not in ("thomas", "marie") for p in c.personnes)
        assert sum(e.solde for e in c.epargnes) >= c.projet.apport  # l'épargne couvre toujours l'apport


def test_les_faciles_sont_favorables_sans_piege_et_les_resultats_sont_divers():
    attendus = [calculer_attendu(c) for c in cas_du_catalogue()]
    faciles = [a for a in attendus if a.lot == "facile"]
    assert all(a.recommandation == "FAVORABLE" and not a.doutes_attendus and not a.reserves for a in faciles)
    assert all(v == "DANS_LA_NORME" for a in faciles for v in a.verdicts.values())
    recos = Counter(a.recommandation for a in attendus)
    assert set(recos) == {"FAVORABLE", "FAVORABLE_SOUS_RESERVES", "DEFAVORABLE", "NE_SE_PRONONCE_PAS"}
    assert recos["DEFAVORABLE"] >= 3 and recos["NE_SE_PRONONCE_PAS"] >= 2
    types = {d["type"] for a in attendus for d in a.doutes_attendus}
    assert {
        "PIECE_MANQUANTE",
        "PIECE_HORS_PERIODE",
        "PRIME_DANS_LE_NET",
        "ECART_SALAIRE_RELEVES",
        "ECART_AVIS_FICHES",
        "REVENU_NON_ETABLI",
        "CAS_NON_COUVERT_INDEPENDANT",
        "PERIODE_ESSAI",
        "CDD_EXCLU",
        "PENSION_RECENTE",
        "SIGNAUX_COMPTE",
        "INCIDENT",
    } <= types
    # les revenus calés restent plausibles
    for c in cas_du_catalogue():
        for p in c.personnes:
            if p.salaire_net_mensuel:
                assert 1_300 <= p.salaire_net_mensuel <= 9_000, (c.demande_id, p.id, p.salaire_net_mensuel)


def test_le_moteur_de_verite_applique_les_nouvelles_regles():
    par_scenario = {c.scenario: calculer_attendu(c) for c in cas_du_catalogue()}
    cdd = par_scenario["cdd_recent_exclu"]
    assert 0.0 in cdd.revenus_par_personne.values() and cdd.recommandation == "FAVORABLE_SOUS_RESERVES"
    assert "HORS_NORME_HCSF_TAUX_EFFORT" in cdd.reserves
    seul = par_scenario["celibataire_cdd_recent"]
    assert seul.bloquant and seul.recommandation == "NE_SE_PRONONCE_PAS"
    sans_fiche = par_scenario["sans_fiche_de_paie"]
    assert sans_fiche.bloquant and len(sans_fiche.pieces_manquantes) == 3
    locatif = par_scenario["locatif_cdi_couple"]
    assert locatif.revenus_locatifs_retenus == 455.0  # 650 × 70 %
    assert locatif.charges_retenues == round(locatif.mensualites_assurance_comprise[20] + 900.0, 2)  # loyer conservé
    fin_proche = par_scenario["credit_fin_proche"]
    assert fin_proche.charges_credits == 240.0  # le crédit qui se termine dans quatre mois ne compte pas
    assert par_scenario["retraite_recente"].verdicts["SEUIL_PENSION"] == "CAS_NON_COUVERT"
    assert par_scenario["incident_en_cours"].recommandation == "DEFAVORABLE"
    assert par_scenario["incident_regularise"].reserves == ["INCIDENT_REGULARISE"]
    assert par_scenario["reste_a_vivre_juste"].verdicts["SEUIL_RESTE_A_VIVRE"] == "HORS_NORME"
    assert par_scenario["apport_insuffisant"].verdicts["SEUIL_APPORT"] == "HORS_NORME"
    assert par_scenario["avis_ancien"].pieces_manquantes[0]["periode"] == "2026"


def test_les_pieces_portent_les_nouvelles_situations(config):
    pypdf = pytest.importorskip("pypdf")

    def texte(demande: str, fichier: str) -> str:
        chemin = config.coffre_dir / demande / fichier
        return "\n".join(p.extract_text() for p in pypdf.PdfReader(str(chemin)).pages)

    retraites = json.loads((config.coffre_dir / "DEM-0032" / "inventaire.json").read_text(encoding="utf-8"))
    types = Counter(p["type"] for p in retraites["pieces"])
    assert types["attestation_pension"] == 2 and types["fiche_paie"] == 0
    cas = cas_de(config, "DEM-0032")
    recent = cas.pieges and [p for p in cas.personnes if p.id in attendu_de(config, "DEM-0032").revenus_non_couverts][0]
    assert "pension liquidée le" in texte("DEM-0032", f"attestation_pension_{recent.id}.pdf")
    sans_fiche = json.loads((config.coffre_dir / "DEM-0027" / "inventaire.json").read_text(encoding="utf-8"))
    cas27 = cas_de(config, "DEM-0027")
    exclu = cas27.pieges.salarie_sans_fiche[0]
    assert not any(p["type"] == "fiche_paie" and p["personne"] == exclu for p in sans_fiche["pieces"])
    assert any(p["type"] == "fiche_paie" for p in sans_fiche["pieces"])  # l'autre salarié a les siennes
    seul = json.loads((config.coffre_dir / "DEM-0018" / "inventaire.json").read_text(encoding="utf-8"))
    fiche = [p for p in seul["pieces"] if p["type"] == "fiche_paie"][0]
    assert "contrat : CDD" in texte("DEM-0018", fiche["fichier"])


def test_la_verite_terrain_porte_le_lot_et_le_catalogue_se_lit(config):
    lignes = catalogue(config)
    assert [x["demande_id"] for x in lignes] == DEMANDES_TEST
    assert {x["lot"] for x in lignes} == {"reglage", "scelle"}
    assert attendu_de(config, "DEM-0048").lot == "scelle"
    store = SQLiteStore(config.sqlite_banque)
    assert "loyers_attendus_declares" in store.requete("SELECT * FROM banque_demande LIMIT 1").columns
    clients = store.requete("SELECT client_depuis FROM banque_client")["client_depuis"].to_list()
    assert all(c[:4].isdigit() and c < "2026" for c in clients)


# ---------------------------------------------------------------------------------------------------------------------
# Ce que la première campagne a appris à l'outillage
# ---------------------------------------------------------------------------------------------------------------------
def test_la_demande_donne_ages_anciennetes_mois_attendus_et_total_des_credits(config):
    from poc.outils import BackendLocal

    b = BackendLocal(config)
    d = b.lire("demande", demande_id="DEM-0001")
    thomas, marie = d["emprunteurs"]
    assert thomas["age_au_depot"] == 36 and marie["age_au_depot"] == 34
    assert thomas["anciennete_mois_au_depot"] == 78 and marie["anciennete_mois_au_depot"] == 14
    assert d["mois_attendus_fiches_et_releves"] == ["2026-06", "2026-07", "2026-08"]
    assert d["total_mensualites_credits_declares"] == 210.0 and d["ages_au_depot"] == [36, 34]
    sans_credit = b.lire("demande", demande_id="DEM-0048")
    assert sans_credit["total_mensualites_credits_declares"] == 0.0
    # la consigne les rappelle à chaque étape
    from poc.agent.fiches import consigne_systeme
    from poc.etapes import charger_parcours

    texte = consigne_systeme(charger_parcours().etapes[0], "DEM-0001", "S-X", {}, [], demande=d)
    assert "36 ans au dépôt" in texte and "78 mois au dépôt" in texte and "2026-06, 2026-07, 2026-08" in texte
    assert "total 210.0 €" in texte


def test_le_simulateur_prend_les_ages_de_la_demande(config):
    from poc.outils import BackendLocal, executer_outil

    b = BackendLocal(config)
    sid = b.ecrire("sessions", {"demande_id": "DEM-0001", "modele": "test"})["session_id"]
    r = executer_outil(b, "simuler_pret", {"session_id": sid, "montant": 303250, "duree_annees": 25})
    assert r["ages_utilises"] == [36, 34] and abs(r["mensualite_assurance_comprise"] - 1571.42) < 0.02
    assert r["ages_source"].startswith("demande")


def test_le_verificateur_reconnait_une_valeur_enregistree_et_ignore_les_codes_postaux():
    from poc.services.verificateur import chiffres_du_texte, verifier_synthese

    assert [c.valeur for c in chiffres_du_texte("domicilié 8 allée des Tilleuls, 44300 Nantes ; prix 320 000 €")] == [
        320000.0
    ]
    r = verifier_synthese(
        "La mensualité serait de 1 571,42 € pour un apport de 40 000 € ; le seuil HCSF est de 35 %.",
        [],
        {"apport": 40000.0},
        {"mensualite_25": 1571.42},
        {"HCSF_TAUX_EFFORT_MAX": 35.0},
    )
    assert r.verdict == "ACCEPTE" and "3 par leur valeur" in r.message
    r = verifier_synthese("Le reste à vivre minimum est de 2 000 €.", [], {}, {}, {"RESTE_A_VIVRE_PAR_ADULTE": 1000.0})
    assert r.verdict == "REFUSE" and r.orphelins == ["2 000 €"]


def test_l_atelier_complete_les_entrees_connues_et_suggere_les_noms_proches(config):
    from poc.outils import BackendLocal, ErreurOutil, executer_outil

    b = BackendLocal(config)
    sid = b.ecrire("sessions", {"demande_id": "DEM-0001", "modele": "test"})["session_id"]
    executer_outil(
        b,
        "noter_fait",
        {"session_id": sid, "nom": "apport", "valeur": 40000, "source": {"type": "demande", "champ": "apport"}},
    )
    r = executer_outil(
        b,
        "calculer",
        {
            "session_id": sid,
            "etape": "calculer",
            "sorties": ["reste"],
            "code": "reste = apport - frais",
            "entrees": [{"nom": "frais", "origine": {"type": "constante", "valeur": 23250, "justification": "test"}}],
        },
    )
    assert (
        r[0]["valeur"] == 16750.0
    )  # `apport` non déclaré mais fait de la session : ajouté comme entrée d'origine fait
    entrees = SQLiteStore(config.sqlite_agent).requete(
        "SELECT entrees_json FROM agent_calculs WHERE session_id = ? ORDER BY rowid DESC LIMIT 1", (sid,)
    )["entrees_json"][0]
    assert any(e["nom"] == "apport" and e["origine"]["type"] == "fait" for e in json.loads(entrees))
    with pytest.raises(ErreurOutil) as exc:
        executer_outil(
            b,
            "calculer",
            {
                "session_id": sid,
                "etape": "calculer",
                "sorties": ["x"],
                "code": "x = aport * 2",
                "entrees": [{"nom": "aport", "origine": {"type": "fait", "nom": "aport"}}],
            },
        )
    assert exc.value.code == "FAIT_INCONNU" and "noms proches : apport" in exc.value.message


def test_une_regle_sans_objet_ne_se_juge_pas(config):
    from poc.outils import BackendLocal, ErreurOutil, executer_outil

    b = BackendLocal(config)
    sid = b.ecrire("sessions", {"demande_id": "DEM-0048", "modele": "test"})["session_id"]  # une salariée seule
    with pytest.raises(ErreurOutil) as exc:
        executer_outil(
            b,
            "enregistrer_verdict",
            {"session_id": sid, "regle": "SEUIL_INDEPENDANT", "verdict": "CAS_NON_COUVERT", "justification": "?"},
        )
    assert exc.value.code == "REGLE_SANS_OBJET"
    ok = executer_outil(
        b,
        "enregistrer_verdict",
        {"session_id": sid, "regle": "SEUIL_CDI", "verdict": "DANS_LA_NORME", "justification": "ancienneté suffisante"},
    )
    assert ok["regle"] == "SEUIL_CDI"


def test_noter_doute_tolere_hypotheses_accentuees_et_question_absente(config):
    from poc.outils import BackendLocal, executer_outil

    b = BackendLocal(config)
    sid = b.ecrire("sessions", {"demande_id": "DEM-0001", "modele": "test"})["session_id"]
    r = executer_outil(b, "noter_doute", {"session_id": sid, "objet": "x", "hypothèses": ["a"]})
    assert r["doute_id"].startswith("D")


# ---------------------------------------------------------------------------------------------------------------------
# Les campagnes
# ---------------------------------------------------------------------------------------------------------------------
def test_une_campagne_factice_tourne_se_persiste_et_se_relit(config):
    from poc.evaluation import campagnes, demandes_du_lot, lancer_campagne, sessions_de_campagne

    assert demandes_du_lot(config, "scelle") == ["DEM-0048"]
    with pytest.raises(ValueError):
        demandes_du_lot(config, "inconnu")
    vus = []
    c = lancer_campagne(
        config,
        ["DEM-0001", "DEM-0048"],
        repetitions=2,
        nom="test",
        config_llm=config_factice(),
        rapporter=vus.append,
        publier=False,
    )
    assert len(c.sessions) == 4 and len(vus) == 4
    assert all(s.statut == "REMISE" and not s.erreur for s in c.sessions)
    assert c.pass_1 == 0.0 and c.pass_k == 0.0  # le modèle factice ne calcule ni ne recommande
    r = c.resume()
    assert r["sessions"] == 4 and r["dossiers"] == 2 and r["repetitions"] == 2
    liste = campagnes(config)
    assert liste[0]["campagne_id"] == c.campagne_id and liste[0]["statut"] == "TERMINEE" and liste[0]["nom"] == "test"
    detail = sessions_de_campagne(config, c.campagne_id)
    assert len(detail) == 4 and {d["demande_id"] for d in detail} == {"DEM-0001", "DEM-0048"}
    assert (config.data_dir / "campagnes" / f"{c.campagne_id}.csv").exists()
    # chaque session de la campagne est évaluée et la table des évaluations en garde la trace
    store = SQLiteStore(config.sqlite_agent)
    evals = store.requete("SELECT DISTINCT session_id FROM agent_evaluations")["session_id"].to_list()
    assert all(s.session_id in evals for s in c.sessions)


def test_pass_k_exige_toutes_les_repetitions():
    from poc.evaluation.campagne import Campagne, SessionCampagne

    def s(demande: str, rep: int, ok: bool) -> SessionCampagne:
        return SessionCampagne(
            demande, rep, f"S-{demande}-{rep}", "REMISE", ok, 0, 0, "", "", "", 0, 0, 0, 0, 0, 0, 0.0
        )

    c = Campagne("C", "x", "m", "selection", 2, ["A", "B"], "t")
    c.sessions = [s("A", 1, True), s("A", 2, True), s("B", 1, True), s("B", 2, False)]
    assert c.pass_1 == 0.75 and c.pass_k == 0.5


def test_le_correcteur_ne_note_pas_les_chiffres_d_un_dossier_bloquant(config):
    from poc.agent import lancer_agent
    from poc.evaluation import evaluer_session

    r = lancer_agent(config, "DEM-0027", config_llm=config_factice(), checkpoints=False)
    ev = evaluer_session(config, r.session_id)
    statuts = {m.nom: m.statut for m in ev.mesures}
    assert statuts["taux_effort"] == "NON_EVALUABLE" and statuts["montant_emprunte"] == "NON_CALCULE"
    assert statuts["recommandation"] == "NON_CALCULE"


# ---------------------------------------------------------------------------------------------------------------------
# MCP de bout en bout
# ---------------------------------------------------------------------------------------------------------------------
def test_l_agent_factice_traverse_le_parcours_avec_les_outils_mcp(config, monkeypatch):
    pytest.importorskip("mcp")
    import os

    from poc.agent import lancer_agent
    from poc.mcp import BackendMCP
    from poc.outils import BackendLocal

    monkeypatch.setenv("POC_DATA_DIR", str(config.data_dir))
    env = {**os.environ, "POC_DATA_DIR": str(config.data_dir)}
    with BackendMCP(orchestrateur=BackendLocal(config), env=env) as b:
        r = lancer_agent(config, "DEM-0001", config_llm=config_factice(), backend=b, checkpoints=False)
        assert r.statut == "REMISE" and [x["etape"] for x in r.bilans][-1] == "remettre"
        session = BackendLocal(config).lire("session", session_id=r.session_id)
        assert session["modele"].endswith("+mcp")
        journal = BackendLocal(config).lire("journal", session_id=r.session_id)
        outils = [e for e in journal if e["type"] == "outil"]
        assert outils, "aucun appel d'outil n'a traversé MCP"


def test_debrancher_un_serveur_mcp_rend_ses_outils_inconnus(config):
    pytest.importorskip("mcp")
    import os

    from poc.mcp import BackendMCP
    from poc.outils import BackendLocal, ErreurOutil, executer_outil

    env = {**os.environ, "POC_DATA_DIR": str(config.data_dir)}
    with BackendMCP(orchestrateur=BackendLocal(config), serveurs=("coffre", "banque"), env=env) as b:
        assert b.serveurs_ouverts() == ["coffre", "banque"]
        assert executer_outil(b, "lire_demande", {"demande_id": "DEM-0001"})["demande_id"] == "DEM-0001"
        with pytest.raises(ErreurOutil) as exc:
            executer_outil(b, "noter_doute", {"session_id": "S-X", "objet": "x", "hypotheses": ["a"], "question": "q"})
        assert exc.value.code == "OUTIL_INCONNU"


# ---------------------------------------------------------------------------------------------------------------------
# Les évaluations déposées sur la trace
# ---------------------------------------------------------------------------------------------------------------------
def test_les_evaluations_du_correcteur_deviennent_des_colonnes_eval(config):
    from poc.agent import lancer_agent
    from poc.evaluation import evaluer_session
    from poc.observabilite import ConfigObservabilite
    from poc.observabilite.evaluations import PuitsArize, evaluations_de, publier_evaluation, verdict_envoi

    r = lancer_agent(config, "DEM-0001", config_llm=config_factice(), checkpoints=False)
    ev = evaluer_session(config, r.session_id)
    evals = evaluations_de(ev)
    noms = [e.nom for e in evals]
    assert noms == [
        "chiffres_exacts",
        "taux_effort",
        "recommandation",
        "doutes_attendus",
        "faux_doutes",
        "moments_reflexivite",
        "synthese_verifiee",
        "recommandation_concordante",  # colonnes ajoutées pour que les moniteurs lisent un OUI/NON ou un écart chiffré
        "ecart_taux_effort",
        "conformite",
        "verdict_hcsf",
        "faits_extraits",
        "pieces_demandees",
        "ocr_pieces_numerisees",
        "score_consulte",
        "reussite",
    ]
    assert dict(zip(noms, [e.label for e in evals], strict=True))["reussite"] == "NON"

    class ClientSimule:
        def __init__(self) -> None:
            self.appels: list = []
            self.reponses = [{"unmatched_ids": ["abc"]}, {"records_updated": 1}]

        class spans:  # noqa: N801 — reproduit `client.spans.update_evaluations`
            pass

    client = ClientSimule()

    def update_evaluations(dataframe, project_name, space_id):
        client.appels.append((dataframe, project_name, space_id))
        return client.reponses.pop(0)

    client.spans.update_evaluations = staticmethod(update_evaluations)
    cfg = ConfigObservabilite(
        active=True, backend="arize", projet="p", space_id="s", api_key="k", attente_ingestion_s=100
    )
    puits = PuitsArize(cfg, client=client)
    puits.dormir = lambda s: None
    n = puits.deposer("abc", evals)
    assert n == len(evals) and len(client.appels) == 2  # un essai pendant que le span manque, puis accepté
    df = client.appels[-1][0]
    assert df.loc[0, "context.span_id"] == "abc"
    assert "eval.reussite.label" in df.columns and "eval.chiffres_exacts.score" in df.columns
    assert not any(c.startswith("annotation.") for c in df.columns)
    assert verdict_envoi({"errors": [{"span_id": "abc", "error_message": "no matching span"}]}, "abc") == "SPAN_ABSENT"
    assert verdict_envoi({"errors": [{"error_message": "bad column"}]}, "abc") == "REFUSE"
    # observabilité inactive : rien ne part, sans erreur
    assert publier_evaluation(ConfigObservabilite(), ev, {"span_id": "abc"}) == {"span": 0}


def test_cli_catalogue_campagne_et_evaluations(config, monkeypatch):
    from typer.testing import CliRunner

    from poc.cli import app

    monkeypatch.setenv("POC_DATA_DIR", str(config.data_dir))
    monkeypatch.setenv("COLUMNS", "250")
    runner = CliRunner()
    res = runner.invoke(app, ["donnees", "catalogue", "--lot", "scelle"])
    assert res.exit_code == 0 and "DEM-0048" in res.output and "scelle_celibataire_sain" in res.output
    res = runner.invoke(
        app, ["agent", "campagne", "-d", "DEM-0048", "-m", "factice", "--nom", "cli", "--sans-publication"]
    )
    assert res.exit_code == 0 and "pass@1 = 0%" in res.output, res.output
    res = runner.invoke(app, ["agent", "campagnes"])
    assert res.exit_code == 0 and "cli" in res.output
    cid = [ligne for ligne in res.output.splitlines() if "cli" in ligne][0].split("│")[1].strip()
    res = runner.invoke(app, ["agent", "campagnes", "--detail", cid])
    assert res.exit_code == 0 and "DEM-0048" in res.output
    sid = runner.invoke(app, ["agent", "sessions"]).output
    session = [t for t in sid.split() if t.startswith("S-DEM-0048")][0]
    res = runner.invoke(app, ["obs", "evaluations", session])
    assert res.exit_code == 0 and "eval.reussite" in res.output and "inactive" in res.output
