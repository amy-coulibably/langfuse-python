"""Lot 2 : les guichets et les mains. Les services répondent sur les données du fil rouge, les garde-fous du conseiller
refusent ce qu'ils doivent refuser, les quatre API servent les mêmes réponses que les services (clients de test, sans port),
le registre déclare ses outils avec des schémas valides, et l'agent factice traverse le parcours avec ses nouvelles mains."""

from __future__ import annotations

import pytest
from fastapi.testclient import TestClient

from poc.agent import lancer_agent
from poc.config import Config
from poc.evaluation import evaluer_session
from poc.generateur import generer_tout
from poc.llm import config_factice
from poc.outils import (
    OUTILS,
    BackendLocal,
    ErreurOutil,
    executer_outil,
    outils_pour_etape,
    outils_prevus_absents,
    schema_outils,
)
from poc.outils.backend import BackendHTTP
from poc.services.verificateur import chiffres_du_texte, verifier_synthese


@pytest.fixture(scope="module")
def config(tmp_path_factory) -> Config:
    cfg = Config(data_dir=tmp_path_factory.mktemp("lot2") / "data")
    generer_tout(cfg, demandes=["DEM-0001"])
    return cfg


@pytest.fixture(scope="module")
def local(config) -> BackendLocal:
    return BackendLocal(config)


@pytest.fixture(scope="module")
def http(config) -> BackendHTTP:
    """Le backend HTTP branché sur les quatre applications FastAPI en mémoire : mêmes chemins, pas de port."""
    from poc.api import banque_api, coffre_api, conseiller_api, incidents_api, ocr_api, scoring_api

    clients = {
        "coffre": TestClient(coffre_api.creer(config)),
        "banque": TestClient(banque_api.creer(config)),
        "incidents": TestClient(incidents_api.creer(config)),
        "conseiller": TestClient(conseiller_api.creer(config)),
        "scoring": TestClient(scoring_api.creer(config)),
        "ocr": TestClient(ocr_api.creer(config)),
    }
    return BackendHTTP(clients=clients)


def _session(backend) -> str:
    return backend.ecrire("sessions", {"demande_id": "DEM-0001", "modele": "test"})["session_id"]


def test_le_registre_a_ses_mains_et_le_parcours_les_voit():
    assert len(OUTILS) == 27  # 26 au lot 2, plus consulter_score
    assert outils_prevus_absents("extraire") == [] and outils_prevus_absents("rediger") == []
    assert {o.nom for o in outils_pour_etape("rediger")} >= {
        "enregistrer_synthese",
        "enregistrer_recommandation",
        "lire_dossier_travail",
    }
    for s in schema_outils():
        assert s["input_schema"]["type"] == "object" and s["description"]
    serveurs = {o.serveur_mcp for o in OUTILS.values()}
    assert serveurs == {None, "mcp-coffre", "mcp-banque", "mcp-conseiller"}


@pytest.mark.parametrize("backend_nom", ["local", "http"])
def test_les_guichets_repondent(request, backend_nom):
    b = request.getfixturevalue(backend_nom)
    d = executer_outil(b, "lire_demande", {"demande_id": "DEM-0001"})
    assert (
        d["prix"] == 320000
        and len(d["emprunteurs"]) == 2
        and d["credits_declares_par_le_client"][0]["mensualite_declaree"] == 210
    )
    thomas = next(e["client_id"] for e in d["emprunteurs"] if e["prenom"] == "Thomas")
    assert executer_outil(b, "consulter_client", {"client_id": thomas})["employeur"] == "Logistique Ouest SAS"
    comptes = executer_outil(b, "consulter_comptes", {"client_id": thomas})
    assert [c["compte_id"] for c in comptes] == ["CPT-THOMAS"]  # le compte joint est ailleurs
    m = executer_outil(b, "consulter_mouvements", {"compte_id": "CPT-THOMAS", "motif": "SALAIRE"})
    assert [x["montant"] for x in m["mouvements"]] == [5100.0, 2700.0, 2700.0]
    assert executer_outil(b, "consulter_credits", {"client_id": thomas})["credits_de_la_banque"] == []
    assert executer_outil(b, "consulter_epargne", {"client_id": thomas})[0]["solde"] in (12000.0, 28000.0)
    assert executer_outil(b, "consulter_incidents", {"client_id": thomas})["conclusion"] == "aucun incident connu"
    assert executer_outil(b, "consulter_bareme", {"duree_annees": 25})["taux_nominal_pct_par_duree"] == {"25": 3.4}
    assert "SEUIL_INDEPENDANT" in executer_outil(b, "consulter_politique", {"nom": "politique_credit"})["contenu"]
    pieces = executer_outil(b, "lister_pieces", {"demande_id": "DEM-0001"})
    fiche = next(p for p in pieces if p["type"] == "fiche_paie" and p["periode"] == "2026-07")
    lecture = executer_outil(b, "lire_piece", {"demande_id": "DEM-0001", "piece": fiche["piece_id"]})
    assert any("3 200,00" in ligne["texte"] for ligne in lecture["lignes"]) and lecture["lignes"][0]["n"] == 1
    assert executer_outil(b, "ocr_piece", {"demande_id": "DEM-0001", "piece": fiche["piece_id"]})["ocr"] is False
    with pytest.raises(ErreurOutil) as exc:
        executer_outil(b, "lire_piece", {"demande_id": "DEM-0001", "piece": "P99"})
    assert exc.value.code == "INTROUVABLE"
    with pytest.raises(ErreurOutil) as exc:
        executer_outil(b, "consulter_bareme", {"duree_annees": 17})
    assert exc.value.code == "DUREE_HORS_BAREME"


@pytest.mark.parametrize("backend_nom", ["local", "http"])
def test_les_garde_fous_du_conseiller(request, backend_nom):
    b = request.getfixturevalue(backend_nom)
    sid = _session(b)
    pieces = executer_outil(b, "lister_pieces", {"demande_id": "DEM-0001"})
    p07 = next(p["piece_id"] for p in pieces if p["type"] == "fiche_paie" and p["periode"] == "2026-07")
    # règle 2 : un fait a une source vérifiée, et la valeur est dans l'extrait
    f = executer_outil(
        b,
        "noter_fait",
        {
            "session_id": sid,
            "nom": "net_paye_thomas_2026_07",
            "valeur": 3200,
            "source": {"type": "piece", "piece": p07, "extrait": "NET PAYÉ 3 200,00 €"},
        },
    )
    assert f["reference"] == f"piece:{p07}"
    for source, code in (
        ({"type": "piece", "piece": p07, "extrait": "NET PAYÉ 4 500,00 €"}, "SOURCE_INTROUVABLE"),
        ({"type": "piece", "piece": p07, "extrait": "NET PAYÉ"}, "VALEUR_HORS_EXTRAIT"),
        ({"type": "mouvement", "compte_id": "CPT-THOMAS", "date": "2026-07-28", "montant": 9999}, "SOURCE_INTROUVABLE"),
        ({"type": "demande", "champ": "apport"}, "VALEUR_HORS_EXTRAIT"),
        ({"type": "sorcellerie"}, "PARAMETRES_INVALIDES"),
    ):
        with pytest.raises(ErreurOutil) as exc:
            executer_outil(b, "noter_fait", {"session_id": sid, "nom": "x", "valeur": 3200, "source": source})
        assert exc.value.code == code, source
    # règle 4 : une valeur contradictoire sans doute est refusée ; avec un doute, elle passe
    with pytest.raises(ErreurOutil) as exc:
        executer_outil(
            b,
            "noter_fait",
            {
                "session_id": sid,
                "nom": "net_paye_thomas_2026_07",
                "valeur": 2700,
                "source": {"type": "mouvement", "compte_id": "CPT-THOMAS", "date": "2026-07-28", "montant": 2700},
            },
        )
    assert exc.value.code == "ECART_SANS_DOUTE"
    with pytest.raises(ErreurOutil) as exc:
        executer_outil(b, "noter_doute", {"session_id": sid, "objet": "écart", "hypotheses": [], "question": "?"})
    assert exc.value.code == "DOUTE_INCOMPLET"
    executer_outil(
        b,
        "noter_doute",
        {
            "session_id": sid,
            "objet": "écart entre fiche de paie et virements",
            "hypotheses": ["virement scindé sur un autre compte", "saisie sur salaire"],
            "question": "Où va la différence de 500 € ?",
            "faits_concernes": ["net_paye_thomas_2026_07"],
        },
    )
    executer_outil(
        b,
        "noter_fait",
        {
            "session_id": sid,
            "nom": "net_paye_thomas_2026_07",
            "valeur": 2700,
            "source": {"type": "mouvement", "compte_id": "CPT-THOMAS", "date": "2026-07-28", "montant": 2700},
        },
    )
    executer_outil(
        b,
        "noter_fait",
        {"session_id": sid, "nom": "apport", "valeur": 40000, "source": {"type": "demande", "champ": "apport"}},
    )
    executer_outil(
        b,
        "noter_fait",
        {
            "session_id": sid,
            "nom": "net_paye_fiche_thomas_2026_07",
            "valeur": 3200,
            "source": {"type": "piece", "piece": p07, "extrait": "NET PAYÉ 3 200,00 €"},
        },
    )
    executer_outil(
        b,
        "noter_fait",
        {
            "session_id": sid,
            "nom": "credit_auto",
            "valeur": 210,
            "source": {"type": "credit_declare", "organisme": "Crédit Fictif Auto"},
        },
    )
    # le simulateur archive ses résultats dans la feuille de calcul
    sim = executer_outil(
        b, "simuler_pret", {"session_id": sid, "montant": 303250, "duree_annees": 25, "ages": [36, 34]}
    )
    assert abs(sim["mensualite_assurance_comprise"] - 1571.42) < 0.02 and "mensualite_25" in sim["resultats_archives"]
    assert any(c["nom_resultat"] == "mensualite_25" for c in executer_outil(b, "lire_calculs", {"session_id": sid}))
    # un message au client, une ligne de grille
    msg = executer_outil(
        b,
        "demander_piece",
        {
            "session_id": sid,
            "piece": "fiche de paie d'août 2026",
            "personne": "Thomas",
            "periode": "2026-08",
            "motif": "Elle manque au dossier.",
        },
    )
    assert msg["statut"] == "ENVOYE" and "août 2026" in msg["texte"]
    executer_outil(
        b,
        "enregistrer_verdict",
        {
            "session_id": sid,
            "regle": "seuil_independant",
            "verdict": "CAS_NON_COUVERT",
            "justification": "14 mois d'activité, la règle en demande 24",
        },
    )
    with pytest.raises(ErreurOutil) as exc:
        executer_outil(
            b, "enregistrer_verdict", {"session_id": sid, "regle": "X", "verdict": "PEUT_ETRE", "justification": "?"}
        )
    assert exc.value.code == "PARAMETRES_INVALIDES"
    # règle 1 et 2 sur la synthèse : chiffres sourcés, pas d'avis
    corps = (
        "## Foyer et projet\n"
        + "Thomas est responsable d'exploitation en CDI depuis six ans ; Marie est graphiste indépendante depuis quatorze mois. "
        * 3
    )
    texte = (
        corps
        + "\n## Capacité\nLe net payé de Thomas est de 3 200,00 € ; la mensualité à 25 ans serait de 1 571,42 €, avec un apport de 40 000 €."
    )
    with pytest.raises(ErreurOutil) as exc:
        executer_outil(
            b,
            "enregistrer_synthese",
            {
                "session_id": sid,
                "texte": texte + " Les frais de dossier seraient de 1 234,56 €.",  # un chiffre qui n'existe nulle part
                "chiffres": [{"texte": "3 200,00 €", "type": "fait", "nom": "net_paye_fiche_thomas_2026_07"}],
            },
        )
    assert exc.value.code == "CHIFFRE_ORPHELIN" and "1 234,56" in exc.value.message
    assert "1 571,42" not in exc.value.message  # égal à mensualite_25 : sourcé par sa valeur, même sans citation
    with pytest.raises(ErreurOutil) as exc:
        executer_outil(
            b, "enregistrer_synthese", {"session_id": sid, "texte": texte + " Avis favorable.", "chiffres": []}
        )
    assert exc.value.code == "AVIS_INTERDIT"
    chiffres = [
        {"texte": "3 200,00 €", "type": "fait", "nom": "net_paye_fiche_thomas_2026_07"},
        {"texte": "1 571,42 €", "type": "calcul", "nom": "mensualite_25"},
        {"texte": "40 000 €", "type": "fait", "nom": "apport"},
    ]
    with pytest.raises(ErreurOutil) as exc:
        executer_outil(
            b,
            "enregistrer_synthese",
            {
                "session_id": sid,
                "texte": texte,
                "chiffres": [{"texte": "3 200,00 €", "type": "fait", "nom": "apport"}, *chiffres[1:]],
            },
        )
    assert exc.value.code == "CITATION_FAUSSE"
    ok = executer_outil(b, "enregistrer_synthese", {"session_id": sid, "texte": texte, "chiffres": chiffres})
    assert ok["statut"] == "VERIFIEE" and ok["verification"]["nb_chiffres"] == 3
    # règle 1 sur la recommandation : pas de position tranchée avec un cas non couvert ; motifs sourcés ; réserves exigées
    motifs = [
        {"texte": "mensualité compatible", "type": "calcul", "nom": "mensualite_25"},
        {"texte": "indépendante récente", "type": "verdict", "nom": "SEUIL_INDEPENDANT"},
    ]
    for corps_reco, code in (
        ({"position": "FAVORABLE", "motifs": motifs}, "TRANCHE_MALGRE_RESERVE"),
        (
            {
                "position": "FAVORABLE_SOUS_RESERVES",
                "motifs": [{"texte": "x", "type": "fait", "nom": "inexistant"}],
                "reserves": [{"code": "A", "texte": "a"}],
            },
            "MOTIF_SANS_SOURCE",
        ),
        ({"position": "FAVORABLE_SOUS_RESERVES", "motifs": motifs}, "RESERVES_MANQUANTES"),
    ):
        with pytest.raises(ErreurOutil) as exc:
            executer_outil(b, "enregistrer_recommandation", {"session_id": sid, **corps_reco})
        assert exc.value.code == code, corps_reco
    reco = executer_outil(
        b,
        "enregistrer_recommandation",
        {
            "session_id": sid,
            "position": "FAVORABLE_SOUS_RESERVES",
            "motifs": motifs,
            "reserves": [
                {"code": "REVENUS_NON_COUVERTS", "texte": "Marie a 14 mois d'activité"},
                {"code": "PIECE_MANQUANTE", "texte": "fiche de paie d'août"},
            ],
            "conditions": ["recevoir la fiche d'août"],
        },
    )
    assert reco["position"] == "FAVORABLE_SOUS_RESERVES"
    dossier = executer_outil(b, "lire_dossier_travail", {"session_id": sid})
    assert (
        dossier["synthese"]
        and dossier["recommandation"]["position"] == "FAVORABLE_SOUS_RESERVES"
        and len(dossier["faits"]) == 5
    )
    assert executer_outil(b, "remettre_dossier", {"session_id": sid})["statut"] == "REMISE"


def test_le_correcteur_lit_maintenant_toutes_les_tables(config, local):
    sid = _session(local)
    executer_outil(
        local,
        "noter_fait",
        {"session_id": sid, "nom": "apport", "valeur": 40000, "source": {"type": "demande", "champ": "apport"}},
    )
    executer_outil(
        local,
        "noter_doute",
        {
            "session_id": sid,
            "objet": "Marie est indépendante depuis 14 mois",
            "hypotheses": ["cas non couvert"],
            "question": "Le conseiller retient-il ses revenus ?",
        },
    )
    executer_outil(
        local,
        "noter_doute",
        {"session_id": sid, "objet": "la couleur du dossier", "hypotheses": ["bleu"], "question": "?"},
    )
    executer_outil(
        local,
        "demander_piece",
        {"session_id": sid, "piece": "fiche de paie", "personne": "Thomas", "periode": "2026-08", "motif": "manquante"},
    )
    executer_outil(
        local,
        "enregistrer_verdict",
        {"session_id": sid, "regle": "HCSF_DUREE", "verdict": "DANS_LA_NORME", "justification": "25 ans"},
    )
    ev = evaluer_session(config, sid)
    statuts = {m.nom: m for m in ev.mesures}
    assert statuts["faits_extraits"].obtenu == 1 and statuts["faits_extraits"].statut == "ECART"
    assert ev.doutes_attendus_trouves == 1 and ev.faux_doutes == 1 and ev.moments["CAS_NON_COUVERT_INDEPENDANT"] is True
    assert statuts["pieces_manquantes_demandees"].statut == "EXACT"
    assert (
        statuts["verdicts"].obtenu == 1
        and statuts["recommandation"].statut == "NON_CALCULE"
        and statuts["synthese_produite"].statut == "NON_CALCULE"
    )


def test_verificateur_de_synthese():
    texte = "Signé le 28/08/2026. Prix 320 000 €, soit 33,5 % d'effort sur 25 ans ; 14 mois d'activité ; année 2026 ; 150 opérations."
    detectes = [c.brut for c in chiffres_du_texte(texte)]
    assert detectes == ["320 000 €", "33,5 %", "150"]  # ni la date, ni 25 ans, ni 14 mois, ni l'année
    r = verifier_synthese(
        texte,
        [
            {"texte": "320 000 €", "type": "fait", "nom": "prix"},
            {"texte": "33,5 %", "type": "calcul", "nom": "taux"},
            {"texte": "150", "type": "fait", "nom": "ops"},
        ],
        {"prix": 320000.0, "ops": 150.0},
        {"taux": 33.46},
    )
    assert r.verdict == "ACCEPTE" and r.nb_cites == 3
    r2 = verifier_synthese(texte, [{"texte": "320 000 €", "type": "fait", "nom": "prix"}], {"prix": 320000.0}, {})
    assert r2.verdict == "REFUSE" and r2.orphelins == ["33,5 %", "150"]


def test_l_agent_factice_traverse_le_parcours_avec_ses_mains(config):
    r = lancer_agent(config, "DEM-0001", config_llm=config_factice(), checkpoints=False)
    assert r.statut == "REMISE" and all(not b["erreurs"] for b in r.bilans)
    traces = BackendLocal(config).lire("traces", session_id=r.session_id)
    appels = {t["nom"] for t in traces if t["type"] == "outil"}
    assert {"lire_demande", "lister_pieces", "consulter_politique", "lire_faits", "lire_dossier_travail"} <= appels
    assert all(not t["detail"]["erreur"] for t in traces if t["type"] == "outil")


def test_verificateur_cite_les_regles_et_les_doutes():
    """Un seuil de règle (35 %, abattement de 34 %) et un écart constaté dans un doute (500 €) sont des sources acceptées."""
    from poc.generateur.referentiels import constantes_des_regles

    regles = constantes_des_regles()
    assert (
        regles["HCSF_TAUX_EFFORT_MAX"] == 35.0
        and regles["ABATTEMENT_MICRO_BNC"] == 34.0
        and "TAUX_NOMINAL_25_ANS" in regles
    )
    texte = "Le plafond est de 35 % ; l'abattement de 34 % ; l'écart constaté est de 500 € par mois ; apport 40 000 €."
    chiffres = [
        {"texte": "35 %", "type": "regle", "nom": "HCSF_TAUX_EFFORT_MAX"},
        {"texte": "34 %", "type": "regle", "nom": "ABATTEMENT_MICRO_BNC"},
        {"texte": "500 €", "type": "doute", "nom": "D1"},
        {"texte": "40 000 €", "type": "fait", "nom": "apport"},
    ]
    doutes = {"D1": "écart de 500 € entre la fiche de paie et les virements"}
    assert verifier_synthese(texte, chiffres, {"apport": 40000.0}, {}, regles, doutes).verdict == "ACCEPTE"
    faux = [
        {"texte": "35 %", "type": "regle", "nom": "INCONNUE"},
        {"texte": "500 €", "type": "doute", "nom": "D1"},
        *chiffres[1:2],
        chiffres[3],
    ]
    r = verifier_synthese(texte, faux, {"apport": 40000.0}, {}, regles, doutes)
    assert r.verdict == "REFUSE" and any("INCONNUE" in c for c in r.citations_fausses)
    r2 = verifier_synthese(
        texte,
        [*chiffres[:2], {"texte": "500 €", "type": "doute", "nom": "D1"}, chiffres[3]],
        {"apport": 40000.0},
        {},
        regles,
        {"D1": "écart de 700 €"},
    )
    assert r2.verdict == "REFUSE" and r2.orphelins == ["500 €"]


def test_recadrage_apres_refus_repetes(config):
    """Un modèle qui s'obstine sur un outil refusé reçoit un message de recadrage au troisième refus, et perd l'outil au sixième."""
    from poc.llm import AppelOutil, ReponseLLM

    compteur = {"n": 0}

    def obstine(systeme, messages, outils):
        compteur["n"] += 1
        noms = {o["name"] for o in outils or []}
        if "noter_fait" in noms and compteur["n"] <= 8:
            return ReponseLLM(
                texte="J'enregistre l'apport.",
                appels=[
                    AppelOutil(
                        id=f"a{compteur['n']}",
                        nom="noter_fait",
                        parametres={
                            "nom": "apport",
                            "valeur": 999 + compteur["n"],
                            "source": {"type": "demande", "champ": "apport"},
                        },
                    )
                ],
                tokens_entree=10,
                tokens_sortie=5,
                duree_ms=1,
                modele="factice",
                fin="tool_use",
            )
        return ReponseLLM(
            texte='{"resume": "fin", "points_cles": [], "doutes": [], "bloquant": false}',
            appels=[],
            tokens_entree=10,
            tokens_sortie=5,
            duree_ms=1,
            modele="factice",
            fin="end_turn",
        )

    r = lancer_agent(config, "DEM-0001", config_llm=config_factice(), scenario_factice=obstine, checkpoints=False)
    journal = BackendLocal(config).lire("journal", session_id=r.session_id)
    garde_fous = [e["texte"] for e in journal if e["type"] == "garde_fou"]
    assert any("recadrage" in t for t in garde_fous) and any("retiré pour cette étape" in t for t in garde_fous)
    assert r.statut == "REMISE"


def test_un_ecart_cite_par_un_doute_peut_etre_une_difference():
    doutes = {"D1": "écart entre le net payé (3 200 € en juillet 2026) et les virements reçus (2 700 €)"}
    r = verifier_synthese(
        "L'écart est de 500 € par mois.", [{"texte": "500 €", "type": "doute", "nom": "D1"}], {}, {}, {}, doutes
    )
    assert r.verdict == "ACCEPTE"


def test_le_recadrage_attend_la_fin_du_tour(config):
    """Quatre appels refusés dans une même réponse : le message de recadrage vient après les quatre résultats d'outils, jamais
    entre deux (les fournisseurs refusent un message « user » suivi d'un résultat d'outil : session du 6 novembre 2026)."""
    from poc.llm import AppelOutil, ReponseLLM

    vus: list[list] = []

    def rafale(systeme, messages, outils):
        vus.append([m.role for m in messages])
        noms = {o["name"] for o in outils or []}
        if "noter_fait" in noms and len(vus) == 1:
            appels = [
                AppelOutil(
                    id=f"r{i}",
                    nom="noter_fait",
                    parametres={"nom": "apport", "valeur": 1000 + i, "source": {"type": "demande", "champ": "apport"}},
                )
                for i in range(4)
            ]
            return ReponseLLM(
                texte="J'enregistre.",
                appels=appels,
                tokens_entree=10,
                tokens_sortie=5,
                duree_ms=1,
                modele="factice",
                fin="tool_use",
            )
        return ReponseLLM(
            texte='{"resume": "fin", "points_cles": [], "doutes": [], "bloquant": false}',
            appels=[],
            tokens_entree=10,
            tokens_sortie=5,
            duree_ms=1,
            modele="factice",
            fin="end_turn",
        )

    lancer_agent(config, "DEM-0001", config_llm=config_factice(), scenario_factice=rafale, checkpoints=False)
    second = vus[1]
    assert second[-5:] == ["tool", "tool", "tool", "tool", "user"]  # quatre résultats, puis le recadrage
    assert not any(a == "user" and b == "tool" for a, b in zip(second, second[1:], strict=False))
