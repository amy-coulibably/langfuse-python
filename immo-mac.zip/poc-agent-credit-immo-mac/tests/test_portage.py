"""Le portage sur un nouveau poste (Mac de la banque) : tout se règle dans `.env`. Configuration des modèles interpolée,
autorité interne unique pour la passerelle, l'exportateur des traces, la sonde et le SDK Arize (vérifiée en vrai TLS),
masquage effectif des contenus, span racine renseigné, colonnes eval.* validées par le SDK Arize s'il est installé,
sélections de dossiers, vérifications du poste."""

from __future__ import annotations

import datetime as dt
import http.server
import json
import ssl
import threading
from types import SimpleNamespace

import pytest

from poc.config import RACINE, Config
from poc.generateur import generer_tout
from poc.llm import config_factice


@pytest.fixture(scope="module")
def config(tmp_path_factory) -> Config:
    cfg = Config(data_dir=tmp_path_factory.mktemp("portage") / "data")
    generer_tout(cfg, demandes=["DEM-0001", "DEM-0002", "DEM-0037"])
    return cfg


# ---------------------------------------------------------------------------------------------------------------------
# La configuration des modèles vient du .env
# ---------------------------------------------------------------------------------------------------------------------
def test_interpolation_des_variables():
    from poc.llm.config import interpoler

    env = {"A": "x", "VIDE": ""}
    assert (
        interpoler("${A}", env) == "x" and interpoler("${ABSENTE}", env) is None and interpoler("${VIDE}", env) is None
    )
    assert interpoler("${ABSENTE:-defaut}", env) == "defaut" and interpoler("${ABSENTE:-}", env) == ""
    assert interpoler("https://${H:-hote}:${P:-443}/v1", env) == "https://hote:443/v1"
    assert interpoler({"k": ["${A}", 3]}, env) == {"k": ["x", 3]}


def test_la_passerelle_se_regle_entierement_dans_l_environnement(monkeypatch):
    from poc.llm import charger_config_llm

    for v in (
        "LLM_MODELE_DEFAUT",
        "LLM_URL",
        "LLM_MODELE",
        "LLM_EN_TETES",
        "LLM_TIMEOUT_S",
        "LLM_PRIX_ENTREE_PAR_MILLION",
    ):
        monkeypatch.delenv(v, raising=False)
    cfg = charger_config_llm()
    m = cfg.modeles["passerelle_banque"]
    assert cfg.defaut == "principal" and m.en_tetes == {} and m.certificat_ca is None and m.prix_connu is False
    monkeypatch.setenv("LLM_MODELE_DEFAUT", "passerelle_banque")
    monkeypatch.setenv("LLM_URL", "https://passerelle.exemple.test/v1")
    monkeypatch.setenv("LLM_MODELE", "modele-x")
    monkeypatch.setenv("LLM_EN_TETES", '{"X-Application": "poc"}')
    monkeypatch.setenv("LLM_TIMEOUT_S", "90")
    monkeypatch.setenv("LLM_PRIX_ENTREE_PAR_MILLION", "1.5")
    cfg = charger_config_llm()
    m = cfg.modele_pour("calculer")  # aucune étape n'a de rôle propre : toutes prennent le modèle par défaut
    assert (m.nom_logique, m.nom, m.url, m.timeout_s) == (
        "passerelle_banque",
        "modele-x",
        "https://passerelle.exemple.test/v1",
        90.0,
    )
    assert m.en_tetes == {"X-Application": "poc"} and m.prix_connu and m.cle_api_env == "LLM_API_KEY"
    monkeypatch.setenv("LLM_EN_TETES", "pas du json")
    with pytest.raises(ValueError):
        charger_config_llm()


# ---------------------------------------------------------------------------------------------------------------------
# Une seule autorité interne, en vrai TLS
# ---------------------------------------------------------------------------------------------------------------------
def _autorite_et_serveur(dossier):
    """Une autorité de certification et un certificat serveur pour localhost, signés par elle."""
    crypto = pytest.importorskip("cryptography")  # noqa: F841
    from cryptography import x509
    from cryptography.hazmat.primitives import hashes, serialization
    from cryptography.hazmat.primitives.asymmetric import ec
    from cryptography.x509.oid import NameOID

    maintenant = dt.datetime.now(dt.UTC)
    cle_ca = ec.generate_private_key(ec.SECP256R1())
    nom_ca = x509.Name([x509.NameAttribute(NameOID.COMMON_NAME, "Autorite interne de test")])
    ca = (
        x509.CertificateBuilder()
        .subject_name(nom_ca)
        .issuer_name(nom_ca)
        .public_key(cle_ca.public_key())
        .serial_number(x509.random_serial_number())
        .not_valid_before(maintenant - dt.timedelta(days=1))
        .not_valid_after(maintenant + dt.timedelta(days=2))
        .add_extension(x509.BasicConstraints(ca=True, path_length=None), critical=True)
        .add_extension(x509.KeyUsage(True, False, False, False, False, True, True, False, False), critical=True)
        .add_extension(x509.SubjectKeyIdentifier.from_public_key(cle_ca.public_key()), critical=False)
        .sign(cle_ca, hashes.SHA256())
    )
    cle_srv = ec.generate_private_key(ec.SECP256R1())
    import ipaddress

    srv = (
        x509.CertificateBuilder()
        .subject_name(x509.Name([x509.NameAttribute(NameOID.COMMON_NAME, "localhost")]))
        .issuer_name(nom_ca)
        .public_key(cle_srv.public_key())
        .serial_number(x509.random_serial_number())
        .not_valid_before(maintenant - dt.timedelta(days=1))
        .not_valid_after(maintenant + dt.timedelta(days=2))
        .add_extension(
            x509.SubjectAlternativeName([x509.DNSName("localhost"), x509.IPAddress(ipaddress.ip_address("127.0.0.1"))]),
            critical=False,
        )
        .add_extension(x509.BasicConstraints(ca=False, path_length=None), critical=True)
        .add_extension(x509.ExtendedKeyUsage([x509.oid.ExtendedKeyUsageOID.SERVER_AUTH]), critical=False)
        .add_extension(x509.AuthorityKeyIdentifier.from_issuer_public_key(cle_ca.public_key()), critical=False)
        .sign(cle_ca, hashes.SHA256())
    )
    chemin_ca = dossier / "ca-bundle.crt"
    chemin_ca.write_bytes(ca.public_bytes(serialization.Encoding.PEM))
    chemin_cert = dossier / "serveur.pem"
    chemin_cert.write_bytes(
        srv.public_bytes(serialization.Encoding.PEM)
        + cle_srv.private_bytes(
            serialization.Encoding.PEM, serialization.PrivateFormat.PKCS8, serialization.NoEncryption()
        )
    )
    return chemin_ca, chemin_cert


class _Collecteur(http.server.BaseHTTPRequestHandler):
    recus: list = []

    def do_POST(self):  # noqa: N802
        n = int(self.headers.get("content-length") or 0)
        _Collecteur.recus.append(
            {"chemin": self.path, "en_tetes": dict(self.headers), "taille": len(self.rfile.read(n))}
        )
        self.send_response(200)
        self.send_header("content-type", "application/x-protobuf")
        self.end_headers()

    def log_message(self, *args):
        pass


@pytest.fixture()
def collecteur_tls(tmp_path):
    chemin_ca, chemin_cert = _autorite_et_serveur(tmp_path)
    serveur = http.server.ThreadingHTTPServer(("127.0.0.1", 0), _Collecteur)
    contexte = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
    contexte.load_cert_chain(str(chemin_cert))
    serveur.socket = contexte.wrap_socket(serveur.socket, server_side=True)
    fil = threading.Thread(target=serveur.serve_forever, daemon=True)
    fil.start()
    _Collecteur.recus = []
    yield f"https://localhost:{serveur.server_address[1]}/v1/traces", chemin_ca
    serveur.shutdown()


def test_la_sonde_refuse_sans_l_autorite_et_passe_avec(collecteur_tls, monkeypatch):
    from poc.observabilite import ConfigObservabilite
    from poc.observabilite.sonde import sonder_collecteur

    endpoint, chemin_ca = collecteur_tls
    for v in (
        "OBS_CA_BUNDLE",
        "OTEL_EXPORTER_OTLP_TRACES_CERTIFICATE",
        "OTEL_EXPORTER_OTLP_CERTIFICATE",
        "POC_CA_BUNDLE",
        "REQUESTS_CA_BUNDLE",
    ):
        monkeypatch.delenv(v, raising=False)
    cfg = ConfigObservabilite(active=True, backend="arize", endpoint=endpoint, api_key="cle", space_id="espace")
    code, detail = sonder_collecteur(cfg, delai_s=5)
    assert code is None and "certificat refusé" in detail and "POC_CA_BUNDLE" in detail
    monkeypatch.setenv("POC_CA_BUNDLE", str(chemin_ca))
    code, detail = sonder_collecteur(cfg, delai_s=5)
    assert code == 200, detail
    assert _Collecteur.recus[-1]["en_tetes"].get("space_id") == "espace"  # les en-têtes d'authentification d'Arize


def test_l_autorite_relative_est_posee_en_absolu_pour_l_exportateur(monkeypatch, tmp_path):
    from poc.observabilite import adaptateur
    from poc.observabilite.config import autorite_interne

    for v in (
        "OBS_CA_BUNDLE",
        "OTEL_EXPORTER_OTLP_TRACES_CERTIFICATE",
        "OTEL_EXPORTER_OTLP_CERTIFICATE",
        "REQUESTS_CA_BUNDLE",
    ):
        monkeypatch.delenv(v, raising=False)
    monkeypatch.setenv("POC_CA_BUNDLE", "ca-bundle.crt")
    ca, variable = autorite_interne()
    assert ca == RACINE / "ca-bundle.crt" and variable == "POC_CA_BUNDLE"  # relatif = depuis la racine du projet
    absolu = tmp_path / "autorite.crt"
    absolu.write_text("-----BEGIN CERTIFICATE-----\n", encoding="utf-8")
    monkeypatch.setenv("POC_CA_BUNDLE", str(absolu))
    adaptateur.poser_autorite_interne()
    import os

    assert os.environ["OTEL_EXPORTER_OTLP_CERTIFICATE"] == str(absolu)  # l'exportateur OTLP ne lit que ce chemin absolu


def test_le_client_arize_prend_l_hote_le_port_et_l_autorite(monkeypatch, tmp_path):
    from poc.observabilite import ConfigObservabilite
    from poc.observabilite.evaluations import options_client_arize

    ca = tmp_path / "ca.crt"
    ca.write_text("x", encoding="utf-8")
    monkeypatch.setenv("POC_CA_BUNDLE", str(ca))
    for v in ("OBS_CA_BUNDLE", "OTEL_EXPORTER_OTLP_TRACES_CERTIFICATE", "OTEL_EXPORTER_OTLP_CERTIFICATE"):
        monkeypatch.delenv(v, raising=False)
    cfg = ConfigObservabilite(
        active=True, backend="arize", endpoint="https://ax.interne.test:8443/v1/traces", api_key="k"
    )
    o = options_client_arize(cfg)
    assert o == {
        "api_key": "k",
        "single_host": "ax.interne.test",
        "single_port": 8443,
        "api_scheme": "https",
        "ssl_ca_cert": str(ca),
    }
    o = options_client_arize(cfg.model_copy(update={"arize_hote": "flight.interne.test", "arize_port": 443}))
    assert o["single_host"] == "flight.interne.test" and o["single_port"] == 443


def test_un_echec_du_sdk_arize_se_dit_en_une_phrase(capsys):
    from poc.observabilite import ConfigObservabilite
    from poc.observabilite.evaluations import EvaluationTrace, PuitsArize, resumer_erreur_sdk

    assert "OBS_ARIZE_HOTE" in resumer_erreur_sdk(
        RuntimeError("Flight returned unavailable error: failed to connect"), "h:1"
    )
    assert "POC_CA_BUNDLE" in resumer_erreur_sdk(RuntimeError("SSL handshake failed: CERTIFICATE_VERIFY_FAILED"), "h:1")
    assert "OBS_API_KEY" in resumer_erreur_sdk(RuntimeError("Unauthenticated"), "h:1")

    class Client:
        class spans:  # noqa: N801
            @staticmethod
            def update_evaluations(**_):
                raise RuntimeError(
                    "Flight returned unavailable error, with message: failed to connect to all addresses"
                )

    cfg = ConfigObservabilite(
        active=True, backend="arize", endpoint="https://ax.test:8443/v1/traces", api_key="k", space_id="s"
    )
    puits = PuitsArize(cfg, client=Client())
    assert puits.deposer("abc", [EvaluationTrace("reussite", "NON", 0.0)]) == 0
    assert "Flight injoignable sur ax.test:8443" in puits.derniere_erreur
    sortie = capsys.readouterr().err
    assert "Traceback" not in sortie and len(sortie.strip().splitlines()) == 1  # une ligne, pas une pile


def test_les_colonnes_eval_passent_les_validations_du_sdk_arize(config):
    pytest.importorskip("arize")
    import pandas as pd
    from arize.spans.validation.evals import evals_validation

    from poc.agent import lancer_agent
    from poc.evaluation import evaluer_session
    from poc.observabilite.evaluations import PuitsArize, evaluations_de

    r = lancer_agent(config, "DEM-0001", config_llm=config_factice(), checkpoints=False)
    df = pd.DataFrame([PuitsArize.ligne("0123456789abcdef", evaluations_de(evaluer_session(config, r.session_id)))])
    assert evals_validation.validate_argument_types(evals_dataframe=df, project_name="agent-credit-immo") == []
    assert evals_validation.validate_dataframe_form(evals_dataframe=df) == []
    assert evals_validation.validate_values(evals_dataframe=df, project_name="agent-credit-immo") == []


# ---------------------------------------------------------------------------------------------------------------------
# Ce que la trace porte : masquage effectif, racine renseignée
# ---------------------------------------------------------------------------------------------------------------------
@pytest.fixture()
def memoire(monkeypatch):
    pytest.importorskip("ml_utils.observability")
    from ml_utils.observability import ArizeManager

    from poc.observabilite import ConfigObservabilite, Observabilite, adaptateur, reinitialiser
    from poc.observabilite.config import vers_config_ml_utils
    from tests.test_observabilite import BackendMemoire

    def construire(contenu: bool):
        reinitialiser()
        cfg = ConfigObservabilite(
            active=True, backend="phoenix", endpoint="http://memoire/v1/traces", projet="test", contenu_messages=contenu
        )
        backend = BackendMemoire()
        manager = ArizeManager(vers_config_ml_utils(cfg), backend=backend)
        monkeypatch.setattr(adaptateur, "_INSTANCE", Observabilite(cfg, manager))
        return backend.exporteur

    yield construire
    reinitialiser()


def test_contenu_messages_faux_masque_vraiment_les_contenus(config, memoire):
    from poc.agent import lancer_agent
    from poc.observabilite.adaptateur import MASQUE

    exporteur = memoire(False)
    lancer_agent(config, "DEM-0001", config_llm=config_factice(), checkpoints=False)
    spans = exporteur.get_finished_spans()
    llm = [s for s in spans if (s.attributes or {}).get("openinference.span.kind") == "LLM"]
    outils = [s for s in spans if (s.attributes or {}).get("openinference.span.kind") == "TOOL"]
    assert llm and outils
    for s in llm:
        a = dict(s.attributes)
        contenus = [v for k, v in a.items() if k.endswith("message.content") or k.endswith("function.arguments")]
        assert contenus and all(v == MASQUE for v in contenus)
    assert all(dict(s.attributes)["tool.parameters"] == MASQUE for s in outils)
    # aucun texte de fiche (consigne) ni de pièce ne part, nulle part dans les attributs
    tout = json.dumps([dict(s.attributes) for s in spans], ensure_ascii=False)
    assert "Règles communes" not in tout and "NET PAYÉ" not in tout


def test_la_racine_porte_dimensions_versions_et_signaux(config, memoire):
    from poc.agent import lancer_agent
    from poc.versions import empreinte_savoir

    exporteur = memoire(True)
    lancer_agent(config, "DEM-0001", config_llm=config_factice(), checkpoints=False)
    racine = next(s for s in exporteur.get_finished_spans() if s.name == "agent-credit-immo")
    a = dict(racine.attributes)
    assert (a["poc.lot"], a["poc.scenario"], a["poc.difficulte"]) == ("reglage", "fil_rouge", 3)
    assert a["poc.modele"] == "factice" and a["poc.modele_nom"] == "factice"
    assert (
        a["poc.version_savoir"] == empreinte_savoir() and len(a["poc.version_savoir"]) == 12 and a["poc.version_code"]
    )
    assert a["poc.recommandation"] == "AUCUNE" and a["poc.synthese_verifiee"] is False and a["poc.statut"] == "REMISE"
    assert isinstance(a["metric.refus_garde_fous"], int) and "metric.pieces_demandees" in a


def test_la_sortie_de_la_racine_est_la_synthese_verifiee(config):
    from poc.agent.harnais import ResultatSession, conclure_racine, preparer_contexte
    from poc.observabilite.adaptateur import Enregistreur
    from poc.outils import BackendLocal, executer_outil

    b = BackendLocal(config)
    sid = b.ecrire("sessions", {"demande_id": "DEM-0001", "modele": "test"})["session_id"]
    texte = "## Synthèse\n" + "Le dossier est examiné et les pièces sont présentes. " * 6
    executer_outil(b, "enregistrer_synthese", {"session_id": sid, "texte": texte, "chiffres": []})
    rec = Enregistreur(observation=SimpleNamespace(output=None))
    ctx = preparer_contexte(config, config_factice(), b)
    conclure_racine(rec, ctx, sid, ResultatSession(sid, "DEM-0001", "REMISE", [], 0, None, 1.0))
    assert rec.observation.output == texte and rec.attributs["poc.synthese_verifiee"] is True
    masque = Enregistreur(observation=SimpleNamespace(output=None), masquer=True)
    conclure_racine(masque, ctx, sid, ResultatSession(sid, "DEM-0001", "REMISE", [], 0, None, 1.0))
    assert masque.observation.output == {"contenu_masque": True, "taille": len(json.dumps(texte, ensure_ascii=False))}


# ---------------------------------------------------------------------------------------------------------------------
# Campagnes : sélections nommées, verdict HCSF, versions
# ---------------------------------------------------------------------------------------------------------------------
def test_selections_nommees(config):
    from poc.evaluation import demandes_du_lot

    assert demandes_du_lot(config, "demo") == ["DEM-0001", "DEM-0002", "DEM-0037"]
    with pytest.raises(LookupError):
        demandes_du_lot(config, "panorama")  # seuls trois dossiers sont générés dans ce test
    with pytest.raises(ValueError):
        demandes_du_lot(config, "inconnue")


def test_la_reussite_exige_le_verdict_hcsf():
    from poc.evaluation import reussite
    from poc.evaluation.correcteur import Evaluation, Mesure

    def ev(hcsf: str) -> Evaluation:
        e = Evaluation("S", "D")
        e.mesures = [
            Mesure("recommandation", "X", "X", "EXACT"),
            Mesure("taux_effort", 33.5, 33.5, "EXACT"),
            Mesure("synthese_produite", True, True, "EXACT"),
            Mesure("verdict_hcsf", "DANS_LA_NORME", "?", hcsf),
        ]
        return e

    assert reussite(ev("EXACT")) and reussite(ev("NON_EVALUABLE"))
    assert not reussite(ev("ECART")) and not reussite(ev("NON_CALCULE"))


def test_une_campagne_garde_les_versions(config):
    from poc.donnees import SQLiteStore
    from poc.evaluation import lancer_campagne
    from poc.versions import empreinte_savoir

    c = lancer_campagne(config, ["DEM-0002"], config_llm=config_factice(), publier=False)
    ligne = (
        SQLiteStore(config.sqlite_agent)
        .requete("SELECT version_savoir, version_code FROM agent_campagnes WHERE campagne_id = ?", (c.campagne_id,))
        .to_dicts()[0]
    )
    assert ligne["version_savoir"] == empreinte_savoir() and ligne["version_code"]


# ---------------------------------------------------------------------------------------------------------------------
# Les vérifications du poste
# ---------------------------------------------------------------------------------------------------------------------
def test_verifier_configuration_dit_quoi_renseigner(config, monkeypatch):
    from poc.verification import verifier_configuration

    monkeypatch.setenv("LLM_MODELE_DEFAUT", "passerelle_banque")
    for v in ("LLM_URL", "LLM_MODELE", "LLM_API_KEY", "OBS_API_KEY", "OBS_SPACE_ID"):
        monkeypatch.delenv(v, raising=False)
    monkeypatch.setenv("OBS_ENABLED", "true")
    monkeypatch.setenv("OBS_BACKEND", "arize")
    monkeypatch.setenv("OBS_ENDPOINT", "https://<instance>/v1/traces")
    par_nom = {c.nom: c for c in verifier_configuration(config)}
    modele = par_nom["modèle par défaut (LLM_MODELE_DEFAUT)"]
    assert (
        not modele.ok
        and "LLM_API_KEY" in modele.detail
        and "LLM_URL" in modele.detail
        and "LLM_MODELE" in modele.detail
    )
    obs = par_nom["observabilité (OBS_*)"]
    assert not obs.ok and "OBS_ENDPOINT" in obs.detail and "OBS_API_KEY" in obs.detail and "OBS_SPACE_ID" in obs.detail
    monkeypatch.setenv("LLM_URL", "https://passerelle.exemple.test/v1")
    monkeypatch.setenv("LLM_MODELE", "modele-x")
    monkeypatch.setenv("LLM_API_KEY", "cle")
    monkeypatch.setenv("OBS_ENABLED", "false")
    par_nom = {c.nom: c for c in verifier_configuration(config)}
    assert par_nom["modèle par défaut (LLM_MODELE_DEFAUT)"].ok and par_nom["observabilité (OBS_*)"].ok


def test_verifier_plateforme_de_bout_en_bout_vers_un_collecteur(config, collecteur_tls, monkeypatch):
    """Session factice tracée vers un collecteur HTTPS signé par l'autorité interne : sonde, brique, export réel des spans."""
    pytest.importorskip("ml_utils.observability")
    from poc.observabilite import reinitialiser
    from poc.verification import verifier_plateforme

    endpoint, chemin_ca = collecteur_tls
    for v in (
        "OBS_CA_BUNDLE",
        "OTEL_EXPORTER_OTLP_TRACES_CERTIFICATE",
        "OTEL_EXPORTER_OTLP_CERTIFICATE",
        "REQUESTS_CA_BUNDLE",
    ):
        monkeypatch.delenv(v, raising=False)
    monkeypatch.setenv("POC_CA_BUNDLE", str(chemin_ca))
    monkeypatch.setenv("OBS_ENABLED", "true")
    monkeypatch.setenv("OBS_BACKEND", "arize")
    monkeypatch.setenv("OBS_ENDPOINT", endpoint)
    monkeypatch.setenv("OBS_API_KEY", "cle")
    monkeypatch.setenv("OBS_SPACE_ID", "espace")
    monkeypatch.setenv("OBS_PROJECT", "agent-credit-immo-test")
    reinitialiser()
    try:
        controles, info = verifier_plateforme(config, "DEM-0002", evaluations=False)
        assert all(c.ok for c in controles), [(c.nom, c.detail) for c in controles]
        from poc.observabilite import obtenir

        obtenir().vider()
        exports = [r for r in _Collecteur.recus if r["taille"] > 0]
        assert exports and all(r["chemin"] == "/v1/traces" for r in exports)  # les spans sont partis, en TLS interne
        assert exports[-1]["en_tetes"].get("space_id") == "espace"
        assert info["session_id"].startswith("S-DEM-0002") and len(info["trace_id"]) == 32
    finally:
        reinitialiser()
