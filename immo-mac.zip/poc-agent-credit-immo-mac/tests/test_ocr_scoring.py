"""Les deux guichets ajoutés après le lot 5.

Le service OCR montre la **planification dynamique** de l'agent : la lecture native d'une pièce numérisée échoue avec un
code lisible (`TEXTE_ABSENT`, `FORMAT_NON_LISIBLE`), l'OCR prend le relais avec une confiance par ligne, une ligne incertaine
est refusée comme source, une pièce illisible se redemande. Le score de la banque est un indicateur consultatif : il se
consulte, se cite dans la synthèse, ne motive jamais une recommandation.
"""

from __future__ import annotations

import re

import pytest
from fastapi.testclient import TestClient

from poc.config import Config
from poc.generateur import attendu_de, generer_tout
from poc.llm import config_factice
from poc.outils import BackendLocal, ErreurOutil, executer_outil
from poc.services.ocr import SEUIL_LIGNE, description_moteur
from poc.services.verificateur import nombre_de

DEMANDES = ["DEM-0001", "DEM-0019", "DEM-0037"]
AVEC_TESSERACT = pytest.mark.skipif(not description_moteur()["disponible"], reason="Tesseract n'est pas installé")


@pytest.fixture(scope="module")
def config(tmp_path_factory) -> Config:
    cfg = Config(data_dir=tmp_path_factory.mktemp("ocr_scoring") / "data")
    generer_tout(cfg, demandes=DEMANDES)
    return cfg


@pytest.fixture(scope="module")
def b(config) -> BackendLocal:
    return BackendLocal(config)


def _session(b: BackendLocal, demande: str = "DEM-0001") -> str:
    return b.ecrire("sessions", {"demande_id": demande, "modele": "test"})["session_id"]


def _piece(b: BackendLocal, demande: str, type_: str, periode: str | None = None) -> dict:
    return next(
        p
        for p in b.lire("pieces", demande_id=demande)
        if p["type"] == type_ and (periode is None or p["periode"] == periode)
    )


# ---------------------------------------------------------------------------------------------------------------------
# La lecture native échoue, avec un code qui dit quoi faire
# ---------------------------------------------------------------------------------------------------------------------
def test_les_pieces_numerisees_ne_se_lisent_pas_nativement(b):
    avis = _piece(b, "DEM-0001", "avis_imposition", "2025")
    assert (
        avis["format"] == "pdf" and avis["fichier"] == "avis_imposition_2025.pdf"
    )  # rien ne trahit le scan à l'inventaire
    with pytest.raises(ErreurOutil) as exc:
        executer_outil(b, "lire_piece", {"demande_id": "DEM-0001", "piece": avis["piece_id"]})
    assert exc.value.code == "TEXTE_ABSENT" and "ocr_piece" in exc.value.message
    recent = _piece(b, "DEM-0001", "avis_imposition", "2026")
    assert executer_outil(b, "lire_piece", {"demande_id": "DEM-0001", "piece": recent["piece_id"]})["lignes"]
    photo = _piece(b, "DEM-0019", "compromis")
    assert photo["format"] == "jpg" and photo["fichier"].endswith(".jpg")
    with pytest.raises(ErreurOutil) as exc:
        executer_outil(b, "lire_piece", {"demande_id": "DEM-0019", "piece": photo["piece_id"]})
    assert exc.value.code == "FORMAT_NON_LISIBLE"


# ---------------------------------------------------------------------------------------------------------------------
# L'OCR prend le relais
# ---------------------------------------------------------------------------------------------------------------------
@AVEC_TESSERACT
def test_l_ocr_lit_un_scan_ligne_par_ligne_et_garde_sa_lecture(b, config):
    avis = _piece(b, "DEM-0001", "avis_imposition", "2025")
    r = executer_outil(b, "ocr_piece", {"demande_id": "DEM-0001", "piece": avis["piece_id"]})
    assert r["ocr"] is True and r["statut"] == "LISIBLE" and r["confiance_moyenne"] >= 0.8
    texte = " ".join(x["texte"] for x in r["lignes"])
    assert "66 520,00" in texte and "Revenu brut global" in texte
    assert all(0 <= x["confiance"] <= 1 for x in r["lignes"])
    assert r["lignes_incertaines"] == [x["n"] for x in r["lignes"] if x["confiance"] < SEUIL_LIGNE]
    assert (config.data_dir / "ocr" / "DEM-0001" / f"{avis['fichier']}.json").exists()
    assert executer_outil(b, "ocr_piece", {"demande_id": "DEM-0001", "piece": avis["piece_id"]}).get("depuis_cache")
    # sur un PDF qui a du texte, l'OCR n'était pas nécessaire : il le dit
    recent = _piece(b, "DEM-0001", "avis_imposition", "2026")
    natif = executer_outil(b, "ocr_piece", {"demande_id": "DEM-0001", "piece": recent["piece_id"]})
    assert natif["ocr"] is False and "lire_piece suffisait" in natif["note"]


@AVEC_TESSERACT
def test_la_photo_se_lit_et_le_scan_degrade_est_signale_illisible(b, config):
    photo = _piece(b, "DEM-0019", "compromis")
    r = executer_outil(b, "ocr_piece", {"demande_id": "DEM-0019", "piece": photo["piece_id"]})
    assert r["statut"] == "LISIBLE" and "290 000,00" in " ".join(x["texte"] for x in r["lignes"])
    a = attendu_de(config, "DEM-0037")
    scan = a.pieces_scannees[0]
    assert scan["qualite"] == "illisible" and scan["type"] == "fiche_paie"
    fiche = next(
        p
        for p in b.lire("pieces", demande_id="DEM-0037")
        if p["type"] == "fiche_paie" and p["personne"] == scan["personne"] and p["periode"] == scan["periode"]
    )
    r = executer_outil(b, "ocr_piece", {"demande_id": "DEM-0037", "piece": fiche["piece_id"]})
    assert r["statut"] == "LECTURE_INCERTAINE" and r["confiance_moyenne"] < 0.75 and "demander_piece" in r["conseil"]
    # la vérité terrain attend la copie lisible : pièce à redemander, doute, réserve
    assert "PIECE_ILLISIBLE" in [d["type"] for d in a.doutes_attendus]
    assert {"type": "fiche_paie", "personne": scan["personne"], "periode": scan["periode"]} in a.pieces_manquantes
    assert a.recommandation == "FAVORABLE_SOUS_RESERVES" and "PIECE_MANQUANTE" in a.reserves
    assert f"net_paye_{scan['personne']}_{scan['periode'].replace('-', '_')}" not in a.faits


@AVEC_TESSERACT
def test_un_fait_se_tire_de_l_ocr_mais_pas_d_une_ligne_incertaine(b):
    sid = _session(b)
    avis = _piece(b, "DEM-0001", "avis_imposition", "2025")
    r = executer_outil(b, "ocr_piece", {"demande_id": "DEM-0001", "piece": avis["piece_id"]})
    sure = next(x for x in r["lignes"] if "Revenu brut global" in x["texte"])
    assert sure["confiance"] >= SEUIL_LIGNE
    fait = executer_outil(
        b,
        "noter_fait",
        {
            "session_id": sid,
            "nom": "revenu_brut_global_2024",
            "valeur": 66520,
            "source": {"type": "piece", "piece": avis["piece_id"], "extrait": sure["texte"]},
        },
    )
    assert fait["valeur"] == 66520
    incertaines = [x for x in r["lignes"] if x["confiance"] < SEUIL_LIGNE and re.search(r"\d", x["texte"])]
    if not incertaines or nombre_de(incertaines[0]["texte"]) is None:
        pytest.skip("ce moteur ne rend aucune ligne chiffrée incertaine sur cette pièce")
    ligne = incertaines[0]
    with pytest.raises(ErreurOutil) as exc:
        executer_outil(
            b,
            "noter_fait",
            {
                "session_id": sid,
                "nom": "revenu_incertain",
                "valeur": nombre_de(ligne["texte"])[0],
                "source": {"type": "piece", "piece": avis["piece_id"], "extrait": ligne["texte"]},
            },
        )
    assert exc.value.code == "LECTURE_INCERTAINE" and "Recoupe" in exc.value.message


def test_un_scan_jamais_lu_par_ocr_n_est_pas_une_source(config):
    b = BackendLocal(config)
    sid = _session(b, "DEM-0037")
    a = attendu_de(config, "DEM-0037")
    scan = a.pieces_scannees[0]
    fiche = next(
        p
        for p in b.lire("pieces", demande_id="DEM-0037")
        if p["type"] == "fiche_paie" and p["personne"] == scan["personne"] and p["periode"] == scan["periode"]
    )
    cache = config.data_dir / "ocr" / "DEM-0037" / f"{fiche['fichier']}.json"
    if cache.exists():
        cache.unlink()
    with pytest.raises(ErreurOutil) as exc:
        executer_outil(
            b,
            "noter_fait",
            {
                "session_id": sid,
                "nom": "x",
                "valeur": 1000,
                "source": {"type": "piece", "piece": fiche["piece_id"], "extrait": "NET PAYÉ 1 000,00 €"},
            },
        )
    assert exc.value.code == "SOURCE_INTROUVABLE" and "ocr_piece" in exc.value.message


def test_sans_moteur_l_ocr_repond_proprement(b, monkeypatch):
    import poc.services.ocr as ocr

    monkeypatch.setattr(ocr, "description_moteur", lambda: {"disponible": False, "moteur": None, "langue": None})
    monkeypatch.setattr(ocr.ServiceOCR, "lecture_en_cache", lambda self, d, p: None)
    photo = _piece(b, "DEM-0019", "compromis")
    with pytest.raises(ErreurOutil) as exc:
        executer_outil(b, "ocr_piece", {"demande_id": "DEM-0019", "piece": photo["piece_id"]})
    assert exc.value.code == "OCR_NON_DISPONIBLE" and "lisible" in exc.value.message


# ---------------------------------------------------------------------------------------------------------------------
# Le score de la banque
# ---------------------------------------------------------------------------------------------------------------------
def test_le_score_du_fil_rouge_est_eleve_et_contredit_l_analyse(b, config):
    s = b.lire("score", demande_id="DEM-0001")
    assert s["score"] == 850 and s["classe"] == "A" and len(s["criteres"]) == 6
    assert sum(c["points"] for c in s["criteres"]) == s["score"] and sum(c["max"] for c in s["criteres"]) == 1000
    criteres = {c["critere"]: c for c in s["criteres"]}
    # 2 700 € reçus chez nous (500 € partent ailleurs), plus la prime de juin, plus les 2 000 € de rémunération de Marie
    assert s["revenus_constates_mensuels"] == 5500.0 and criteres["taux_endettement_estime"]["points"] == 200
    assert criteres["stabilite_professionnelle"]["points"] == 90  # Thomas 150, Marie 30 : quatorze mois d'activité
    assert s["comptes_vus"] == ["CPT-MARIE", "CPT-MARIE-PRO", "CPT-THOMAS"]  # pas le compte joint tenu ailleurs
    assert any("autres banques" in x for x in s["ne_voit_pas"]) and "consultatif" in s["avertissement"]
    a = attendu_de(config, "DEM-0001")
    assert a.score_banque == 850 and a.classe_score == "A" and a.score_diverge and "SCORE_RELATIVISE" in a.moments
    assert s["plafond_applique"] is None


def test_le_score_se_consulte_se_cite_et_ne_motive_jamais(b):
    sid = _session(b)
    r = executer_outil(b, "consulter_score", {"session_id": sid, "demande_id": "DEM-0001"})
    assert r["resultat_archive"] == "score_eligibilite" and r["classe"] == "A"
    assert any(
        c["nom_resultat"] == "score_eligibilite" and c["valeur"] == 850 for c in b.lire("calculs", session_id=sid)
    )
    for motif in (
        {"texte": "Classe A au score interne", "type": "calcul", "nom": "score_eligibilite"},
        {"texte": "Le score de la banque est bon", "type": "calcul", "nom": "score_eligibilite"},
    ):
        with pytest.raises(ErreurOutil) as exc:
            executer_outil(
                b,
                "enregistrer_recommandation",
                {
                    "session_id": sid,
                    "position": "FAVORABLE_SOUS_RESERVES",
                    "motifs": [motif],
                    "reserves": [{"code": "PIECE_MANQUANTE", "texte": "fiche d'août"}],
                },
            )
        assert exc.value.code == "SCORE_NON_DECISIONNEL"
    texte = (
        "## Indicateurs de la banque\n"
        + "Le score interne est un indicateur consultatif calculé sur le seul système d'information. " * 4
        + "Il vaut 850 points, classe A ; il ne voit pas le compte joint tenu ailleurs ni le cas non couvert de Marie."
    )
    synthese = executer_outil(b, "enregistrer_synthese", {"session_id": sid, "texte": texte, "chiffres": []})
    assert synthese["statut"] == "VERIFIEE"  # 850 est sourcé par sa valeur : score_eligibilite


def test_un_incident_en_cours_plafonne_le_score(tmp_path):
    cfg = Config(data_dir=tmp_path / "data")
    generer_tout(cfg, demandes=["DEM-0024"])  # un emprunteur seul, un retard de crédit non régularisé
    s = BackendLocal(cfg).lire("score", demande_id="DEM-0024")
    assert s["classe"] == "E" and s["score"] == 399 and s["plafond_applique"]
    assert BackendLocal(cfg).lire("score", demande_id="DEM-0024")["criteres"][4]["points"] == 0  # incidents


def test_les_deux_guichets_http(config):
    from poc.api import ocr_api, scoring_api
    from poc.outils.backend import BackendHTTP

    scoring = TestClient(scoring_api.creer(config))
    ocr = TestClient(ocr_api.creer(config))
    http = BackendHTTP(clients={"scoring": scoring, "ocr": ocr})
    assert http.lire("score", demande_id="DEM-0001")["score"] == 850
    assert "ne voit pas" in scoring.get("/grille").json()["texte"]
    assert scoring.get("/demandes/DEM-9999/score").status_code == 404
    assert ocr.get("/moteur").status_code == 200
    if description_moteur()["disponible"]:
        assert http.lire("ocr", demande_id="DEM-0019", piece="compromis_de_vente")["statut"] == "LISIBLE"


# ---------------------------------------------------------------------------------------------------------------------
# Le correcteur mesure les deux nouveaux moments
# ---------------------------------------------------------------------------------------------------------------------
def test_le_correcteur_mesure_le_changement_de_methode_et_le_score(config):
    from poc.agent import lancer_agent
    from poc.evaluation import evaluer_session

    r = lancer_agent(config, "DEM-0001", config_llm=config_factice(), checkpoints=False)
    ev = evaluer_session(config, r.session_id)
    mesures = {m.nom: m for m in ev.mesures}
    assert {"ocr_pieces_numerisees", "score_consulte"} <= set(mesures)
    assert "CHANGEMENT_DE_METHODE" in ev.moments and "SCORE_RELATIVISE" in ev.moments
    # une session qui a lu l'avis scanné par OCR et cité le score avec ses limites : les deux moments sont reconnus
    b = BackendLocal(config)
    sid = _session(b)
    avis = _piece(b, "DEM-0001", "avis_imposition", "2025")
    b.ecrire(
        "traces",
        {
            "session_id": sid,
            "etape": "extraire",
            "type": "outil",
            "nom": "ocr_piece",
            "duree_ms": 900,
            "detail": {"parametres": {"demande_id": "DEM-0001", "piece": avis["piece_id"]}},
        },
    )
    executer_outil(b, "consulter_score", {"session_id": sid, "demande_id": "DEM-0001"})
    texte = (
        "## Indicateurs de la banque\n"
        + "Le score est un indicateur consultatif. " * 6
        + "Il vaut 850 et ne voit pas le compte joint."
    )
    executer_outil(b, "enregistrer_synthese", {"session_id": sid, "texte": texte, "chiffres": []})
    ev = evaluer_session(config, sid)
    mesures = {m.nom: m for m in ev.mesures}
    assert mesures["ocr_pieces_numerisees"].statut == "EXACT" and mesures["score_consulte"].statut == "EXACT"
    assert ev.moments["CHANGEMENT_DE_METHODE"] and ev.moments["SCORE_RELATIVISE"]
