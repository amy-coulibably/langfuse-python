"""Garde commune des tests : ils n'envoient jamais de traces vers la plateforme d'observabilité du poste, même quand le
fichier `.env` est rempli (OBS_ENABLED=true vers Arize AX). Posé avant que `poc.config` ne lise `.env`, qui ne remplace pas
une variable déjà définie ; les tests qui ont besoin de l'observabilité la règlent eux-mêmes (monkeypatch, backend en
mémoire ou collecteur local)."""

import os

os.environ["OBS_ENABLED"] = "false"
os.environ.setdefault("LLM_MODELE_DEFAUT", "principal")  # les tests utilisent le modèle factice, jamais la passerelle
