"""Lot 1 : Marie et Thomas existent. Le cas est cohérent avec le cadrage (33,5 %), le générateur est déterministe, les pièces
se lisent, la banque ne connaît que ce qu'une banque connaît, la vérité terrain reste séparée, et le correcteur sait noter
une session factice (en disant pourquoi chaque mesure manque)."""

from __future__ import annotations

import json

import pytest

from poc.agent import lancer_agent
from poc.config import Config
from poc.donnees import SQLiteStore
from poc.evaluation import evaluer_session
from poc.generateur import attendu_de, calculer_attendu, cas_de, cas_fil_rouge, demandes_disponibles, generer_tout
from poc.generateur.mouvements import releves_du_cas
from poc.llm import config_factice
from poc.outils import BackendLocal, executer_outil


@pytest.fixture(scope="module")
def config(tmp_path_factory) -> Config:
    cfg = Config(data_dir=tmp_path_factory.mktemp("lot1") / "data")
    generer_tout(cfg, demandes=["DEM-0001"])
    return cfg


def test_le_fil_rouge_est_celui_du_cadrage():
    cas = cas_fil_rouge()
    a = calculer_attendu(cas)
    assert a.taux_effort == 33.5 and a.duree_souhaitee_annees == 25
    assert a.montant_emprunte == 303_250 and a.frais_acquisition == 23_250 and a.apport == 40_000
    assert a.revenus_par_personne["thomas"] == 3200 and a.revenus_non_couverts == ["marie"]
    assert a.taux_effort_standard > 50  # sans les revenus de Marie, le dossier ne passe pas : d'où la réserve
    assert a.verdicts["SEUIL_INDEPENDANT"] == "CAS_NON_COUVERT" and a.verdicts["HCSF_TAUX_EFFORT"] == "DANS_LA_NORME"
    assert a.recommandation == "FAVORABLE_SOUS_RESERVES"
    assert set(a.reserves) == {"REVENUS_NON_COUVERTS", "PIECE_MANQUANTE", "ECART_SALAIRE_A_CONFIRMER"}
    assert [d["type"] for d in a.doutes_attendus] == [
        "ECART_SALAIRE_RELEVES",
        "PIECE_MANQUANTE",
        "PRIME_DANS_LE_NET",
        "CAS_NON_COUVERT_INDEPENDANT",
    ]
    assert a.moments == [
        "INCOHERENCE_ENTRE_SOURCES",
        "PIECE_MANQUANTE",
        "CHANGEMENT_DE_METHODE",  # l'avis d'imposition 2025 est scanné : de lire_piece à ocr_piece
        "CONTROLE_DU_CALCUL",
        "CONSCIENCE_DES_LIMITES",
    ]
    assert a.faits["net_paye_thomas_2026_06"] == 5600 and a.faits["net_paye_thomas_2026_07"] == 3200
    assert "net_paye_thomas_2026_08" not in a.faits  # la fiche d'août manque


def test_le_generateur_est_deterministe():
    c1, c2 = cas_fil_rouge(), cas_fil_rouge()
    assert c1.model_dump() == c2.model_dump()
    r1, r2 = releves_du_cas(c1), releves_du_cas(c2)
    assert r1 == r2
    thomas = r1["CPT-THOMAS"]
    salaires = [x for m in thomas for x in m["lignes"] if "SALAIRE" in x["libelle"]]
    assert [s["montant"] for s in salaires] == [
        5100.0,
        2700.0,
        2700.0,
    ]  # prime en juin, salaire scindé (500 € ailleurs)
    joint = [x["montant"] for m in r1["CPT-JOINT"] for x in m["lignes"] if "SALAIRE" in x["libelle"]]
    assert joint == [500.0, 500.0, 500.0]
    assert all(m["solde_fin"] > 0 for m in thomas), "pas de découvert dans le fil rouge"


def test_les_pieces_se_lisent_et_portent_les_pieges(config):
    from pypdf import PdfReader

    coffre = config.coffre_dir / "DEM-0001"
    inv = json.loads((coffre / "inventaire.json").read_text(encoding="utf-8"))
    types = {p["type"] for p in inv["pieces"]}
    assert {
        "identite",
        "fiche_paie",
        "declaration_ca",
        "avis_imposition",
        "releve_compte",
        "tableau_amortissement",
        "compromis",
        "justificatif_domicile",
        "justificatif_epargne",
    } <= types
    fiches = sorted(p["periode"] for p in inv["pieces"] if p["type"] == "fiche_paie")
    assert fiches == ["2026-06", "2026-07"]  # août manque
    assert all((coffre / p["fichier"]).exists() for p in inv["pieces"])
    juin = PdfReader(coffre / "fiche_paie_thomas_2026-06.pdf").pages[0].extract_text()
    assert "Prime annuelle" in juin and "5 600,00" in juin and "NET PAYÉ" in juin
    juillet = PdfReader(coffre / "fiche_paie_thomas_2026-07.pdf").pages[0].extract_text()
    assert "Prime annuelle" not in juillet and "3 200,00" in juillet
    releve = PdfReader(coffre / "releve_cpt-thomas_2026-07.pdf").pages[0].extract_text()
    assert "SALAIRE" in releve and "2 700,00" in releve
    compromis = PdfReader(coffre / "compromis_de_vente.pdf").pages[0].extract_text()
    assert "320 000,00" in compromis and "12/10/2026" in compromis


def test_la_banque_ne_connait_que_ce_qu_une_banque_connait(config):
    b = SQLiteStore(config.sqlite_banque)
    assert demandes_disponibles(config) == ["DEM-0001"]
    comptes = b.requete("SELECT compte_id, type FROM banque_compte").to_dicts()
    assert {c["compte_id"] for c in comptes} == {
        "CPT-THOMAS",
        "CPT-MARIE",
        "CPT-MARIE-PRO",
    }  # pas le compte joint tenu ailleurs
    assert b.requete("SELECT COUNT(*) AS n FROM banque_credit_en_cours")["n"][0] == 0  # le crédit auto est ailleurs…
    declares = b.requete("SELECT * FROM banque_demande_credit_declare").to_dicts()
    assert len(declares) == 1 and declares[0]["mensualite_declaree"] == 210.0  # … mais le client l'a déclaré
    mouvements = b.requete("SELECT COUNT(*) AS n FROM banque_mouvement WHERE compte_id = 'CPT-THOMAS'")["n"][0]
    assert mouvements >= 30
    assert SQLiteStore(config.sqlite_incidents).requete("SELECT COUNT(*) AS n FROM incidents_incident")["n"][0] == 0


def test_la_verite_terrain_est_separee_et_relisible(config):
    vt = SQLiteStore(config.sqlite_verite_terrain)
    assert all(t.startswith("vt_") for t in vt.lister()) and {
        "vt_cas",
        "vt_attendu",
        "vt_faits",
        "vt_doutes",
        "vt_verdicts",
        "vt_pieces",
    } <= set(vt.lister())
    assert not any(t.startswith("vt_") for t in SQLiteStore(config.sqlite_banque).lister())
    a = attendu_de(config, "DEM-0001")
    assert a is not None and a.taux_effort == 33.5 and a.mensualites_assurance_comprise[25] > 1500
    cas = cas_de(config, "DEM-0001")
    assert cas is not None and cas.personne("marie").mois_activite(cas.date_depot) == 14


def test_le_correcteur_note_une_session_factice_et_dit_pourquoi(config):
    r = lancer_agent(config, "DEM-0001", config_llm=config_factice(), checkpoints=False)
    ev = evaluer_session(config, r.session_id)
    statuts = {m.nom: m.statut for m in ev.mesures}
    assert statuts["taux_effort"] == "NON_CALCULE" and statuts["recommandation"] == "NON_CALCULE"
    # le modèle factice ne calcule rien ; il appelle seulement chaque outil disponible, dont consulter_score
    assert [m.nom for m in ev.mesures if m.statut == "EXACT"] == ["score_consulte"] and ev.doutes_attendus_total == 4
    assert SQLiteStore(config.sqlite_agent).requete(
        "SELECT COUNT(*) AS n FROM agent_evaluations WHERE session_id = ?", (r.session_id,)
    )["n"][0] == len(ev.mesures)
    # un calcul juste sous un nom hors convention est reconnu comme tel ; un calcul juste bien nommé est EXACT
    backend = BackendLocal(config)
    a = attendu_de(config, "DEM-0001")
    executer_outil(
        backend,
        "calculer",
        {
            "session_id": r.session_id,
            "etape": "calculer",
            "entrees": [
                {
                    "nom": "charges",
                    "origine": {"type": "constante", "valeur": a.charges_retenues, "justification": "test"},
                },
                {
                    "nom": "revenus",
                    "origine": {"type": "constante", "valeur": a.revenus_retenus, "justification": "test"},
                },
            ],
            "code": "effort = charges / revenus * 100\nmensualite_25 = charges - 210",
            "sorties": ["effort", "mensualite_25"],
            "unite": "pourcentage",
        },
    )
    ev2 = evaluer_session(config, r.session_id)
    statuts = {m.nom: m.statut for m in ev2.mesures}
    assert statuts["taux_effort"] == "NOM_HORS_CONVENTION" and statuts["mensualite_25"] == "EXACT"
