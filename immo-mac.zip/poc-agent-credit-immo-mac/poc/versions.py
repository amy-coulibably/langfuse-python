"""Les versions de ce qui fait le comportement de l'agent, posées sur chaque trace et chaque campagne pour pouvoir les
comparer : « la réussite a baissé » ne veut rien dire tant qu'on ne sait pas ce qui a changé entre-temps.

- `empreinte_savoir()` : empreinte des fiches de méthode, des référentiels et du parcours (`config/etapes.yaml`), c'est-à-dire
  de tout ce que l'on modifie quand on « règle » l'agent sans toucher au code ;
- `version_code()` : la version du paquet et le commit d'origine (fichier `VERSION` écrit à l'export, sinon `git`).
"""

from __future__ import annotations

import hashlib
import subprocess
from functools import lru_cache

from poc import __version__
from poc.config import RACINE

SAVOIR = ("fiches", "referentiels", "config/etapes.yaml")


@lru_cache(maxsize=1)
def empreinte_savoir() -> str:
    """Douze caractères hexadécimaux, identiques sur Windows et sur Mac (fins de ligne normalisées)."""
    h = hashlib.sha256()
    fichiers = []
    for element in SAVOIR:
        chemin = RACINE / element
        if chemin.is_dir():
            fichiers += [f for f in chemin.rglob("*") if f.is_file() and "__pycache__" not in f.parts]
        elif chemin.is_file():
            fichiers.append(chemin)
    for f in sorted(fichiers, key=lambda x: x.relative_to(RACINE).as_posix()):
        h.update(f.relative_to(RACINE).as_posix().encode("utf-8"))
        h.update(f.read_bytes().replace(b"\r\n", b"\n"))
    return h.hexdigest()[:12]


@lru_cache(maxsize=1)
def version_code() -> str:
    fichier = RACINE / "VERSION"
    if fichier.is_file():
        premiere = fichier.read_text(encoding="utf-8").strip().splitlines()
        if premiere:
            return premiere[0].strip()
    try:
        commit = subprocess.run(
            ["git", "rev-parse", "--short", "HEAD"], cwd=RACINE, capture_output=True, text=True, timeout=5, check=True
        ).stdout.strip()
        return f"{__version__}+{commit}" if commit else __version__
    except (OSError, subprocess.SubprocessError):
        return __version__
