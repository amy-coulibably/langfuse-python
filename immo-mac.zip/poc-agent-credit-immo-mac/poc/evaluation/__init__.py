"""L'évaluation : le correcteur compare une session à la vérité terrain, sans modèle de langage ; les campagnes font tourner
l'agent sur une série de dossiers et gardent le résultat (pass@1, pass^k)."""

from poc.evaluation.campagne import (
    LOTS,
    Campagne,
    SessionCampagne,
    campagnes,
    demandes_du_lot,
    lancer_campagne,
    publier_evaluation_session,
    reussite,
    sessions_de_campagne,
)
from poc.evaluation.correcteur import CORRESPONDANCES, Evaluation, Mesure, evaluer_session

__all__ = [
    "CORRESPONDANCES",
    "LOTS",
    "Campagne",
    "Evaluation",
    "Mesure",
    "SessionCampagne",
    "campagnes",
    "demandes_du_lot",
    "evaluer_session",
    "lancer_campagne",
    "publier_evaluation_session",
    "reussite",
    "sessions_de_campagne",
]
