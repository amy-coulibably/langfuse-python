"""Les campagnes : faire tourner l'agent sur une série de dossiers, noter chaque session avec le correcteur, et **garder le
résultat** (tables `agent_campagnes` et `agent_campagne_sessions`, plus un CSV dans `data/campagnes/`). Leçon du premier
POC : une campagne qui n'est pas persistée ne se compare à rien ; on ne sait plus, deux jours après, si une modification de
fiche a aidé ou nui.

Deux chiffres résument une campagne, à la manière des évaluations d'agents (Anthropic, 2026) :

- **pass@1** : la part des sessions réussies ;
- **pass^k** : la part des dossiers réussis à **chaque** répétition (k fois de suite). C'est la mesure de fiabilité : un
  agent qui réussit une fois sur trois ne rend pas service à un conseiller.

Une session est **réussie** quand, à la fois : la recommandation est celle attendue ; le taux d'effort est exact (sauf dossier
bloquant, où aucun taux n'est attendu) ; la synthèse a été vérifiée par le garde-fou ; aucun faux doute n'a été posé. Les
mesures détaillées restent disponibles ligne par ligne.

Les dossiers **scellés** (`lot = scelle`) ne doivent servir qu'à mesurer : `lancer_campagne(..., lot="scelle")` les fait
tourner, mais rien dans le code ne les regarde pendant le réglage ; c'est une discipline, et le journal la rappelle.
"""

from __future__ import annotations

import csv
import datetime as dt
import json
import time
import uuid
from collections.abc import Callable
from dataclasses import dataclass, field
from typing import Any

import polars as pl

from poc.config import Config
from poc.donnees import SQLiteStore
from poc.evaluation.correcteur import Evaluation, evaluer_session
from poc.generateur import catalogue
from poc.versions import empreinte_savoir, version_code

LOTS = ("facile", "reglage", "scelle", "tous")
# Des sélections nommées, pour tester l'agent sur une diversité de situations sans lancer les cinquante dossiers.
SELECTIONS: dict[str, tuple[str, ...]] = {
    # trois dossiers, une demi-heure avec un modèle rapide : le fil rouge, un dossier sain, une pièce illisible
    "demo": ("DEM-0001", "DEM-0002", "DEM-0037"),
    # douze dossiers, une situation chacun : fil rouge, sain, retraités, locatif, prime, CDD seul (bloquant), compromis en
    # photo, incident en cours, taux à 49 %, salarié sans fiche (bloquant), pension récente, fiche illisible
    "panorama": (
        "DEM-0001",
        "DEM-0002",
        "DEM-0006",
        "DEM-0009",
        "DEM-0013",
        "DEM-0018",
        "DEM-0019",
        "DEM-0021",
        "DEM-0024",
        "DEM-0027",
        "DEM-0032",
        "DEM-0037",
    ),
    # les sept dossiers à pièce numérisée (OCR : scan, photo, illisible)
    "ocr": ("DEM-0001", "DEM-0019", "DEM-0023", "DEM-0036", "DEM-0037", "DEM-0045", "DEM-0048"),
}


@dataclass
class SessionCampagne:
    demande_id: str
    repetition: int
    session_id: str | None
    statut: str
    reussite: bool
    mesures_exactes: int
    evaluables: int
    recommandation: str
    taux_effort: str
    synthese: str
    doutes_trouves: int
    doutes_attendus: int
    faux_doutes: int
    moments_ok: int
    moments_total: int
    tokens: int
    duree_s: float
    erreur: str = ""


@dataclass
class Campagne:
    campagne_id: str
    nom: str
    modele: str
    lot: str
    repetitions: int
    demandes: list[str]
    horodatage: str
    sessions: list[SessionCampagne] = field(default_factory=list)
    duree_s: float = 0.0
    version_savoir: str = field(default_factory=empreinte_savoir)  # fiches, référentiels, parcours
    version_code: str = field(default_factory=version_code)

    @property
    def pass_1(self) -> float:
        return round(sum(1 for s in self.sessions if s.reussite) / len(self.sessions), 3) if self.sessions else 0.0

    @property
    def pass_k(self) -> float:
        """Part des dossiers réussis à chaque répétition."""
        if not self.sessions:
            return 0.0
        par_dossier: dict[str, list[bool]] = {}
        for s in self.sessions:
            par_dossier.setdefault(s.demande_id, []).append(s.reussite)
        reussis = sum(1 for v in par_dossier.values() if all(v) and len(v) == self.repetitions)
        return round(reussis / len(par_dossier), 3)

    def resume(self) -> dict[str, Any]:
        exacts = sum(s.mesures_exactes for s in self.sessions)
        evaluables = sum(s.evaluables for s in self.sessions)
        return {
            "campagne_id": self.campagne_id,
            "nom": self.nom,
            "modele": self.modele,
            "lot": self.lot,
            "repetitions": self.repetitions,
            "dossiers": len(self.demandes),
            "sessions": len(self.sessions),
            "pass_1": self.pass_1,
            "pass_k": self.pass_k,
            "mesures_exactes": f"{exacts}/{evaluables}",
            "recommandations_exactes": sum(1 for s in self.sessions if s.recommandation == "EXACT"),
            "syntheses_verifiees": sum(1 for s in self.sessions if s.synthese == "EXACT"),
            "faux_doutes": sum(s.faux_doutes for s in self.sessions),
            "tokens": sum(s.tokens for s in self.sessions),
            "duree_s": round(self.duree_s, 1),
            "echecs_techniques": sum(1 for s in self.sessions if s.erreur),
        }


def reussite(ev: Evaluation) -> bool:
    statuts = {m.nom: m.statut for m in ev.mesures}
    taux_ok = statuts.get("taux_effort") in ("EXACT", "NON_EVALUABLE")
    hcsf_ok = statuts.get("verdict_hcsf", "EXACT") in ("EXACT", "NON_EVALUABLE")  # norme contraignante (EBA §95, HCSF)
    return (
        statuts.get("recommandation") == "EXACT"
        and taux_ok
        and hcsf_ok
        and statuts.get("synthese_produite") == "EXACT"
        and ev.faux_doutes == 0
    )


def demandes_du_lot(config: Config, lot: str) -> list[str]:
    """Les dossiers d'un lot du catalogue (facile, reglage, scelle, tous) ou d'une sélection nommée (demo, panorama, ocr)."""
    if lot in SELECTIONS:
        connues = {c["demande_id"] for c in catalogue(config)}
        absentes = [d for d in SELECTIONS[lot] if d not in connues]
        if absentes:
            raise LookupError(f"sélection {lot} : dossiers non générés {absentes} (lancer `poc donnees generer`)")
        return list(SELECTIONS[lot])
    if lot not in LOTS:
        raise ValueError(f"lot inconnu : {lot} (attendu : {', '.join(LOTS + tuple(SELECTIONS))})")
    return [c["demande_id"] for c in catalogue(config) if lot == "tous" or c["lot"] == lot]


def _ligne(ev: Evaluation | None, demande_id: str, repetition: int, r: Any, erreur: str = "") -> SessionCampagne:
    statuts = {m.nom: m.statut for m in ev.mesures} if ev else {}
    return SessionCampagne(
        demande_id=demande_id,
        repetition=repetition,
        session_id=ev.session_id if ev else (r.session_id if r else None),
        statut=r.statut if r else "ECHEC",
        reussite=reussite(ev) if ev else False,
        mesures_exactes=ev.exacts if ev else 0,
        evaluables=ev.evaluables if ev else 0,
        recommandation=statuts.get("recommandation", "NON_EVALUE"),
        taux_effort=statuts.get("taux_effort", "NON_EVALUE"),
        synthese=statuts.get("synthese_produite", "NON_EVALUE"),
        doutes_trouves=ev.doutes_attendus_trouves if ev else 0,
        doutes_attendus=ev.doutes_attendus_total if ev else 0,
        faux_doutes=ev.faux_doutes if ev else 0,
        moments_ok=sum(1 for v in ev.moments.values() if v) if ev else 0,
        moments_total=len(ev.moments) if ev else 0,
        tokens=r.tokens if r else 0,
        duree_s=r.duree_s if r else 0.0,
        erreur=erreur,
    )


def lancer_campagne(
    config: Config,
    demandes: list[str] | None = None,
    lot: str = "reglage",
    modele: str | None = None,
    repetitions: int = 1,
    nom: str | None = None,
    config_llm: Any = None,
    backend: Any = None,
    scenario_factice: Any = None,
    mcp: bool = False,
    verbeux: bool = False,
    rapporter: Callable[[SessionCampagne], None] | None = None,
    publier: bool = True,
) -> Campagne:
    """Fait tourner l'agent `repetitions` fois sur chaque dossier, note chaque session, persiste la campagne."""
    from poc.agent import lancer_agent

    liste = demandes if demandes is not None else demandes_du_lot(config, lot)
    if not liste:
        raise LookupError("aucun dossier : lancer `poc donnees generer` ou vérifier le lot demandé")
    debut = time.time()
    cfg_llm = config_llm
    if cfg_llm is None:
        from poc.llm import charger_config_llm

        cfg_llm = charger_config_llm()
    nom_modele = cfg_llm.modele_pour(None, modele).nom_logique + ("+mcp" if mcp else "")
    campagne = Campagne(
        campagne_id=f"C-{dt.datetime.now():%Y%m%d-%H%M%S}-{uuid.uuid4().hex[:4]}",
        nom=nom or f"{lot if demandes is None else 'selection'} x {repetitions}",
        modele=nom_modele,
        lot=lot if demandes is None else "selection",
        repetitions=repetitions,
        demandes=list(liste),
        horodatage=dt.datetime.now().isoformat(timespec="seconds"),
    )
    for repetition in range(1, repetitions + 1):
        for demande_id in liste:
            r = None
            ev = None
            erreur = ""
            try:
                r = lancer_agent(
                    config,
                    demande_id,
                    modele=modele,
                    verbeux=verbeux,
                    config_llm=cfg_llm,
                    backend=backend,
                    scenario_factice=scenario_factice,
                    checkpoints=False,
                    mcp=True if mcp else None,
                )
                ev = evaluer_session(config, r.session_id)
                if publier:
                    publier_evaluation_session(config, ev)
            except Exception as exc:  # noqa: BLE001 — une session qui casse ne doit pas perdre la campagne
                erreur = f"{type(exc).__name__}: {str(exc)[:300]}"
            ligne = _ligne(ev, demande_id, repetition, r, erreur)
            campagne.sessions.append(ligne)
            if rapporter:
                rapporter(ligne)
            persister_campagne(config, campagne, en_cours=True)
    campagne.duree_s = time.time() - debut
    persister_campagne(config, campagne)
    return campagne


def publier_evaluation_session(config: Config, ev: Evaluation) -> dict[str, int]:
    """Dépose les évaluations `eval.*` sur la trace de la session si l'observabilité est active (sinon ne fait rien)."""
    try:
        from poc.agent import trace_de_session
        from poc.observabilite import charger_config_observabilite
        from poc.observabilite.evaluations import publier_evaluation

        return publier_evaluation(charger_config_observabilite(), ev, trace_de_session(config, ev.session_id))
    except Exception:  # noqa: BLE001 — fail-open
        return {"span": 0}


def persister_campagne(config: Config, campagne: Campagne, en_cours: bool = False) -> None:
    store = SQLiteStore(config.sqlite_agent)
    resume = campagne.resume()
    resume["statut"] = "EN_COURS" if en_cours else "TERMINEE"
    store.remplacer(
        "agent_campagnes",
        pl.DataFrame(
            [
                {
                    "campagne_id": campagne.campagne_id,
                    "nom": campagne.nom,
                    "horodatage": campagne.horodatage,
                    "modele": campagne.modele,
                    "lot": campagne.lot,
                    "repetitions": campagne.repetitions,
                    "nb_dossiers": len(campagne.demandes),
                    "nb_sessions": len(campagne.sessions),
                    "pass_1": campagne.pass_1,
                    "pass_k": campagne.pass_k,
                    "statut": resume["statut"],
                    "version_savoir": campagne.version_savoir,
                    "version_code": campagne.version_code,
                    "demandes_json": json.dumps(campagne.demandes),
                    "resume_json": json.dumps(resume, ensure_ascii=False),
                }
            ],
            schema_overrides={"pass_1": pl.Float64, "pass_k": pl.Float64},
        ),
        "campagne_id",
        campagne.campagne_id,
    )
    if campagne.sessions:
        lignes = [{"campagne_id": campagne.campagne_id, **s.__dict__} for s in campagne.sessions]
        store.remplacer(
            "agent_campagne_sessions",
            pl.DataFrame(lignes, schema_overrides={"duree_s": pl.Float64, "session_id": pl.Utf8, "erreur": pl.Utf8}),
            "campagne_id",
            campagne.campagne_id,
        )
        dossier = config.data_dir / "campagnes"
        dossier.mkdir(parents=True, exist_ok=True)
        with (dossier / f"{campagne.campagne_id}.csv").open("w", newline="", encoding="utf-8") as f:
            w = csv.DictWriter(f, fieldnames=list(lignes[0].keys()))
            w.writeheader()
            w.writerows(lignes)


def campagnes(config: Config, n: int = 20) -> list[dict]:
    store = SQLiteStore(config.sqlite_agent)
    if not config.sqlite_agent.exists() or not store.existe("agent_campagnes"):
        return []
    return store.requete(f"SELECT * FROM agent_campagnes ORDER BY horodatage DESC LIMIT {int(n)}").to_dicts()


def sessions_de_campagne(config: Config, campagne_id: str) -> list[dict]:
    store = SQLiteStore(config.sqlite_agent)
    if not store.existe("agent_campagne_sessions"):
        return []
    return store.requete(
        "SELECT * FROM agent_campagne_sessions WHERE campagne_id = ? ORDER BY repetition, demande_id", (campagne_id,)
    ).to_dicts()
