"""Le correcteur : compare ce que l'agent a produit dans une session à la vérité terrain de la demande. Sans modèle de
langage : des comparaisons de chiffres, de listes et de mots-clés, que n'importe qui peut relire.

Chaque mesure a un statut qui dit **pourquoi** elle n'est pas exacte (leçon du premier POC : un zéro doit s'expliquer) :

- `EXACT` : la valeur de l'agent est dans la tolérance ;
- `ECART` : l'agent a produit une valeur, fausse ;
- `NOM_HORS_CONVENTION` : une valeur juste existe dans la feuille de calcul, sous un autre nom que ceux attendus ;
- `NON_CALCULE` : l'agent n'a rien produit sur ce point ;
- `NON_EVALUABLE` : la mesure n'a pas de sens pour ce dossier (un dossier bloquant, où aucun revenu ne peut être établi,
  n'attend aucun taux d'effort) ; avant le lot 2, aussi les mesures dont l'outil n'était pas livré.

Les tables lues : agent_calculs (lot 0), agent_faits, agent_doutes, agent_messages_client, agent_verdicts, agent_syntheses,
agent_recommandations (lot 2), agent_traces (appels d'outils : l'OCR des pièces numérisées). Le correcteur tolère leur
absence : il fonctionne dès le lot 1 et se complète seul.

Deux moments de réflexivité ne laissent pas de doute derrière eux et se mesurent autrement :

- `CHANGEMENT_DE_METHODE` : chaque pièce numérisée a été lue par `ocr_piece` (la lecture native ne donnait rien) ;
- `SCORE_RELATIVISE` : quand le score de la banque contredit l'analyse, la synthèse vérifiée parle du score et de ce qu'il
  ne voit pas.
"""

from __future__ import annotations

import datetime as dt
import json
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import polars as pl

from poc.config import Config
from poc.donnees import SQLiteStore
from poc.generateur import Attendu, attendu_de
from poc.services.sessions import ServiceSessions

# nom d'une mesure -> noms de résultats acceptés dans la feuille de calcul (la fiche 07 fixera la convention)
CORRESPONDANCES: dict[str, list[str]] = {
    "taux_effort": ["taux_effort", "taux_effort_25", "taux_effort_25_ans", "taux_d_effort", "taux_endettement"],
    "mensualite_25": [
        "mensualite_25",
        "mensualite_25_ans",
        "mensualite_assurance_comprise_25",
        "mensualite_totale_25",
        "mensualite",
    ],
    "mensualite_20": ["mensualite_20", "mensualite_20_ans", "mensualite_assurance_comprise_20"],
    "mensualite_15": ["mensualite_15", "mensualite_15_ans", "mensualite_assurance_comprise_15"],
    "revenus_retenus": ["revenus_retenus", "revenus_retenus_total", "revenus_mensuels_retenus", "revenus"],
    "charges_retenues": ["charges_retenues", "charges_mensuelles", "charges"],
    "reste_a_vivre": ["reste_a_vivre", "reste_a_vivre_25"],
    "montant_emprunte": ["montant_emprunte", "capital_emprunte", "montant_pret", "capital"],
}
TOLERANCES = {
    "taux_effort": 0.2,
    "mensualite_25": 1.0,
    "mensualite_20": 1.0,
    "mensualite_15": 1.0,
    "revenus_retenus": 1.0,
    "charges_retenues": 1.0,
    "reste_a_vivre": 1.0,
    "montant_emprunte": 1.0,
}


@dataclass
class Mesure:
    nom: str
    attendu: Any
    obtenu: Any
    statut: str
    detail: str = ""


@dataclass
class Evaluation:
    session_id: str
    demande_id: str
    mesures: list[Mesure] = field(default_factory=list)
    doutes_attendus_trouves: int = 0
    doutes_attendus_total: int = 0
    faux_doutes: int = 0
    moments: dict[str, bool] = field(default_factory=dict)

    @property
    def exacts(self) -> int:
        return sum(1 for m in self.mesures if m.statut == "EXACT")

    @property
    def evaluables(self) -> int:
        return sum(1 for m in self.mesures if m.statut != "NON_EVALUABLE")

    def resume(self) -> dict:
        return {
            "session_id": self.session_id,
            "demande_id": self.demande_id,
            "mesures_exactes": f"{self.exacts}/{self.evaluables}",
            "doutes_attendus_trouves": f"{self.doutes_attendus_trouves}/{self.doutes_attendus_total}",
            "faux_doutes": self.faux_doutes,
            "moments": self.moments,
            "detail": [
                {"mesure": m.nom, "attendu": m.attendu, "obtenu": m.obtenu, "statut": m.statut, "detail": m.detail}
                for m in self.mesures
            ],
        }


def _valeur_attendue(attendu: Attendu, nom: str) -> float:
    if nom == "taux_effort":
        return attendu.taux_effort
    if nom.startswith("mensualite_"):
        return attendu.mensualites_assurance_comprise[int(nom.split("_")[1])]
    return float(getattr(attendu, nom))


def _comparer_calcul(nom: str, attendu_val: float, calculs: list[dict]) -> Mesure:
    tol = TOLERANCES[nom]
    noms = CORRESPONDANCES[nom]
    par_nom = {c["nom_resultat"]: c for c in calculs}  # le dernier calcul d'un nom l'emporte (ordre chronologique)
    for n in noms:
        if n in par_nom and par_nom[n]["valeur"] is not None:
            v = float(par_nom[n]["valeur"])
            if nom == "taux_effort" and v < 1.0:
                v *= 100  # un ratio au lieu d'un pourcentage : on compare quand même
            statut = "EXACT" if abs(v - attendu_val) <= tol else "ECART"
            return Mesure(nom, attendu_val, round(v, 2), statut, f"résultat « {n} »")
    if not calculs:
        return Mesure(nom, attendu_val, None, "NON_CALCULE", "aucun calcul dans la session")
    for c in calculs:  # une valeur juste sous un autre nom ?
        v = c["valeur"]
        if v is None:
            continue
        v = float(v)
        if nom == "taux_effort" and v < 1.0:
            v *= 100
        if abs(v - attendu_val) <= tol:
            return Mesure(
                nom,
                attendu_val,
                round(v, 2),
                "NOM_HORS_CONVENTION",
                f"valeur juste sous le nom « {c['nom_resultat']} » ; noms attendus : {noms[:3]}",
            )
    return Mesure(nom, attendu_val, None, "NON_CALCULE", f"aucun résultat nommé {noms[:3]} ni valeur approchante")


def _lire(store: SQLiteStore, table: str, session_id: str) -> list[dict] | None:
    if not store.existe(table):
        return []  # table jamais écrite = l'agent n'a rien produit de ce type (les outils existent depuis le lot 2)
    return store.requete(f'SELECT * FROM "{table}" WHERE session_id = ? ORDER BY rowid', (session_id,)).to_dicts()


def _texte_doute(d: dict) -> str:
    return " ".join(str(d.get(k) or "") for k in ("objet", "hypotheses", "question", "texte", "detail")).lower()


def evaluer_session(config: Config, session_id: str) -> Evaluation:
    store = SQLiteStore(config.sqlite_agent)
    session = ServiceSessions(store).session(session_id)
    attendu = attendu_de(config, session.demande_id)
    if attendu is None:
        raise LookupError(f"pas de vérité terrain pour la demande {session.demande_id} : lancer `poc donnees generer`")
    ev = Evaluation(session_id, session.demande_id)
    calculs = _lire(store, "agent_calculs", session_id) or []

    # ---- chiffres de la feuille de calcul
    for nom in CORRESPONDANCES:
        if attendu.bloquant and nom != "montant_emprunte":
            ev.mesures.append(
                Mesure(
                    nom,
                    None,
                    None,
                    "NON_EVALUABLE",
                    "dossier bloquant : aucun revenu ne peut être établi, pas de chiffre attendu",
                )
            )
            continue
        ev.mesures.append(_comparer_calcul(nom, _valeur_attendue(attendu, nom), calculs))

    # ---- faits extraits (lot 2)
    faits = _lire(store, "agent_faits", session_id)
    if faits is None:
        ev.mesures.append(
            Mesure("faits_extraits", len(attendu.faits), None, "NON_EVALUABLE", "table agent_faits absente (lot 2)")
        )
    else:
        par_nom = {f["nom"]: f["valeur"] for f in faits}
        par_nom.update(
            {c["nom_resultat"]: c["valeur"] for c in calculs}
        )  # un fait attendu peut être un résultat de l'atelier
        trouves = sum(
            1
            for n, v in attendu.faits.items()
            if par_nom.get(n) is not None and abs(float(par_nom[n]) - v) <= max(1.0, abs(v) * 0.005)
        )
        ev.mesures.append(
            Mesure(
                "faits_extraits",
                len(attendu.faits),
                trouves,
                "EXACT" if trouves == len(attendu.faits) else ("ECART" if trouves else "NON_CALCULE"),
                f"{trouves} fait(s) attendu(s) retrouvé(s) à l'euro",
            )
        )

    # ---- doutes attendus, faux doutes, moments
    doutes_agent = _lire(store, "agent_doutes", session_id)
    journal = _lire(store, "agent_journal", session_id) or []
    messages_envoyes = _lire(store, "agent_messages_client", session_id) or []
    ev.doutes_attendus_total = len(attendu.doutes_attendus)
    if doutes_agent is None:
        ev.mesures.append(
            Mesure(
                "doutes_attendus", ev.doutes_attendus_total, None, "NON_EVALUABLE", "table agent_doutes absente (lot 2)"
            )
        )
        ev.moments = {m: False for m in attendu.moments}
    else:
        textes = [_texte_doute(d) for d in doutes_agent]
        reconnus = [False] * len(textes)
        for attendu_d in attendu.doutes_attendus:
            mots = [m.lower() for m in attendu_d["mots_cles"]]
            mots += [_mois_en_clair(m) for m in mots if _mois_en_clair(m)]  # « 2026-08 » se dit aussi « août 2026 »
            minimum = min(2, len(mots))
            trouve = False
            for i, t in enumerate(textes):
                if sum(1 for m in mots if m in t) >= minimum:
                    reconnus[i] = True
                    trouve = True
            if trouve:
                ev.doutes_attendus_trouves += 1
            if (
                not trouve
            ):  # preuves alternatives : un message au client pour la pièce, une correction visible dans le journal
                trouve = _preuve_alternative(attendu_d, messages_envoyes, journal)
            ev.moments[attendu_d["type"]] = trouve
        ev.faux_doutes = sum(1 for r in reconnus if not r)
        statut = (
            "EXACT"
            if ev.doutes_attendus_trouves == ev.doutes_attendus_total and ev.faux_doutes == 0
            else ("ECART" if ev.doutes_attendus_trouves else "NON_CALCULE")
        )
        ev.mesures.append(
            Mesure(
                "doutes_attendus",
                ev.doutes_attendus_total,
                ev.doutes_attendus_trouves,
                statut,
                f"{ev.faux_doutes} doute(s) non attendu(s)",
            )
        )

    # ---- pièces manquantes demandées (lot 2)
    messages = _lire(store, "agent_messages_client", session_id)
    if messages is None:
        ev.mesures.append(
            Mesure(
                "pieces_manquantes_demandees",
                len(attendu.pieces_manquantes),
                None,
                "NON_EVALUABLE",
                "table agent_messages_client absente (lot 2)",
            )
        )
    else:
        textes = " ".join(str(m.get("texte") or "") + " " + str(m.get("piece") or "") for m in messages).lower()
        trouvees = sum(
            1
            for p in attendu.pieces_manquantes
            if (p.get("periode") or "").lower() in textes and all(mot in textes for mot in p["type"].split("_"))
        )
        ev.mesures.append(
            Mesure(
                "pieces_manquantes_demandees",
                len(attendu.pieces_manquantes),
                trouvees,
                "EXACT" if trouvees == len(attendu.pieces_manquantes) else "ECART" if trouvees else "NON_CALCULE",
            )
        )

    # ---- verdicts de conformité (lot 2)
    verdicts = _lire(store, "agent_verdicts", session_id)
    if verdicts is None:
        ev.mesures.append(
            Mesure("verdicts", len(attendu.verdicts), None, "NON_EVALUABLE", "table agent_verdicts absente (lot 2)")
        )
    else:
        par_regle = {v["regle"]: v["verdict"] for v in verdicts}
        justes = sum(1 for k, v in attendu.verdicts.items() if par_regle.get(k) == v)
        ev.mesures.append(
            Mesure(
                "verdicts",
                len(attendu.verdicts),
                justes,
                "EXACT" if justes == len(attendu.verdicts) else "ECART" if justes else "NON_CALCULE",
                f"écarts : {[k for k, v in attendu.verdicts.items() if par_regle.get(k) != v]}",
            )
        )
        hcsf_attendu, hcsf_obtenu = attendu.verdicts.get("HCSF_TAUX_EFFORT"), par_regle.get("HCSF_TAUX_EFFORT")
        if attendu.bloquant:
            ev.mesures.append(
                Mesure(
                    "verdict_hcsf", hcsf_attendu, hcsf_obtenu, "NON_EVALUABLE", "dossier bloquant : pas de taux à juger"
                )
            )
        else:
            ev.mesures.append(
                Mesure(
                    "verdict_hcsf",
                    hcsf_attendu,
                    hcsf_obtenu,
                    "EXACT" if hcsf_obtenu == hcsf_attendu else ("ECART" if hcsf_obtenu else "NON_CALCULE"),
                    "norme HCSF du taux d'effort (35 %), contraignante pour la production de crédits",
                )
            )

    # ---- recommandation (lot 2)
    recos = _lire(store, "agent_recommandations", session_id)
    if recos is None:
        ev.mesures.append(
            Mesure(
                "recommandation",
                attendu.recommandation,
                None,
                "NON_EVALUABLE",
                "table agent_recommandations absente (lot 2)",
            )
        )
    else:
        position = recos[-1]["position"] if recos else None
        ev.mesures.append(
            Mesure(
                "recommandation",
                attendu.recommandation,
                position,
                "EXACT" if position == attendu.recommandation else ("ECART" if position else "NON_CALCULE"),
            )
        )
        if recos:
            reserves = " ".join(str(r.get("reserves") or "") for r in recos).upper()
            trouvees = sum(1 for r in attendu.reserves if r in reserves)
            ev.mesures.append(
                Mesure(
                    "reserves",
                    len(attendu.reserves),
                    trouvees,
                    "EXACT" if trouvees == len(attendu.reserves) else "ECART" if trouvees else "NON_CALCULE",
                )
            )

    # ---- synthèse (lot 2)
    syntheses = _lire(store, "agent_syntheses", session_id)
    if syntheses is None:
        ev.mesures.append(
            Mesure("synthese_produite", True, None, "NON_EVALUABLE", "table agent_syntheses absente (lot 2)")
        )
    else:
        verifiees = [x for x in syntheses if x.get("statut") == "VERIFIEE"]
        ev.mesures.append(
            Mesure(
                "synthese_produite",
                True,
                bool(verifiees),
                "EXACT" if verifiees else ("ECART" if syntheses else "NON_CALCULE"),
                f"{len(syntheses)} dépôt(s), {len(verifiees)} vérifié(s)",
            )
        )

    # ---- pièces numérisées : le changement de méthode (de lire_piece à ocr_piece)
    if attendu.pieces_scannees:
        pieces_vt = (
            SQLiteStore(config.sqlite_verite_terrain)
            .requete(
                "SELECT piece_id, type, personne, periode, fichier FROM vt_pieces WHERE demande_id = ?",
                (session.demande_id,),
            )
            .to_dicts()
        )
        lus_par_ocr: set[str] = set()
        for t in _lire(store, "agent_traces", session_id) or []:
            if t.get("nom") == "ocr_piece":
                parametres = json.loads(t.get("detail_json") or "{}").get("parametres", {})
                lus_par_ocr.add(str(parametres.get("piece", "")))
        trouvees = 0
        for scan in attendu.pieces_scannees:
            cible = next(
                (
                    x
                    for x in pieces_vt
                    if x["type"] == scan["type"]
                    and (x["personne"] or "") == (scan["personne"] or "")
                    and (x["periode"] or "") == (scan["periode"] or "")
                ),
                None,
            )
            if cible and {cible["piece_id"], cible["fichier"], Path(cible["fichier"]).stem} & lus_par_ocr:
                trouvees += 1
        total = len(attendu.pieces_scannees)
        ev.mesures.append(
            Mesure(
                "ocr_pieces_numerisees",
                total,
                trouvees,
                "EXACT" if trouvees == total else ("ECART" if trouvees else "NON_CALCULE"),
                f"{trouvees} pièce(s) numérisée(s) lue(s) par OCR sur {total}",
            )
        )
        ev.moments["CHANGEMENT_DE_METHODE"] = trouvees == total

    # ---- le score de la banque : consulté, et relativisé quand il contredit l'analyse
    if attendu.score_banque is not None:
        valeur = next((c["valeur"] for c in reversed(calculs) if c["nom_resultat"] == "score_eligibilite"), None)
        ev.mesures.append(
            Mesure(
                "score_consulte",
                attendu.score_banque,
                valeur,
                "NON_CALCULE"
                if valeur is None
                else ("EXACT" if abs(float(valeur) - attendu.score_banque) < 0.5 else "ECART"),
                f"classe attendue {attendu.classe_score}"
                + (" ; le score contredit l'analyse" if attendu.score_diverge else ""),
            )
        )
        if attendu.score_diverge:
            textes = [str(x.get("texte") or "").lower() for x in (syntheses or []) if x.get("statut") == "VERIFIEE"]
            ev.moments["SCORE_RELATIVISE"] = any("score" in t and any(m in t for m in MOTS_RELATIVISER) for t in textes)

    # ---- persistance
    horodatage = dt.datetime.now().isoformat(timespec="seconds")
    store.remplacer(
        "agent_evaluations",
        pl.DataFrame(
            [
                {
                    "session_id": session_id,
                    "demande_id": session.demande_id,
                    "mesure": m.nom,
                    "attendu": json.dumps(m.attendu, default=str),
                    "obtenu": json.dumps(m.obtenu, default=str),
                    "statut": m.statut,
                    "detail": m.detail,
                    "horodatage": horodatage,
                }
                for m in ev.mesures
            ]
        ),
        "session_id",
        session_id,
    )
    return ev


MOTS_RELATIVISER = (
    "ne voit pas",
    "ne remplace",
    "consultatif",
    "indicateur",
    "ne tient pas compte",
    "ignore",
    "limite",
    "ne lit",
)
MOIS = [
    "janvier",
    "février",
    "mars",
    "avril",
    "mai",
    "juin",
    "juillet",
    "août",
    "septembre",
    "octobre",
    "novembre",
    "décembre",
]


def _mois_en_clair(cle: str) -> str | None:
    """« 2026-08 » → « août 2026 » ; sinon None."""
    m = re.fullmatch(r"(\d{4})-(\d{2})", cle)
    if not m:
        return None
    return f"{MOIS[int(m.group(2)) - 1]} {m.group(1)}"


def _preuve_alternative(attendu_d: dict, messages: list[dict], journal: list[dict]) -> bool:
    """Un moment de réflexivité peut laisser une autre trace qu'un doute : la pièce manquante a été demandée au client ;
    le contrôle du calcul se lit dans le journal (« je corrige ») ou dans l'exclusion explicite de la prime."""
    t = attendu_d["type"]
    if t == "PIECE_MANQUANTE":
        per = (attendu_d.get("periode") or "").lower()
        formes = [per, _mois_en_clair(per) or per]
        return any(
            any(f in (str(m.get("texte", "")) + " " + str(m.get("periode", ""))).lower() for f in formes)
            for m in messages
        )
    if t == "PRIME_DANS_LE_NET":
        textes = " ".join(str(e.get("texte", "")).lower() for e in journal if e.get("type") in ("pensee", "constat"))
        return "prime" in textes and any(x in textes for x in ("corrig", "exclu", "sans prime", "hors prime"))
    return False
