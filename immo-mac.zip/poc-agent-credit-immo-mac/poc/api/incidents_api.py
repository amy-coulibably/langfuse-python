"""api-incidents : le fichier d'incidents simulé, un guichet externe à la banque (port 8003)."""

from __future__ import annotations

from poc.api.commun import creer_app
from poc.config import Config, charger_config
from poc.services.incidents import ServiceIncidents


def creer(config: Config | None = None):
    service = ServiceIncidents(config or charger_config())
    app = creer_app(
        "api-incidents", "Le fichier d'incidents : interrogé par identité (nom, prénom, date de naissance)."
    )

    @app.get("/incidents", summary="Les incidents connus d'une personne")
    def incidents(nom: str, prenom: str, date_naissance: str) -> dict:
        return service.rechercher(nom, prenom, date_naissance)

    return app


app = creer()
