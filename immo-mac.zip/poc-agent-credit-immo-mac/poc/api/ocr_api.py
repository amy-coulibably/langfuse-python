"""api-ocr : la reconnaissance de caractères des pièces scannées (port 8006). Un service à part du coffre : le coffre
garde les pièces, ce guichet les lit quand la lecture native échoue."""

from __future__ import annotations

from poc.api.commun import creer_app
from poc.config import Config, charger_config
from poc.services.ocr import ServiceOCR, description_moteur


def creer(config: Config | None = None):
    service = ServiceOCR(config or charger_config())
    app = creer_app(
        "api-ocr",
        "La lecture des pièces scannées ou photographiées : texte ligne par ligne, confiance par ligne, statut de lecture.",
    )

    @app.get("/moteur", summary="Le moteur OCR installé (nom, version, langue)")
    def moteur() -> dict:
        return {k: v for k, v in description_moteur().items() if k != "chemin"}

    @app.get(
        "/demandes/{demande_id}/pieces/{piece}/ocr", summary="Le texte reconnu d'une pièce, avec confiance par ligne"
    )
    def ocr(demande_id: str, piece: str) -> dict:
        return service.ocr_piece(demande_id, piece)

    return app


app = creer()
