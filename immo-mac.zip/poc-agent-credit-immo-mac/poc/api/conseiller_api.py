"""api-conseiller : l'espace de travail du conseiller et de l'agent (port 8004) : sessions, journal, traces, feuille de calcul,
faits, doutes, messages au client, verdicts, synthèse, recommandation, remise, fiches de méthode."""

from __future__ import annotations

from typing import Any

from pydantic import BaseModel, Field

from poc.api.commun import creer_app
from poc.config import Config, charger_config
from poc.donnees import SQLiteStore
from poc.schemas import DemandeCalcul
from poc.services.conseiller import ServiceConseiller
from poc.services.erreurs import ErreurService


class CreationSession(BaseModel):
    demande_id: str
    modele: str = "sans_modele"


class MiseAJourSession(BaseModel):
    statut: str | None = None
    etape: str | None = None


class EntreeJournalCorps(BaseModel):
    etape: str
    type: str
    texte: str


class TraceCorps(BaseModel):
    etape: str
    type: str
    nom: str
    duree_ms: int
    tokens_entree: int = 0
    tokens_sortie: int = 0
    cout_euros: float | None = None
    detail: dict | None = None


class CalculExterneCorps(BaseModel):
    etape: str
    resultats: dict[str, float]
    unite: str = "euros"
    code: str
    entrees: dict[str, Any] = Field(default_factory=dict)
    commentaire: str = ""


class FaitCorps(BaseModel):
    nom: str
    valeur: float
    unite: str = "euros"
    source: dict
    commentaire: str = ""


class DouteCorps(BaseModel):
    objet: str
    hypotheses: list[str]
    question: str
    pieces_concernees: list[str] = Field(default_factory=list)
    faits_concernes: list[str] = Field(default_factory=list)
    bloquant: bool = False
    etape: str = ""


class MessageCorps(BaseModel):
    piece: str
    personne: str
    periode: str | None = None
    motif: str = ""


class VerdictCorps(BaseModel):
    regle: str
    verdict: str
    valeur: str | None = None
    seuil: str | None = None
    justification: str = ""
    references: list[str] = Field(default_factory=list)


class SyntheseCorps(BaseModel):
    texte: str
    chiffres: list[dict] = Field(default_factory=list)


class RecommandationCorps(BaseModel):
    position: str
    motifs: list[dict] = Field(default_factory=list)
    reserves: list[dict] = Field(default_factory=list)
    conditions: list[str] = Field(default_factory=list)


def creer(config: Config | None = None):
    config = config or charger_config()
    c = ServiceConseiller(config, SQLiteStore(config.sqlite_agent))
    s = c.sessions
    app = creer_app(
        "api-conseiller",
        "L'espace de travail : sessions, journal, calculs, faits, doutes, messages, verdicts, synthèse, recommandation, remise.",
    )

    # ---- sessions, journal, traces
    @app.post("/sessions", summary="Ouvre une session de l'agent sur une demande")
    def creer_session(corps: CreationSession) -> dict:
        return s.creer_session(corps.demande_id, corps.modele).model_dump(mode="json")

    @app.get("/sessions", summary="Les dernières sessions")
    def sessions(demande_id: str | None = None, n: int | None = None) -> list[dict]:
        return [x.model_dump(mode="json") for x in s.sessions(demande_id, n)]

    @app.get("/sessions/{session_id}", summary="Une session")
    def session(session_id: str) -> dict:
        return s.session(session_id).model_dump(mode="json")

    @app.patch("/sessions/{session_id}", summary="Change le statut ou l'étape d'une session")
    def maj_session(session_id: str, corps: MiseAJourSession) -> dict:
        return s.mettre_a_jour(session_id, corps.statut, corps.etape).model_dump(mode="json")

    @app.post("/sessions/{session_id}/journal", summary="Ajoute une ligne au journal de raisonnement")
    def journaliser(session_id: str, corps: EntreeJournalCorps) -> dict:
        return s.journaliser(session_id, corps.etape, corps.type, corps.texte).model_dump(mode="json")

    @app.get("/sessions/{session_id}/journal", summary="Le journal de raisonnement")
    def journal(session_id: str) -> list[dict]:
        return [e.model_dump(mode="json") for e in s.journal(session_id)]

    @app.post("/sessions/{session_id}/traces", summary="Ajoute une trace technique")
    def tracer(session_id: str, corps: TraceCorps) -> dict:
        return s.tracer(
            session_id,
            corps.etape,
            corps.type,
            corps.nom,
            corps.duree_ms,
            corps.tokens_entree,
            corps.tokens_sortie,
            corps.cout_euros,
            corps.detail,
        ).model_dump(mode="json")

    @app.get("/sessions/{session_id}/traces", summary="Les traces techniques")
    def traces(session_id: str) -> list[dict]:
        return [t.model_dump(mode="json") for t in s.traces(session_id)]

    # ---- feuille de calcul
    @app.post("/sessions/{session_id}/calculs", summary="Pose un calcul dans l'atelier")
    def calculer(session_id: str, demande: DemandeCalcul) -> list[dict]:
        s.session(session_id)
        return [r.model_dump(mode="json") for r in s.atelier.calculer(session_id, demande)]

    @app.post("/sessions/{session_id}/calculs-externes", summary="Archive les résultats d'un calcul fermé (simulateur)")
    def calcul_externe(session_id: str, corps: CalculExterneCorps) -> list[dict]:
        return c.archiver_calcul_externe(
            session_id, corps.etape, corps.resultats, corps.unite, corps.code, corps.entrees, corps.commentaire
        )

    @app.get("/sessions/{session_id}/calculs", summary="La feuille de calcul")
    def calculs(session_id: str) -> list[dict]:
        s.session(session_id)
        return [x.model_dump(mode="json") for x in s.atelier.feuille(session_id)]

    # ---- faits, doutes, messages, verdicts
    @app.post("/sessions/{session_id}/faits", summary="Enregistre un fait avec sa source vérifiée")
    def noter_fait(session_id: str, corps: FaitCorps) -> dict:
        return c.noter_fait(session_id, corps.nom, corps.valeur, corps.unite, corps.source, corps.commentaire)

    @app.get("/sessions/{session_id}/faits", summary="Les faits enregistrés")
    def faits(session_id: str) -> list[dict]:
        return c.faits(session_id)

    @app.post("/sessions/{session_id}/doutes", summary="Enregistre un doute")
    def noter_doute(session_id: str, corps: DouteCorps) -> dict:
        return c.noter_doute(
            session_id,
            corps.etape,
            corps.objet,
            corps.hypotheses,
            corps.question,
            corps.pieces_concernees,
            corps.faits_concernes,
            corps.bloquant,
        )

    @app.get("/sessions/{session_id}/doutes", summary="Les doutes")
    def doutes(session_id: str) -> list[dict]:
        return c.doutes(session_id)

    @app.post("/sessions/{session_id}/messages", summary="Envoie un message au client (pièce demandée)")
    def demander_piece(session_id: str, corps: MessageCorps) -> dict:
        return c.demander_piece(session_id, corps.piece, corps.personne, corps.periode, corps.motif)

    @app.get("/sessions/{session_id}/messages", summary="Les messages envoyés au client")
    def messages(session_id: str) -> list[dict]:
        return c.messages(session_id)

    @app.post("/sessions/{session_id}/verdicts", summary="Enregistre une ligne de la grille de conformité")
    def enregistrer_verdict(session_id: str, corps: VerdictCorps) -> dict:
        return c.enregistrer_verdict(
            session_id, corps.regle, corps.verdict, corps.valeur, corps.seuil, corps.justification, corps.references
        )

    @app.get("/sessions/{session_id}/verdicts", summary="La grille de conformité")
    def verdicts(session_id: str) -> list[dict]:
        return c.verdicts(session_id)

    # ---- synthèse, recommandation, remise
    @app.post(
        "/sessions/{session_id}/syntheses", summary="Dépose la synthèse (vérifiée : chiffres sourcés, pas d'avis)"
    )
    def enregistrer_synthese(session_id: str, corps: SyntheseCorps) -> dict:
        return c.enregistrer_synthese(session_id, corps.texte, corps.chiffres)

    @app.post("/sessions/{session_id}/recommandations", summary="Dépose la recommandation (contrôlée)")
    def enregistrer_recommandation(session_id: str, corps: RecommandationCorps) -> dict:
        return c.enregistrer_recommandation(session_id, corps.position, corps.motifs, corps.reserves, corps.conditions)

    @app.get("/sessions/{session_id}/dossier-travail", summary="Tout ce que la session a produit")
    def dossier_travail(session_id: str) -> dict:
        return c.dossier_travail(session_id)

    @app.post("/sessions/{session_id}/remettre", summary="Remet le dossier au conseiller")
    def remettre(session_id: str) -> dict:
        return c.remettre(session_id)

    # ---- fiches de méthode
    @app.get("/fiches", summary="Les fiches de méthode disponibles")
    def fiches() -> list[dict]:
        from poc.agent.fiches import lister_fiches

        return lister_fiches(config.fiches_dir)

    @app.get("/fiches/{nom}", summary="Une fiche de méthode")
    def fiche(nom: str) -> dict:
        from poc.agent.fiches import lire_fiche

        try:
            return {"nom": nom, "contenu": lire_fiche(nom, config.fiches_dir)}
        except FileNotFoundError as exc:
            raise ErreurService("FICHE_INTROUVABLE", str(exc), 404) from exc

    return app


app = creer()
