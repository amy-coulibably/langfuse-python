"""api-coffre : les pièces déposées par le client (port 8001)."""

from __future__ import annotations

from fastapi import Query

from poc.api.commun import creer_app
from poc.config import Config, charger_config
from poc.services.coffre import ServiceCoffre


def creer(config: Config | None = None):
    service = ServiceCoffre(config or charger_config())
    app = creer_app(
        "api-coffre",
        "Les pièces déposées par le client : inventaire, lecture ligne à ligne (l'OCR est le guichet api-ocr).",
    )

    @app.get("/demandes/{demande_id}/pieces", summary="L'inventaire des pièces d'une demande")
    def pieces(demande_id: str) -> list[dict]:
        return service.lister_pieces(demande_id)

    @app.get("/demandes/{demande_id}/pieces/{piece}", summary="Le texte d'une pièce, ligne par ligne")
    def piece(demande_id: str, piece: str, page: int | None = Query(default=None)) -> dict:
        return service.lire_piece(demande_id, piece, page)

    return app


app = creer()
