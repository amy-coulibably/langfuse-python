"""Ce que les quatre API partagent : la création de l'application, la traduction des erreurs de service en réponses HTTP
lisibles (`{"detail": {"code": ..., "message": ...}}`), la route `/sante`."""

from __future__ import annotations

from fastapi import FastAPI, Request
from fastapi.responses import JSONResponse

from poc import __version__
from poc.services.atelier import ErreurAtelier
from poc.services.erreurs import ErreurService
from poc.services.sessions import SessionIntrouvable


def creer_app(nom: str, description: str) -> FastAPI:
    app = FastAPI(title=nom, description=description, version=__version__)

    @app.exception_handler(ErreurService)
    async def _erreur_service(_: Request, exc: ErreurService) -> JSONResponse:
        return JSONResponse(status_code=exc.statut_http, content={"detail": {"code": exc.code, "message": exc.message}})

    @app.exception_handler(ErreurAtelier)
    async def _erreur_atelier(_: Request, exc: ErreurAtelier) -> JSONResponse:
        return JSONResponse(status_code=400, content={"detail": {"code": exc.code, "message": exc.message}})

    @app.exception_handler(SessionIntrouvable)
    async def _session_introuvable(_: Request, exc: SessionIntrouvable) -> JSONResponse:
        return JSONResponse(status_code=404, content={"detail": {"code": "INTROUVABLE", "message": str(exc)}})

    @app.get("/sante", summary="Le guichet répond-il ?")
    def sante() -> dict:
        return {"api": nom, "version": __version__, "ok": True}

    return app
