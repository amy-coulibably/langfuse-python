"""Les quatre guichets : des API HTTP locales (FastAPI), une par « maison ».

| API | Port | Guichets |
| --- | --- | --- |
| `api-coffre` | 8001 | pièces d'une demande, contenu d'une pièce, OCR |
| `api-banque` | 8002 | demande, client, comptes, mouvements, crédits, épargne, barème, simulateur, politique |
| `api-incidents` | 8003 | incidents connus d'une personne |
| `api-conseiller` | 8004 | sessions, journal, traces, calculs, faits, doutes, messages, verdicts, synthèse, recommandation, remise, fiches |

Chaque API a sa page `/docs` (documentation interactive) et sa route `/sante`. Lancement : `poc api coffre` (une) ou
`poc api tout` (les quatre). Les outils de l'agent en sont les clients (`BackendHTTP`) quand on lance l'agent avec `--http`.
"""

from poc.api.commun import creer_app

__all__ = ["creer_app"]
