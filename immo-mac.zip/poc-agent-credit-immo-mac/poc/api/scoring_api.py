"""api-scoring : le score d'éligibilité de la banque (port 8005). Une grille de points transparente
(`referentiels/grille_score.md`), consultative, jamais décisionnelle."""

from __future__ import annotations

from poc.api.commun import creer_app
from poc.config import Config, charger_config
from poc.services.scoring import ServiceScoring


def creer(config: Config | None = None):
    service = ServiceScoring(config or charger_config())
    app = creer_app(
        "api-scoring",
        "Le score interne préliminaire d'une demande, critère par critère, avec ce qu'il ne voit pas. Indicateur consultatif.",
    )

    @app.get("/grille", summary="La grille de points, en clair")
    def grille() -> dict:
        return service.grille()

    @app.get("/demandes/{demande_id}/score", summary="Le score d'une demande, critère par critère")
    def score(demande_id: str) -> dict:
        return service.score(demande_id)

    return app


app = creer()
