"""api-banque : le système d'information de la banque, le barème, le simulateur, les textes de politique (port 8002)."""

from __future__ import annotations

from fastapi import Query
from pydantic import BaseModel, Field

from poc.api.commun import creer_app
from poc.config import Config, charger_config
from poc.services.banque import ServiceBanque


class DemandeSimulation(BaseModel):
    montant: float = Field(gt=0)
    duree_annees: int = Field(gt=0)
    taux_nominal_pct: float | None = None
    ages: list[int] = Field(default_factory=list)


def creer(config: Config | None = None):
    service = ServiceBanque(config or charger_config())
    app = creer_app(
        "api-banque",
        "Le système d'information de la banque : demande, clients, comptes, mouvements, crédits, épargne ; barème, simulateur, politique.",
    )

    @app.get("/demandes/{demande_id}", summary="La demande déposée")
    def demande(demande_id: str) -> dict:
        return service.demande(demande_id)

    @app.get("/clients/{client_id}", summary="La fiche d'un client")
    def client(client_id: str) -> dict:
        return service.client(client_id)

    @app.get("/clients/{client_id}/identite", summary="Nom, prénom, date de naissance (pour le fichier d'incidents)")
    def identite(client_id: str) -> dict:
        return service.identite(client_id)

    @app.get("/clients/{client_id}/comptes", summary="Les comptes d'un client dans la banque")
    def comptes(client_id: str) -> list[dict]:
        return service.comptes(client_id)

    @app.get("/comptes/{compte_id}/mouvements", summary="Les lignes d'un compte sur une période")
    def mouvements(
        compte_id: str,
        du: str | None = None,
        au: str | None = None,
        motif: str | None = None,
        limite: int = Query(default=200, le=500),
    ) -> dict:
        return service.mouvements(compte_id, du, au, motif, limite)

    @app.get("/clients/{client_id}/credits", summary="Les crédits en cours : banque et déclarés")
    def credits(client_id: str) -> dict:
        return service.credits(client_id)

    @app.get("/clients/{client_id}/epargne", summary="L'épargne d'un client dans la banque")
    def epargne(client_id: str) -> list[dict]:
        return service.epargne(client_id)

    @app.get("/bareme", summary="Taux, assurance, frais d'acquisition")
    def bareme(duree_annees: int | None = None, age: int | None = None) -> dict:
        return service.bareme(duree_annees, age)

    @app.post("/simulateur", summary="Mensualité, assurance et coût d'un prêt")
    def simulateur(demande: DemandeSimulation) -> dict:
        return service.simuler(demande.montant, demande.duree_annees, demande.taux_nominal_pct, demande.ages)

    @app.get("/politique/{nom}", summary="Un texte de référence : politique_credit, norme_hcsf, pieces_attendues")
    def politique(nom: str) -> dict:
        return service.politique(nom)

    return app


app = creer()
