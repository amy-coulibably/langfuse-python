"""Configuration locale du POC : racine du projet, répertoire des données, chemins des bases et des dossiers.

Tout vit sous `data/` (ignoré par git, régénéré par le générateur) sauf les référentiels et les fiches de méthode, qui sont
du texte versionné à la racine du projet.
"""

from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path

from dotenv import load_dotenv

RACINE = Path(__file__).resolve().parents[1]
REFERENTIELS_DIR = RACINE / "referentiels"
FICHES_DIR = RACINE / "fiches"
CONFIG_DIR = RACINE / "config"

load_dotenv(RACINE / ".env")


@dataclass(frozen=True)
class Config:
    """Paramètres de l'exécution locale."""

    data_dir: Path

    @property
    def sqlite_agent(self) -> Path:
        """Ce que l'agent produit : sessions, journal, faits, calculs, doutes, synthèses, recommandations, évaluations."""
        return self.data_dir / "agent.sqlite"

    @property
    def sqlite_banque(self) -> Path:
        """Le système d'information de la banque, en miniature (lot 1)."""
        return self.data_dir / "banque.sqlite"

    @property
    def sqlite_incidents(self) -> Path:
        """Le fichier d'incidents simulé (lot 1)."""
        return self.data_dir / "incidents.sqlite"

    @property
    def sqlite_verite_terrain(self) -> Path:
        """Base séparée, jamais exposée à l'agent : sert seulement à le noter (lot 1)."""
        return self.data_dir / "verite_terrain.sqlite"

    @property
    def coffre_dir(self) -> Path:
        """Les pièces déposées par les clients, un dossier par demande (lot 1)."""
        return self.data_dir / "coffre"

    @property
    def checkpoints(self) -> Path:
        """Sauvegarde LangGraph de l'état après chaque étape, pour reprendre une session interrompue."""
        return self.data_dir / "agent_checkpoints.sqlite"

    @property
    def referentiels_dir(self) -> Path:
        return REFERENTIELS_DIR

    @property
    def fiches_dir(self) -> Path:
        return FICHES_DIR


def charger_config() -> Config:
    data_dir = Path(os.getenv("POC_DATA_DIR", "data"))
    if not data_dir.is_absolute():
        data_dir = RACINE / data_dir
    return Config(data_dir=data_dir)
