"""L'interface de démonstration (Streamlit) : `poc interface`."""
