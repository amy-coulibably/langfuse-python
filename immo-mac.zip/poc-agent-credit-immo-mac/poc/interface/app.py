"""L'interface de démonstration (Streamlit) : trois colonnes, pensées pour un vidéoprojecteur.

- à gauche, le dossier : les pièces déposées (lues, demandées), les comptes, les crédits déclarés ;
- au centre, le raisonnement de l'agent, phrase par phrase, avec ses appels d'outils, ses doutes et ses garde-fous ;
- à droite, le résultat qui se remplit : feuille de calcul, faits, grille de conformité, synthèse, recommandation.

Trois façons de faire tourner l'agent : **rejouer** une session enregistrée (sans modèle, sans attente : la démonstration ne
dépend de rien), **lancer** en continu, ou **pas à pas** (l'agent s'arrête à chaque étape ; on commente ; on continue). La
remise au conseiller est une vraie interruption : le workflow s'arrête et attend le bouton. Un bouton simule la réception
de la pièce manquante et fait repartir l'agent de l'étape « vérifier ».

Lancement : `poc interface` (ou `streamlit run poc/interface/app.py`).
"""

from __future__ import annotations

import datetime as dt
import json
import time

import streamlit as st

from poc.agent import PiloteSession, reprendre_session
from poc.config import charger_config
from poc.etapes import charger_parcours
from poc.generateur import cas_de, demandes_disponibles, deposer_piece
from poc.llm import charger_config_llm
from poc.outils import BackendLocal

st.set_page_config(page_title="Agent crédit immobilier — POC", layout="wide", page_icon="🏠")
CONFIG = charger_config()
STYLES_JOURNAL = {
    "etape": ("#1f4e79", "**"),
    "pensee": ("#444444", "_"),
    "outil": ("#888888", "`"),
    "constat": ("#1b5e20", ""),
    "doute": ("#b26a00", ""),
    "garde_fou": ("#b71c1c", ""),
    "systeme": ("#6a1b9a", ""),
}
ICONES = {"etape": "▶", "pensee": "💭", "outil": "🔧", "constat": "✔", "doute": "❓", "garde_fou": "🛑", "systeme": "⚙"}


# ---------------------------------------------------------------------------------------------------------------------
# Accès aux données (toujours relues : l'agent écrit pendant qu'on regarde)
# ---------------------------------------------------------------------------------------------------------------------
def backend() -> BackendLocal:
    if "backend" not in st.session_state:
        st.session_state.backend = BackendLocal(CONFIG)
    return st.session_state.backend


def sessions_de(demande_id: str) -> list[dict]:
    return backend().lire("sessions", demande_id=demande_id, n=30)


def journal(session_id: str) -> list[dict]:
    try:
        return backend().lire("journal", session_id=session_id)
    except Exception:  # noqa: BLE001
        return []


def dossier(session_id: str) -> dict:
    return backend().lire("dossier_travail", session_id=session_id)


def pieces(demande_id: str) -> list[dict]:
    try:
        return backend().lire("pieces", demande_id=demande_id)
    except Exception:  # noqa: BLE001
        return []


def demande(demande_id: str) -> dict | None:
    try:
        return backend().lire("demande", demande_id=demande_id)
    except Exception:  # noqa: BLE001
        return None


# ---------------------------------------------------------------------------------------------------------------------
# État de l'interface
# ---------------------------------------------------------------------------------------------------------------------
def etat_initial() -> None:
    st.session_state.setdefault("mode", "rejeu")
    st.session_state.setdefault("session_id", None)
    st.session_state.setdefault("pilote", None)
    st.session_state.setdefault("curseur", 0)  # rejeu : nombre de lignes du journal déjà affichées
    st.session_state.setdefault("lecture", False)
    st.session_state.setdefault("reprise_en_cours", False)
    st.session_state.setdefault("message", "")


def horodatage_courant(lignes: list[dict], curseur: int) -> str | None:
    """En rejeu, l'instant « présent » : l'horodatage de la dernière ligne affichée ; les résultats de droite s'y arrêtent."""
    if not lignes or curseur <= 0:
        return None
    return lignes[min(curseur, len(lignes)) - 1]["horodatage"]


def jusqu_a(elements: list[dict], limite: str | None, cle: str = "horodatage") -> list[dict]:
    if limite is None:
        return elements
    return [e for e in elements if str(e.get(cle, "")) <= limite]


# ---------------------------------------------------------------------------------------------------------------------
# Barre latérale : choisir la demande, le mode, lancer
# ---------------------------------------------------------------------------------------------------------------------
def barre_laterale() -> None:
    st.sidebar.title("Agent crédit immobilier")
    st.sidebar.caption("POC — données synthétiques. L'agent recommande, le conseiller décide.")
    demandes = demandes_disponibles(CONFIG)
    if not demandes:
        st.sidebar.error("Aucune demande : lancer `poc donnees generer`.")
        st.stop()
    demande_id = st.sidebar.selectbox("Demande", demandes, key="demande_id")
    mode = st.sidebar.radio(
        "Mode",
        ["rejeu", "continu", "pas à pas"],
        key="mode",
        help="Rejeu : une session enregistrée, sans modèle. Continu : l'agent déroule les sept étapes. Pas à pas : il s'arrête à chaque étape.",
    )

    if mode == "rejeu":
        sessions = [s for s in sessions_de(demande_id) if s["statut"] in ("REMISE", "ECHEC", "INTERROMPUE")]
        if not sessions:
            st.sidebar.warning("Aucune session enregistrée pour cette demande : lancer l'agent d'abord.")
            return
        libelles = {
            f"{s['session_id']} · {s['modele']} · {s['statut']} · {s['creation'][:16]}": s["session_id"]
            for s in sessions
        }
        choix = st.sidebar.selectbox("Session à rejouer", list(libelles), key="choix_rejeu")
        st.sidebar.slider("Vitesse (lignes par seconde)", 0.5, 10.0, 2.0, 0.5, key="vitesse")
        c1, c2, c3 = st.sidebar.columns(3)
        if c1.button("▶ Rejouer", use_container_width=True):
            st.session_state.session_id = libelles[choix]
            st.session_state.curseur = 0
            st.session_state.lecture = True
        if c2.button("⏸ Pause", use_container_width=True):
            st.session_state.lecture = not st.session_state.lecture
        if c3.button("⏭ Fin", use_container_width=True):
            st.session_state.session_id = libelles[choix]
            st.session_state.curseur = 10**6
            st.session_state.lecture = False
        return

    cfg_llm = charger_config_llm()
    modeles = cfg_llm.modeles_disponibles()
    defaut = cfg_llm.defaut if cfg_llm.defaut in modeles else modeles[0]
    modele = st.sidebar.selectbox("Modèle", modeles, index=modeles.index(defaut), key="modele")
    pilote: PiloteSession | None = st.session_state.pilote
    if pilote is None or pilote.termine or pilote.erreur:
        if st.sidebar.button("🚀 Démarrer une session", use_container_width=True, type="primary"):
            pilote = PiloteSession(
                CONFIG, demande_id, modele=modele, pas_a_pas=(mode == "pas à pas"), arret_avant_remise=True
            )
            st.session_state.session_id = pilote.demarrer()
            st.session_state.pilote = pilote
            st.session_state.curseur = 10**6
            st.session_state.lecture = False
            st.rerun()
    else:
        if pilote.en_cours:
            st.sidebar.info(f"Étape en cours : **{pilote.etape_en_cours or '…'}**")
        elif pilote.prochaine_etape == "remettre":
            st.sidebar.success("Dossier prêt. L'agent attend votre feu vert pour le remettre.")
            if st.sidebar.button("📨 Remettre au conseiller", use_container_width=True, type="primary"):
                pilote.continuer()
                st.rerun()
        elif pilote.prochaine_etape:
            st.sidebar.info(f"Prochaine étape : **{pilote.prochaine_etape}**")
            if st.sidebar.button("⏭ Étape suivante", use_container_width=True, type="primary"):
                pilote.continuer()
                st.rerun()
        if st.sidebar.button("⏹ Arrêter", use_container_width=True):
            pilote.arreter()
            st.session_state.pilote = None
            st.rerun()


# ---------------------------------------------------------------------------------------------------------------------
# Les trois colonnes
# ---------------------------------------------------------------------------------------------------------------------
def colonne_dossier(demande_id: str, session_id: str | None, limite: str | None) -> None:
    st.subheader("Le dossier")
    d = demande(demande_id)
    if d:
        st.markdown(
            f"**{', '.join(e['prenom'] + ' ' + e['nom'] for e in d['emprunteurs'])}**  \n"
            f"{d['description_bien']}  \n{d['adresse_bien']}  \nPrix **{d['prix']:,.0f} €** · apport **{d['apport']:,.0f} €** · {d['duree_souhaitee_annees']} ans".replace(
                ",", " "
            )
        )
        if d["credits_declares_par_le_client"]:
            st.caption(
                "Crédits déclarés : "
                + ", ".join(
                    f"{c['type']} {c['organisme']} {c['mensualite_declaree']:.0f} €/mois"
                    for c in d["credits_declares_par_le_client"]
                )
            )
    lues: set[str] = set()
    demandees: list[str] = []
    if session_id:
        for e in jusqu_a(journal(session_id), limite):
            if e["type"] == "outil" and e["texte"].startswith(("lire_piece(", "ocr_piece(")) and "piece=" in e["texte"]:
                lues.add(e["texte"].split("piece=")[1].split(")")[0].split(",")[0].strip())
        try:
            demandees = [
                f"{m['piece']} ({m['periode'] or ''})"
                for m in jusqu_a(backend().lire("messages", session_id=session_id), limite)
            ]
        except Exception:  # noqa: BLE001
            demandees = []
    st.markdown("**Pièces déposées**")
    for p in pieces(demande_id):
        statut = "🟢" if p["piece_id"] in lues else "⚪"
        st.markdown(f"{statut} `{p['piece_id']}` {p['libelle']}")
    if demandees:
        st.markdown("**Pièces demandées au client**")
        for x in demandees:
            st.markdown(f"🟠 {x}")


def colonne_raisonnement(session_id: str | None, lignes: list[dict], curseur: int) -> None:
    st.subheader("Le raisonnement")
    if not session_id:
        st.info("Choisissez une session à rejouer, ou démarrez l'agent.")
        return
    visibles = lignes[:curseur]
    if not visibles:
        st.caption("L'agent n'a encore rien dit.")
    for e in visibles:
        couleur, _ = STYLES_JOURNAL.get(e["type"], ("#000000", ""))
        texte = e["texte"].replace("\n", "  \n")
        if e["type"] == "etape":
            st.markdown(
                f"<div style='color:{couleur};font-weight:600;margin-top:10px'>{ICONES['etape']} {texte}</div>",
                unsafe_allow_html=True,
            )
        elif e["type"] == "outil":
            st.markdown(
                f"<div style='color:{couleur};font-family:monospace;font-size:0.8em'>{ICONES['outil']} {texte}</div>",
                unsafe_allow_html=True,
            )
        elif e["type"] in ("doute", "garde_fou"):
            st.markdown(
                f"<div style='border-left:4px solid {couleur};padding:4px 8px;margin:4px 0;background:#fff8e1'>{ICONES[e['type']]} {texte}</div>",
                unsafe_allow_html=True,
            )
        else:
            st.markdown(
                f"<div style='color:{couleur}'>{ICONES.get(e['type'], '')} {texte}</div>", unsafe_allow_html=True
            )


def colonne_resultat(session_id: str | None, limite: str | None) -> None:
    st.subheader("Le résultat")
    st.markdown(
        "<div style='background:#e8f0fe;padding:6px 10px;border-radius:6px;font-weight:600'>La décision appartient au conseiller.</div>",
        unsafe_allow_html=True,
    )
    if not session_id:
        return
    try:
        d = dossier(session_id)
    except Exception as exc:  # noqa: BLE001
        st.warning(f"Session illisible : {exc}")
        return
    onglets = st.tabs(["Calculs", "Faits", "Doutes", "Conformité", "Synthèse", "Recommandation"])
    with onglets[0]:
        calculs = jusqu_a(d["calculs"], limite)
        if calculs:
            st.dataframe(
                [
                    {"résultat": c["nom_resultat"], "valeur": c["valeur"], "unité": c["unite"], "étape": c["etape"]}
                    for c in calculs
                ],
                use_container_width=True,
                hide_index=True,
            )
        else:
            st.caption("Aucun calcul encore.")
    with onglets[1]:
        faits = jusqu_a(d["faits"], limite)
        if faits:
            st.dataframe(
                [
                    {"fait": f["nom"], "valeur": f["valeur"], "unité": f["unite"], "source": f["reference"]}
                    for f in faits
                ],
                use_container_width=True,
                hide_index=True,
            )
        else:
            st.caption("Aucun fait encore.")
    with onglets[2]:
        for x in jusqu_a(d["doutes"], limite):
            st.markdown(f"❓ **{x['objet']}**  \nHypothèses : {x['hypotheses']}  \nQuestion : _{x['question']}_")
    with onglets[3]:
        verdicts = jusqu_a(d["verdicts"], limite)
        if verdicts:
            st.dataframe(
                [
                    {
                        "règle": v["regle"],
                        "verdict": v["verdict"],
                        "valeur": v["valeur"],
                        "seuil": v["seuil"],
                        "justification": v["justification"],
                    }
                    for v in verdicts
                ],
                use_container_width=True,
                hide_index=True,
            )
        else:
            st.caption("Grille de conformité à venir.")
    with onglets[4]:
        if d["synthese"] and (limite is None or True):
            st.markdown(d["synthese"])
        else:
            st.caption("Synthèse à venir (vérifiée par le garde-fou : chaque chiffre a une source).")
    with onglets[5]:
        r = d["recommandation"]
        if r and (limite is None or r["horodatage"] <= limite):
            st.markdown(f"### {r['position'].replace('_', ' ')}")
            for m in r["motifs"]:
                st.markdown(f"- {m['texte']} _( {m['type']} `{m['nom']}` )_")
            if r["reserves"]:
                st.markdown("**Réserves**")
                for x in r["reserves"]:
                    st.markdown(f"- `{x['code']}` {x['texte']}")
            if r["conditions"]:
                st.markdown("**Conditions**")
                for c in r["conditions"]:
                    st.markdown(f"- {c}")
        else:
            st.caption("Recommandation à venir.")


# ---------------------------------------------------------------------------------------------------------------------
# Le bouton de démonstration : recevoir la pièce manquante et reprendre
# ---------------------------------------------------------------------------------------------------------------------
def zone_reprise(demande_id: str, session_id: str | None) -> None:
    if not session_id:
        return
    s = backend().lire("session", session_id=session_id)
    if s["statut"] != "REMISE" or st.session_state.mode == "rejeu":
        return
    st.divider()
    c1, c2 = st.columns([3, 1])
    c1.markdown(
        "**Le dossier est remis.** Pour la démonstration : simuler la réception de la fiche de paie manquante, et faire repartir l'agent de l'étape « vérifier » avec le dossier complété."
    )
    if c2.button("📎 Recevoir la pièce et reprendre", type="primary", disabled=st.session_state.reprise_en_cours):
        cas = cas_de(CONFIG, demande_id)
        manquantes = cas.pieges.fiches_paie_manquantes if cas else []
        if not manquantes:
            st.warning("Aucune pièce manquante connue pour cette demande.")
            return
        pid, per = manquantes[0]
        try:
            deposer_piece(CONFIG, cas, "fiche_paie", pid, per)
        except ValueError as exc:
            st.info(str(exc))
        import threading

        st.session_state.reprise_en_cours = True

        def _reprendre():
            try:
                reprendre_session(CONFIG, session_id, "verifier", modele=st.session_state.get("modele"))
            finally:
                st.session_state.reprise_en_cours = False

        threading.Thread(target=_reprendre, daemon=True).start()
        st.rerun()
    if st.session_state.reprise_en_cours:
        st.info("Reprise en cours depuis l'étape « vérifier »…")


# ---------------------------------------------------------------------------------------------------------------------
# Page
# ---------------------------------------------------------------------------------------------------------------------
def page() -> None:
    etat_initial()
    barre_laterale()
    demande_id = st.session_state.get("demande_id")
    session_id = st.session_state.session_id
    st.markdown("## Pré-instruction d'un dossier de crédit immobilier")
    parcours = charger_parcours()
    st.caption(" → ".join(e.titre for e in parcours.etapes))
    lignes = journal(session_id) if session_id else []
    en_direct = st.session_state.mode != "rejeu"
    if en_direct:
        curseur = len(lignes)
        limite = None
    else:
        curseur = min(st.session_state.curseur, len(lignes))
        limite = horodatage_courant(lignes, curseur) if curseur < len(lignes) else None
    gauche, centre, droite = st.columns([1, 1.6, 1.4])
    with gauche:
        colonne_dossier(demande_id, session_id, limite)
    with centre:
        colonne_raisonnement(session_id, lignes, curseur)
    with droite:
        colonne_resultat(session_id, limite)
    zone_reprise(demande_id, session_id)

    # avancer le rejeu, ou suivre l'agent en direct
    pilote: PiloteSession | None = st.session_state.pilote
    if not en_direct and st.session_state.lecture and curseur < len(lignes):
        time.sleep(1.0 / float(st.session_state.get("vitesse", 2.0)))
        st.session_state.curseur = curseur + 1
        st.rerun()
    elif en_direct and ((pilote is not None and pilote.en_cours) or st.session_state.reprise_en_cours):
        time.sleep(1.0)
        st.rerun()
    elif pilote is not None and pilote.erreur:
        st.error(f"L'agent s'est arrêté : {pilote.erreur}")
    st.caption(
        f"Dernière lecture : {dt.datetime.now().strftime('%H:%M:%S')} · session {session_id or '—'} · {json.dumps({'mode': st.session_state.mode})}"
    )


page()
