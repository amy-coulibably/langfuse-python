"""Ligne de commande du POC : `poc <commande>`."""

from __future__ import annotations

import typer
from rich.console import Console
from rich.table import Table

from poc.config import charger_config

app = typer.Typer(help="POC agent de pré-instruction d'un dossier de crédit immobilier.")
console = Console()

llm_app = typer.Typer(
    help="Modèles de langage : configuration (config/llm.yaml), disponibilité des clés, test d'appel."
)
agent_app = typer.Typer(help="L'agent : lancer une session sur une demande, relire ses sessions et son journal.")
obs_app = typer.Typer(help="Observabilité : configuration, trace de test, Phoenix local, sessions tracées.")
mcp_app = typer.Typer(help="Serveurs MCP : lancer un serveur sur stdio, découvrir les outils publiés.")
app.add_typer(llm_app, name="llm")
app.add_typer(agent_app, name="agent")
app.add_typer(obs_app, name="obs")
app.add_typer(mcp_app, name="mcp")
donnees_app = typer.Typer(help="Données synthétiques : générer, inspecter une demande, lister les pièces du coffre.")
app.add_typer(donnees_app, name="donnees")
api_app = typer.Typer(
    help="Les guichets : lancer une API locale (coffre, banque, incidents, conseiller, scoring, ocr) ou les six."
)
config_app = typer.Typer(
    help="La configuration du poste : fichier .env, modèle de langage, observabilité, OCR, données."
)
app.add_typer(config_app, name="config")
outils_app = typer.Typer(help="Les outils de l'agent : registre, schémas, exécution directe ou par les API.")
app.add_typer(api_app, name="api")
app.add_typer(outils_app, name="outils")


# ---------------------------------------------------------------------------------------------------------------------
# Santé, parcours
# ---------------------------------------------------------------------------------------------------------------------
@app.command("sante")
def sante(
    http: bool = typer.Option(False, "--http", help="Vérifie aussi que les quatre API locales répondent."),
) -> None:
    """Vérifie l'installation : parcours, modèles, fiches, outils, données, guichets, garde-fous, brique d'observabilité."""
    from poc.sante import verifier_installation

    controles = verifier_installation(charger_config(), http=http)
    table = Table(title="Santé du POC")
    table.add_column("contrôle")
    table.add_column("état")
    table.add_column("détail")
    for c in controles:
        table.add_row(c.nom, "[green]OK[/green]" if c.ok else "[red]KO[/red]", c.detail)
    console.print(table)
    if not all(c.ok for c in controles):
        raise typer.Exit(code=1)


@app.command("etapes")
def etapes() -> None:
    """Affiche le parcours : pour chaque étape, sa question, ses fiches (présentes ou à écrire) et ses outils (livrés ou prévus)."""
    from poc.agent.fiches import lister_fiches
    from poc.etapes import charger_parcours
    from poc.outils import outils_pour_etape, outils_prevus_absents

    parcours = charger_parcours()
    presentes = {f["nom"] for f in lister_fiches(charger_config().fiches_dir)}
    table = Table(title="Le parcours de l'agent (config/etapes.yaml)")
    for col in ("#", "étape", "question", "fiches", "outils"):
        table.add_column(col)
    for i, e in enumerate(parcours.etapes, start=1):
        fiches = ", ".join((f if f in presentes else f"[dim]{f} (à écrire)[/dim]") for f in e.fiches) or "—"
        if e.type == "code":
            outils = "[dim]sans modèle : étape codée[/dim]"
        else:
            livres = [o.nom for o in outils_pour_etape(e.nom)]
            prevus = outils_prevus_absents(e.nom)
            outils = ", ".join(livres) + (f" ; [dim]prévus : {', '.join(prevus)}[/dim]" if prevus else "")
        table.add_row(str(i), f"[bold]{e.titre}[/bold]\n{e.nom}", e.question, fiches, outils)
    console.print(table)


# ---------------------------------------------------------------------------------------------------------------------
# Modèles
# ---------------------------------------------------------------------------------------------------------------------
@llm_app.command("lister")
def llm_lister() -> None:
    """Affiche les modèles configurés, le rôle de chacun et si leur clé est présente dans l'environnement."""
    import os

    from poc.llm import charger_config_llm

    cfg = charger_config_llm()
    table = Table(title="config/llm.yaml")
    for col in ("nom logique", "fournisseur", "modèle", "url", "clé (variable)", "clé présente", "rôles"):
        table.add_column(col)
    roles_par_modele: dict[str, list[str]] = {}
    for etape, nom in cfg.roles.items():
        roles_par_modele.setdefault(nom, []).append(etape)
    for nom, m in cfg.modeles.items():
        if m.fournisseur == "factice":
            presente = "—"
        elif not m.cle_api_env:
            presente = "sans clé"
        else:
            presente = "oui" if os.environ.get(m.cle_api_env) else "[red]non[/red]"
        roles = ", ".join(roles_par_modele.get(nom, [])) + (" (défaut)" if nom == cfg.defaut else "")
        table.add_row(nom, m.fournisseur, m.nom, m.url or "—", m.cle_api_env or "—", presente, roles)
    console.print(table)
    console.print(
        f"Modèle par défaut : [bold]{cfg.defaut}[/bold] ; utilisables maintenant : {cfg.modeles_disponibles()}"
    )
    gf = cfg.agent
    console.print(
        f"Garde-fous : {gf.max_tours_par_etape} tours et {gf.max_appels_outils_par_etape} appels d'outils par étape, "
        f"{gf.budget_tokens_par_dossier:,} tokens par session, arrêt après {gf.max_appels_identiques} appels identiques.".replace(
            ",", " "
        )
    )


@llm_app.command("tester")
def llm_tester(
    modele: str = typer.Option(None, "--modele", "-m", help="Nom logique (défaut : le modèle par défaut)."),
) -> None:
    """Envoie une question courte au modèle, avec un outil factice, pour vérifier url, clé et appel d'outils."""
    from poc.llm import Message, charger_config_llm, creer_client

    cfg = charger_config_llm()
    m = cfg.modele_pour(None, modele)
    client = creer_client(m)
    outil = {
        "name": "additionner",
        "description": "Additionne deux entiers.",
        "input_schema": {
            "type": "object",
            "properties": {"a": {"type": "integer"}, "b": {"type": "integer"}},
            "required": ["a", "b"],
        },
    }
    try:
        rep = client.appeler(
            "Tu es un assistant de test. Utilise l'outil fourni.",
            [Message(role="user", contenu="Combien font 17 + 25 ? Utilise l'outil.")],
            [outil],
        )
    except Exception as exc:  # noqa: BLE001
        console.print(f"[red]Échec de l'appel à {m.nom_logique} ({m.nom} @ {m.url}) : {exc}[/red]")
        raise typer.Exit(code=1) from exc
    appel = f"{rep.appels[0].nom}({rep.appels[0].parametres})" if rep.appels else "aucun appel d'outil"
    cout = client.cout_euros(rep.tokens_entree, rep.tokens_sortie)
    console.print(
        f"[green]OK[/green] {m.nom_logique} -> {rep.modele} en {rep.duree_ms} ms ; {rep.tokens_entree}+{rep.tokens_sortie} tokens ; "
        f"coût {'inconnu (prix non renseigné)' if cout is None else f'{cout:.5f} €'} ; fin={rep.fin} ; {appel}"
    )
    if rep.texte:
        console.print(f"Texte : {rep.texte[:300]}")


# ---------------------------------------------------------------------------------------------------------------------
# Agent
# ---------------------------------------------------------------------------------------------------------------------
def _afficher_bilans(r) -> None:
    table = Table(title=f"Session {r.session_id} — demande {r.demande_id} — statut {r.statut}")
    for col in ("étape", "tours", "appels d'outils", "tokens", "coût €", "durée s", "erreurs"):
        table.add_column(col)
    for b in r.bilans:
        table.add_row(
            b["etape"],
            str(b["tours"]),
            str(b["appels_outils"]),
            str(b["tokens"]),
            "—" if b.get("cout_euros") is None else f"{b['cout_euros']:.4f}",
            str(b["duree_s"]),
            ("; ".join(b["erreurs"]))[:160],
        )
    console.print(table)
    cout = "coût inconnu (prix non renseigné)" if r.cout_euros is None else f"{r.cout_euros:.4f} €"
    console.print(f"Total : {r.tokens} tokens, {cout}, {r.duree_s} s ; {len(r.doutes)} doute(s) remonté(s).")


@agent_app.command("lancer")
def agent_lancer(
    demande: str = typer.Option("DEM-0001", "--demande", "-d", help="Identifiant de la demande (ex. DEM-0001)."),
    modele: str = typer.Option(
        None, "--modele", "-m", help="Nom logique du modèle (défaut : rôles de config/llm.yaml)."
    ),
    verbeux: bool = typer.Option(False, "--verbeux", "-v", help="Affiche le journal de raisonnement au fil de l'eau."),
    mcp: bool = typer.Option(False, "--mcp", help="Outils servis par les serveurs MCP locaux (lot 5)."),
    http: bool = typer.Option(
        False, "--http", help="Outils clients des quatre API locales (`poc api lancer tout` au préalable)."
    ),
    pas_a_pas: bool = typer.Option(
        False, "--pas-a-pas", help="S'arrête à chaque étape et avant la remise ; Entrée pour continuer."
    ),
    sans_checkpoints: bool = typer.Option(
        False, "--sans-checkpoints", help="Ne pas sauvegarder l'état après chaque étape."
    ),
) -> None:
    """Lance une session de l'agent sur une demande : les sept étapes, le journal, la remise au conseiller."""
    from poc.agent import lancer_agent

    config = charger_config()
    backend = None
    if http:
        from poc.outils.backend import BackendHTTP

        backend = BackendHTTP()
    if pas_a_pas:
        from poc.agent import PiloteSession

        pilote = PiloteSession(
            config, demande, modele=modele, pas_a_pas=True, arret_avant_remise=True, backend=backend, verbeux=True
        )
        console.print(
            f"Session {pilote.demarrer()} : l'agent s'arrête à chaque étape. Entrée pour continuer, q pour arrêter."
        )
        while True:
            pilote.attendre()
            if pilote.erreur:
                console.print(f"[red]{pilote.erreur}[/red]")
                raise typer.Exit(code=1)
            if pilote.termine:
                break
            if pilote.prochaine_etape == "remettre":
                invite = "Remettre le dossier au conseiller ?"
            else:
                invite = f"Prochaine étape : {pilote.prochaine_etape}."
            if input(f"{invite} [Entrée / q] ").strip().lower() == "q":
                pilote.arreter()
                console.print("Session interrompue.")
                raise typer.Exit()
            pilote.continuer()
        _afficher_bilans(pilote.resultat)
        return
    r = lancer_agent(
        config,
        demande,
        modele=modele,
        verbeux=verbeux,
        checkpoints=not sans_checkpoints,
        mcp=True if mcp else None,
        backend=backend,
    )
    _afficher_bilans(r)


@agent_app.command("sessions")
def agent_sessions(n: int = typer.Option(20, help="Nombre de sessions affichées.")) -> None:
    """Les dernières sessions : demande, modèle, statut, étape atteinte, calculs, doutes."""
    from poc.outils import BackendLocal

    config = charger_config()
    sessions = BackendLocal(config).lire("sessions", n=n)
    if not sessions:
        console.print("Aucune session. Lancer `poc agent lancer -d DEM-0001 -m factice`.")
        return
    table = Table(title="Sessions de l'agent")
    for col in ("session_id", "demande", "modèle", "statut", "étape", "calculs", "doutes", "créée"):
        table.add_column(col)
    for s in sessions:
        table.add_row(
            s["session_id"],
            s["demande_id"],
            s["modele"],
            s["statut"],
            s["etape_courante"],
            str(s["nb_calculs"]),
            str(s["nb_doutes"]),
            s["creation"][:16],
        )
    console.print(table)


@agent_app.command("journal")
def agent_journal(session: str = typer.Argument(..., help="Identifiant de session (S-DEM-0001-xxxxxx).")) -> None:
    """Le journal de raisonnement d'une session, ligne par ligne : ce que l'agent a dit, appelé, constaté, douté."""
    from poc.outils import BackendLocal, ErreurOutil

    try:
        lignes = BackendLocal(charger_config()).lire("journal", session_id=session)
    except ErreurOutil as exc:
        console.print(f"[red]{exc.message}[/red]")
        raise typer.Exit(code=1) from exc
    styles = {
        "etape": "bold",
        "pensee": "italic",
        "outil": "dim",
        "doute": "yellow",
        "garde_fou": "red",
        "constat": "",
        "systeme": "red",
    }
    for e in lignes:
        style = styles.get(e["type"], "")
        texte = e["texte"].replace("[", "\\[")
        console.print(
            f"[{style}]{e['horodatage'][11:19]}  {e['type']:<9} {texte}[/{style}]"
            if style
            else f"{e['horodatage'][11:19]}  {e['type']:<9} {texte}"
        )


# ---------------------------------------------------------------------------------------------------------------------
# Observabilité
# ---------------------------------------------------------------------------------------------------------------------
@obs_app.command("sante")
def obs_sante() -> None:
    """Affiche la configuration effective, construit la brique et envoie une trace de test (session, étape, appel LLM, outil)."""
    from poc.observabilite import charger_config_observabilite, demarrer, reinitialiser
    from poc.observabilite.sonde import collecteur_joignable, sonder_collecteur

    cfg = charger_config_observabilite()
    table = Table(title="Observabilité")
    table.add_column("réglage")
    table.add_column("valeur")
    for k in (
        "active",
        "backend",
        "endpoint",
        "projet",
        "model_id",
        "environnement",
        "taux_echantillonnage",
        "redaction",
        "contenu_messages",
        "propagation_mcp",
    ):
        table.add_row(k, str(getattr(cfg, k)))
    table.add_row("clé API", "présente" if cfg.api_key else "absente")
    table.add_row("space_id", "présent" if cfg.space_id else "absent")
    console.print(table)
    if not cfg.effective:
        console.print(
            "[yellow]Inactive : aucune trace ne part. Activer avec `active: true` dans config/observabilite.yaml ou OBS_ENABLED=true.[/yellow]"
        )
        return
    reinitialiser()
    obs = demarrer(cfg)
    if not obs.actif:
        console.print("[red]La brique n'a pas démarré (collecteur injoignable ou erreur, voir ci-dessus).[/red]")
        raise typer.Exit(code=1)
    from poc.llm import Message, ReponseLLM
    from poc.llm.config import ModeleLLM

    modele = ModeleLLM(nom_logique="factice", fournisseur="factice", nom="factice")
    with obs.session("S-TEST-000000", "DEM-TEST", {"modele": "factice", "mode_outils": "direct"}) as s:
        with obs.etape("comprendre", "S-TEST-000000", "DEM-TEST") as e:
            with obs.appel_modele(
                modele, "consigne de test", [Message(role="user", contenu="bonjour")], [], "comprendre", "S-TEST-000000"
            ) as llm:
                obs.reponse_modele(
                    llm,
                    ReponseLLM(
                        texte="ok",
                        appels=[],
                        tokens_entree=10,
                        tokens_sortie=2,
                        duree_ms=1,
                        modele="factice",
                        fin="end_turn",
                    ),
                    None,
                )
            with obs.appel_outil("consulter_fiche", {"nom": "00-regles-communes"}, "comprendre", "S-TEST-000000") as o:
                o.sortie({"ok": True})
            obs.garde_fou("atelier", "CHIFFRE_RECOPIE", "test", "comprendre", "S-TEST-000000")
            e.sortie({"resume": "test"})
        s.sortie({"test": True})
    obs.vider()
    code, detail = sonder_collecteur(cfg)
    if collecteur_joignable(code):
        console.print(
            f"[green]Collecteur joignable[/green] ({cfg.endpoint}, HTTP {code}) : trace de test S-TEST-000000 (5 spans) envoyée au projet « {cfg.projet} »."
        )
        console.print(
            "Phoenix : http://localhost:6006 ; Arize : projet › Traces (délai d'affichage possible d'une à deux minutes)."
        )
        return
    console.print(f"[red]Collecteur non joignable ou refus[/red] ({cfg.endpoint}) : {detail}")
    raise typer.Exit(code=1)


def _tableau_controles(titre: str, controles) -> bool:
    table = Table(title=titre)
    table.add_column("contrôle")
    table.add_column("état")
    table.add_column("détail")
    for c in controles:
        table.add_row(c.nom, "[green]OK[/green]" if c.ok else "[red]KO[/red]", c.detail)
    console.print(table)
    return all(c.ok for c in controles)


@config_app.command("verifier")
def config_verifier(
    etat: bool = typer.Option(
        False, "--etat", help="Sortie courte VARIABLE=0|1 (LLM_PRET, OBS_ACTIVE, OBS_PRET), pour les scripts."
    ),
) -> None:
    """Vérifie, sans appel réseau, ce qu'il faut pour lancer l'agent : .env, modèle par défaut (adresse, nom, clé,
    autorité), observabilité (adresse, clé, espace, SDK), OCR, données. Dit quoi renseigner et où."""
    from poc.verification import verifier_configuration

    controles = verifier_configuration(charger_config())
    if etat:
        from poc.observabilite import charger_config_observabilite

        par_nom = {c.nom: c.ok for c in controles}
        active = charger_config_observabilite().effective
        print(f"LLM_PRET={int(par_nom.get('modèle par défaut (LLM_MODELE_DEFAUT)', False))}")
        print(f"OBS_ACTIVE={int(active)}")
        print(f"OBS_PRET={int(active and par_nom.get('observabilité (OBS_*)', False))}")
        return
    if not _tableau_controles("Configuration du poste", controles):
        console.print("[red]À compléter avant de lancer l'agent sur un vrai modèle (voir la colonne détail).[/red]")
        raise typer.Exit(code=1)
    console.print(
        "[green]Configuration complète.[/green] Suite : `poc llm tester`, puis `poc obs verifier` si OBS_ENABLED=true."
    )


@obs_app.command("verifier")
def obs_verifier(
    demande: str = typer.Option("DEM-0001", "--demande", "-d", help="Dossier de la session de vérification."),
    sans_evaluations: bool = typer.Option(False, "--sans-evaluations", help="Ne pas déposer les évaluations eval.*."),
) -> None:
    """De bout en bout vers la plateforme (Arize AX ou Phoenix) : sonde du collecteur, une session complète tracée avec le
    modèle factice (aucun appel au modèle de langage), puis dépôt des évaluations eval.* sur le span racine."""
    from poc.verification import verifier_plateforme

    controles, info = verifier_plateforme(charger_config(), demande, evaluations=not sans_evaluations)
    ok = _tableau_controles("Observabilité de bout en bout", controles)
    if info.get("session_id"):
        console.print(
            f"Dans la plateforme : projet « {info['projet']} » › Traces, filtre session.id = {info['session_id']} "
            f"(trace {info.get('trace_id')}). Délai d'affichage : une à quelques minutes."
        )
    if not ok:
        raise typer.Exit(code=1)


@obs_app.command("moniteurs")
def obs_moniteurs() -> None:
    """Les moniteurs et tableaux de bord à créer dans Arize AX (config/arize_moniteurs.yaml), avec les attributs exacts."""
    import yaml

    from poc.config import CONFIG_DIR
    from poc.llm.config import interpoler

    spec = interpoler(yaml.safe_load((CONFIG_DIR / "arize_moniteurs.yaml").read_text(encoding="utf-8")))
    table = Table(title=f"Moniteurs à créer dans Arize AX (projet « {spec['projet']} »)")
    for col in ("moniteur", "famille", "ce qu'il lit", "seuil"):
        table.add_column(col)
    for m in spec["moniteurs"]:
        table.add_row(m["nom"], m["famille"], m["lire"], m["seuil"])
    console.print(table)
    table = Table(title="Tableaux de bord")
    table.add_column("tableau")
    table.add_column("contenu")
    for t in spec["tableaux_de_bord"]:
        table.add_row(t["nom"], t["contenu"])
    console.print(table)
    console.print("Mode d'emploi pas à pas : ARIZE_AX.md.")


@obs_app.command("phoenix")
def obs_phoenix(port: int = typer.Option(6006, help="Port de l'interface Phoenix.")) -> None:
    """Lance Phoenix en local (banc d'essai des traces) : interface sur http://localhost:<port>, OTLP sur /v1/traces."""
    import importlib.util
    import os
    import subprocess
    import sys

    if importlib.util.find_spec("phoenix") is None:
        console.print(
            "[yellow]Phoenix n'est pas installé dans cet environnement (il est incompatible avec le SDK arize, dépendance wrapt). "
            "Pour un banc d'essai local : un environnement à part, `python -m venv .venv-phoenix && .venv-phoenix/bin/pip install "
            "arize-phoenix && .venv-phoenix/bin/phoenix serve`.[/yellow]"
        )
        raise typer.Exit(code=1)

    env = {**os.environ, "PHOENIX_PORT": str(port)}
    console.print(
        f"Phoenix : http://localhost:{port} — Ctrl+C pour arrêter. Envoyer les traces vers http://localhost:{port}/v1/traces."
    )
    subprocess.run([sys.executable, "-m", "phoenix.server.main", "serve"], env=env, check=False)


@obs_app.command("evaluations")
def obs_evaluations(session: str = typer.Argument(..., help="Identifiant de session (S-DEM-0001-xxxxxx).")) -> None:
    """(Re)dépose les évaluations eval.* du correcteur sur la trace d'une session (Arize AX ou Phoenix)."""
    from poc.evaluation import evaluer_session, publier_evaluation_session
    from poc.observabilite import charger_config_observabilite
    from poc.observabilite.evaluations import evaluations_de

    config = charger_config()
    cfg = charger_config_observabilite()
    try:
        ev = evaluer_session(config, session)
    except LookupError as exc:
        console.print(f"[red]{exc}[/red]")
        raise typer.Exit(code=1) from exc
    table = Table(title=f"Évaluations de trace pour {session}")
    for col in ("eval.<nom>", "label", "score", "explication"):
        table.add_column(col)
    for e in evaluations_de(ev):
        table.add_row(f"eval.{e.nom}", e.label, "" if e.score is None else f"{e.score:.3f}", (e.explication or "")[:80])
    console.print(table)
    if not cfg.effective:
        console.print("Observabilité inactive : rien n'est envoyé (OBS_ENABLED=true et un backend pour déposer).")
        return
    n = publier_evaluation_session(config, ev)["span"]
    console.print(f"{n} évaluation(s) déposée(s) sur {cfg.backend} (projet {cfg.projet}).")


@obs_app.command("sessions")
def obs_sessions(n: int = typer.Option(20, help="Nombre de sessions affichées.")) -> None:
    """Les sessions tracées : identifiant de trace, backend et projet, pour les retrouver dans Phoenix ou Arize."""
    from poc.agent import sessions_tracees

    lignes = sessions_tracees(charger_config(), n)
    if not lignes:
        console.print(
            "Aucune session tracée : l'observabilité était inactive (OBS_ENABLED) ou le collecteur injoignable."
        )
        return
    table = Table(title="Sessions tracées")
    for col in ("session_id", "trace_id", "backend", "projet", "horodatage"):
        table.add_column(col)
    for r in lignes:
        table.add_row(r["session_id"], r["trace_id"], r["backend"], r["projet"], r["horodatage"])
    console.print(table)


# ---------------------------------------------------------------------------------------------------------------------
# MCP
# ---------------------------------------------------------------------------------------------------------------------
@mcp_app.command("serveur")
def mcp_serveur(nom: str = typer.Argument(..., help="coffre | banque | conseiller")) -> None:
    """Lance un serveur MCP sur stdio (pour un client MCP externe)."""
    from poc.mcp.serveur import main

    main([nom])


@mcp_app.command("lister")
def mcp_lister() -> None:
    """Démarre les serveurs MCP locaux, découvre leurs outils par le protocole, puis les arrête."""
    from poc.mcp import SERVEURS, BackendMCP

    with BackendMCP() as b:
        table = Table(title="Outils découverts par MCP")
        for col in ("serveur", "outil", "description"):
            table.add_column(col)
        for nom in b.serveurs_ouverts():
            outils = [(n, info) for n, info in b.outils.items() if info["serveur"] == nom]
            if not outils:
                table.add_row(
                    SERVEURS[nom]["nom_mcp"], "[dim]aucun outil encore (lot 2)[/dim]", SERVEURS[nom]["description"]
                )
            for n, info in outils:
                table.add_row(SERVEURS[nom]["nom_mcp"], n, info["description"][:90])
        console.print(table)
        console.print(f"{len(b.serveurs_ouverts())} serveur(s) démarré(s), {len(b.outils)} outil(s) publié(s).")


# ---------------------------------------------------------------------------------------------------------------------
# Données synthétiques
# ---------------------------------------------------------------------------------------------------------------------
@donnees_app.command("generer")
def donnees_generer() -> None:
    """Génère (ou régénère, à l'identique) la vérité terrain, les pièces PDF, la banque simulée et le fichier d'incidents."""
    import time

    from poc.generateur import generer_tout

    config = charger_config()
    debut = time.time()
    attendus = generer_tout(config)
    table = Table(title=f"Demandes générées dans {config.data_dir}")
    for col in (
        "demande",
        "scénario",
        "difficulté",
        "emprunt",
        "taux d'effort attendu",
        "recommandation attendue",
        "pièges",
    ):
        table.add_column(col)
    for a in attendus:
        table.add_row(
            a.demande_id,
            a.scenario,
            str(a.difficulte),
            f"{a.montant_emprunte:,.0f} €".replace(",", " "),
            f"{a.taux_effort} %",
            a.recommandation,
            ", ".join(a.moments),
        )
    console.print(table)
    lots: dict[str, int] = {}
    for a in attendus:
        lots[a.lot] = lots.get(a.lot, 0) + 1
    recos: dict[str, int] = {}
    for a in attendus:
        recos[a.recommandation] = recos.get(a.recommandation, 0) + 1
    console.print(
        f"{len(attendus)} demande(s) en {time.time() - debut:.1f} s. Pièces dans {config.coffre_dir}. "
        f"Lots : {lots}. Recommandations attendues : {recos}."
    )


@donnees_app.command("catalogue")
def donnees_catalogue(
    lot: str = typer.Option("tous", "--lot", "-l", help="facile | reglage | scelle | tous"),
) -> None:
    """Le catalogue des dossiers générés : scénario, lot, difficulté, recommandation attendue. Les dossiers scellés servent à
    mesurer, jamais à régler l'agent."""
    from poc.generateur import catalogue

    lignes = [c for c in catalogue(charger_config()) if lot == "tous" or c["lot"] == lot]
    if not lignes:
        console.print("Aucun dossier : lancer `poc donnees generer`.")
        raise typer.Exit(code=1)
    table = Table(title=f"Catalogue ({len(lignes)} dossier(s), lot : {lot})")
    for col in ("demande", "lot", "diff.", "scénario", "taux attendu", "recommandation attendue", "description"):
        table.add_column(col)
    for c in lignes:
        table.add_row(
            c["demande_id"],
            c["lot"],
            str(c["difficulte"]),
            c["scenario"],
            f"{c['taux_effort']} %" if c["taux_effort"] < 900 else "—",
            c["recommandation"],
            c["description"][:90],
        )
    console.print(table)


@donnees_app.command("inspecter")
def donnees_inspecter(demande: str = typer.Argument("DEM-0001", help="Identifiant de la demande.")) -> None:
    """Montre la vérité terrain d'une demande : le cas, les pièges, et ce que l'agent devrait trouver."""
    import json

    from poc.generateur import attendu_de, cas_de

    config = charger_config()
    cas, attendu = cas_de(config, demande), attendu_de(config, demande)
    if cas is None or attendu is None:
        console.print(f"[red]Demande {demande} inconnue : lancer `poc donnees generer`.[/red]")
        raise typer.Exit(code=1)
    console.rule(f"{demande} — {cas.scenario} (difficulté {cas.difficulte})")
    console.print(cas.description)
    table = Table(title="Ce que l'agent devrait trouver (vérité terrain, jamais montrée à l'agent)")
    table.add_column("mesure")
    table.add_column("valeur")
    euros = lambda x: f"{x:,.2f} €".replace(",", " ")  # noqa: E731
    lignes = [
        (
            "montant emprunté",
            f"{euros(attendu.montant_emprunte)} (prix {euros(attendu.prix)} + frais {euros(attendu.frais_acquisition)} − apport {euros(attendu.apport)})",
        ),
        (
            "mensualités assurance comprise",
            ", ".join(f"{d} ans : {euros(m)}" for d, m in attendu.mensualites_assurance_comprise.items()),
        ),
        (
            "revenus retenus",
            f"{euros(attendu.revenus_retenus)} ({', '.join(f'{k} {euros(v)}' for k, v in attendu.revenus_par_personne.items())}) ; non couverts : {attendu.revenus_non_couverts}",
        ),
        ("charges retenues", f"{euros(attendu.charges_retenues)} (dont crédits {euros(attendu.charges_credits)})"),
        (
            "taux d'effort",
            f"{attendu.taux_effort} % à {attendu.duree_souhaitee_annees} ans ; {attendu.taux_effort_standard} % avec les seuls revenus couverts ; par durée {attendu.taux_effort_par_duree}",
        ),
        ("reste à vivre", f"{euros(attendu.reste_a_vivre)} (minimum {euros(attendu.reste_a_vivre_minimum)})"),
        ("verdicts", json.dumps(attendu.verdicts, ensure_ascii=False)),
        ("recommandation", f"{attendu.recommandation} ; réserves : {attendu.reserves}"),
        ("pièces manquantes", json.dumps(attendu.pieces_manquantes, ensure_ascii=False)),
        ("doutes attendus", "\n".join(f"{d['type']} : {d['question']}" for d in attendu.doutes_attendus)),
        ("moments de réflexivité", ", ".join(attendu.moments)),
    ]
    for nom, val in lignes:
        table.add_row(nom, str(val))
    console.print(table)


@donnees_app.command("pieces")
def donnees_pieces(demande: str = typer.Argument("DEM-0001", help="Identifiant de la demande.")) -> None:
    """Liste les pièces déposées dans le coffre d'une demande (l'inventaire que verra l'outil `lister_pieces`)."""
    import json

    config = charger_config()
    chemin = config.coffre_dir / demande / "inventaire.json"
    if not chemin.exists():
        console.print(f"[red]Aucun coffre pour {demande} : lancer `poc donnees generer`.[/red]")
        raise typer.Exit(code=1)
    inv = json.loads(chemin.read_text(encoding="utf-8"))
    table = Table(title=f"Coffre de {demande} — déposé le {inv['deposee_le']} — {len(inv['pieces'])} pièces")
    for col in ("id", "type", "personne", "période", "fichier"):
        table.add_column(col)
    for piece in inv["pieces"]:
        table.add_row(
            piece["piece_id"], piece["type"], piece["personne"] or "foyer", piece["periode"] or "—", piece["fichier"]
        )
    console.print(table)


@agent_app.command("evaluer")
def agent_evaluer(session: str = typer.Argument(..., help="Identifiant de session (S-DEM-0001-xxxxxx).")) -> None:
    """Compare une session à la vérité terrain : chiffres de la feuille de calcul, doutes, pièces, verdicts, recommandation."""
    from poc.evaluation import evaluer_session

    try:
        ev = evaluer_session(charger_config(), session)
    except LookupError as exc:
        console.print(f"[red]{exc}[/red]")
        raise typer.Exit(code=1) from exc
    table = Table(title=f"Évaluation de {session} (demande {ev.demande_id})")
    for col in ("mesure", "attendu", "obtenu", "statut", "détail"):
        table.add_column(col)
    couleurs = {
        "EXACT": "green",
        "ECART": "red",
        "NOM_HORS_CONVENTION": "yellow",
        "NON_CALCULE": "red",
        "NON_EVALUABLE": "dim",
    }
    for m in ev.mesures:
        c = couleurs.get(m.statut, "")
        table.add_row(m.nom, str(m.attendu), str(m.obtenu), f"[{c}]{m.statut}[/{c}]" if c else m.statut, m.detail[:90])
    console.print(table)
    from poc.evaluation import publier_evaluation_session, reussite

    console.print(
        f"{ev.exacts}/{ev.evaluables} mesure(s) exacte(s) ; doutes attendus trouvés {ev.doutes_attendus_trouves}/{ev.doutes_attendus_total} ; "
        f"faux doutes {ev.faux_doutes} ; moments : {ev.moments or 'non évaluables avant le lot 2'} ; "
        f"session {'réussie' if reussite(ev) else 'non réussie'} au sens des campagnes"
    )
    n = publier_evaluation_session(charger_config(), ev)["span"]
    if n:
        console.print(f"{n} évaluation(s) eval.* déposée(s) sur la trace de la session.")


@agent_app.command("campagne")
def agent_campagne(
    lot: str = typer.Option(
        "reglage",
        "--lot",
        "-l",
        help="Lot du catalogue (facile | reglage | scelle | tous) ou sélection (demo | panorama | ocr) ; ignoré si --demandes.",
    ),
    demandes: str = typer.Option(
        None, "--demandes", "-d", help="Identifiants séparés par des virgules : DEM-0002,DEM-0014"
    ),
    modele: str = typer.Option(None, "--modele", "-m", help="Nom logique du modèle."),
    repetitions: int = typer.Option(1, "--repetitions", "-k", min=1, help="Répétitions par dossier (pass^k)."),
    nom: str = typer.Option(None, "--nom", help="Nom de la campagne (pour la retrouver)."),
    mcp: bool = typer.Option(False, "--mcp", help="Outils servis par les serveurs MCP."),
    sans_publication: bool = typer.Option(
        False, "--sans-publication", help="Ne pas déposer les évaluations sur les traces."
    ),
) -> None:
    """Fait tourner l'agent sur une série de dossiers, note chaque session, garde le résultat (agent_campagnes, CSV)."""
    from poc.evaluation import lancer_campagne

    config = charger_config()
    liste = [d.strip() for d in demandes.split(",") if d.strip()] if demandes else None

    def rapporter(s) -> None:
        etat = (
            "[green]réussie[/green]"
            if s.reussite
            else ("[red]échec technique[/red]" if s.erreur else "[yellow]non réussie[/yellow]")
        )
        console.print(
            f"  {s.demande_id} (répétition {s.repetition}) : {s.session_id or '—'} {s.statut} — {etat} — "
            f"{s.mesures_exactes}/{s.evaluables} exacts, reco {s.recommandation}, synthèse {s.synthese}, faux doutes {s.faux_doutes}"
            + (f" — {s.erreur}" if s.erreur else "")
        )

    try:
        c = lancer_campagne(
            config,
            liste,
            lot=lot,
            modele=modele,
            repetitions=repetitions,
            nom=nom,
            mcp=mcp,
            rapporter=rapporter,
            publier=not sans_publication,
        )
    except (LookupError, ValueError) as exc:
        console.print(f"[red]{exc}[/red]")
        raise typer.Exit(code=1) from exc
    r = c.resume()
    console.print(
        f"Campagne {c.campagne_id} « {c.nom} » ({c.modele}) : {r['sessions']} session(s) sur {r['dossiers']} dossier(s) ; "
        f"pass@1 = {r['pass_1']:.0%}, pass^{c.repetitions} = {r['pass_k']:.0%} ; mesures exactes {r['mesures_exactes']} ; "
        f"{r['tokens']} tokens, {r['duree_s']} s. CSV : data/campagnes/{c.campagne_id}.csv"
    )


@agent_app.command("campagnes")
def agent_campagnes(
    detail: str = typer.Option(None, "--detail", help="Identifiant d'une campagne : affiche ses sessions."),
    n: int = typer.Option(20, help="Nombre de campagnes affichées."),
) -> None:
    """Les campagnes passées (pass@1, pass^k), et le détail d'une campagne session par session."""
    from poc.evaluation import campagnes, sessions_de_campagne

    config = charger_config()
    if detail:
        lignes = sessions_de_campagne(config, detail)
        if not lignes:
            console.print(f"[red]Campagne {detail} inconnue ou sans session.[/red]")
            raise typer.Exit(code=1)
        table = Table(title=f"Sessions de la campagne {detail}")
        for col in (
            "demande",
            "rép.",
            "session",
            "statut",
            "réussite",
            "exacts",
            "reco",
            "taux",
            "synthèse",
            "faux doutes",
            "moments",
            "tokens",
        ):
            table.add_column(col)
        for s in lignes:
            table.add_row(
                s["demande_id"],
                str(s["repetition"]),
                s["session_id"] or "—",
                s["statut"],
                "oui" if s["reussite"] else "non",
                f"{s['mesures_exactes']}/{s['evaluables']}",
                s["recommandation"],
                s["taux_effort"],
                s["synthese"],
                str(s["faux_doutes"]),
                f"{s['moments_ok']}/{s['moments_total']}",
                str(s["tokens"]),
            )
        console.print(table)
        return
    lignes = campagnes(config, n)
    if not lignes:
        console.print("Aucune campagne : `poc agent campagne --lot facile -m factice` pour en lancer une.")
        return
    table = Table(title="Campagnes")
    for col in ("campagne", "nom", "modèle", "lot", "k", "dossiers", "sessions", "pass@1", "pass^k", "statut", "date"):
        table.add_column(col)
    for c in lignes:
        table.add_row(
            c["campagne_id"],
            c["nom"],
            c["modele"],
            c["lot"],
            str(c["repetitions"]),
            str(c["nb_dossiers"]),
            str(c["nb_sessions"]),
            f"{c['pass_1']:.0%}",
            f"{c['pass_k']:.0%}",
            c["statut"],
            c["horodatage"],
        )
    console.print(table)


# ---------------------------------------------------------------------------------------------------------------------
# Guichets (API locales) et outils
# ---------------------------------------------------------------------------------------------------------------------
MODULES_API = {
    "coffre": "poc.api.coffre_api",
    "banque": "poc.api.banque_api",
    "incidents": "poc.api.incidents_api",
    "conseiller": "poc.api.conseiller_api",
    "scoring": "poc.api.scoring_api",
    "ocr": "poc.api.ocr_api",
}


@api_app.command("lancer")
def api_lancer(
    nom: str = typer.Argument(..., help="coffre | banque | incidents | conseiller | scoring | ocr | tout"),
    hote: str = typer.Option("127.0.0.1", help="Adresse d'écoute."),
) -> None:
    """Lance un guichet (ou les six avec `tout`) : documentation interactive sur http://127.0.0.1:<port>/docs."""
    import subprocess
    import sys

    from poc.outils.backend import PORTS

    if nom != "tout" and nom not in MODULES_API:
        console.print(f"[red]guichet inconnu : {nom} (attendu : {', '.join(MODULES_API)} ou tout)[/red]")
        raise typer.Exit(code=2)
    noms = list(MODULES_API) if nom == "tout" else [nom]
    for n in noms:
        console.print(f"api-{n} : http://{hote}:{PORTS[n]}/docs")
    if len(noms) == 1:
        import uvicorn

        uvicorn.run(f"{MODULES_API[noms[0]]}:app", host=hote, port=PORTS[noms[0]], log_level="warning")
        return
    procs = [
        subprocess.Popen(
            [
                sys.executable,
                "-m",
                "uvicorn",
                f"{MODULES_API[n]}:app",
                "--host",
                hote,
                "--port",
                str(PORTS[n]),
                "--log-level",
                "warning",
            ]
        )
        for n in noms
    ]
    console.print(f"{len(noms)} guichets lancés — Ctrl+C pour tout arrêter.")
    try:
        for pr in procs:
            pr.wait()
    except KeyboardInterrupt:
        for pr in procs:
            pr.terminate()


@outils_app.command("lister")
def outils_lister(
    etape: str = typer.Option(None, "--etape", "-e", help="Ne montrer que les outils visibles à cette étape."),
) -> None:
    """Le registre des outils : nom, serveur MCP, écriture, description ; par étape si demandé."""
    from poc.outils import OUTILS, outils_pour_etape

    specs = outils_pour_etape(etape) if etape else list(OUTILS.values())
    titre = f"Outils visibles à l'étape {etape}" if etape else "Outils du registre"
    table = Table(title=f"{titre} ({len(specs)})")
    for col in ("outil", "serveur", "écrit", "description"):
        table.add_column(col)
    for o in specs:
        desc = o.description[:110] + ("…" if len(o.description) > 110 else "")
        table.add_row(o.nom, o.serveur_mcp or "agent", "oui" if o.ecriture else "", desc)
    console.print(table)


@outils_app.command("appeler")
def outils_appeler(
    nom: str = typer.Argument(..., help="Nom de l'outil."),
    parametres: str = typer.Argument("{}", help="Paramètres en JSON."),
    http: bool = typer.Option(
        False, "--http", help="Passer par les API locales plutôt que par les services en mémoire."
    ),
    session: str = typer.Option(
        None, "--session", "-s", help="Session à utiliser pour les outils qui en demandent une (créée sinon)."
    ),
) -> None:
    """Exécute un outil tel que l'agent le ferait, et affiche le résultat (ou l'erreur lisible)."""
    import json

    from poc.outils import OUTILS, BackendLocal, ErreurOutil, executer_outil

    if nom not in OUTILS:
        console.print(f"[red]outil inconnu : {nom} ; voir `poc outils lister`[/red]")
        raise typer.Exit(code=2)
    if http:
        from poc.outils.backend import BackendHTTP

        backend = BackendHTTP()
    else:
        backend = BackendLocal(charger_config())
    params = json.loads(parametres)
    if "session_id" in OUTILS[nom].schema.model_fields and "session_id" not in params:
        sid = (
            session
            or backend.ecrire("sessions", {"demande_id": params.get("demande_id", "DEM-0001"), "modele": "outils"})[
                "session_id"
            ]
        )
        params["session_id"] = sid
        console.print(f"[dim]session {sid}[/dim]")
    try:
        resultat = executer_outil(backend, nom, params)
    except ErreurOutil as exc:
        console.print(f"[red]{exc.code}[/red] : {exc.message}")
        raise typer.Exit(code=1) from exc
    except ValueError as exc:
        console.print(f"[red]PARAMETRES_INVALIDES[/red] : {str(exc)[:600]}")
        raise typer.Exit(code=1) from exc
    console.print_json(json.dumps(resultat, ensure_ascii=False, default=str)[:20000])


# ---------------------------------------------------------------------------------------------------------------------
# Reprise, pièce reçue, interface
# ---------------------------------------------------------------------------------------------------------------------
@agent_app.command("reprendre")
def agent_reprendre(
    session: str = typer.Argument(..., help="Identifiant de session (S-DEM-0001-xxxxxx)."),
    depuis: str = typer.Option(
        "verifier", "--depuis", help="Étape à partir de laquelle rejouer (état restauré tel qu'avant)."
    ),
    modele: str = typer.Option(None, "--modele", "-m"),
    verbeux: bool = typer.Option(False, "--verbeux", "-v"),
) -> None:
    """Reprend une session sauvegardée à partir d'une étape (retour dans le temps LangGraph), par exemple après réception d'une pièce."""
    from poc.agent import reprendre_session

    try:
        r = reprendre_session(charger_config(), session, depuis, modele=modele, verbeux=verbeux)
    except (LookupError, ValueError) as exc:
        console.print(f"[red]{exc}[/red]")
        raise typer.Exit(code=1) from exc
    _afficher_bilans(r)


@donnees_app.command("deposer-piece")
def donnees_deposer_piece(
    demande: str = typer.Option("DEM-0001", "--demande", "-d"),
    personne: str = typer.Option(
        "thomas", "--personne", help="Identifiant de la personne dans le cas (thomas, marie)."
    ),
    periode: str = typer.Option("2026-08", "--periode", help="Mois de la fiche de paie, AAAA-MM."),
) -> None:
    """Simule la réception d'une fiche de paie manquante : la génère depuis la vérité terrain et l'ajoute au coffre."""
    from poc.generateur import cas_de, deposer_piece

    config = charger_config()
    cas = cas_de(config, demande)
    if cas is None:
        console.print(f"[red]Demande {demande} inconnue.[/red]")
        raise typer.Exit(code=1)
    try:
        piece = deposer_piece(config, cas, "fiche_paie", personne, periode)
    except (ValueError, KeyError) as exc:
        console.print(f"[red]{exc}[/red]")
        raise typer.Exit(code=1) from exc
    console.print(
        f"Pièce déposée : {piece['piece_id']} {piece['fichier']} ({piece['libelle']}). "
        "Relancer, ou reprendre une session depuis « verifier »."
    )


@app.command("interface")
def interface(port: int = typer.Option(8501, help="Port de l'interface.")) -> None:
    """Lance l'interface de démonstration (Streamlit) : dossier, raisonnement en direct, résultat ; rejeu, continu, pas à pas."""
    import subprocess
    import sys
    from pathlib import Path

    chemin = Path(__file__).resolve().parent / "interface" / "app.py"
    console.print(f"Interface : http://localhost:{port} — Ctrl+C pour arrêter.")
    subprocess.run(
        [
            sys.executable,
            "-m",
            "streamlit",
            "run",
            str(chemin),
            "--server.port",
            str(port),
            "--server.headless",
            "true",
            "--browser.gatherUsageStats",
            "false",
        ],
        check=False,
    )


if __name__ == "__main__":
    app()
