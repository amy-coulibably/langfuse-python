"""Schémas de ce que l'agent produit et que la base `agent.sqlite` conserve.

La pièce centrale est le **calcul** : du code écrit par l'agent, des entrées désignées par leur origine (un fait extrait
d'une pièce, un résultat antérieur, une hypothèse déclarée ; jamais une valeur tapée à la main), des résultats nommés.
Chaque résultat enregistré est une cellule de tableur qui garde sa formule.
"""

from __future__ import annotations

import datetime as dt
from typing import Literal

from pydantic import BaseModel, Field

TypeOrigine = Literal["fait", "calcul", "constante"]


class Origine(BaseModel):
    """D'où vient une entrée de calcul. Le service résout la valeur ; l'agent ne la saisit pas."""

    type: TypeOrigine = Field(
        description="fait (donnée extraite d'une pièce ou des comptes, enregistrée par noter_fait), "
        "calcul (résultat antérieur de la session), constante (hypothèse déclarée avec sa justification)"
    )
    nom: str | None = Field(default=None, description="Pour fait ou calcul : le nom du fait ou du résultat enregistré")
    valeur: float | None = Field(default=None, description="Pour constante : la valeur de l'hypothèse")
    justification: str | None = Field(
        default=None, description="Pour constante : pourquoi cette hypothèse (fiche de méthode, politique maison…)"
    )


class Entree(BaseModel):
    nom: str = Field(description="Nom de la variable dans le code (identifiant Python)")
    origine: Origine


class DemandeCalcul(BaseModel):
    etape: str = Field(description="Étape du parcours en cours")
    entrees: list[Entree]
    code: str = Field(
        description="Code Python : affectations simples, opérateurs arithmétiques, fonctions de math. Les variables d'entrée sont disponibles par leur nom."
    )
    sorties: list[str] = Field(description="Noms des variables à enregistrer comme résultats")
    unite: str | dict[str, str] = Field(
        default="euros",
        description="Unité des résultats : euros, pourcentage, ratio, mois, annees ; ou un dictionnaire sortie → unité quand elles diffèrent",
    )
    commentaire: str = Field(
        default="", description="Ce que calcule ce bloc, en une phrase (repris dans la feuille de calcul)"
    )


class ResultatCalcul(BaseModel):
    nom_resultat: str
    valeur: float | int | bool | list | None
    unite: str
    calcul_id: str


class Calcul(BaseModel):
    """Une ligne de la feuille de calcul (table agent_calculs)."""

    calcul_id: str
    session_id: str
    etape: str
    nom_resultat: str
    valeur: float | None
    unite: str
    code_execute: str
    entrees: list[dict]
    hypotheses: list[dict]
    commentaire: str = ""
    horodatage: dt.datetime
    duree_ms: int = 0


class Trace(BaseModel):
    trace_id: str
    session_id: str
    etape: str
    type: Literal["modele", "outil", "systeme"]
    nom: str
    duree_ms: int
    tokens_entree: int = 0
    tokens_sortie: int = 0
    cout_euros: float | None = None
    detail: dict = Field(default_factory=dict)
    horodatage: dt.datetime


class EntreeJournal(BaseModel):
    """Une ligne du journal de raisonnement, celui que l'interface affiche phrase par phrase."""

    session_id: str
    etape: str
    type: Literal["etape", "pensee", "outil", "constat", "doute", "garde_fou", "systeme"]
    texte: str
    horodatage: dt.datetime


StatutSession = Literal["EN_COURS", "REMISE", "INTERROMPUE", "ECHEC"]


class Session(BaseModel):
    session_id: str
    demande_id: str
    modele: str
    statut: StatutSession
    etape_courante: str
    creation: dt.datetime
    mise_a_jour: dt.datetime
    nb_calculs: int = 0
    nb_doutes: int = 0
