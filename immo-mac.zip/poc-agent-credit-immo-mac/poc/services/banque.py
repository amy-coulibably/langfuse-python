"""Le système d'information de la banque, vu par l'agent : la demande déposée, les clients, leurs comptes et mouvements,
leurs crédits (ceux de la banque, et ceux que le client a déclarés), leur épargne ; le barème, le simulateur de prêt, et les
textes de la politique de crédit. Lecture seule, sur `banque.sqlite` et `referentiels/`.
"""

from __future__ import annotations

import datetime as dt
from typing import Any

from poc.config import Config
from poc.donnees import SQLiteStore
from poc.generateur import referentiels as refs
from poc.services.erreurs import ErreurService, Introuvable

TEXTES_POLITIQUE = ("grille_score", "politique_credit", "norme_hcsf", "pieces_attendues")


def mensualite(capital: float, taux_pct: float, annees: int) -> float:
    t = taux_pct / 100 / 12
    n = annees * 12
    return capital / n if t == 0 else capital * t / (1 - (1 + t) ** -n)


def _annees_entre(naissance: str | None, jour: str | None) -> int | None:
    if not naissance or not jour:
        return None
    n, j = dt.date.fromisoformat(naissance[:10]), dt.date.fromisoformat(jour[:10])
    return j.year - n.year - ((j.month, j.day) < (n.month, n.day))


def _mois_entre(debut: str | None, jour: str | None) -> int | None:
    if not debut or not jour:
        return None
    a, b = dt.date.fromisoformat(debut[:10]), dt.date.fromisoformat(jour[:10])
    return (b.year - a.year) * 12 + b.month - a.month - (b.day < a.day)


def _trois_mois_avant(jour: str | None) -> list[str]:
    if not jour:
        return []
    j = dt.date.fromisoformat(jour[:10])
    out = []
    annee, mois = j.year, j.month
    for _ in range(3):
        mois -= 1
        if mois == 0:
            mois, annee = 12, annee - 1
        out.append(f"{annee:04d}-{mois:02d}")
    return list(reversed(out))


class ServiceBanque:
    def __init__(self, config: Config) -> None:
        self.config = config
        self.store = SQLiteStore(config.sqlite_banque)

    def _verifier_base(self) -> None:
        if not self.config.sqlite_banque.exists() or not self.store.existe("banque_demande"):
            raise ErreurService(
                "DONNEES_ABSENTES", "la banque simulée n'est pas générée : lancer `poc donnees generer`", 503
            )

    # ---- demande et clients
    def demande(self, demande_id: str) -> dict:
        self._verifier_base()
        rows = self.store.requete("SELECT * FROM banque_demande WHERE demande_id = ?", (demande_id,)).to_dicts()
        if not rows:
            raise Introuvable(f"demande {demande_id} inconnue")
        d = rows[0]
        emprunteurs = self.store.requete(
            "SELECT e.client_id, e.role, c.prenom, c.nom, c.date_naissance, c.situation_pro, c.employeur, c.poste, "
            "c.date_entree, c.activite, c.debut_activite FROM banque_emprunteur e "
            "JOIN banque_client c ON c.client_id = e.client_id WHERE e.demande_id = ? ORDER BY CASE e.role WHEN 'emprunteur' THEN 0 ELSE 1 END",
            (demande_id,),
        ).to_dicts()
        declares = (
            self.store.requete(
                "SELECT * FROM banque_demande_credit_declare WHERE demande_id = ?", (demande_id,)
            ).to_dicts()
            if self.store.existe("banque_demande_credit_declare")
            else []
        )
        for e in emprunteurs:
            e["age_au_depot"] = _annees_entre(e.get("date_naissance"), d.get("date_depot"))
            debut = e.get("date_entree") or e.get("debut_activite")
            e["anciennete_mois_au_depot"] = _mois_entre(debut, d.get("date_depot"))
        return {
            **d,
            "mois_attendus_fiches_et_releves": _trois_mois_avant(d.get("date_depot")),
            "emprunteurs": emprunteurs,
            "ages_au_depot": [e["age_au_depot"] for e in emprunteurs if e.get("age_au_depot") is not None],
            "credits_declares_par_le_client": declares,
            "total_mensualites_credits_declares": round(sum(float(c["mensualite_declaree"]) for c in declares), 2),
        }

    def ages_au_depot(self, demande_id: str) -> list[int]:
        """Les âges des emprunteurs à la date de dépôt (pour l'assurance), dans l'ordre emprunteur puis co-emprunteur."""
        return [e["age_au_depot"] for e in self.demande(demande_id)["emprunteurs"] if e.get("age_au_depot") is not None]

    def client(self, client_id: str) -> dict:
        self._verifier_base()
        rows = self.store.requete("SELECT * FROM banque_client WHERE client_id = ?", (client_id,)).to_dicts()
        if not rows:
            raise Introuvable(f"client {client_id} inconnu")
        return rows[0]

    def identite(self, client_id: str) -> dict:
        c = self.client(client_id)
        return {"nom": c["nom"], "prenom": c["prenom"], "date_naissance": c["date_naissance"]}

    # ---- comptes et mouvements
    def comptes(self, client_id: str) -> list[dict]:
        self.client(client_id)
        rows = (
            self.store.requete("SELECT * FROM banque_compte ORDER BY compte_id").to_dicts()
            if self.store.existe("banque_compte")
            else []
        )
        return [r for r in rows if client_id in (r["client_ids"] or "").split(",")]

    def mouvements(
        self, compte_id: str, du: str | None = None, au: str | None = None, motif: str | None = None, limite: int = 200
    ) -> dict:
        self._verifier_base()
        if (
            not self.store.existe("banque_compte")
            or not self.store.requete("SELECT 1 FROM banque_compte WHERE compte_id = ?", (compte_id,)).height
        ):
            raise Introuvable(f"compte {compte_id} inconnu (voir consulter_comptes)")
        sql, params = (
            "SELECT date, libelle, montant, solde_apres FROM banque_mouvement WHERE compte_id = ?",
            [compte_id],
        )
        if du:
            sql, params = sql + " AND date >= ?", params + [du]
        if au:
            sql, params = sql + " AND date <= ?", params + [au + ("-31" if len(au) == 7 else "")]
        if motif:
            sql, params = sql + " AND UPPER(libelle) LIKE ?", params + [f"%{motif.upper()}%"]
        rows = self.store.requete(sql + " ORDER BY date, rowid", tuple(params)).to_dicts()
        total = len(rows)
        rows = rows[: max(1, min(limite, 500))]
        credits = round(sum(r["montant"] for r in rows if r["montant"] > 0), 2)
        debits = round(sum(r["montant"] for r in rows if r["montant"] < 0), 2)
        return {
            "compte_id": compte_id,
            "du": du,
            "au": au,
            "motif": motif,
            "nb_total": total,
            "nb_renvoyes": len(rows),
            "total_credits": credits,
            "total_debits": debits,
            "mouvements": rows,
        }

    def credits(self, client_id: str) -> dict:
        self.client(client_id)
        banque = (
            self.store.requete("SELECT * FROM banque_credit_en_cours WHERE client_id = ?", (client_id,)).to_dicts()
            if self.store.existe("banque_credit_en_cours")
            else []
        )
        declares = (
            self.store.requete(
                "SELECT * FROM banque_demande_credit_declare WHERE client_id = ?", (client_id,)
            ).to_dicts()
            if self.store.existe("banque_demande_credit_declare")
            else []
        )
        return {
            "client_id": client_id,
            "credits_de_la_banque": banque,
            "credits_declares_par_le_client": declares,
            "note": "Les crédits souscrits dans d'autres établissements n'apparaissent que dans la déclaration du client et dans ses relevés.",
        }

    def epargne(self, client_id: str) -> list[dict]:
        self.client(client_id)
        return (
            self.store.requete("SELECT * FROM banque_epargne WHERE client_id = ?", (client_id,)).to_dicts()
            if self.store.existe("banque_epargne")
            else []
        )

    # ---- barème, simulateur, politique
    def bareme(self, duree_annees: int | None = None, age: int | None = None) -> dict:
        taux = refs.bareme_taux()
        assurance = [r for r in refs._csv("assurance.csv", str(self.config.referentiels_dir)).to_dicts()]
        frais = refs._csv("frais_notaire.csv", str(self.config.referentiels_dir)).to_dicts()
        out: dict[str, Any] = {
            "taux_nominal_pct_par_duree": {
                str(k): v for k, v in taux.items() if duree_annees is None or k == duree_annees
            },
            "assurance_taux_annuel_pct_par_age": [
                {"age_min": r["age_min"], "age_max": r["age_max"], "taux_annuel_pct": r["taux_annuel_pct"]}
                for r in assurance
                if age is None or int(r["age_min"]) <= age <= int(r["age_max"])
            ],
            "frais_acquisition_pct_par_type_bien": {r["type_bien"]: r["taux_pct"] for r in frais},
            "note": "Barèmes inventés pour le POC. Assurance : taux annuel sur le capital initial, par emprunteur, au prorata de sa quotité.",
        }
        if duree_annees is not None and duree_annees not in taux:
            raise ErreurService("DUREE_HORS_BAREME", f"aucun taux pour {duree_annees} ans ; durées : {sorted(taux)}")
        return out

    def simuler(
        self, montant: float, duree_annees: int, taux_nominal_pct: float | None = None, ages: list[int] | None = None
    ) -> dict:
        if montant <= 0 or duree_annees <= 0:
            raise ErreurService("PARAMETRES_INVALIDES", "montant et durée doivent être positifs")
        taux = taux_nominal_pct if taux_nominal_pct is not None else refs.taux_pour_duree(duree_annees)
        m = round(mensualite(montant, taux, duree_annees), 2)
        assurance = 0.0
        detail = []
        for age in ages or []:
            t = refs.taux_assurance(age)
            part = round(t / 100 * montant / len(ages) / 12, 2)
            assurance += part
            detail.append(
                {
                    "age": age,
                    "taux_annuel_pct": t,
                    "quotite_pct": round(100 / len(ages), 1),
                    "assurance_mensuelle": part,
                }
            )
        assurance = round(assurance, 2)
        return {
            "montant": montant,
            "duree_annees": duree_annees,
            "taux_nominal_pct": taux,
            "mensualite_hors_assurance": m,
            "assurance_mensuelle": assurance,
            "assurance_detail": detail,
            "mensualite_assurance_comprise": round(m + assurance, 2),
            "cout_total_interets": round(m * duree_annees * 12 - montant, 2),
            "cout_total_assurance": round(assurance * duree_annees * 12, 2),
        }

    def politique(self, nom: str) -> dict:
        if nom not in TEXTES_POLITIQUE:
            raise ErreurService("TEXTE_INCONNU", f"textes disponibles : {TEXTES_POLITIQUE}")
        return {"nom": nom, "contenu": refs.lire_referentiel_texte(nom, self.config.referentiels_dir)}
