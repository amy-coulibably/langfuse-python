"""Le service OCR : lire une pièce que la lecture native ne sait pas lire (document scanné sans couche texte, photo).

C'est un guichet à part du coffre, comme dans une banque où la reconnaissance de caractères est un service mutualisé :
le coffre garde les pièces, le service OCR les lit. Il sert à montrer la **planification dynamique** de l'agent : il essaie
d'abord `lire_piece` (rapide, exact) ; si la pièce n'a pas de texte (`TEXTE_ABSENT`) ou n'est pas un PDF
(`FORMAT_NON_LISIBLE`), il passe à `ocr_piece` ; si l'OCR rend une lecture incertaine, il demande une copie lisible.

Ce que le service renvoie, ligne par ligne : le texte reconnu et une **confiance** de 0 à 1 (moyenne des mots de la
ligne, telle que le moteur la donne). Deux seuils, écrits ici et rappelés dans la fiche 13 :

- une ligne en dessous de `SEUIL_LIGNE` (0,80) est **incertaine** : `noter_fait` refuse d'en tirer un chiffre
  (`LECTURE_INCERTAINE`) ; on recoupe ce chiffre avec une autre source ;
- une pièce dont la confiance moyenne est sous `SEUIL_PIECE` (0,75) a le statut `LECTURE_INCERTAINE` : elle est
  inutilisable, on la redemande au client.

Moteur : Tesseract (local, gratuit, langue française), appelé en ligne de commande, sans dépendance Python. Le chemin se
règle par la variable `POC_TESSERACT` ; sinon le service cherche `tesseract` dans le PATH, puis aux emplacements Homebrew
(Mac) et d'installation Windows habituels. Sans moteur, `ocr_piece` répond `OCR_NON_DISPONIBLE` et l'agent demande une copie lisible.

Les lectures sont gardées en cache (`data/ocr/<demande>/<fichier>.json`) avec l'empreinte du fichier : relire une pièce ne
relance pas le moteur, et `noter_fait` vérifie un extrait contre la lecture que l'agent a eue sous les yeux.
"""

from __future__ import annotations

import csv
import hashlib
import io
import json
import os
import shutil
import subprocess
import time
from functools import lru_cache
from pathlib import Path

from poc.config import Config
from poc.services.coffre import ServiceCoffre
from poc.services.erreurs import ErreurService

SEUIL_LIGNE = 0.80
SEUIL_PIECE = 0.75
MIN_LIGNES = 3
RESOLUTION_DPI = 200
CHEMINS_WINDOWS = (
    r"C:\Program Files\Tesseract-OCR\tesseract.exe",
    r"C:\Program Files (x86)\Tesseract-OCR\tesseract.exe",
)
# Homebrew sur Mac (Apple Silicon, puis Intel) : souvent hors du PATH d'un shell non interactif ou d'un service
CHEMINS_MAC = ("/opt/homebrew/bin/tesseract", "/usr/local/bin/tesseract")


@lru_cache(maxsize=1)
def trouver_tesseract() -> str | None:
    """Le chemin du moteur, ou None s'il n'est pas installé."""
    candidat = os.environ.get("POC_TESSERACT")
    if candidat and Path(candidat).exists():
        return candidat
    trouve = shutil.which("tesseract")
    if trouve:
        return trouve
    return next((c for c in CHEMINS_MAC + CHEMINS_WINDOWS if Path(c).exists()), None)


@lru_cache(maxsize=1)
def description_moteur() -> dict:
    """Nom, version et langue du moteur, pour l'afficher et le tracer."""
    chemin = trouver_tesseract()
    if chemin is None:
        return {"disponible": False, "moteur": None, "langue": None}
    try:
        version = subprocess.run([chemin, "--version"], capture_output=True, text=True, timeout=20).stdout.split("\n")[
            0
        ]
        langues = subprocess.run([chemin, "--list-langs"], capture_output=True, text=True, timeout=20).stdout.split()
    except (OSError, subprocess.SubprocessError):
        return {"disponible": False, "moteur": None, "langue": None}
    langue = "fra" if "fra" in langues else "eng"
    return {"disponible": True, "moteur": version.strip() or "tesseract", "langue": langue, "chemin": chemin}


def _empreinte(chemin: Path) -> str:
    return hashlib.sha1(chemin.read_bytes()).hexdigest()[:16]


class ServiceOCR:
    def __init__(self, config: Config, coffre: ServiceCoffre | None = None) -> None:
        self.config = config
        self.coffre = coffre or ServiceCoffre(config)

    # ---- le cache ----------------------------------------------------------------------------------------------------------
    def _chemin_cache(self, demande_id: str, fichier: str) -> Path:
        return self.config.data_dir / "ocr" / demande_id / f"{fichier}.json"

    def lecture_en_cache(self, demande_id: str, piece: str) -> dict | None:
        p = self.coffre.piece(demande_id, piece)
        cache = self._chemin_cache(demande_id, p["fichier"])
        if not cache.exists():
            return None
        lu = json.loads(cache.read_text(encoding="utf-8"))
        chemin = self.coffre.chemin_piece(demande_id, piece)
        return lu if lu.get("empreinte") == _empreinte(chemin) else None

    # ---- la lecture --------------------------------------------------------------------------------------------------------
    def ocr_piece(self, demande_id: str, piece: str) -> dict:
        p = self.coffre.piece(demande_id, piece)
        entete = {k: p[k] for k in ("piece_id", "type", "personne", "periode", "fichier", "libelle")}
        if p["format"] == "pdf":
            try:
                lecture = self.coffre.lire_piece(demande_id, piece)
                for ligne in lecture["lignes"]:
                    ligne["confiance"] = 1.0
                return {
                    **lecture,
                    "ocr": False,
                    "statut": "LISIBLE",
                    "confiance_moyenne": 1.0,
                    "note": "document texte : lire_piece suffisait, aucun OCR nécessaire",
                }
            except ErreurService as exc:
                if exc.code != "TEXTE_ABSENT":
                    raise
        deja = self.lecture_en_cache(demande_id, piece)
        if deja is not None:
            return {**deja, "depuis_cache": True}
        moteur = description_moteur()
        if not moteur["disponible"]:
            raise ErreurService(
                "OCR_NON_DISPONIBLE",
                "aucun moteur OCR n'est installé sur ce poste : demander au client une version lisible de la pièce",
                503,
            )
        debut = time.time()
        chemin = self.coffre.chemin_piece(demande_id, piece)
        images = _images_de(chemin, p["format"])
        lignes: list[dict] = []
        for numero_page, image in enumerate(images, start=1):
            for texte, confiance in _reconnaitre(moteur["chemin"], moteur["langue"], image):
                lignes.append({"n": len(lignes) + 1, "page": numero_page, "texte": texte, "confiance": confiance})
        moyenne = round(sum(x["confiance"] for x in lignes) / len(lignes), 2) if lignes else 0.0
        lisible = moyenne >= SEUIL_PIECE and len(lignes) >= MIN_LIGNES
        resultat = {
            **entete,
            "ocr": True,
            "moteur": f"{moteur['moteur']} ({moteur['langue']})",
            "nb_pages": len(images),
            "lignes": lignes,
            "confiance_moyenne": moyenne,
            "statut": "LISIBLE" if lisible else "LECTURE_INCERTAINE",
            "seuil_confiance_ligne": SEUIL_LIGNE,
            "lignes_incertaines": [x["n"] for x in lignes if x["confiance"] < SEUIL_LIGNE],
            "conseil": (
                "Pièce lisible par OCR. Cite les lignes telles quelles dans noter_fait (source piece, extrait copié) ; une ligne "
                f"de confiance inférieure à {SEUIL_LIGNE:.2f} sera refusée : recoupe ce chiffre avec une autre source."
                if lisible
                else "Lecture trop incertaine pour en tirer un chiffre : demande au client une copie lisible (demander_piece), "
                "note un doute non bloquant, et poursuis avec les autres pièces."
            ),
            "duree_ms": int((time.time() - debut) * 1000),
            "empreinte": _empreinte(chemin),
        }
        cache = self._chemin_cache(demande_id, p["fichier"])
        cache.parent.mkdir(parents=True, exist_ok=True)
        cache.write_text(json.dumps(resultat, ensure_ascii=False, indent=1), encoding="utf-8")
        return resultat

    def lignes_connues(self, demande_id: str, piece: str) -> list[dict]:
        """Les lignes que l'agent a pu voir d'une pièce, avec leur confiance : le texte natif (confiance 1) ou la dernière
        lecture OCR. Sert à vérifier un extrait cité par `noter_fait`."""
        p = self.coffre.piece(demande_id, piece)
        if p["format"] == "pdf":
            try:
                return [{**x, "confiance": 1.0} for x in self.coffre.lire_piece(demande_id, piece)["lignes"]]
            except ErreurService as exc:
                if exc.code != "TEXTE_ABSENT":
                    raise
        lu = self.lecture_en_cache(demande_id, piece)
        if lu is None:
            raise ErreurService(
                "SOURCE_INTROUVABLE",
                f"la pièce {p['piece_id']} n'a pas de texte natif : la lire d'abord avec ocr_piece, puis citer une ligne de l'OCR",
            )
        return lu["lignes"]


# ---------------------------------------------------------------------------------------------------------------------
# Le moteur
# ---------------------------------------------------------------------------------------------------------------------
def _images_de(chemin: Path, format_: str):
    from PIL import Image

    if format_ == "pdf":
        import pypdfium2 as pdfium

        doc = pdfium.PdfDocument(str(chemin))
        try:
            return [doc[i].render(scale=RESOLUTION_DPI / 72).to_pil().convert("L") for i in range(len(doc))]
        finally:
            doc.close()
    with Image.open(chemin) as img:
        return [img.convert("L")]


def _reconnaitre(tesseract: str, langue: str, image) -> list[tuple[str, float]]:
    """Les lignes reconnues sur une page : (texte, confiance 0-1). Sortie TSV du moteur, regroupée par ligne."""
    tampon = io.BytesIO()
    image.save(tampon, format="PNG")
    proc = subprocess.run(
        [tesseract, "stdin", "stdout", "-l", langue, "--psm", "4", "tsv"],
        input=tampon.getvalue(),
        capture_output=True,
        timeout=120,
    )
    if proc.returncode != 0:
        raise ErreurService(
            "OCR_ECHEC", f"le moteur OCR a échoué : {proc.stderr.decode('utf-8', 'replace')[:300]}", 502
        )
    lignes: dict[tuple[str, str, str], list[tuple[str, float]]] = {}
    for row in csv.DictReader(io.StringIO(proc.stdout.decode("utf-8", "replace")), delimiter="\t"):
        mot = (row.get("text") or "").strip()
        if row.get("level") != "5" or not mot:
            continue
        try:
            confiance = float(row["conf"])
        except (TypeError, ValueError):
            continue
        if confiance < 0:
            continue
        lignes.setdefault((row["block_num"], row["par_num"], row["line_num"]), []).append((mot, confiance))
    return [
        (" ".join(m for m, _ in mots), round(sum(c for _, c in mots) / len(mots) / 100, 2))
        for mots in lignes.values()
        if mots
    ]
