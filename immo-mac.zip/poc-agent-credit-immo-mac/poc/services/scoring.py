"""Le score d'éligibilité de la banque (`api-scoring`) : une grille de points transparente, calculée sur ce que le système
d'information voit, et rien d'autre. Voir `referentiels/grille_score.md`, qui est la documentation publique de la grille.

Le score est volontairement **myope** : il ne lit aucune pièce, ne voit que les comptes tenus dans la banque, compte une
prime comme un salaire et un crédit qui finit bientôt comme un autre. C'est ce qui le rend utile en démonstration : sur le
fil rouge, il donne un A à un dossier que l'analyse place « sous réserves ». L'agent doit le dire. Il ne doit jamais en
faire un motif de recommandation (garde-fou `SCORE_NON_DECISIONNEL` dans le service du conseiller).
"""

from __future__ import annotations

import datetime as dt

from poc.config import Config
from poc.generateur import referentiels as refs
from poc.services.banque import ServiceBanque
from poc.services.erreurs import ErreurService
from poc.services.incidents import ServiceIncidents

VERSION_GRILLE = "G-2026.1"
MOTS_REVENUS = ("SALAIRE", "PENSION", "REMUNERATION")
MOTS_SIGNAUX = ("COMMISSION INTERVENTION", "REJET", "PARIS EN LIGNE", "WINAMAX")
CLASSES = (("A", 850), ("B", 700), ("C", 550), ("D", 400), ("E", 0))
PLAFOND_INCIDENT_EN_COURS = 399  # un incident en cours plafonne le score en classe E
AVERTISSEMENT = (
    "Indicateur interne consultatif, calculé sur les seules données du système d'information de la banque. Il ne lit "
    "aucune pièce, ne remplace pas l'analyse du dossier et ne décide de rien : la décision appartient au conseiller."
)
NE_VOIT_PAS = [
    "les comptes tenus dans d'autres banques (un salaire versé en partie ailleurs fait baisser les revenus constatés)",
    "les éléments exceptionnels : une prime versée dans les trois mois fait monter les revenus constatés",
    "les règles de la politique : indépendant de moins de deux exercices, CDD de moins de trois ans, pension récente",
    "les loyers attendus d'un projet locatif et le loyer actuel qui reste à payer",
    "la fin proche d'un crédit : tous les crédits déclarés sont comptés",
    "les pièces du dossier et les doutes de l'analyse (pièce manquante, avis en écart, pièce illisible)",
]


def classe_de(score: int) -> str:
    return next(c for c, seuil in CLASSES if score >= seuil)


def _paliers(valeur: float, paliers: list[tuple[float, int]], sinon: int) -> int:
    for seuil, points in paliers:
        if valeur <= seuil:
            return points
    return sinon


class ServiceScoring:
    def __init__(self, config: Config) -> None:
        self.config = config
        self.banque = ServiceBanque(config)
        self.incidents = ServiceIncidents(config)

    def grille(self) -> dict:
        return {
            "version_grille": VERSION_GRILLE,
            "texte": refs.lire_referentiel_texte("grille_score", self.config.referentiels_dir),
        }

    def score(self, demande_id: str) -> dict:
        d = self.banque.demande(demande_id)
        emprunteurs = d["emprunteurs"]
        if not emprunteurs:
            raise ErreurService("DONNEES_ABSENTES", f"la demande {demande_id} n'a pas d'emprunteur")
        depot = dt.date.fromisoformat(d["date_depot"][:10])
        mois = d.get("mois_attendus_fiches_et_releves") or []
        comptes = {
            c["compte_id"]: c for e in emprunteurs for c in self.banque.comptes(e["client_id"])
        }  # les comptes tenus dans la banque, une fois chacun
        mouvements = {
            cid: self.banque.mouvements(cid, du=mois[0] if mois else None, au=mois[-1] if mois else None, limite=500)[
                "mouvements"
            ]
            for cid in comptes
        }
        criteres: list[dict] = []

        # ---- taux d'endettement estimé
        recus = [
            m["montant"]
            for lignes in mouvements.values()
            for m in lignes
            if m["montant"] > 0 and any(k in m["libelle"].upper() for k in MOTS_REVENUS)
        ]
        revenus = round(sum(recus) / max(1, len(mois)), 2)
        frais = round((d["prix"] - d["honoraires_agence_inclus"]) * refs.taux_frais_notaire(d["type_bien"]) / 100)
        capital = round(d["prix"] + frais - d["apport"])
        duree = int(d["duree_souhaitee_annees"])
        mensualite = self.banque.simuler(capital, duree, ages=d.get("ages_au_depot") or None)[
            "mensualite_assurance_comprise"
        ]
        credits = float(d.get("total_mensualites_credits_declares") or 0.0)
        taux = round((mensualite + credits) / revenus * 100, 1) if revenus > 0 else None
        criteres.append(
            {
                "critere": "taux_endettement_estime",
                "libelle": "Taux d'endettement estimé",
                "valeur_vue": f"{taux} %" if taux is not None else "aucun revenu constaté",
                "detail": f"({mensualite} € de mensualité du barème sur {duree} ans + {credits} € de crédits déclarés) ÷ "
                f"{revenus} € de revenus constatés par mois sur les comptes de la banque",
                "points": 0 if taux is None else _paliers(taux, [(30, 250), (33, 200), (35, 150), (40, 60)], 0),
                "max": 250,
            }
        )

        # ---- apport
        ratio = d["apport"] / d["prix"] * 100 if d["prix"] else 0.0
        criteres.append(
            {
                "critere": "apport",
                "libelle": "Apport",
                "valeur_vue": f"{ratio:.1f} % du prix",
                "detail": f"{d['apport']} € d'apport pour un prix de {d['prix']} € ; frais d'acquisition estimés {frais} €",
                "points": 150 if ratio >= 20 else 110 if ratio >= 10 else 70 if d["apport"] >= frais else 0,
                "max": 150,
            }
        )

        # ---- stabilité professionnelle
        def stabilite(e: dict) -> int:
            sit, anc = e.get("situation_pro"), e.get("anciennete_mois_au_depot") or 0
            if sit == "retraite" or (sit == "cdi" and anc >= 24):
                return 150
            if sit == "cdi" and anc >= 6:
                return 100
            if sit == "auto_entrepreneur" and anc >= 24:
                return 100
            if sit == "cdd" and anc >= 36:
                return 80
            return 30

        points_pro = [stabilite(e) for e in emprunteurs]
        criteres.append(
            {
                "critere": "stabilite_professionnelle",
                "libelle": "Stabilité professionnelle",
                "valeur_vue": " ; ".join(
                    f"{e['prenom']} : {e.get('situation_pro')} depuis {e.get('anciennete_mois_au_depot')} mois"
                    for e in emprunteurs
                ),
                "detail": "moyenne des emprunteurs : " + ", ".join(str(x) for x in points_pro),
                "points": round(sum(points_pro) / len(points_pro)),
                "max": 150,
            }
        )

        # ---- ancienneté dans la banque
        depuis = min(
            dt.date.fromisoformat(self.banque.client(e["client_id"])["client_depuis"][:10]) for e in emprunteurs
        )
        annees = (depot - depuis).days / 365.25
        criteres.append(
            {
                "critere": "anciennete_bancaire",
                "libelle": "Ancienneté dans la banque",
                "valeur_vue": f"cliente ou client depuis {depuis.isoformat()} ({annees:.1f} ans)",
                "detail": "le client le plus ancien du foyer",
                "points": 100 if annees >= 5 else 60 if annees >= 2 else 20,
                "max": 100,
            }
        )

        # ---- incidents
        etats = []
        for e in emprunteurs:
            r = self.incidents.rechercher(**self.banque.identite(e["client_id"]))
            etats.append("en_cours" if r["incidents_en_cours"] else "regularise" if r["nb_incidents"] else "aucun")
        pire = "en_cours" if "en_cours" in etats else "regularise" if "regularise" in etats else "aucun"
        criteres.append(
            {
                "critere": "incidents",
                "libelle": "Incidents",
                "valeur_vue": {
                    "aucun": "aucun incident",
                    "regularise": "incident régularisé",
                    "en_cours": "incident en cours",
                }[pire],
                "detail": "fichier d'incidents, pour chaque emprunteur",
                "points": {"aucun": 150, "regularise": 60, "en_cours": 0}[pire],
                "max": 150,
            }
        )

        # ---- tenue de compte
        signaux = [
            f"{cid} {m['date']} {m['libelle']}"
            for cid, lignes in mouvements.items()
            for m in lignes
            if any(k in m["libelle"].upper() for k in MOTS_SIGNAUX)
        ]
        criteres.append(
            {
                "critere": "tenue_de_compte",
                "libelle": "Tenue de compte",
                "valeur_vue": f"{len(signaux)} signal(aux) sur {len(comptes)} compte(s) de la banque",
                "detail": "; ".join(signaux[:5])
                or "aucune commission d'intervention, aucun rejet, aucun pari en ligne",
                "points": 0 if signaux else 200,
                "max": 200,
            }
        )

        total = sum(c["points"] for c in criteres)
        plafonne = pire == "en_cours" and total > PLAFOND_INCIDENT_EN_COURS
        if plafonne:
            total = PLAFOND_INCIDENT_EN_COURS
        return {
            "demande_id": demande_id,
            "score": total,
            "sur": 1000,
            "classe": classe_de(total),
            "version_grille": VERSION_GRILLE,
            "criteres": criteres,
            "plafond_applique": "incident en cours : score plafonné en classe E" if plafonne else None,
            "comptes_vus": sorted(comptes),
            "revenus_constates_mensuels": revenus,
            "ne_voit_pas": NE_VOIT_PAS,
            "avertissement": AVERTISSEMENT,
        }
