"""L'erreur commune des services : un code court et un message lisible, que les API traduisent en réponse HTTP et que les
outils renvoient à l'agent tels quels (jamais une pile d'appels)."""

from __future__ import annotations


class ErreurService(Exception):
    def __init__(self, code: str, message: str, statut_http: int = 400) -> None:
        super().__init__(f"{code}: {message}")
        self.code = code
        self.message = message
        self.statut_http = statut_http


class Introuvable(ErreurService):
    def __init__(self, message: str) -> None:
        super().__init__("INTROUVABLE", message, 404)
