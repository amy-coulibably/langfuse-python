"""Le fichier d'incidents, simulé (`incidents.sqlite`) : un guichet externe à la banque, interrogé par l'identité d'une
personne (nom, prénom, date de naissance), jamais par un identifiant client."""

from __future__ import annotations

from poc.config import Config
from poc.donnees import SQLiteStore
from poc.services.erreurs import ErreurService


class ServiceIncidents:
    def __init__(self, config: Config) -> None:
        self.config = config
        self.store = SQLiteStore(config.sqlite_incidents)

    def rechercher(self, nom: str, prenom: str, date_naissance: str) -> dict:
        if not self.config.sqlite_incidents.exists() or not self.store.existe("incidents_incident"):
            raise ErreurService(
                "DONNEES_ABSENTES", "le fichier d'incidents n'est pas généré : lancer `poc donnees generer`", 503
            )
        rows = self.store.requete(
            "SELECT type, date, montant, regularise, date_regularisation FROM incidents_incident "
            "WHERE UPPER(nom) = ? AND UPPER(prenom) = ? AND date_naissance = ? ORDER BY date",
            (nom.upper(), prenom.upper(), date_naissance),
        ).to_dicts()
        for r in rows:
            r["regularise"] = bool(r["regularise"])
        return {
            "personne": {"nom": nom, "prenom": prenom, "date_naissance": date_naissance},
            "nb_incidents": len(rows),
            "incidents_en_cours": sum(1 for r in rows if not r["regularise"]),
            "incidents": rows,
            "conclusion": "aucun incident connu"
            if not rows
            else ("incident(s) en cours" if any(not r["regularise"] for r in rows) else "incident(s) régularisé(s)"),
        }
