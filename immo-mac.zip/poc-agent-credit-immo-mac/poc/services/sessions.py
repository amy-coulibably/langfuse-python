"""Sessions de l'agent : création, suivi d'étape, journal de raisonnement, traces techniques, feuille de calcul.

Tables de la base `agent.sqlite` écrites ici : agent_sessions, agent_journal, agent_traces ; agent_calculs est écrite par
l'atelier. Les tables des lots suivants (faits, doutes, messages, synthèses, recommandations, évaluations, campagnes)
viendront s'y ajouter sans changer ce module.
"""

from __future__ import annotations

import datetime as dt
import json
import uuid

import polars as pl

from poc.donnees import SQLiteStore
from poc.etapes import noms_etapes
from poc.schemas import EntreeJournal, Session, Trace
from poc.services.atelier import Atelier


class SessionIntrouvable(LookupError):
    pass


def _now() -> str:
    return dt.datetime.now().isoformat(timespec="seconds")


class ServiceSessions:
    def __init__(self, store_agent: SQLiteStore) -> None:
        self.store = store_agent
        self.atelier = Atelier(store_agent)

    # ------------------------------------------------------------------ sessions
    def creer_session(self, demande_id: str, modele: str = "sans_modele") -> Session:
        session_id = f"S-{demande_id}-{uuid.uuid4().hex[:6]}"
        now = _now()
        self.store.ecrire(
            "agent_sessions",
            pl.DataFrame(
                [
                    {
                        "session_id": session_id,
                        "demande_id": demande_id,
                        "modele": modele,
                        "statut": "EN_COURS",
                        "etape_courante": noms_etapes()[0],
                        "creation": now,
                        "mise_a_jour": now,
                    }
                ]
            ),
            ajouter=True,
        )
        return self.session(session_id)

    def session(self, session_id: str) -> Session:
        if not self.store.existe("agent_sessions"):
            raise SessionIntrouvable(f"Session {session_id} introuvable")
        df = self.store.requete("SELECT * FROM agent_sessions WHERE session_id = ?", (session_id,))
        if not df.height:
            raise SessionIntrouvable(f"Session {session_id} introuvable")
        r = df.to_dicts()[0]
        return Session(
            session_id=r["session_id"],
            demande_id=r["demande_id"],
            modele=r["modele"],
            statut=r["statut"],
            etape_courante=r["etape_courante"],
            creation=dt.datetime.fromisoformat(r["creation"]),
            mise_a_jour=dt.datetime.fromisoformat(r["mise_a_jour"]),
            nb_calculs=self._compte("agent_calculs", session_id),
            nb_doutes=self._compte("agent_doutes", session_id),
        )

    def _compte(self, table: str, session_id: str) -> int:
        if not self.store.existe(table):
            return 0
        return int(
            self.store.requete(f'SELECT COUNT(*) AS n FROM "{table}" WHERE session_id = ?', (session_id,))["n"][0]
        )

    def mettre_a_jour(self, session_id: str, statut: str | None = None, etape: str | None = None) -> Session:
        self.session(session_id)
        if statut:
            self.store.executer(
                "UPDATE agent_sessions SET statut = ?, mise_a_jour = ? WHERE session_id = ?",
                (statut, _now(), session_id),
            )
        if etape:
            if etape not in noms_etapes():
                raise ValueError(f"étape inconnue : {etape} ; attendues : {noms_etapes()}")
            self.store.executer(
                "UPDATE agent_sessions SET etape_courante = ?, mise_a_jour = ? WHERE session_id = ?",
                (etape, _now(), session_id),
            )
        return self.session(session_id)

    def sessions(self, demande_id: str | None = None, n: int | None = None) -> list[Session]:
        if not self.store.existe("agent_sessions"):
            return []
        sql = (
            "SELECT session_id FROM agent_sessions"
            + (" WHERE demande_id = ?" if demande_id else "")
            + " ORDER BY creation DESC"
            + (f" LIMIT {int(n)}" if n else "")
        )
        ids = self.store.requete(sql, (demande_id,) if demande_id else ())["session_id"].to_list()
        return [self.session(s) for s in ids]

    # ------------------------------------------------------------------ journal de raisonnement
    def journaliser(self, session_id: str, etape: str, type_: str, texte: str) -> EntreeJournal:
        e = EntreeJournal(session_id=session_id, etape=etape, type=type_, texte=texte, horodatage=dt.datetime.now())
        self.store.ecrire(
            "agent_journal",
            pl.DataFrame(
                [{**e.model_dump(exclude={"horodatage"}), "horodatage": e.horodatage.isoformat(timespec="seconds")}]
            ),
            ajouter=True,
        )
        return e

    def journal(self, session_id: str) -> list[EntreeJournal]:
        if not self.store.existe("agent_journal"):
            return []
        rows = self.store.requete(
            "SELECT * FROM agent_journal WHERE session_id = ? ORDER BY horodatage, rowid", (session_id,)
        ).to_dicts()
        return [
            EntreeJournal(
                **{k: v for k, v in r.items() if k != "horodatage"},
                horodatage=dt.datetime.fromisoformat(r["horodatage"]),
            )
            for r in rows
        ]

    # ------------------------------------------------------------------ traces techniques
    def tracer(
        self,
        session_id: str,
        etape: str,
        type_: str,
        nom: str,
        duree_ms: int,
        tokens_entree: int = 0,
        tokens_sortie: int = 0,
        cout_euros: float | None = None,
        detail: dict | None = None,
    ) -> Trace:
        t = Trace(
            trace_id=f"T{uuid.uuid4().hex[:10]}",
            session_id=session_id,
            etape=etape,
            type=type_,
            nom=nom,
            duree_ms=duree_ms,
            tokens_entree=tokens_entree,
            tokens_sortie=tokens_sortie,
            cout_euros=cout_euros,
            detail=detail or {},
            horodatage=dt.datetime.now(),
        )
        self.store.ecrire(
            "agent_traces",
            pl.DataFrame(
                [
                    {
                        **t.model_dump(exclude={"detail", "horodatage"}),
                        "detail_json": json.dumps(t.detail, ensure_ascii=False),
                        "horodatage": t.horodatage.isoformat(timespec="seconds"),
                    }
                ],
                schema_overrides={"cout_euros": pl.Float64},
            ),
            ajouter=True,
        )
        return t

    def traces(self, session_id: str) -> list[Trace]:
        if not self.store.existe("agent_traces"):
            return []
        rows = self.store.requete(
            "SELECT * FROM agent_traces WHERE session_id = ? ORDER BY horodatage, rowid", (session_id,)
        ).to_dicts()
        return [
            Trace(
                **{k: v for k, v in r.items() if k in Trace.model_fields and k not in ("detail", "horodatage")},
                detail=json.loads(r["detail_json"] or "{}"),
                horodatage=dt.datetime.fromisoformat(r["horodatage"]),
            )
            for r in rows
        ]
