"""Le coffre : les pièces déposées par le client pour une demande (`data/coffre/<demande_id>/`).

Lister l'inventaire, lire une pièce (texte du PDF, ligne par ligne et numéroté, pour pouvoir citer « pièce P03, ligne 14 »).
La lecture native échoue de deux façons, chacune avec un code que l'agent sait lire : `FORMAT_NON_LISIBLE` pour une image
(photo de la pièce) et `TEXTE_ABSENT` pour un PDF sans couche texte (document scanné). Dans les deux cas, la suite est le
service OCR (`poc/services/ocr.py`, outil `ocr_piece`) : c'est le changement de méthode que la démonstration veut montrer.
"""

from __future__ import annotations

import json
import re
from functools import lru_cache
from pathlib import Path

from poc.config import Config
from poc.services.erreurs import ErreurService, Introuvable

TAILLE_MAX_LIGNE = 400


def _normaliser(texte: str) -> str:
    """Pour comparer un extrait cité au texte d'une pièce : espaces (dont insécables) réduits, casse ignorée."""
    return re.sub(r"\s+", " ", texte.replace(" ", " ").replace("\xa0", " ")).strip().lower()


class ServiceCoffre:
    def __init__(self, config: Config) -> None:
        self.config = config

    def _dossier(self, demande_id: str) -> Path:
        d = self.config.coffre_dir / demande_id
        if not (d / "inventaire.json").exists():
            raise Introuvable(f"aucun coffre pour la demande {demande_id}")
        return d

    def inventaire(self, demande_id: str) -> dict:
        d = self._dossier(demande_id)
        return json.loads((d / "inventaire.json").read_text(encoding="utf-8"))

    def lister_pieces(self, demande_id: str) -> list[dict]:
        return self.inventaire(demande_id)["pieces"]

    def piece(self, demande_id: str, piece: str) -> dict:
        """Une pièce par son identifiant (P03), son nom de fichier, ou son nom sans extension."""
        for p in self.lister_pieces(demande_id):
            if p["piece_id"] == piece or p["fichier"] == piece or Path(p["fichier"]).stem == piece:
                return p
        raise Introuvable(f"pièce {piece} inconnue dans le coffre de {demande_id} (utiliser lister_pieces)")

    def chemin_piece(self, demande_id: str, piece: str) -> Path:
        return self._dossier(demande_id) / self.piece(demande_id, piece)["fichier"]

    def lire_piece(self, demande_id: str, piece: str, page: int | None = None) -> dict:
        p = self.piece(demande_id, piece)
        chemin = self._dossier(demande_id) / p["fichier"]
        if p["format"] != "pdf":
            raise ErreurService(
                "FORMAT_NON_LISIBLE",
                f"la pièce {p['piece_id']} est une image ({p['format']}) : lire_piece ne lit que le texte des PDF ; "
                "passer par ocr_piece",
            )
        pages = _pages_pdf(str(chemin), chemin.stat().st_mtime_ns)
        if not any(t.strip() for t in pages):
            raise ErreurService(
                "TEXTE_ABSENT",
                f"la pièce {p['piece_id']} est un PDF sans texte (document scanné, sans couche texte) : la lecture native "
                "ne donne rien ; passer par ocr_piece",
            )
        if page is not None and not (1 <= page <= len(pages)):
            raise ErreurService("PAGE_INVALIDE", f"la pièce {p['piece_id']} a {len(pages)} page(s)")
        lignes: list[dict] = []
        n = 0
        for i, texte in enumerate(pages, start=1):
            for brut in texte.splitlines():
                brut = brut.strip()
                if not brut:
                    continue
                n += 1
                if page is None or i == page:
                    lignes.append({"n": n, "page": i, "texte": brut[:TAILLE_MAX_LIGNE]})
        return {
            **{k: p[k] for k in ("piece_id", "type", "personne", "periode", "fichier", "libelle")},
            "nb_pages": len(pages),
            "lignes": lignes,
        }

    def texte_piece(self, demande_id: str, piece: str) -> str:
        return "\n".join(ligne["texte"] for ligne in self.lire_piece(demande_id, piece)["lignes"])

    def extrait_present(self, demande_id: str, piece: str, extrait: str) -> bool:
        return _normaliser(extrait) in _normaliser(self.texte_piece(demande_id, piece))


@lru_cache(maxsize=256)
def _pages_pdf(chemin: str, empreinte: int) -> tuple[str, ...]:
    from pypdf import PdfReader

    lecteur = PdfReader(chemin)
    return tuple((page.extract_text() or "") for page in lecteur.pages)
