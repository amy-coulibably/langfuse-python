"""L'atelier de calcul : l'agent écrit ses formules, l'atelier résout les entrées, exécute le code en environnement
fermé et archive chaque résultat dans la feuille de calcul de la session (`agent_calculs`).

Garde-fous, dans l'ordre :
1. les entrées sont désignées par leur origine (un fait enregistré, un résultat antérieur, une hypothèse déclarée) et
   résolues par le service : l'agent ne recopie jamais un chiffre ;
2. le code est analysé (arbre syntaxique) avant toute exécution : affectations et arithmétique, fonctions de `math` et de
   `statistics`, quelques fonctions intégrées ; aucun import, aucun attribut caché, aucun accès au système ; tout nombre
   d'au moins 1 000 écrit en dur est refusé (un montant se déclare comme entrée, jamais dans la formule) ;
3. l'exécution a lieu dans un processus Python séparé, lancé en mode isolé (`-I -S`), sans variables d'environnement,
   avec des fonctions intégrées réduites et une durée plafonnée ; tout dépassement tue le processus ;
4. les résultats doivent être des nombres finis (ou de courtes listes de nombres) ; ils sont enregistrés avec le code,
   les entrées et leurs origines, les hypothèses, l'étape et la session.
"""

from __future__ import annotations

import ast
import datetime as dt
import json
import math
import os
import subprocess
import sys
import time
import uuid
from typing import Any

import polars as pl

from poc.donnees import SQLiteStore
from poc.schemas import Calcul, DemandeCalcul, Entree, Origine, ResultatCalcul

SEUIL_CHIFFRE_RECOPIE = 1_000  # au-delà, un nombre écrit dans le code est un montant recopié, pas un coefficient


def _est_puissance_de_dix(valeur: float) -> bool:
    """1 000, 1e6… restent permis : ce sont des facteurs d'unité, pas des montants."""
    v = abs(valeur)
    while v >= 10 and v == int(v) and int(v) % 10 == 0:
        v //= 10
    return v == 1


NOEUDS_AUTORISES = (
    ast.Module,
    ast.Assign,
    ast.AugAssign,
    ast.AnnAssign,
    ast.Expr,
    ast.If,
    ast.IfExp,
    ast.For,
    ast.Compare,
    ast.BoolOp,
    ast.UnaryOp,
    ast.BinOp,
    ast.Name,
    ast.Load,
    ast.Store,
    ast.Constant,
    ast.Call,
    ast.Attribute,
    ast.Subscript,
    ast.Slice,
    ast.Tuple,
    ast.List,
    ast.Dict,
    ast.ListComp,
    ast.comprehension,
    ast.keyword,
    ast.Pass,
    ast.Break,
    ast.Continue,
    ast.JoinedStr,
    ast.FormattedValue,
    ast.Add,
    ast.Sub,
    ast.Mult,
    ast.Div,
    ast.FloorDiv,
    ast.Mod,
    ast.Pow,
    ast.USub,
    ast.UAdd,
    ast.Not,
    ast.And,
    ast.Or,
    ast.Eq,
    ast.NotEq,
    ast.Lt,
    ast.LtE,
    ast.Gt,
    ast.GtE,
    ast.Is,
    ast.IsNot,
    ast.In,
    ast.NotIn,
)
FONCTIONS_AUTORISEES = {
    "abs",
    "min",
    "max",
    "round",
    "sum",
    "len",
    "float",
    "int",
    "bool",
    "range",
    "sorted",
    "enumerate",
    "zip",
    "any",
    "all",
    "list",
    "tuple",
    "dict",
}
MODULES_AUTORISES = {"math", "statistics"}
NOMS_INTERDITS = {
    "exec",
    "eval",
    "open",
    "compile",
    "input",
    "breakpoint",
    "globals",
    "locals",
    "vars",
    "getattr",
    "setattr",
    "delattr",
    "__import__",
    "import",
    "os",
    "sys",
    "subprocess",
    "socket",
    "pathlib",
    "shutil",
    "builtins",
    "type",
    "object",
    "super",
    "memoryview",
    "bytearray",
}
DUREE_MAX_S = 5.0
TAILLE_LISTE_MAX = 100

RUNNER = r"""
import json, sys, math, statistics
donnees = json.loads(sys.stdin.read())
SAFE = {n: __builtins__[n] if isinstance(__builtins__, dict) else getattr(__builtins__, n) for n in FONCTIONS_AUTORISEES_JSON}
SAFE["True"], SAFE["False"], SAFE["None"] = True, False, None
espace = {"__builtins__": SAFE, "math": math, "statistics": statistics}
espace.update(donnees["entrees"])
try:
    exec(compile(donnees["code"], "<atelier>", "exec"), espace)
    sorties = {}
    for nom in donnees["sorties"]:
        if nom not in espace:
            print(json.dumps({"erreur": "SORTIE_ABSENTE", "message": f"la variable {nom} n'est pas definie par le code"})); sys.exit(0)
        sorties[nom] = espace[nom]
    print(json.dumps({"sorties": sorties}, default=str))
except ZeroDivisionError as e:
    print(json.dumps({"erreur": "DIVISION_PAR_ZERO", "message": str(e)}))
except Exception as e:
    print(json.dumps({"erreur": type(e).__name__, "message": str(e)}))
""".replace("FONCTIONS_AUTORISEES_JSON", json.dumps(sorted(FONCTIONS_AUTORISEES)))


class ErreurAtelier(ValueError):
    def __init__(self, code: str, message: str) -> None:
        super().__init__(f"{code}: {message}")
        self.code = code
        self.message = message


class Atelier:
    def __init__(self, store_agent: SQLiteStore, duree_max_s: float = DUREE_MAX_S) -> None:
        self.store_agent = store_agent
        self.duree_max_s = duree_max_s

    # ------------------------------------------------------------------ 1. résolution des entrées
    def resoudre(self, session_id: str, entree: Entree) -> tuple[float | int, str]:
        o: Origine = entree.origine
        if o.type == "constante":
            if o.valeur is None or not o.justification:
                raise ErreurAtelier(
                    "HYPOTHESE_INCOMPLETE", f"l'hypothèse {entree.nom} doit porter une valeur et une justification"
                )
            return o.valeur, f"constante:{o.justification}"
        if not o.nom:
            raise ErreurAtelier("ORIGINE_INCOMPLETE", f"{entree.nom} : le nom du {o.type} est requis")
        if o.type == "calcul":
            val = self.valeur_resultat(session_id, o.nom)
            if val is None:
                raise ErreurAtelier(
                    "RESULTAT_INCONNU",
                    f"{o.nom} n'existe pas dans la feuille de calcul de la session{self._proches(session_id, o.nom)}",
                )
            return val, f"calcul:{o.nom}"
        val = self.valeur_fait(session_id, o.nom)
        if val is None:
            raise ErreurAtelier(
                "FAIT_INCONNU",
                f"{o.nom} n'est pas un fait enregistré dans cette session (l'enregistrer d'abord avec noter_fait)"
                f"{self._proches(session_id, o.nom)}",
            )
        return val, f"fait:{o.nom}"

    def _proches(self, session_id: str, nom: str) -> str:
        """« ; noms proches : a, b » pour aider à corriger une faute de frappe, à partir des faits et résultats de la session."""
        import difflib

        candidats: list[str] = []
        for table, col in (("agent_faits", "nom"), ("agent_calculs", "nom_resultat")):
            if self.store_agent.existe(table):
                candidats += self.store_agent.requete(
                    f'SELECT DISTINCT "{col}" FROM "{table}" WHERE session_id = ?', (session_id,)
                )[col].to_list()
        proches = difflib.get_close_matches(nom, candidats, n=3, cutoff=0.6)
        return f" ; noms proches : {', '.join(proches)}" if proches else ""

    def _derniere_valeur(self, table: str, colonne_nom: str, session_id: str, nom: str) -> float | None:
        if not self.store_agent.existe(table):
            return None
        df = self.store_agent.requete(
            f'SELECT valeur FROM "{table}" WHERE session_id = ? AND "{colonne_nom}" = ? ORDER BY horodatage DESC, rowid DESC LIMIT 1',
            (session_id, nom),
        )
        return None if not df.height or df["valeur"][0] is None else float(df["valeur"][0])

    def valeur_resultat(self, session_id: str, nom_resultat: str) -> float | None:
        return self._derniere_valeur("agent_calculs", "nom_resultat", session_id, nom_resultat)

    def valeur_fait(self, session_id: str, nom_fait: str) -> float | None:
        return self._derniere_valeur("agent_faits", "nom", session_id, nom_fait)

    # ------------------------------------------------------------------ 2. analyse statique
    @staticmethod
    def analyser(code: str, noms_entrees: set[str], sorties: list[str]) -> None:
        try:
            arbre = ast.parse(code, mode="exec")
        except SyntaxError as exc:
            raise ErreurAtelier("SYNTAXE", f"code invalide : {exc.msg} (ligne {exc.lineno})") from exc
        for noeud in ast.walk(arbre):
            if not isinstance(noeud, NOEUDS_AUTORISES):
                raise ErreurAtelier("CODE_REFUSE", f"construction non autorisée : {type(noeud).__name__}")
            if isinstance(noeud, ast.Name):
                if noeud.id in NOMS_INTERDITS or noeud.id.startswith("__"):
                    raise ErreurAtelier("CODE_REFUSE", f"nom interdit : {noeud.id}")
            if isinstance(noeud, ast.Attribute):
                if noeud.attr.startswith("_"):
                    raise ErreurAtelier("CODE_REFUSE", f"attribut interdit : {noeud.attr}")
                if not (isinstance(noeud.value, ast.Name) and noeud.value.id in MODULES_AUTORISES):
                    raise ErreurAtelier("CODE_REFUSE", "seuls les attributs de math et statistics sont autorisés")
            if isinstance(noeud, ast.Call):
                f = noeud.func
                if isinstance(f, ast.Name) and f.id not in FONCTIONS_AUTORISEES:
                    raise ErreurAtelier("CODE_REFUSE", f"fonction non autorisée : {f.id}")
                if not isinstance(f, (ast.Name, ast.Attribute)):
                    raise ErreurAtelier("CODE_REFUSE", "appel indirect non autorisé")
            if isinstance(noeud, ast.Constant) and isinstance(noeud.value, (bytes, complex)):
                raise ErreurAtelier("CODE_REFUSE", "constante non autorisée")
            if (
                isinstance(noeud, ast.Constant)
                and isinstance(noeud.value, (int, float))
                and not isinstance(noeud.value, bool)
                and abs(noeud.value) >= SEUIL_CHIFFRE_RECOPIE
                and not _est_puissance_de_dix(noeud.value)
            ):
                raise ErreurAtelier(
                    "CHIFFRE_RECOPIE",
                    f"le nombre {noeud.value!r} est écrit en dur dans le code : tout montant doit être déclaré comme entrée "
                    "(origine fait, calcul ou constante justifiée), jamais recopié",
                )
        for s in sorties:
            if not s.isidentifier() or s in noms_entrees:
                raise ErreurAtelier("SORTIE_INVALIDE", f"nom de sortie invalide ou identique à une entrée : {s}")
        for n in noms_entrees:
            if not n.isidentifier() or n in NOMS_INTERDITS or n in FONCTIONS_AUTORISEES or n in MODULES_AUTORISES:
                raise ErreurAtelier("ENTREE_INVALIDE", f"nom d'entrée invalide : {n}")

    # ------------------------------------------------------------------ 3. exécution isolée
    def executer(self, code: str, entrees: dict[str, float | int], sorties: list[str]) -> dict:
        charge = json.dumps({"code": code, "entrees": entrees, "sorties": sorties})
        env = {"PYTHONIOENCODING": "utf-8", "PYTHONHASHSEED": "0"}
        if os.name == "nt" and "SYSTEMROOT" in os.environ:
            env["SYSTEMROOT"] = os.environ["SYSTEMROOT"]  # requis par l'interpréteur Windows pour démarrer
        try:
            proc = subprocess.run(
                [sys.executable, "-I", "-S", "-c", RUNNER],
                input=charge,
                capture_output=True,
                text=True,
                timeout=self.duree_max_s,
                env=env,
                cwd=os.path.dirname(sys.executable),
            )
        except subprocess.TimeoutExpired as exc:
            raise ErreurAtelier("CALCUL_TROP_LONG", f"exécution interrompue après {self.duree_max_s:.0f} s") from exc
        if proc.returncode != 0:
            raise ErreurAtelier("EXECUTION", (proc.stderr or "échec de l'exécution").strip()[-400:])
        try:
            reponse = json.loads(proc.stdout.strip().splitlines()[-1])
        except (json.JSONDecodeError, IndexError) as exc:
            raise ErreurAtelier("EXECUTION", f"réponse illisible : {proc.stdout[-200:]}") from exc
        if "erreur" in reponse:
            raise ErreurAtelier(reponse["erreur"], reponse.get("message", ""))
        return reponse["sorties"]

    # ------------------------------------------------------------------ 4. validation et enregistrement
    @staticmethod
    def valider_sortie(nom: str, valeur) -> float | int | bool | list:
        if isinstance(valeur, bool):
            return valeur
        if isinstance(valeur, (int, float)):
            if isinstance(valeur, float) and not math.isfinite(valeur):
                raise ErreurAtelier("RESULTAT_NON_FINI", f"{nom} n'est pas un nombre fini")
            return valeur
        if isinstance(valeur, list):
            if len(valeur) > TAILLE_LISTE_MAX or not all(
                isinstance(x, (int, float)) and math.isfinite(x) for x in valeur
            ):
                raise ErreurAtelier("RESULTAT_INVALIDE", f"{nom} : liste trop longue ou non numérique")
            return valeur
        raise ErreurAtelier(
            "RESULTAT_INVALIDE",
            f"{nom} : un résultat doit être un nombre, un booléen ou une liste de nombres (reçu {type(valeur).__name__})",
        )

    def completer_entrees(self, session_id: str, demande: DemandeCalcul) -> list[str]:
        """Les noms lus par le code sans être déclarés : s'ils sont des faits ou des résultats de la session, ils deviennent des
        entrées (origine fait ou calcul, donc traçables) ; sinon l'analyse statique les refusera comme avant."""
        try:
            arbre = ast.parse(demande.code, mode="exec")
        except SyntaxError:
            return []
        declares = {e.nom for e in demande.entrees} | set(demande.sorties)
        assignes = {
            c.id for n in ast.walk(arbre) if isinstance(n, ast.Assign) for c in n.targets if isinstance(c, ast.Name)
        }
        lus = [
            n.id
            for n in ast.walk(arbre)
            if isinstance(n, ast.Name) and isinstance(n.ctx, ast.Load) and n.id not in declares and n.id not in assignes
        ]
        ajoutes: list[str] = []
        for nom in dict.fromkeys(lus):
            if nom in FONCTIONS_AUTORISEES or nom in MODULES_AUTORISES or nom in NOMS_INTERDITS:
                continue
            if self.valeur_fait(session_id, nom) is not None:
                demande.entrees.append(Entree(nom=nom, origine=Origine(type="fait", nom=nom)))
            elif self._derniere_valeur("agent_calculs", "nom_resultat", session_id, nom) is not None:
                demande.entrees.append(Entree(nom=nom, origine=Origine(type="calcul", nom=nom)))
            else:
                continue
            ajoutes.append(nom)
        return ajoutes

    def calculer(self, session_id: str, demande: DemandeCalcul) -> list[ResultatCalcul]:
        debut = time.time()
        self.completer_entrees(session_id, demande)
        noms = {e.nom for e in demande.entrees}
        if len(noms) != len(demande.entrees):
            raise ErreurAtelier("ENTREE_INVALIDE", "deux entrées portent le même nom")
        self.analyser(demande.code, noms, demande.sorties)
        valeurs: dict[str, float | int] = {}
        entrees_json: list[dict] = []
        hypotheses: list[dict] = []
        for e in demande.entrees:
            valeur, reference = self.resoudre(session_id, e)
            valeurs[e.nom] = valeur
            entrees_json.append(
                {
                    "nom": e.nom,
                    "origine": e.origine.model_dump(exclude_none=True),
                    "valeur": valeur,
                    "reference": reference,
                }
            )
            if e.origine.type == "constante":
                hypotheses.append({"nom": e.nom, "valeur": valeur, "justification": e.origine.justification})
        sorties = self.executer(demande.code, valeurs, demande.sorties)
        duree_ms = int((time.time() - debut) * 1000)
        horodatage = dt.datetime.now().isoformat(timespec="seconds")
        resultats = []
        lignes = []
        for nom in demande.sorties:
            valeur = self.valider_sortie(nom, sorties[nom])
            calcul_id = f"C{uuid.uuid4().hex[:10]}"
            scalaire = None if isinstance(valeur, list) else float(valeur)
            lignes.append(
                {
                    "calcul_id": calcul_id,
                    "session_id": session_id,
                    "etape": demande.etape,
                    "nom_resultat": nom,
                    "valeur": scalaire,
                    "valeur_json": json.dumps(valeur),
                    "unite": demande.unite.get(nom, "euros") if isinstance(demande.unite, dict) else demande.unite,
                    "code_execute": demande.code,
                    "entrees_json": json.dumps(entrees_json, ensure_ascii=False),
                    "hypotheses_json": json.dumps(hypotheses, ensure_ascii=False),
                    "commentaire": demande.commentaire,
                    "horodatage": horodatage,
                    "duree_ms": duree_ms,
                }
            )
            unite = demande.unite.get(nom, "euros") if isinstance(demande.unite, dict) else demande.unite
            resultats.append(ResultatCalcul(nom_resultat=nom, valeur=valeur, unite=unite, calcul_id=calcul_id))
        self.store_agent.ecrire("agent_calculs", pl.DataFrame(lignes), ajouter=True)
        return resultats

    def archiver(
        self,
        session_id: str,
        etape: str,
        resultats: dict[str, float],
        unite: str,
        code: str,
        entrees: dict[str, Any],
        commentaire: str = "",
    ) -> list[ResultatCalcul]:
        """Archive dans la feuille de calcul des résultats produits par un calcul fermé de la banque (le simulateur de prêt),
        avec ses entrées : ils deviennent citables comme n'importe quel résultat de l'atelier."""
        horodatage = dt.datetime.now().isoformat(timespec="seconds")
        entrees_json = [
            {
                "nom": k,
                "origine": {"type": "constante", "justification": "paramètre du simulateur"},
                "valeur": v,
                "reference": f"simulateur:{k}",
            }
            for k, v in entrees.items()
        ]
        lignes, out = [], []
        for nom, valeur in resultats.items():
            valeur = self.valider_sortie(nom, valeur)
            calcul_id = f"C{uuid.uuid4().hex[:10]}"
            lignes.append(
                {
                    "calcul_id": calcul_id,
                    "session_id": session_id,
                    "etape": etape,
                    "nom_resultat": nom,
                    "valeur": None if isinstance(valeur, list) else float(valeur),
                    "valeur_json": json.dumps(valeur),
                    "unite": unite,
                    "code_execute": code,
                    "entrees_json": json.dumps(entrees_json, ensure_ascii=False),
                    "hypotheses_json": "[]",
                    "commentaire": commentaire,
                    "horodatage": horodatage,
                    "duree_ms": 0,
                }
            )
            out.append(ResultatCalcul(nom_resultat=nom, valeur=valeur, unite=unite, calcul_id=calcul_id))
        self.store_agent.ecrire("agent_calculs", pl.DataFrame(lignes), ajouter=True)
        return out

    def feuille(self, session_id: str) -> list[Calcul]:
        if not self.store_agent.existe("agent_calculs"):
            return []
        rows = self.store_agent.requete(
            "SELECT * FROM agent_calculs WHERE session_id = ? ORDER BY horodatage, rowid", (session_id,)
        ).to_dicts()
        return [
            Calcul(
                calcul_id=r["calcul_id"],
                session_id=r["session_id"],
                etape=r["etape"],
                nom_resultat=r["nom_resultat"],
                valeur=r["valeur"],
                unite=r["unite"],
                code_execute=r["code_execute"],
                entrees=json.loads(r["entrees_json"]),
                hypotheses=json.loads(r["hypotheses_json"]),
                commentaire=r["commentaire"] or "",
                horodatage=dt.datetime.fromisoformat(r["horodatage"]),
                duree_ms=int(r["duree_ms"] or 0),
            )
            for r in rows
        ]
