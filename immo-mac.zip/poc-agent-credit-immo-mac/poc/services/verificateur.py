"""Le vérificateur de synthèse : chaque chiffre du texte doit être justifié par un fait enregistré ou un calcul archivé, à
l'arrondi près ; aucun avis d'octroi ne doit s'y glisser (la recommandation est un champ à part).

Règles de détection : on relève les nombres du texte ; les années (1900-2100 sans unité), les dates et les petits
nombres sans unité (durées, âges, comptages : « 25 ans », « 14 mois », « 3 fiches ») ne sont pas des chiffres à sourcer ;
tout montant en euros, tout pourcentage et tout nombre d'au moins 100 le sont. Un nombre de cinq chiffres sans unité suivi d'un
nom de ville (« 44000 Nantes ») est un code postal, pas un montant.

Un chiffre est **sourcé** s'il est cité explicitement (liste `chiffres`) ou s'il est **égal à la valeur d'un fait, d'un
calcul ou d'une règle de la session** (citation implicite, à l'arrondi près) : ce qui compte est qu'il remonte à une source
enregistrée, pas l'effort de secrétariat. Une citation explicite fausse reste refusée.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field

AVIS_INTERDITS = (
    "avis favorable",
    "avis défavorable",
    "avis defavorable",
    "je recommande",
    "nous recommandons",
    "recommandation :",
    "accorder le prêt",
    "accorder le pret",
    "refuser le prêt",
    "refuser le pret",
    "octroi recommandé",
    "le prêt peut être accordé",
    "le prêt doit être refusé",
)
MOTIF_NOMBRE = re.compile(r"(?<![\w/])(\d{1,3}(?:[  \xa0]\d{3})+|\d+)(?:[,.](\d+))?\s*(€|%|euros?)?", re.IGNORECASE)
MOTIF_DATE = re.compile(r"\b\d{1,2}/\d{1,2}/\d{2,4}\b|\b\d{4}-\d{2}(?:-\d{2})?\b")
MOTIF_CODE_POSTAL = re.compile(r"\b\d{5}\s+(?=[A-ZÀ-Ý][\wÀ-ÿ'-]+)")


@dataclass
class Chiffre:
    brut: str
    valeur: float
    unite: str
    decimales: int


@dataclass
class ResultatVerification:
    verdict: str  # ACCEPTE | REFUSE
    nb_chiffres: int
    nb_cites: int
    orphelins: list[str] = field(default_factory=list)
    citations_fausses: list[str] = field(default_factory=list)
    avis_detectes: list[str] = field(default_factory=list)
    message: str = ""

    def as_dict(self) -> dict:
        return self.__dict__.copy()


def nombre_de(texte: str) -> tuple[float, int] | None:
    """« 1 571,42 € » → (1571.42, 2) ; « 33,5 % » → (33.5, 1) ; None si rien."""
    m = MOTIF_NOMBRE.search(texte or "")
    if not m:
        return None
    entier = re.sub(r"[  \xa0]", "", m.group(1))
    dec = m.group(2) or ""
    return float(f"{entier}.{dec}" if dec else entier), len(dec)


def chiffres_du_texte(texte: str) -> list[Chiffre]:
    sans_dates = MOTIF_CODE_POSTAL.sub(" ", MOTIF_DATE.sub(" ", texte))
    out: list[Chiffre] = []
    for m in MOTIF_NOMBRE.finditer(sans_dates):
        brut = m.group(0).strip()
        entier = re.sub(r"[  \xa0]", "", m.group(1))
        dec = m.group(2) or ""
        valeur = float(f"{entier}.{dec}" if dec else entier)
        unite = (m.group(3) or "").lower()
        unite = "€" if unite.startswith("euro") else unite
        if not unite and 1900 <= valeur <= 2100 and not dec:
            continue  # une année
        if not unite and valeur < 100:
            continue  # durée, âge, comptage
        out.append(Chiffre(brut, valeur, unite, len(dec)))
    return out


def valeurs_compatibles(citee: float, decimales: int, reference: float) -> bool:
    tolerance = max(0.6 * 10 ** (-decimales), abs(reference) * 0.005)
    if abs(citee - reference) <= tolerance:
        return True
    # un ratio cité en pourcentage (0.335 → 33,5 %) ou l'inverse
    return abs(citee - reference * 100) <= tolerance or abs(citee * 100 - reference) <= tolerance


def verifier_synthese(
    texte: str,
    chiffres_cites: list[dict],
    faits: dict[str, float],
    calculs: dict[str, float],
    regles: dict[str, float] | None = None,
    doutes: dict[str, str] | None = None,
) -> ResultatVerification:
    """`chiffres_cites` : [{"texte": "1 571,42 €", "type": "calcul", "nom": "mensualite_25"}, …]."""
    detectes = chiffres_du_texte(texte)
    avis = [a for a in AVIS_INTERDITS if a in texte.lower()]
    citations_fausses: list[str] = []
    valeurs_citees: dict[float, str] = {}
    for c in chiffres_cites:
        n = nombre_de(str(c.get("texte", "")))
        if n is None:
            citations_fausses.append(f"« {c.get('texte')} » : aucun nombre lisible")
            continue
        valeur, dec = n
        nom = str(c.get("nom", ""))
        t = c.get("type")
        if t == "doute":
            # un chiffre constaté dans un doute enregistré (un écart, une différence) se cite par ce doute
            texte_doute = (doutes or {}).get(nom) or next(
                (v for k, v in (doutes or {}).items() if nom and nom.lower() in k.lower()), None
            )
            if texte_doute is None:
                citations_fausses.append(f"« {c.get('texte')} » : doute « {nom} » inconnu")
                continue
            nombres = [d.valeur for d in _petits_nombres(texte_doute)]
            ecarts = [
                abs(x - y) for i, x in enumerate(nombres) for y in nombres[i + 1 :]
            ]  # un écart constaté = une différence
            if not any(valeurs_compatibles(valeur, dec, v) for v in nombres + ecarts):
                citations_fausses.append(f"« {c.get('texte')} » n'apparaît pas dans le doute « {nom} »")
                continue
            valeurs_citees[round(valeur, 6)] = f"doute:{nom}"
            continue
        source = {"fait": faits, "calcul": calculs, "regle": regles or {}}.get(t or "", {})
        if nom not in source or source[nom] is None:
            citations_fausses.append(f"« {c.get('texte')} » : {t} « {nom} » inconnu")
            continue
        if not valeurs_compatibles(valeur, dec, float(source[nom])):
            citations_fausses.append(f"« {c.get('texte')} » ≠ {t} « {nom} » = {source[nom]}")
            continue
        valeurs_citees[round(valeur, 6)] = nom
    references = [float(v) for src in (faits, calculs, regles or {}) for v in src.values() if v is not None]
    orphelins = []
    implicites = 0
    for d in detectes:
        if round(d.valeur, 6) in valeurs_citees:
            continue
        if any(valeurs_compatibles(d.valeur, d.decimales, r) for r in references):
            implicites += 1  # la valeur existe telle quelle dans la session : sourcée, sans citation explicite
            continue
        orphelins.append(d.brut)
    verdict = "ACCEPTE" if not orphelins and not citations_fausses and not avis else "REFUSE"
    parties = []
    if orphelins:
        parties.append(f"chiffres sans source : {orphelins[:8]}")
    if citations_fausses:
        parties.append(f"citations fausses : {citations_fausses[:5]}")
    if avis:
        parties.append(f"avis d'octroi interdit dans la synthèse : {avis}")
    return ResultatVerification(
        verdict=verdict,
        nb_chiffres=len(detectes),
        nb_cites=len(detectes) - len(orphelins),
        orphelins=orphelins,
        citations_fausses=citations_fausses,
        avis_detectes=avis,
        message=" ; ".join(parties)
        if parties
        else f"{len(detectes)} chiffre(s), tous sourcés" + (f" ({implicites} par leur valeur)" if implicites else ""),
    )


def _petits_nombres(texte: str) -> list[Chiffre]:
    """Les nombres d'un texte sans filtre de taille (pour retrouver « 500 € » ou « 14 mois » dans un doute)."""
    out = []
    for m in MOTIF_NOMBRE.finditer(MOTIF_DATE.sub(" ", texte)):
        entier = re.sub(r"[ \u202f\xa0]", "", m.group(1))
        dec = m.group(2) or ""
        valeur = float(f"{entier}.{dec}" if dec else entier)
        out.append(Chiffre(m.group(0).strip(), valeur, (m.group(3) or "").lower(), len(dec)))
    return out
