"""L'espace de travail du conseiller : ce que l'agent dépose au fil de la session et que le conseiller relira.

Faits (chaque chiffre extrait, avec sa source vérifiée), doutes (hypothèses et question), messages au client (pièces
demandées), verdicts de conformité, synthèse (passée au vérificateur), recommandation (contrôlée), remise du dossier.
Les garde-fous des règles 1, 2 et 4 du cadrage vivent ici, dans le programme :

- `noter_fait` refuse une source qu'il ne retrouve pas (extrait absent de la pièce, mouvement inexistant…), une valeur
  absente de l'extrait cité, et une valeur qui contredit un fait déjà enregistré sans qu'un doute ait été posé ;
- `enregistrer_synthese` refuse un chiffre sans source et tout avis d'octroi glissé dans le texte ;
- `enregistrer_recommandation` refuse un motif sans référence, et une position tranchée (favorable / défavorable) tant
  qu'un verdict « cas non couvert » ou un doute bloquant subsiste.

Tables écrites : agent_faits, agent_doutes, agent_messages_client, agent_verdicts, agent_syntheses, agent_recommandations.
"""

from __future__ import annotations

import datetime as dt
import json
import uuid
from typing import Any

import polars as pl

from poc.config import Config
from poc.donnees import SQLiteStore
from poc.services.banque import ServiceBanque
from poc.services.coffre import ServiceCoffre, _normaliser
from poc.services.erreurs import ErreurService, Introuvable
from poc.services.ocr import SEUIL_LIGNE, ServiceOCR
from poc.services.sessions import ServiceSessions, SessionIntrouvable
from poc.services.verificateur import nombre_de, valeurs_compatibles, verifier_synthese

POSITIONS = ("FAVORABLE", "FAVORABLE_SOUS_RESERVES", "DEFAVORABLE", "NE_SE_PRONONCE_PAS")
VERDICTS = ("DANS_LA_NORME", "HORS_NORME", "CAS_NON_COUVERT")
TYPES_SOURCE = ("piece", "mouvement", "demande", "client", "credit_declare", "epargne", "calcul")


def _now() -> str:
    return dt.datetime.now().isoformat(timespec="seconds")


def _id(prefixe: str) -> str:
    return f"{prefixe}{uuid.uuid4().hex[:10]}"


class ServiceConseiller:
    def __init__(self, config: Config, store_agent: SQLiteStore | None = None) -> None:
        self.config = config
        self.store = store_agent or SQLiteStore(config.sqlite_agent)
        self.sessions = ServiceSessions(self.store)
        self.coffre = ServiceCoffre(config)
        self.banque = ServiceBanque(config)
        self.ocr = ServiceOCR(config, self.coffre)

    def _session(self, session_id: str):
        try:
            return self.sessions.session(session_id)
        except SessionIntrouvable as exc:
            raise Introuvable(str(exc)) from exc

    def _lignes(self, table: str, session_id: str) -> list[dict]:
        if not self.store.existe(table):
            return []
        return self.store.requete(
            f'SELECT * FROM "{table}" WHERE session_id = ? ORDER BY rowid', (session_id,)
        ).to_dicts()

    # ------------------------------------------------------------------ faits
    def _verifier_source(self, demande_id: str, valeur: float, source: dict) -> str:
        t = source.get("type")
        if t not in TYPES_SOURCE:
            raise ErreurService("SOURCE_INVALIDE", f"type de source inconnu : {t} ; attendus : {TYPES_SOURCE}")
        if t == "piece":
            piece, extrait = source.get("piece"), source.get("extrait")
            if not piece or not extrait:
                raise ErreurService(
                    "SOURCE_INCOMPLETE",
                    "une source de type piece demande `piece` (P03 ou fichier) et `extrait` (le texte copié de la pièce)",
                )
            lignes = self.ocr.lignes_connues(demande_id, piece)
            cherche = _normaliser(extrait)
            contenant = [x for x in lignes if cherche in _normaliser(x["texte"])]
            if not contenant and cherche not in _normaliser("\n".join(x["texte"] for x in lignes)):
                raise ErreurService(
                    "SOURCE_INTROUVABLE",
                    f"l'extrait « {extrait[:80]} » ne figure pas dans la pièce {piece} "
                    "(copier le texte tel quel, depuis lire_piece ou ocr_piece)",
                )
            confiance = max((x["confiance"] for x in contenant), default=min(x["confiance"] for x in lignes))
            if confiance < SEUIL_LIGNE:
                raise ErreurService(
                    "LECTURE_INCERTAINE",
                    f"l'extrait « {extrait[:80]} » vient d'une ligne lue par OCR avec une confiance de {confiance:.2f} "
                    f"(seuil {SEUIL_LIGNE:.2f}) : ce chiffre n'est pas sûr. Recoupe-le avec une autre source (une autre ligne "
                    "plus sûre, une autre pièce, un mouvement du relevé) ou demande une copie lisible au client",
                )
            if not _valeur_dans(extrait, valeur):
                raise ErreurService(
                    "VALEUR_HORS_EXTRAIT", f"la valeur {valeur} n'apparaît pas dans l'extrait cité « {extrait[:80]} »"
                )
            return f"piece:{self.coffre.piece(demande_id, piece)['piece_id']}"
        if t == "mouvement":
            compte_id, date, montant = source.get("compte_id"), source.get("date"), source.get("montant")
            if not compte_id or not date or montant is None:
                raise ErreurService(
                    "SOURCE_INCOMPLETE", "une source de type mouvement demande compte_id, date et montant"
                )
            m = self.banque.mouvements(compte_id, du=date, au=date)
            if not any(abs(abs(x["montant"]) - abs(float(montant))) < 0.01 for x in m["mouvements"]):
                raise ErreurService("SOURCE_INTROUVABLE", f"aucun mouvement de {montant} le {date} sur {compte_id}")
            if abs(abs(float(montant)) - abs(valeur)) > 0.01:
                raise ErreurService(
                    "VALEUR_HORS_EXTRAIT", f"la valeur {valeur} ne correspond pas au mouvement de {montant}"
                )
            return f"mouvement:{compte_id}:{date}"
        if t == "demande":
            champ = source.get("champ")
            d = self.banque.demande(demande_id)
            if champ not in d:
                raise ErreurService(
                    "SOURCE_INTROUVABLE",
                    f"la demande n'a pas de champ « {champ} » ; champs : {sorted(k for k in d if not isinstance(d[k], list))}",
                )
            if not _egal(d[champ], valeur):
                raise ErreurService("VALEUR_HORS_EXTRAIT", f"la demande dit {champ} = {d[champ]}, pas {valeur}")
            return f"demande:{champ}"
        if t == "client":
            client_id, champ = source.get("client_id"), source.get("champ")
            c = self.banque.client(client_id or "")
            if champ not in c or not _egal(c[champ], valeur):
                raise ErreurService("SOURCE_INTROUVABLE", f"le client {client_id} n'a pas {champ} = {valeur}")
            return f"client:{client_id}:{champ}"
        if t == "credit_declare":
            organisme = (source.get("organisme") or "").lower()
            for c in self.banque.demande(demande_id)["credits_declares_par_le_client"]:
                if organisme and organisme in c["organisme"].lower() and _egal(c["mensualite_declaree"], valeur):
                    return f"credit_declare:{c['organisme']}"
            raise ErreurService(
                "SOURCE_INTROUVABLE",
                f"aucun crédit déclaré « {source.get('organisme')} » avec une mensualité de {valeur}",
            )
        if t == "epargne":
            epargne_id = source.get("epargne_id")
            for client in self.banque.demande(demande_id)["emprunteurs"]:
                for e in self.banque.epargne(client["client_id"]):
                    if e["epargne_id"] == epargne_id and _egal(e["solde"], valeur):
                        return f"epargne:{epargne_id}"
            raise ErreurService("SOURCE_INTROUVABLE", f"aucune épargne {epargne_id} de solde {valeur}")
        nom = source.get("nom_resultat") or source.get("nom")
        v = (
            self.sessions.atelier.valeur_resultat(source.get("session_id", ""), nom or "")
            if source.get("session_id")
            else None
        )
        if v is None:
            raise ErreurService("SOURCE_INTROUVABLE", f"aucun résultat de calcul « {nom} » dans la session")
        if not _egal(v, valeur):
            raise ErreurService("VALEUR_HORS_EXTRAIT", f"le calcul « {nom} » vaut {v}, pas {valeur}")
        return f"calcul:{nom}"

    def noter_fait(
        self, session_id: str, nom: str, valeur: float, unite: str, source: dict, commentaire: str = ""
    ) -> dict:
        s = self._session(session_id)
        if not nom.isidentifier():
            raise ErreurService(
                "NOM_INVALIDE", f"le nom d'un fait est un identifiant (lettres, chiffres, soulignés) : {nom!r}"
            )
        source = {**source, "session_id": session_id}
        reference = self._verifier_source(s.demande_id, float(valeur), source)
        existants = [f for f in self._lignes("agent_faits", session_id) if f["nom"] == nom]
        for f in existants:
            if f["valeur"] is not None and abs(float(f["valeur"]) - float(valeur)) > max(
                1.0, abs(float(valeur)) * 0.01
            ):
                doutes = self._lignes("agent_doutes", session_id)
                if not any(nom in (d.get("faits_concernes") or "") for d in doutes):
                    raise ErreurService(
                        "ECART_SANS_DOUTE",
                        f"le fait « {nom} » vaut déjà {f['valeur']} (source {f['reference']}) ; une autre valeur ({valeur}) ne peut être "
                        "retenue sans un doute enregistré avec noter_doute (faits_concernes) qui explique l'écart",
                    )
        fait = {
            "fait_id": _id("F"),
            "session_id": session_id,
            "nom": nom,
            "valeur": float(valeur),
            "unite": unite,
            "reference": reference,
            "source_json": json.dumps({k: v for k, v in source.items() if k != "session_id"}, ensure_ascii=False),
            "commentaire": commentaire,
            "horodatage": _now(),
        }
        self.store.ecrire("agent_faits", pl.DataFrame([fait], schema_overrides={"valeur": pl.Float64}), ajouter=True)
        return {k: v for k, v in fait.items() if k != "source_json"} | {"source": source}

    def faits(self, session_id: str) -> list[dict]:
        self._session(session_id)
        return [
            {**{k: v for k, v in f.items() if k != "source_json"}, "source": json.loads(f["source_json"])}
            for f in self._lignes("agent_faits", session_id)
        ]

    # ------------------------------------------------------------------ doutes
    def noter_doute(
        self,
        session_id: str,
        etape: str,
        objet: str,
        hypotheses: list[str],
        question: str,
        pieces_concernees: list[str],
        faits_concernes: list[str],
        bloquant: bool,
    ) -> dict:
        self._session(session_id)
        if not objet.strip() or not [h for h in hypotheses if h.strip()]:
            raise ErreurService("DOUTE_INCOMPLET", "un doute a un objet et au moins une hypothèse")
        if not (question or "").strip():
            question = f"À confirmer par le conseiller : {objet.strip()}"  # un doute sans question reste un doute
        doute = {
            "doute_id": _id("D"),
            "session_id": session_id,
            "etape": etape,
            "objet": objet.strip(),
            "hypotheses": " | ".join(h.strip() for h in hypotheses if h.strip()),
            "question": question.strip(),
            "pieces_concernees": ",".join(pieces_concernees),
            "faits_concernes": ",".join(faits_concernes),
            "bloquant": int(bloquant),
            "statut": "OUVERT",
            "horodatage": _now(),
        }
        self.store.ecrire("agent_doutes", pl.DataFrame([doute]), ajouter=True)
        return doute

    def doutes(self, session_id: str) -> list[dict]:
        self._session(session_id)
        return [{**d, "bloquant": bool(d["bloquant"])} for d in self._lignes("agent_doutes", session_id)]

    # ------------------------------------------------------------------ messages au client
    def demander_piece(self, session_id: str, piece: str, personne: str, periode: str | None, motif: str) -> dict:
        self._session(session_id)
        if not piece.strip() or not personne.strip():
            raise ErreurService("MESSAGE_INCOMPLET", "préciser la pièce demandée et la personne")
        texte = (
            f"Bonjour {personne}, pour poursuivre l'instruction de votre demande de prêt, pourriez-vous nous transmettre : "
            f"{piece}{f' ({periode})' if periode else ''} ? {motif.strip()} Merci, votre conseiller."
        )
        message = {
            "message_id": _id("M"),
            "session_id": session_id,
            "destinataire": personne,
            "piece": piece,
            "periode": periode,
            "texte": texte,
            "statut": "ENVOYE",
            "horodatage": _now(),
        }
        self.store.ecrire("agent_messages_client", pl.DataFrame([message]), ajouter=True)
        return {
            **message,
            "note": "message déposé dans la boîte aux lettres simulée ; l'analyse se poursuit sans attendre la réponse",
        }

    def messages(self, session_id: str) -> list[dict]:
        self._session(session_id)
        return self._lignes("agent_messages_client", session_id)

    # ------------------------------------------------------------------ verdicts
    REGLES_PAR_SITUATION = {
        "SEUIL_CDI": ("cdi", "un salarié en CDI"),
        "SEUIL_INDEPENDANT": ("auto_entrepreneur", "un indépendant"),
        "SEUIL_PENSION": ("retraite", "un retraité"),
    }

    def _verifier_objet_de_la_regle(self, session_id: str, regle: str) -> None:
        """`SEUIL_INDEPENDANT` sans indépendant au dossier (et de même pour le CDI et la pension) : la règle est sans objet."""
        if regle not in self.REGLES_PAR_SITUATION:
            return
        situation, libelle = self.REGLES_PAR_SITUATION[regle]
        try:
            demande = self.banque.demande(self._session(session_id).demande_id)
        except Exception:  # noqa: BLE001 — sans demande lisible, on ne bloque pas
            return
        if not any(e.get("situation_pro") == situation for e in demande.get("emprunteurs", [])):
            raise ErreurService(
                "REGLE_SANS_OBJET",
                f"{regle} ne s'applique qu'à {libelle} ; aucun emprunteur de ce dossier n'est dans cette situation : "
                "ne remplis pas cette ligne de la grille",
            )

    def enregistrer_verdict(
        self,
        session_id: str,
        regle: str,
        verdict: str,
        valeur: str | None,
        seuil: str | None,
        justification: str,
        references: list[str],
    ) -> dict:
        self._session(session_id)
        if verdict not in VERDICTS:
            raise ErreurService("VERDICT_INVALIDE", f"verdict attendu parmi {VERDICTS}")
        if not justification.strip():
            raise ErreurService("VERDICT_INCOMPLET", "une justification est requise")
        self._verifier_objet_de_la_regle(session_id, regle.strip().upper())
        ligne = {
            "verdict_id": _id("V"),
            "session_id": session_id,
            "regle": regle.strip().upper(),
            "verdict": verdict,
            "valeur": valeur,
            "seuil": seuil,
            "justification": justification.strip(),
            "references": ",".join(references),
            "horodatage": _now(),
        }
        existants = self._lignes("agent_verdicts", session_id)
        if any(v["regle"] == ligne["regle"] for v in existants):
            self.store.executer(
                "DELETE FROM agent_verdicts WHERE session_id = ? AND regle = ?", (session_id, ligne["regle"])
            )
        self.store.ecrire("agent_verdicts", pl.DataFrame([ligne]), ajouter=True)
        return ligne

    def verdicts(self, session_id: str) -> list[dict]:
        self._session(session_id)
        return self._lignes("agent_verdicts", session_id)

    # ------------------------------------------------------------------ synthèse et recommandation
    def _valeurs(self, session_id: str) -> tuple[dict[str, float], dict[str, float]]:
        faits = {
            f["nom"]: float(f["valeur"]) for f in self._lignes("agent_faits", session_id) if f["valeur"] is not None
        }
        calculs = {c.nom_resultat: c.valeur for c in self.sessions.atelier.feuille(session_id) if c.valeur is not None}
        return faits, calculs

    def enregistrer_synthese(self, session_id: str, texte: str, chiffres: list[dict]) -> dict:
        self._session(session_id)
        if len(texte.strip()) < 200:
            raise ErreurService("SYNTHESE_TROP_COURTE", "une synthèse fait au moins quelques paragraphes")
        faits, calculs = self._valeurs(session_id)
        from poc.generateur.referentiels import constantes_des_regles

        lignes_doutes = self._lignes("agent_doutes", session_id)
        doutes = {d["doute_id"]: f"{d['objet']} {d['hypotheses']} {d['question']}" for d in lignes_doutes}
        doutes.update({d["objet"]: f"{d['objet']} {d['hypotheses']} {d['question']}" for d in lignes_doutes})
        verif = verifier_synthese(texte, chiffres, faits, calculs, constantes_des_regles(), doutes)
        ligne = {
            "synthese_id": _id("S"),
            "session_id": session_id,
            "texte": texte,
            "chiffres_json": json.dumps(chiffres, ensure_ascii=False),
            "verification_json": json.dumps(verif.as_dict(), ensure_ascii=False),
            "statut": "VERIFIEE" if verif.verdict == "ACCEPTE" else "REFUSEE",
            "horodatage": _now(),
        }
        self.store.ecrire("agent_syntheses", pl.DataFrame([ligne]), ajouter=True)
        if verif.verdict != "ACCEPTE":
            code = (
                "AVIS_INTERDIT"
                if verif.avis_detectes
                else ("CITATION_FAUSSE" if verif.citations_fausses else "CHIFFRE_ORPHELIN")
            )
            consigne = (
                " → Pour chaque chiffre listé : soit tu le retires du texte, soit tu l'enregistres d'abord (calculer pour un résultat, "
                "noter_fait pour une donnée) et tu le cites sous son nom exact ; un seuil de règle se cite avec le type regle, un écart "
                "constaté avec le type doute. Ne redépose pas le même texte."
            )
            citables = [f"fait {k}={v:g}" for k, v in faits.items()] + [f"calcul {k}={v:g}" for k, v in calculs.items()]
            consigne += " Chiffres citables dans cette session : " + " ; ".join(citables[:60]) + "."
            raise ErreurService(code, verif.message + consigne)
        return {"synthese_id": ligne["synthese_id"], "statut": "VERIFIEE", "verification": verif.as_dict()}

    def syntheses(self, session_id: str) -> list[dict]:
        self._session(session_id)
        return [
            {**s, "chiffres": json.loads(s["chiffres_json"]), "verification": json.loads(s["verification_json"])}
            for s in self._lignes("agent_syntheses", session_id)
        ]

    def enregistrer_recommandation(
        self, session_id: str, position: str, motifs: list[dict], reserves: list[dict], conditions: list[str]
    ) -> dict:
        self._session(session_id)
        if position not in POSITIONS:
            raise ErreurService("POSITION_INVALIDE", f"position attendue parmi {POSITIONS}")
        if not motifs:
            raise ErreurService(
                "MOTIF_SANS_SOURCE",
                "une recommandation a au moins un motif, chacun lié à un fait, un calcul ou un verdict",
            )
        faits, calculs = self._valeurs(session_id)
        verdicts = {v["regle"]: v for v in self._lignes("agent_verdicts", session_id)}
        for m in motifs:
            if "score" in str(m.get("nom", "")).lower() or "score" in str(m.get("texte", "")).lower():
                raise ErreurService(
                    "SCORE_NON_DECISIONNEL",
                    f"le motif « {m.get('texte', '')[:60]} » s'appuie sur le score de la banque : le score est un indicateur "
                    "consultatif, il se restitue dans la synthèse avec ses limites mais ne motive pas une recommandation ; "
                    "motive par les faits, les calculs et les verdicts de la grille",
                )
            t, nom = m.get("type"), str(m.get("nom", "")).strip()
            connu = (
                (t == "fait" and nom in faits)
                or (t == "calcul" and nom in calculs)
                or (t == "verdict" and nom.upper() in verdicts)
            )
            if not connu:
                raise ErreurService(
                    "MOTIF_SANS_SOURCE",
                    f"le motif « {m.get('texte', '')[:60]} » renvoie à {t} « {nom} » qui n'existe pas dans la session",
                )
        non_couverts = [r for r, v in verdicts.items() if v["verdict"] == "CAS_NON_COUVERT"]
        bloquants = [
            d["objet"] for d in self._lignes("agent_doutes", session_id) if d["bloquant"] and d["statut"] == "OUVERT"
        ]
        if position in ("FAVORABLE", "DEFAVORABLE") and (non_couverts or bloquants):
            raise ErreurService(
                "TRANCHE_MALGRE_RESERVE",
                f"impossible de trancher {position} : cas non couverts {non_couverts}, doutes bloquants {bloquants} ; "
                "choisir FAVORABLE_SOUS_RESERVES (avec ces réserves) ou NE_SE_PRONONCE_PAS",
            )
        if position == "FAVORABLE_SOUS_RESERVES" and not reserves:
            raise ErreurService(
                "RESERVES_MANQUANTES", "une position sous réserves exige au moins une réserve (code et texte)"
            )
        ligne = {
            "recommandation_id": _id("R"),
            "session_id": session_id,
            "position": position,
            "motifs_json": json.dumps(motifs, ensure_ascii=False),
            "reserves": ",".join(str(r.get("code", "")).upper() for r in reserves),
            "reserves_json": json.dumps(reserves, ensure_ascii=False),
            "conditions_json": json.dumps(conditions, ensure_ascii=False),
            "horodatage": _now(),
        }
        self.store.remplacer("agent_recommandations", pl.DataFrame([ligne]), "session_id", session_id)
        return {
            "recommandation_id": ligne["recommandation_id"],
            "position": position,
            "reserves": [r.get("code") for r in reserves],
            "note": "La décision appartient au conseiller.",
        }

    def recommandation(self, session_id: str) -> dict | None:
        self._session(session_id)
        rows = self._lignes("agent_recommandations", session_id)
        if not rows:
            return None
        r = rows[-1]
        return {
            "position": r["position"],
            "motifs": json.loads(r["motifs_json"]),
            "reserves": json.loads(r["reserves_json"]),
            "conditions": json.loads(r["conditions_json"]),
            "horodatage": r["horodatage"],
        }

    # ------------------------------------------------------------------ dossier de travail, remise
    def dossier_travail(self, session_id: str) -> dict:
        s = self._session(session_id)
        syntheses = self.syntheses(session_id)
        return {
            "session": s.model_dump(mode="json"),
            "faits": self.faits(session_id),
            "calculs": [c.model_dump(mode="json") for c in self.sessions.atelier.feuille(session_id)],
            "doutes": self.doutes(session_id),
            "messages_client": self.messages(session_id),
            "verdicts": self.verdicts(session_id),
            "synthese": next((x["texte"] for x in reversed(syntheses) if x["statut"] == "VERIFIEE"), None),
            "recommandation": self.recommandation(session_id),
        }

    def remettre(self, session_id: str) -> dict:
        s = self._session(session_id)
        dossier = self.dossier_travail(session_id)
        self.sessions.mettre_a_jour(session_id, statut="REMISE")
        return {
            "session_id": session_id,
            "demande_id": s.demande_id,
            "statut": "REMISE",
            "synthese_presente": dossier["synthese"] is not None,
            "recommandation": (dossier["recommandation"] or {}).get("position"),
            "nb_doutes": len(dossier["doutes"]),
            "nb_messages_client": len(dossier["messages_client"]),
            "note": "Le dossier attend la décision du conseiller.",
        }

    def archiver_calcul_externe(
        self,
        session_id: str,
        etape: str,
        resultats: dict[str, float],
        unite: str,
        code: str,
        entrees: dict[str, Any],
        commentaire: str,
    ) -> list[dict]:
        self._session(session_id)
        return [
            r.model_dump(mode="json")
            for r in self.sessions.atelier.archiver(session_id, etape, resultats, unite, code, entrees, commentaire)
        ]


def _valeur_dans(extrait: str, valeur: float) -> bool:
    import re

    for m in re.finditer(r"\d{1,3}(?:[  \xa0]\d{3})+(?:[,.]\d+)?|\d+(?:[,.]\d+)?", extrait):
        n = nombre_de(m.group(0))
        if n and valeurs_compatibles(n[0], n[1], valeur):
            return True
    return False


def _egal(a: Any, b: float) -> bool:
    try:
        return abs(float(a) - float(b)) <= max(0.01, abs(float(b)) * 0.001)
    except (TypeError, ValueError):
        return False
