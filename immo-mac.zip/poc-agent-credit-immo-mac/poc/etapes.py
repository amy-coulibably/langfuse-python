"""Le parcours de l'agent, lu dans `config/etapes.yaml` : la liste ordonnée des étapes, avec pour chacune sa question, ses
fiches de méthode, ses outils et ce qu'elle doit produire. C'est la seule source de vérité du workflow : le graphe, la
configuration des modèles (rôles) et le registre d'outils s'y réfèrent."""

from __future__ import annotations

import os
from functools import lru_cache
from pathlib import Path
from typing import Literal

import yaml
from pydantic import BaseModel, Field, model_validator

from poc.config import CONFIG_DIR

CHEMIN_DEFAUT = CONFIG_DIR / "etapes.yaml"


class Etape(BaseModel):
    nom: str = Field(description="Identifiant court, sans espace (nom du nœud du graphe)")
    titre: str
    question: str = Field(description="La question à laquelle l'étape répond, telle qu'un conseiller la poserait")
    type: Literal["modele", "code"] = "modele"
    fiches: list[str] = Field(
        default_factory=list, description="Fiches de méthode lues à cette étape (fichiers fiches/<nom>.md)"
    )
    outils: list[str] = Field(
        default_factory=list, description="Outils visibles à cette étape (en plus des outils communs)"
    )
    sortie: str = Field(default="", description="Ce que l'étape laisse derrière elle")


class Parcours(BaseModel):
    etapes: list[Etape]
    outils_communs: list[str] = Field(default_factory=list)

    @model_validator(mode="after")
    def _coherence(self) -> Parcours:
        noms = [e.nom for e in self.etapes]
        if len(noms) != len(set(noms)):
            raise ValueError(f"étapes en double dans etapes.yaml : {noms}")
        if not noms:
            raise ValueError("etapes.yaml ne décrit aucune étape")
        for e in self.etapes:
            if not e.nom.isidentifier():
                raise ValueError(f"nom d'étape invalide : {e.nom!r} (lettres, chiffres, soulignés)")
        return self

    @property
    def noms(self) -> list[str]:
        return [e.nom for e in self.etapes]

    def etape(self, nom: str) -> Etape:
        for e in self.etapes:
            if e.nom == nom:
                return e
        raise KeyError(f"étape inconnue : {nom} ; attendues : {self.noms}")

    def outils_de(self, nom: str) -> list[str]:
        """Les outils visibles à une étape : ceux de l'étape, puis les communs, sans doublon."""
        e = self.etape(nom)
        if e.type == "code":
            return []
        vus: list[str] = []
        for o in [*e.outils, *self.outils_communs]:
            if o not in vus:
                vus.append(o)
        return vus


@lru_cache(maxsize=4)
def _charger(chemin: str) -> Parcours:
    p = Path(chemin)
    if not p.exists():
        raise FileNotFoundError(f"Parcours absent : {p}")
    with p.open(encoding="utf-8") as f:
        brut = yaml.safe_load(f) or {}
    return Parcours(**brut)


def charger_parcours(chemin: Path | None = None) -> Parcours:
    chemin = chemin or Path(os.getenv("POC_ETAPES_CONFIG", str(CHEMIN_DEFAUT)))
    return _charger(str(chemin))


def noms_etapes() -> list[str]:
    return charger_parcours().noms


ETAPES: list[str] = noms_etapes()
