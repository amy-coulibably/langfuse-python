"""Les vérifications d'un poste neuf : la configuration (`poc config verifier`) et la plateforme d'observabilité de bout en
bout (`poc obs verifier`). Chaque contrôle dit ce qui manque et où le renseigner, presque toujours dans `.env`.

Retour d'expérience du portage du premier POC sur Mac, intégré ici : une adresse d'exemple laissée dans la configuration ne
se voit qu'au premier appel ; un collecteur injoignable remplit le terminal ; une autorité de certification en chemin relatif
n'est pas lue par l'exportateur ; une évaluation déposée trop tôt ne trouve pas son span. Les contrôles les signalent avant.
"""

from __future__ import annotations

import platform
import sys
from importlib import metadata

from poc.config import RACINE, Config
from poc.sante import Controle

ADRESSES_EXEMPLE = ("interne.banque", "<instance>", "<", "example")


def _version_sdk_arize() -> str | None:
    try:
        return metadata.version("arize")
    except metadata.PackageNotFoundError:
        return None


def verifier_configuration(config: Config) -> list[Controle]:
    """Ce qu'il faut pour lancer l'agent sur un vrai modèle et envoyer ses traces, sans rien appeler sur le réseau."""
    from poc.llm import charger_config_llm
    from poc.observabilite import charger_config_observabilite
    from poc.observabilite.config import autorite_interne
    from poc.services.ocr import description_moteur

    out: list[Controle] = []

    def ajouter(nom: str, ok: bool, detail: str = "") -> None:
        out.append(Controle(nom, ok, detail))

    v = sys.version_info
    ajouter(
        "Python",
        (3, 11) <= (v.major, v.minor) <= (3, 13),
        f"{platform.python_version()} ({sys.executable}) ; attendu : 3.11, 3.12 ou 3.13",
    )
    fichier_env = RACINE / ".env"
    ajouter(
        "fichier .env",
        fichier_env.is_file(),
        str(fichier_env) if fichier_env.is_file() else "absent : `cp .env.example .env`, puis le compléter",
    )

    # ---- le modèle de langage par défaut
    try:
        cfg = charger_config_llm()
        m = cfg.modele_pour(None)
        detail = f"« {m.nom_logique} » : {m.fournisseur}, modèle {m.nom}, {m.url or '—'}"
        problemes: list[str] = []
        if m.fournisseur != "factice":
            if not m.cle_disponible():
                problemes.append(f"clé absente : renseigner {m.cle_api_env} dans .env")
            if any(x in (m.url or "") for x in ADRESSES_EXEMPLE):
                problemes.append("adresse d'exemple : renseigner LLM_URL dans .env")
            if m.nom == "modele-interne" or "<" in m.nom:
                problemes.append("nom d'exemple : renseigner LLM_MODELE dans .env")
            try:
                ca = m.chemin_certificat_ca()
            except ValueError as exc:
                problemes.append(str(exc))
            else:
                if ca:
                    detail += f" ; autorité {ca.name}"
            if not m.prix_connu:
                detail += " ; prix non renseigné (coût calculé par la grille d'Arize)"
        ajouter(
            "modèle par défaut (LLM_MODELE_DEFAUT)",
            not problemes,
            detail + (" — " + " ; ".join(problemes) if problemes else ""),
        )
    except Exception as exc:  # noqa: BLE001
        ajouter("config/llm.yaml", False, f"{type(exc).__name__} : {str(exc)[:240]}")

    # ---- l'observabilité
    obs = charger_config_observabilite()
    ca, variable = autorite_interne()
    if not obs.effective:
        ajouter("observabilité (OBS_*)", True, "inactive : aucune trace ne part (OBS_ENABLED=true pour l'activer)")
    else:
        problemes = []
        detail = f"{obs.backend}, projet « {obs.projet} », {obs.endpoint or '—'}"
        if obs.backend == "arize":
            if not obs.endpoint or any(x in obs.endpoint for x in ADRESSES_EXEMPLE):
                problemes.append("OBS_ENDPOINT à renseigner (https://<instance>/v1/traces)")
            elif not obs.endpoint.rstrip("/").endswith("/v1/traces"):
                problemes.append("OBS_ENDPOINT doit se terminer par /v1/traces")
            if not obs.api_key:
                problemes.append("OBS_API_KEY absente")
            if not obs.space_id:
                problemes.append("OBS_SPACE_ID absent")
            sdk = _version_sdk_arize()
            if sdk is None:
                problemes.append("SDK arize non installé (évaluations) : `pip install -e '.[arize]'`")
            else:
                detail += f" ; SDK arize {sdk}"
        if ca is not None:
            if ca.is_file():
                detail += f" ; autorité {ca.name} ({variable})"
            else:
                problemes.append(f"autorité introuvable : {ca} (indiquée par {variable})")
        detail += " ; contenu des messages " + ("envoyé" if obs.contenu_messages else "masqué")
        ajouter("observabilité (OBS_*)", not problemes, detail + (" — " + " ; ".join(problemes) if problemes else ""))

    # ---- l'OCR (facultatif : sans lui, les pièces numérisées sont redemandées)
    moteur = description_moteur()
    if moteur["disponible"]:
        francais = moteur["langue"] == "fra"
        ajouter(
            "moteur OCR (Tesseract)",
            True,
            f"{moteur['moteur']}, langue {moteur['langue']}"
            + ("" if francais else " — langue française absente : `brew install tesseract-lang`"),
        )
    else:
        ajouter(
            "moteur OCR (Tesseract)",
            True,
            "absent (facultatif) : `brew install tesseract tesseract-lang` ; sans lui, l'agent redemande les pièces scannées",
        )

    # ---- les données
    from poc.generateur import demandes_disponibles

    demandes = demandes_disponibles(config) if config.sqlite_banque.exists() else []
    ajouter(
        "données synthétiques",
        len(demandes) >= 50,
        f"{len(demandes)} demande(s) dans {config.data_dir}"
        + ("" if len(demandes) >= 50 else " : `poc donnees generer`"),
    )
    return out


def verifier_plateforme(
    config: Config, demande: str = "DEM-0001", evaluations: bool = True
) -> tuple[list[Controle], dict]:
    """De bout en bout, avec le modèle factice (aucun appel au modèle de langage) : sonde du collecteur, une session complète
    tracée, puis le dépôt de ses évaluations `eval.*` sur le span racine, en attendant l'ingestion. Renvoie les contrôles et
    de quoi retrouver la trace dans la plateforme."""
    from poc.agent import lancer_agent, trace_de_session
    from poc.evaluation import evaluer_session, publier_evaluation_session
    from poc.llm import config_factice
    from poc.observabilite import charger_config_observabilite, demarrer, reinitialiser
    from poc.observabilite.sonde import collecteur_joignable, sonder_collecteur

    out: list[Controle] = []
    info: dict = {}
    cfg = charger_config_observabilite()
    info["projet"] = cfg.projet
    if not cfg.effective:
        out.append(Controle("observabilité active", False, "OBS_ENABLED=true et OBS_BACKEND=arize dans .env"))
        return out, info
    code, detail = sonder_collecteur(cfg)
    joignable = collecteur_joignable(code)
    out.append(Controle(f"collecteur {cfg.backend} joignable", joignable, f"{cfg.endpoint} — {detail}"))
    if not joignable:
        return out, info
    reinitialiser()
    obs = demarrer(cfg)
    if not obs.actif:
        out.append(Controle("brique d'observabilité démarrée", False, "voir le message ci-dessus"))
        return out, info
    r = lancer_agent(config, demande, config_llm=config_factice(), checkpoints=False)
    obs.vider()
    trace = trace_de_session(config, r.session_id)
    info.update(
        {"session_id": r.session_id, "trace_id": (trace or {}).get("trace_id"), "span_id": (trace or {}).get("span_id")}
    )
    out.append(
        Controle(
            "session factice tracée",
            bool(trace),
            f"session {r.session_id}, trace {(trace or {}).get('trace_id')}" if trace else "aucun lien session → trace",
        )
    )
    if not evaluations or not trace:
        return out, info
    if cfg.backend == "arize" and _version_sdk_arize() is None:
        out.append(
            Controle("évaluations eval.* déposées", False, "SDK arize non installé : `pip install -e '.[arize]'`")
        )
        return out, info
    ev = evaluer_session(config, r.session_id)
    depot = publier_evaluation_session(config, ev)
    n = depot.get("span", 0)
    out.append(
        Controle(
            "évaluations eval.* déposées sur le span racine",
            n > 0,
            f"{n} évaluation(s) acceptée(s)"
            if n
            else f"non déposées : {depot.get('erreur') or 'voir le message ci-dessus'} ; réessayer ensuite avec "
            f"`poc obs evaluations {r.session_id}`",
        )
    )
    return out, info
