"""Les pièces justificatives d'un cas, en PDF (`reportlab`), rangées dans le coffre de la demande avec un inventaire.

Chaque pièce se lit comme une vraie : une fiche de paie avec brut, cotisations, net imposable, prélèvement à la source et
net payé ; un avis d'imposition ; un relevé de compte ligne à ligne avec solde ; un compromis ; un tableau d'amortissement.
Les pièges viennent de la vérité terrain, jamais d'ailleurs : la fiche de juin de Thomas inclut sa prime parce que le cas
le dit ; sa fiche d'août n'est pas générée parce que le cas la déclare manquante.
"""

from __future__ import annotations

import datetime as dt
import json
from pathlib import Path

from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.lib.units import mm
from reportlab.platypus import Paragraph, SimpleDocTemplate, Spacer, Table, TableStyle

from poc.config import Config
from poc.generateur.modeles import Cas, Compte, Credit, Personne

MOIS_FR = [
    "janvier",
    "février",
    "mars",
    "avril",
    "mai",
    "juin",
    "juillet",
    "août",
    "septembre",
    "octobre",
    "novembre",
    "décembre",
]
STYLES = getSampleStyleSheet()
TITRE = ParagraphStyle("titre", parent=STYLES["Title"], fontSize=15, spaceAfter=6)
SOUS_TITRE = ParagraphStyle("sous", parent=STYLES["Heading3"], spaceBefore=8, spaceAfter=4)
NORMAL = ParagraphStyle("normal", parent=STYLES["BodyText"], fontSize=9.5, leading=12)
PETIT = ParagraphStyle("petit", parent=STYLES["BodyText"], fontSize=7.5, leading=9, textColor=colors.grey)
MENTION = "Document simulé, généré pour un POC : aucune personne, entreprise ou administration réelle."
ADRESSES_EMPLOYEURS = [
    "7 rue des Entrepôts, 44800 Saint-Herblain",
    "12 avenue de l'Industrie, 35000 Rennes",
    "3 place de la République, 49000 Angers",
    "28 boulevard des Sciences, 72000 Le Mans",
    "5 rue du Commerce, 37000 Tours",
    "41 quai des Docks, 29200 Brest",
]
SITUATIONS_FAMILIALES = {"pacses": "pacsés", "maries": "mariés", "concubins": "concubins", "celibataire": "célibataire"}
REGIMES = {
    "micro_bnc": "micro-BNC",
    "micro_bic_services": "micro-BIC (prestations de services)",
    "micro_bic_vente": "micro-BIC (vente)",
}


def _adresse_employeur(nom: str) -> str:
    return ADRESSES_EMPLOYEURS[sum(ord(c) for c in nom) % len(ADRESSES_EMPLOYEURS)]


def _siret(nom: str) -> str:
    n = f"{sum(ord(c) * (i + 1) for i, c in enumerate(nom)) % 10**9:09d}"
    return f"{n[:3]} {n[3:6]} {n[6:9]} 00019"


def _mois_moins(mois: str, n: int) -> str:
    annee, m = (int(x) for x in mois.split("-"))
    m -= n
    while m <= 0:
        m, annee = m + 12, annee - 1
    return f"{annee:04d}-{m:02d}"


def euros(x: float) -> str:
    s = f"{abs(x):,.2f}".replace(",", " ").replace(".", ",")
    return f"-{s} €" if x < 0 else f"{s} €"


def mois_fr(mois: str) -> str:
    return f"{MOIS_FR[int(mois[5:]) - 1]} {mois[:4]}"


def date_fr(d: dt.date) -> str:
    return d.strftime("%d/%m/%Y")


def _tableau(
    lignes: list[list], largeurs: list[float] | None = None, en_tete: bool = True, gras_derniere: bool = False
) -> Table:
    t = Table(lignes, colWidths=largeurs, hAlign="LEFT")
    style = [
        ("FONT", (0, 0), (-1, -1), "Helvetica", 8.5),
        ("GRID", (0, 0), (-1, -1), 0.3, colors.grey),
        ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
        ("TOPPADDING", (0, 0), (-1, -1), 2),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 2),
    ]
    if en_tete:
        style += [
            ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#e8eef5")),
            ("FONT", (0, 0), (-1, 0), "Helvetica-Bold", 8.5),
        ]
    if gras_derniere:
        style.append(("FONT", (0, -1), (-1, -1), "Helvetica-Bold", 8.5))
    t.setStyle(TableStyle(style))
    return t


def _document(chemin: Path, titre: str, blocs: list) -> None:
    chemin.parent.mkdir(parents=True, exist_ok=True)
    doc = SimpleDocTemplate(
        str(chemin),
        pagesize=A4,
        leftMargin=18 * mm,
        rightMargin=18 * mm,
        topMargin=16 * mm,
        bottomMargin=16 * mm,
        title=titre,
    )
    corps = [Paragraph(titre, TITRE)]
    for b in blocs:
        corps.append(Paragraph(b, NORMAL) if isinstance(b, str) else b)
    corps += [Spacer(1, 8), Paragraph(MENTION, PETIT)]
    doc.build(corps)


# ---------------------------------------------------------------------------------------------------------------------
# Pièces
# ---------------------------------------------------------------------------------------------------------------------
def fiche_de_paie(chemin: Path, cas: Cas, p: Personne, mois: str) -> None:
    avec_prime = (p.id, mois) in cas.pieges.prime_dans_le_net
    net_paye = p.salaire_net_mensuel + (p.prime_annuelle if avec_prime else 0.0)
    brut_base = round(p.salaire_net_mensuel * 1.38125, 2)  # 3 200 → 4 420 : ordre de grandeur usuel
    prime_brute = round(p.prime_annuelle * 1.29, 2) if avec_prime else 0.0
    brut = brut_base + prime_brute
    cotisations = round(brut - (p.net_imposable_mensuel + (p.prime_annuelle if avec_prime else 0.0)), 2)
    net_imposable = round(brut - cotisations, 2)
    pas = round(net_imposable - net_paye, 2)
    lignes = [["Rubrique", "Base", "Montant"], ["Salaire de base (151,67 h)", "151,67 h", euros(brut_base)]]
    if avec_prime:
        lignes.append(["Prime annuelle (versement unique)", "", euros(prime_brute)])
    lignes += [
        ["Salaire brut", "", euros(brut)],
        ["Cotisations et contributions salariales", "", euros(-cotisations)],
        ["Net imposable", "", euros(net_imposable)],
        ["Impôt sur le revenu prélevé à la source", f"{pas / net_imposable * 100:.1f} %", euros(-pas)],
        ["NET PAYÉ", "", euros(net_paye)],
    ]
    jours = (cas.date_depot - p.date_entree).days
    anciennete = f"{jours // 365} an{'s' if jours >= 730 else ''}" if jours >= 365 else f"{max(1, jours // 30)} mois"
    contrat = "CDI" if p.situation_pro == "cdi" else "CDD"
    blocs = [
        f"<b>{p.employeur}</b> — {_adresse_employeur(p.employeur)} — SIRET {_siret(p.employeur)}",
        f"<b>Bulletin de paie</b> — période du 01/{mois[5:]}/{mois[:4]} au {dt.date(int(mois[:4]), int(mois[5:]), 1).replace(day=28).strftime('%d/%m/%Y')} ({mois_fr(mois)})",
        f"Salarié : <b>{p.nom_complet}</b> — emploi : {p.poste} — contrat : {contrat} — date d'entrée : {date_fr(p.date_entree)} — "
        f"ancienneté : {anciennete}",
        _tableau(lignes, [95 * mm, 30 * mm, 40 * mm], gras_derniere=True),
        f"Payé le {dt.date(int(mois[:4]), int(mois[5:]), 28).strftime('%d/%m/%Y')} par virement bancaire.",
    ]
    if avec_prime:
        blocs.append(
            f"Mention : la prime annuelle est versée une fois par an, au mois de {MOIS_FR[int(mois[5:]) - 1]}."
        )
    _document(chemin, f"Bulletin de paie — {p.nom_complet} — {mois_fr(mois)}", blocs)


def declarations_ca(chemin: Path, cas: Cas, p: Personne) -> None:
    lignes = [["Mois", "Chiffre d'affaires déclaré", "Cotisations (22 %)"]]
    total = 0.0
    for mois in sorted(p.ca_mensuels):
        ca = p.ca_mensuels[mois]
        total += ca
        lignes.append([mois_fr(mois), euros(ca), euros(round(ca * 0.22, 2))])
    lignes.append(["Total", euros(total), euros(round(total * 0.22, 2))])
    blocs = [
        "<b>URSSAF — Relevé des déclarations de chiffre d'affaires (régime micro-entrepreneur)</b>",
        f"Déclarant : <b>{p.nom_complet}</b> — activité : {p.activite} — régime : {REGIMES.get(p.regime, p.regime)} "
        f"(abattement forfaitaire {p.abattement_pct:.0f} %) — début d'activité : {date_fr(p.debut_activite)} — SIRET {_siret(p.nom_complet)}",
        _tableau(lignes, [55 * mm, 55 * mm, 45 * mm], gras_derniere=True),
        f"Relevé édité le {date_fr(cas.date_depot)}. Déclarations mensuelles, chiffre d'affaires encaissé.",
    ]
    _document(chemin, f"Déclarations de chiffre d'affaires — {p.nom_complet}", blocs)


def avis_imposition(chemin: Path, cas: Cas, annee_emission: int) -> None:
    revenus = annee_emission - 1
    lignes = [["Déclarant", "Nature", "Montant"]]
    total = 0.0
    for p in cas.personnes:
        if p.situation_pro in ("cdi", "cdd", "retraite") and p.net_imposable_mensuel:
            facteur = (
                1.0 if revenus == cas.date_depot.year - 1 else 0.965
            )  # salaires de l'année d'avant un peu plus bas
            if p.id in cas.pieges.avis_incoherent:
                facteur *= 0.82  # piège : l'avis s'écarte des fiches de paie de bien plus de 10 %
            montant = round((p.net_imposable_mensuel * 12 + p.prime_annuelle) * facteur)
            nature = "Pensions, retraites, rentes" if p.situation_pro == "retraite" else "Traitements et salaires"
            lignes.append([p.nom_complet, nature, euros(montant)])
            total += montant
        elif p.situation_pro == "auto_entrepreneur":
            ca = sum(v for m, v in p.ca_mensuels.items() if m.startswith(str(revenus)))
            if ca:
                montant = round(ca * (1 - (p.abattement_pct or 34) / 100))
                lignes.append(
                    [p.nom_complet, "Bénéfices non commerciaux (micro-BNC, après abattement)", euros(montant)]
                )
                total += montant
            else:
                montant = 24_600.0 if revenus == cas.date_depot.year - 2 else 12_300.0
                lignes.append([p.nom_complet, "Traitements et salaires (activité salariée antérieure)", euros(montant)])
                total += montant
    parts = 2.0 if len(cas.personnes) > 1 else 1.0  # déclaration commune simulée, y compris pour les concubins du POC
    parts += 0.5 * min(cas.foyer.nb_enfants, 2) + max(0, cas.foyer.nb_enfants - 2)
    quotient = total / parts
    impot = round(max(0.0, (quotient - 11_497) * 0.11 + max(0.0, quotient - 29_315) * 0.19) * parts)
    lignes.append(["Foyer", "Revenu brut global", euros(total)])
    blocs = [
        "<b>DIRECTION GÉNÉRALE DES FINANCES PUBLIQUES — Avis d'impôt sur les revenus</b>",
        f"Avis émis en {annee_emission} sur les revenus de l'année <b>{revenus}</b> — foyer fiscal : "
        + " et ".join(p.nom_complet for p in cas.personnes)
        + f" — {cas.foyer.adresse}, {cas.foyer.code_postal} {cas.foyer.ville}",
        f"Situation de famille : {SITUATIONS_FAMILIALES.get(cas.foyer.situation_familiale, cas.foyer.situation_familiale)} — nombre de parts : {parts:.1f}",
        _tableau(lignes, [55 * mm, 80 * mm, 35 * mm], gras_derniere=True),
        _tableau(
            [
                ["Revenu fiscal de référence", euros(total)],
                ["Impôt sur le revenu net", euros(impot)],
                [
                    "Taux de prélèvement à la source du foyer",
                    f"{min(impot / total * 100, 45):.1f} %" if total else "0 %",
                ],
            ],
            [80 * mm, 40 * mm],
            en_tete=False,
        ),
        f"Numéro fiscal du foyer : 12 34 567 890 {annee_emission % 100:02d} — avis simulé.",
    ]
    _document(chemin, f"Avis d'imposition {annee_emission} (revenus {revenus})", blocs)


def releve_compte(chemin: Path, cas: Cas, compte: Compte, releve: dict) -> None:
    lignes = [["Date", "Libellé", "Débit", "Crédit", "Solde"]]
    for ligne in releve["lignes"]:
        m = ligne["montant"]
        lignes.append(
            [
                date_fr(ligne["date"]),
                ligne["libelle"],
                euros(-m) if m < 0 else "",
                euros(m) if m > 0 else "",
                euros(ligne["solde_apres"]),
            ]
        )
    titulaires = " et ".join(cas.personne(t).nom_complet for t in compte.titulaires)
    type_libelle = {"courant": "Compte courant", "pro": "Compte professionnel", "joint": "Compte joint"}[compte.type]
    blocs = [
        f"<b>{compte.banque}</b> — relevé de compte — {type_libelle} n° {compte.iban_masque}",
        f"Titulaire(s) : <b>{titulaires}</b> — période : {mois_fr(releve['mois'])}",
        f"Solde au début de la période : <b>{euros(releve['solde_debut'])}</b>",
        _tableau(lignes, [20 * mm, 85 * mm, 22 * mm, 22 * mm, 25 * mm]),
        f"Solde à la fin de la période : <b>{euros(releve['solde_fin'])}</b> — {len(releve['lignes'])} opérations.",
    ]
    _document(chemin, f"Relevé de compte — {type_libelle} — {mois_fr(releve['mois'])}", blocs)


def compromis(chemin: Path, cas: Cas) -> None:
    p = cas.projet
    acquereurs = " et ".join(
        f"{x.nom_complet}, né(e) le {date_fr(x.date_naissance)} à {x.lieu_naissance}" for x in cas.personnes
    )
    pret_max = p.prix - p.apport + round((p.prix - p.honoraires_agence_inclus) * 0.075)
    blocs = [
        f"<b>Compromis de vente</b> — signé le {date_fr(p.date_compromis)} en l'étude de {p.notaire}, par l'intermédiaire de {p.agence}.",
        f"<b>Vendeur</b> : {p.vendeur}. <b>Acquéreurs</b> : {acquereurs}, demeurant {cas.foyer.adresse}, {cas.foyer.code_postal} {cas.foyer.ville}.",
        f"<b>Bien</b> : {p.description_bien}, situé {p.adresse_bien}. Usage : {'résidence principale' if p.usage == 'residence_principale' else 'investissement locatif'}.",
        _tableau(
            [
                ["Prix de vente", euros(p.prix)],
                ["dont honoraires d'agence à la charge de l'acquéreur", euros(p.honoraires_agence_inclus)],
                ["Prix net vendeur", euros(p.prix - p.honoraires_agence_inclus)],
                ["Dépôt de garantie versé à la signature", euros(round(p.prix * 0.05))],
            ],
            [95 * mm, 40 * mm],
            en_tete=False,
        ),
        f"<b>Condition suspensive d'obtention de prêt</b> : l'acquéreur déclare financer l'acquisition au moyen d'un ou plusieurs prêts d'un montant "
        f"maximal de {euros(pret_max)}, sur une durée maximale de {p.duree_souhaitee_annees} ans, au taux nominal maximal de 4,20 % hors assurance. "
        f"La condition devra être réalisée au plus tard le <b>{date_fr(p.date_limite_pret)}</b>. Apport personnel déclaré : {euros(p.apport)}.",
        f"Signature de l'acte authentique prévue au plus tard le {date_fr(p.date_limite_pret + dt.timedelta(days=45))}.",
    ]
    _document(chemin, "Compromis de vente", blocs)


def tableau_amortissement(chemin: Path, cas: Cas, c: Credit) -> None:
    lignes = [["Échéance", "Mensualité", "Intérêts", "Capital", "Capital restant dû"]]
    restant = c.capital_restant
    date = dt.date(cas.date_depot.year, cas.date_depot.month, c.date_fin.day)
    n = 0
    while restant > 0.005 and n < 400:
        interets = round(restant * c.taux_pct / 100 / 12, 2)
        capital = min(round(c.mensualite - interets, 2), restant)
        restant = round(restant - capital, 2)
        lignes.append([date_fr(date), euros(capital + interets), euros(interets), euros(capital), euros(restant)])
        mois = date.month + 1
        date = date.replace(year=date.year + (mois > 12), month=mois if mois <= 12 else 1)
        n += 1
    p = cas.personne(c.titulaire)
    blocs = [
        f"<b>{c.organisme}</b> — tableau d'amortissement — crédit {c.type} n° {c.id}-{cas.demande_id[-4:]}",
        f"Emprunteur : <b>{p.nom_complet}</b> — contrat du {date_fr(c.date_debut)} — taux nominal {c.taux_pct:.2f} % — "
        f"mensualité assurance comprise : <b>{euros(c.mensualite)}</b> — dernière échéance : {date_fr(c.date_fin)}",
        f"Capital restant dû au {date_fr(cas.date_depot)} : <b>{euros(c.capital_restant)}</b> — échéances restantes : {n}",
        _tableau(lignes, [28 * mm, 30 * mm, 28 * mm, 28 * mm, 40 * mm]),
    ]
    _document(chemin, f"Tableau d'amortissement — {c.organisme}", blocs)


def piece_identite(chemin: Path, cas: Cas, p: Personne) -> None:
    blocs = [
        "<b>RÉPUBLIQUE FRANÇAISE — CARTE NATIONALE D'IDENTITÉ</b> (reproduction simulée)",
        _tableau(
            [
                ["Nom", p.nom.upper()],
                ["Prénom", p.prenom],
                [
                    "Née le" if p.prenom.endswith(("e", "a")) else "Né le",
                    f"{date_fr(p.date_naissance)} à {p.lieu_naissance}",
                ],
                ["Nationalité", "Française"],
                [
                    "Numéro",
                    f"{p.date_naissance.year % 100:02d}{p.date_naissance.month:02d}{cas.demande_id[-4:]}{len(p.nom):02d}0{p.id[:1].upper()}",
                ],
                ["Délivrée le", date_fr(dt.date(2021, 5, 3) if p.role == "emprunteur" else dt.date(2022, 9, 19))],
                ["Expire le", date_fr(dt.date(2031, 5, 3) if p.role == "emprunteur" else dt.date(2032, 9, 19))],
            ],
            [40 * mm, 90 * mm],
            en_tete=False,
        ),
    ]
    _document(chemin, f"Pièce d'identité — {p.nom_complet}", blocs)


def attestation_pension(chemin: Path, cas: Cas, p: Personne) -> None:
    mois = cas.mois_releves[-1]
    blocs = [
        f"<b>{p.employeur}</b> — Attestation de paiement de pension de retraite",
        f"Bénéficiaire : <b>{p.nom_complet}</b>, né(e) le {date_fr(p.date_naissance)} — pension liquidée le {date_fr(p.date_entree)}",
        _tableau(
            [
                ["Pension mensuelle nette versée", euros(p.salaire_net_mensuel)],
                ["Pension mensuelle brute (imposable)", euros(p.net_imposable_mensuel)],
                ["Dernier versement", f"09/{mois[5:]}/{mois[:4]}"],
            ],
            [80 * mm, 45 * mm],
            en_tete=False,
        ),
        f"Attestation éditée le {date_fr(cas.date_depot)} à la demande de l'intéressé(e). Pension versée le 9 de chaque mois par virement.",
    ]
    _document(chemin, f"Attestation de pension — {p.nom_complet}", blocs)


def estimation_locative(chemin: Path, cas: Cas) -> None:
    p = cas.projet
    blocs = [
        f"<b>{p.agence}</b> — Estimation de la valeur locative",
        f"Bien : {p.description_bien}, situé {p.adresse_bien}.",
        _tableau(
            [
                ["Loyer mensuel attendu (hors charges)", euros(p.loyers_attendus_mensuels)],
                ["Charges récupérables estimées", euros(round(p.loyers_attendus_mensuels * 0.08))],
                ["Rendement brut sur le prix de vente", f"{p.loyers_attendus_mensuels * 12 / p.prix * 100:.1f} %"],
            ],
            [80 * mm, 45 * mm],
            en_tete=False,
        ),
        f"Estimation établie le {date_fr(p.date_compromis)} au vu du marché locatif local. Elle n'engage pas l'agence.",
    ]
    _document(chemin, "Estimation locative", blocs)


def quittance_loyer(chemin: Path, cas: Cas, mois: str) -> None:
    locataires = " et ".join(p.nom_complet for p in cas.personnes)
    blocs = [
        f"<b>Quittance de loyer</b> — {mois_fr(mois)}",
        f"Bailleur : {cas.logement.bailleur}. Locataire(s) : <b>{locataires}</b>. Logement : {cas.foyer.adresse}, {cas.foyer.code_postal} {cas.foyer.ville}.",
        _tableau(
            [
                ["Loyer", euros(cas.logement.loyer_mensuel * (0.88 if cas.logement.charges_incluses else 1))],
                ["Charges", euros(cas.logement.loyer_mensuel * 0.12 if cas.logement.charges_incluses else 0)],
                ["Total réglé", euros(cas.logement.loyer_mensuel)],
            ],
            [60 * mm, 40 * mm],
            en_tete=False,
        ),
        f"Le bailleur déclare avoir reçu la somme ci-dessus pour la période du 01/{mois[5:]}/{mois[:4]} au dernier jour du mois, et en donne quittance.",
    ]
    _document(chemin, f"Quittance de loyer — {mois_fr(mois)}", blocs)


def releve_epargne(chemin: Path, cas: Cas, p: Personne) -> None:
    mois = cas.mois_releves[-1]
    noms = {"livret_a": "Livret A", "ldds": "LDDS", "assurance_vie": "Assurance-vie", "pel": "PEL"}
    lignes = [["Produit", "Établissement", "Solde", "Disponibilité"]]
    total = 0.0
    for e in cas.epargnes:
        if e.titulaire == p.id:
            lignes.append([noms[e.type], e.banque, euros(e.solde), "disponible" if e.disponible else "bloquée"])
            total += e.solde
    lignes.append(["Total", "", euros(total), ""])
    blocs = [
        f"<b>Relevé des comptes d'épargne</b> au dernier jour de {mois_fr(mois)}",
        f"Titulaire : <b>{p.nom_complet}</b>",
        _tableau(lignes, [40 * mm, 50 * mm, 35 * mm, 35 * mm], gras_derniere=True),
    ]
    _document(chemin, f"Épargne — {p.nom_complet}", blocs)


# ---------------------------------------------------------------------------------------------------------------------
# Le coffre d'une demande
# ---------------------------------------------------------------------------------------------------------------------
DPI_SCAN = 200


def _degrader(image, qualite: str, rng):
    """Ce qu'un scanner ou un téléphone fait à une page : légère rotation, grain, flou ; beaucoup plus pour un scan illisible."""
    from PIL import Image, ImageEnhance, ImageFilter

    if qualite == "illisible":
        w, h = image.size
        image = image.resize((w // 5, h // 5)).resize((w, h)).filter(ImageFilter.GaussianBlur(2.2))
    if qualite == "photo":
        image = ImageEnhance.Contrast(image).enhance(0.85)
    image = image.rotate(rng.uniform(-1.2, 1.2), fillcolor=238 if qualite == "photo" else 245, resample=Image.BICUBIC)
    pixels = image.load()
    w, h = image.size
    for _ in range(w * h // 60):
        x, y = rng.randrange(w), rng.randrange(h)
        pixels[x, y] = max(0, min(255, pixels[x, y] + rng.randint(-90, 90)))
    return image.filter(ImageFilter.GaussianBlur(0.6))


def numeriser(chemin: Path, qualite: str, graine: str) -> tuple[str, str]:
    """Remplace une pièce PDF par sa version numérisée : un PDF fait d'images, sans texte (scan), ou une photo JPG.
    Renvoie (nom du fichier, format). Déterministe : même graine, mêmes pixels."""
    import random

    import pypdfium2 as pdfium
    from reportlab.lib.utils import ImageReader
    from reportlab.pdfgen import canvas

    rng = random.Random(graine)
    doc = pdfium.PdfDocument(str(chemin))
    try:
        pages = [doc[i].render(scale=DPI_SCAN / 72).to_pil().convert("L") for i in range(len(doc))]
    finally:
        doc.close()
    images = [_degrader(p, qualite, rng) for p in pages]
    if qualite == "photo":
        photo = chemin.with_suffix(".jpg")
        images[0].save(photo, "JPEG", quality=72)  # la photo de la première page, prise au téléphone
        chemin.unlink()
        return photo.name, "jpg"
    feuille = canvas.Canvas(str(chemin), pagesize=A4, invariant=1)
    for image in images:
        feuille.drawImage(ImageReader(image), 0, 0, width=A4[0], height=A4[1])
        feuille.showPage()
    feuille.save()
    return chemin.name, "pdf"


def generer_pieces(config: Config, cas: Cas, releves: dict[str, list[dict]]) -> list[dict]:
    """Écrit toutes les pièces déposées dans `coffre/<demande_id>/` et renvoie l'inventaire (aussi écrit en JSON). Les
    pièces que le cas déclare numérisées (`pieges.pieces_scannees`) sont remplacées par leur scan ou leur photo."""
    dossier = config.coffre_dir / cas.demande_id
    if dossier.exists():
        for f in dossier.iterdir():
            f.unlink()
    dossier.mkdir(parents=True, exist_ok=True)
    inventaire: list[dict] = []
    depot = cas.date_depot.isoformat()
    numerisees = {(t, p or "", per or ""): q for t, p, per, q in cas.pieges.pieces_scannees}

    def ajouter(type_: str, personne: str | None, periode: str | None, fichier: str, libelle: str) -> None:
        format_ = "pdf"
        qualite = numerisees.get((type_, personne or "", periode or ""))
        if qualite:
            fichier, format_ = numeriser(dossier / fichier, qualite, f"{cas.demande_id}:{fichier}:{qualite}")
        inventaire.append(
            {
                "piece_id": f"P{len(inventaire) + 1:02d}",
                "type": type_,
                "personne": personne,
                "periode": periode,
                "fichier": fichier,
                "format": format_,
                "deposee_le": depot,
                "libelle": libelle,
            }
        )

    for p in cas.personnes:
        f = f"identite_{p.id}.pdf"
        piece_identite(dossier / f, cas, p)
        ajouter("identite", p.id, None, f, f"Pièce d'identité de {p.nom_complet}")
        if p.situation_pro in ("cdi", "cdd") and p.id not in cas.pieges.salarie_sans_fiche:
            for mois in cas.mois_fiches_paie:
                if (p.id, mois) in cas.pieges.fiches_paie_manquantes:
                    continue
                f = f"fiche_paie_{p.id}_{mois}.pdf"
                fiche_de_paie(dossier / f, cas, p, mois)
                ajouter("fiche_paie", p.id, mois, f, f"Bulletin de paie de {p.prenom}, {mois_fr(mois)}")
        if p.situation_pro == "auto_entrepreneur":
            f = f"declarations_ca_{p.id}.pdf"
            declarations_ca(dossier / f, cas, p)
            ajouter(
                "declaration_ca",
                p.id,
                f"{min(p.ca_mensuels)}/{max(p.ca_mensuels)}",
                f,
                f"Déclarations de chiffre d'affaires de {p.prenom}",
            )
        if p.situation_pro == "retraite":
            f = f"attestation_pension_{p.id}.pdf"
            attestation_pension(dossier / f, cas, p)
            ajouter("attestation_pension", p.id, cas.mois_releves[-1], f, f"Attestation de pension de {p.prenom}")
        f = f"epargne_{p.id}.pdf"
        releve_epargne(dossier / f, cas, p)
        ajouter("justificatif_epargne", p.id, cas.mois_releves[-1], f, f"Relevé d'épargne de {p.prenom}")
    hors_periode = {t for t, _ in cas.pieges.piece_hors_periode}
    annees_avis = [a - 1 for a in cas.annees_avis] if "avis_imposition" in hors_periode else cas.annees_avis
    for annee in annees_avis:
        f = f"avis_imposition_{annee}.pdf"
        avis_imposition(dossier / f, cas, annee)
        ajouter("avis_imposition", None, str(annee), f, f"Avis d'imposition {annee} (revenus {annee - 1})")
    for compte in cas.comptes:
        for rel in releves[compte.id]:
            f = f"releve_{compte.id.lower()}_{rel['mois']}.pdf"
            releve_compte(dossier / f, cas, compte, rel)
            titulaires = "+".join(compte.titulaires)
            ajouter(
                "releve_compte",
                titulaires,
                rel["mois"],
                f,
                f"Relevé {compte.type} {compte.banque} ({compte.iban_masque[-4:]}), {mois_fr(rel['mois'])}",
            )
    for c in cas.credits:
        f = f"amortissement_{c.id.lower()}.pdf"
        tableau_amortissement(dossier / f, cas, c)
        ajouter(
            "tableau_amortissement", c.titulaire, None, f, f"Tableau d'amortissement du crédit {c.type} ({c.organisme})"
        )
    f = "compromis_de_vente.pdf"
    compromis(dossier / f, cas)
    ajouter("compromis", None, cas.projet.date_compromis.isoformat(), f, "Compromis de vente")
    if cas.projet.usage == "locatif":
        f = "estimation_locative.pdf"
        estimation_locative(dossier / f, cas)
        ajouter(
            "estimation_locative", None, cas.projet.date_compromis.isoformat(), f, "Estimation locative de l'agence"
        )
    mois_quittance = (
        _mois_moins(cas.mois_releves[-1], 7) if "justificatif_domicile" in hors_periode else cas.mois_releves[-1]
    )
    f = f"quittance_loyer_{mois_quittance}.pdf"
    quittance_loyer(dossier / f, cas, mois_quittance)
    ajouter("justificatif_domicile", None, mois_quittance, f, f"Quittance de loyer, {mois_fr(mois_quittance)}")
    (dossier / "inventaire.json").write_text(
        json.dumps(
            {"demande_id": cas.demande_id, "deposee_le": depot, "pieces": inventaire}, ensure_ascii=False, indent=1
        ),
        encoding="utf-8",
    )
    return inventaire


def deposer_piece(config: Config, cas: Cas, type_piece: str, personne_id: str, periode: str) -> dict:
    """Simule la réception d'une pièce manquante (pour la démonstration : « reprendre avec la pièce reçue ») : la génère depuis
    la vérité terrain et l'ajoute à l'inventaire du coffre. Lot 4 : seules les fiches de paie sont prises en charge."""
    if type_piece != "fiche_paie":
        raise ValueError("seules les fiches de paie peuvent être déposées après coup pour l'instant")
    p = cas.personne(personne_id)
    dossier = config.coffre_dir / cas.demande_id
    chemin_inv = dossier / "inventaire.json"
    inv = json.loads(chemin_inv.read_text(encoding="utf-8"))
    if any(x["type"] == type_piece and x["personne"] == personne_id and x["periode"] == periode for x in inv["pieces"]):
        raise ValueError(f"la pièce {type_piece} {personne_id} {periode} est déjà dans le coffre")
    fichier = f"fiche_paie_{personne_id}_{periode}.pdf"
    fiche_de_paie(dossier / fichier, cas, p, periode)
    piece = {
        "piece_id": f"P{len(inv['pieces']) + 1:02d}",
        "type": type_piece,
        "personne": personne_id,
        "periode": periode,
        "fichier": fichier,
        "format": "pdf",
        "deposee_le": dt.date.today().isoformat(),
        "libelle": f"Bulletin de paie de {p.prenom}, {mois_fr(periode)} (reçu après demande)",
    }
    inv["pieces"].append(piece)
    chemin_inv.write_text(json.dumps(inv, ensure_ascii=False, indent=1), encoding="utf-8")
    return piece
