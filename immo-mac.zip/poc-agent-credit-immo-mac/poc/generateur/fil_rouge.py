"""Le fil rouge : Marie et Thomas, appartement à 320 000 € à Nantes, 40 000 € d'apport, 25 ans.

Ce fichier est la vérité terrain du scénario de démonstration, écrit comme une fiche de situation. Les quatre pièges du
cadrage y sont posés explicitement (section `pieges`) : la fiche de paie de juin de Thomas inclut sa prime annuelle ;
son salaire arrive sur deux comptes (2 700 € chez nous, 500 € sur le compte joint tenu ailleurs) ; sa fiche d'août
manque ; Marie est auto-entrepreneuse depuis quatorze mois.

Le chiffre d'affaires de Marie est calé pour que le taux d'effort correct, tous revenus retenus, soit de 33,5 % : c'est
le chiffre que l'agent doit retrouver après s'être relu.
"""

from __future__ import annotations

import datetime as dt

from poc.generateur import referentiels as refs
from poc.generateur.attendu import assurance_mensuelle, capital_emprunte, mensualite
from poc.generateur.modeles import (
    Cas,
    Compte,
    Credit,
    Epargne,
    Foyer,
    Logement,
    Personne,
    Pieges,
    Projet,
)

DEMANDE_ID = "DEM-0001"
DATE_DEPOT = dt.date(2026, 9, 7)
MOIS_RELEVES = ["2026-06", "2026-07", "2026-08"]
TAUX_EFFORT_CIBLE = 33.5
SALAIRE_THOMAS = 3200.0
PART_COMPTE_JOINT = 500.0
PRIME_THOMAS = 2400.0
ABATTEMENT_MICRO_BNC = refs.ABATTEMENTS["micro_bnc"]
# écarts mensuels autour de la moyenne, en euros, de juillet 2025 à août 2026 : ils somment à zéro
VARIATIONS_CA = [-380, +240, -60, +310, -420, +90, +150, -210, +380, -120, +60, -290, +200, +50]
MOIS_CA = [
    "2025-07",
    "2025-08",
    "2025-09",
    "2025-10",
    "2025-11",
    "2025-12",
    "2026-01",
    "2026-02",
    "2026-03",
    "2026-04",
    "2026-05",
    "2026-06",
    "2026-07",
    "2026-08",
]


def _ca_marie(cas_sans_ca: Cas) -> dict[str, float]:
    """Le chiffre d'affaires mensuel de Marie, calé pour que le taux d'effort attendu tombe sur la cible."""
    capital = capital_emprunte(cas_sans_ca)
    duree = cas_sans_ca.projet.duree_souhaitee_annees
    charges = mensualite(capital, refs.taux_pour_duree(duree), duree) + assurance_mensuelle(cas_sans_ca, capital)
    charges += sum(c.mensualite for c in cas_sans_ca.credits)
    revenus_cible = charges / (TAUX_EFFORT_CIBLE / 100)
    revenu_marie = revenus_cible - SALAIRE_THOMAS
    ca_moyen = revenu_marie / (1 - ABATTEMENT_MICRO_BNC / 100)
    assert abs(sum(VARIATIONS_CA)) < 1e-9
    base = round(ca_moyen / 10) * 10
    valeurs = [base + v for v in VARIATIONS_CA]
    # ajustement du dernier mois pour que la moyenne reproduise exactement la cible (à l'euro)
    ecart = round(ca_moyen * len(MOIS_CA)) - sum(valeurs)
    valeurs[-1] += ecart
    return dict(zip(MOIS_CA, [float(v) for v in valeurs], strict=True))


def cas_fil_rouge() -> Cas:
    thomas = Personne(
        id="thomas",
        prenom="Thomas",
        nom="Bernard",
        date_naissance=dt.date(1990, 3, 14),
        lieu_naissance="Rennes (35)",
        role="emprunteur",
        situation_pro="cdi",
        employeur="Logistique Ouest SAS",
        poste="Responsable d'exploitation",
        date_entree=dt.date(2020, 3, 2),
        salaire_net_mensuel=SALAIRE_THOMAS,
        net_imposable_mensuel=3420.0,
        prime_annuelle=PRIME_THOMAS,
        mois_prime=6,
        compte_salaire="CPT-THOMAS",
        part_salaire_autre_compte=PART_COMPTE_JOINT,
        compte_salaire_secondaire="CPT-JOINT",
    )
    marie = Personne(
        id="marie",
        prenom="Marie",
        nom="Leroy",
        date_naissance=dt.date(1992, 7, 22),
        lieu_naissance="Angers (49)",
        role="co_emprunteur",
        situation_pro="auto_entrepreneur",
        activite="Graphiste indépendante",
        debut_activite=dt.date(2025, 7, 1),
        regime="micro_bnc",
        abattement_pct=ABATTEMENT_MICRO_BNC,
        compte_pro="CPT-MARIE-PRO",
        compte_perso="CPT-MARIE",
        remuneration_mensuelle=2000.0,
    )
    foyer = Foyer(
        situation_familiale="pacses",
        depuis=dt.date(2023, 5, 12),
        nb_enfants=0,
        adresse="8 allée des Tilleuls",
        code_postal="44300",
        ville="Nantes",
    )
    projet = Projet(
        type_bien="ancien",
        usage="residence_principale",
        description_bien="Appartement T3 de 68 m², 3e étage avec ascenseur, cave, résidence de 1998",
        adresse_bien="12 rue des Lilas, 44000 Nantes",
        prix=320_000.0,
        honoraires_agence_inclus=10_000.0,
        apport=40_000.0,
        duree_souhaitee_annees=25,
        date_compromis=dt.date(2026, 8, 28),
        date_limite_pret=dt.date(2026, 10, 12),
        vendeur="M. et Mme Lefèvre",
        agence="Agence Loire Habitat",
        notaire="Maître Garnier, notaire à Nantes",
    )
    comptes = [
        Compte(
            id="CPT-THOMAS",
            titulaires=["thomas"],
            banque="Banque du POC",
            chez_nous=True,
            type="courant",
            iban_masque="FR76 •••• •••• •••• 4821",
            solde_debut=1840.55,
        ),
        Compte(
            id="CPT-MARIE",
            titulaires=["marie"],
            banque="Banque du POC",
            chez_nous=True,
            type="courant",
            iban_masque="FR76 •••• •••• •••• 7730",
            solde_debut=1215.20,
        ),
        Compte(
            id="CPT-MARIE-PRO",
            titulaires=["marie"],
            banque="Banque du POC",
            chez_nous=True,
            type="pro",
            iban_masque="FR76 •••• •••• •••• 9904",
            solde_debut=4360.00,
        ),
        Compte(
            id="CPT-JOINT",
            titulaires=["thomas", "marie"],
            banque="Crédit Fictif",
            chez_nous=False,
            type="joint",
            iban_masque="FR14 •••• •••• •••• 2210",
            solde_debut=620.00,
        ),
    ]
    epargnes = [
        Epargne(
            id="EP-THOMAS-LA",
            titulaire="thomas",
            type="livret_a",
            banque="Banque du POC",
            chez_nous=True,
            solde=12_000.0,
        ),
        Epargne(
            id="EP-THOMAS-AV",
            titulaire="thomas",
            type="assurance_vie",
            banque="Banque du POC",
            chez_nous=True,
            solde=28_000.0,
        ),
        Epargne(
            id="EP-MARIE-LA", titulaire="marie", type="livret_a", banque="Banque du POC", chez_nous=True, solde=8_000.0
        ),
    ]
    credits = [
        Credit(
            id="CRD-AUTO",
            titulaire="thomas",
            type="auto",
            organisme="Crédit Fictif Auto",
            chez_nous=False,
            date_debut=dt.date(2024, 3, 10),
            date_fin=dt.date(2028, 2, 10),
            mensualite=210.0,
            capital_restant=3_650.0,
            taux_pct=4.9,
            compte_prelevement="CPT-THOMAS",
        )
    ]
    logement = Logement(
        loyer_mensuel=950.0, charges_incluses=True, bailleur="SCI Les Tilleuls", compte_prelevement="CPT-JOINT"
    )
    pieges = Pieges(
        fiches_paie_manquantes=[("thomas", "2026-08")],
        prime_dans_le_net=[("thomas", "2026-06")],
        salaire_scinde=["thomas"],
        independant_recent=["marie"],
        pieces_scannees=[("avis_imposition", "", "2025", "scan")],
    )
    cas = Cas(
        demande_id=DEMANDE_ID,
        scenario="fil_rouge",
        difficulte=3,
        description="Marie et Thomas, pacsés, sans enfant, achètent un appartement ancien à Nantes pour 320 000 € avec 40 000 € d'apport, "
        "sur 25 ans. Thomas est en CDI depuis six ans ; Marie est graphiste auto-entrepreneuse depuis quatorze mois. "
        "Quatre pièges : prime annuelle dans le net de juin, salaire de Thomas scindé sur deux comptes, fiche de paie d'août manquante, "
        "indépendante trop récente pour la règle standard. L'avis d'imposition 2025 est déposé scanné : la lecture native ne donne "
        "rien, il faut passer par l'OCR.",
        date_depot=DATE_DEPOT,
        mois_releves=MOIS_RELEVES,
        foyer=foyer,
        personnes=[thomas, marie],
        projet=projet,
        comptes=comptes,
        epargnes=epargnes,
        credits=credits,
        logement=logement,
        pieges=pieges,
    )
    marie.ca_mensuels = _ca_marie(cas)
    return cas


def tous_les_cas() -> list[Cas]:
    """Les cinquante cas générés par `poc donnees generer` : le fil rouge (DEM-0001) puis le catalogue (DEM-0002 à DEM-0050)."""
    from poc.generateur.catalogue import cas_du_catalogue

    return [cas_fil_rouge(), *cas_du_catalogue()]
