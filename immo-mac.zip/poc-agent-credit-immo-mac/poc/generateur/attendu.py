"""Le moteur de vérité : à partir d'un cas, ce que l'agent **devrait** trouver s'il applique la politique de crédit maison
et la norme HCSF. Sert uniquement à noter l'agent (vérité terrain) ; l'agent, lui, calcule dans l'atelier à partir des
fiches de méthode, sans jamais voir ce module.

Formules : mensualité d'un prêt amortissable à taux fixe M = C × t/12 ÷ (1 − (1 + t/12)^−n) ; assurance au prorata de
la quotité de chaque emprunteur sur le capital initial ; taux d'effort = charges retenues ÷ revenus retenus.

Les règles appliquées sont celles de `referentiels/politique_credit.md` : salarié en CDI (net payé hors prime ; période
d'essai = cas non couvert), CDD de moins de trois ans exclu, indépendant (moyenne du chiffre d'affaires après abattement ;
moins de deux exercices = cas non couvert), retraité (pension), loyers attendus à 70 % ; crédits en cours sauf fin proche ;
reste à vivre minimum par adulte et par enfant ; incidents, signaux de compte.
"""

from __future__ import annotations

import datetime as dt
from typing import Any

from pydantic import BaseModel, Field

from poc.generateur import referentiels as refs
from poc.generateur.modeles import Cas, Personne

DUREES = (15, 20, 25)
CDD_ANCIENNETE_MOIS = refs.CDD_ANCIENNETE_MOIS
PENSION_ANCIENNETE_MOIS = refs.PENSION_ANCIENNETE_MOIS
TAUX_EFFORT_DEFAVORABLE = refs.TAUX_EFFORT_DEFAVORABLE
MOIS_FR = [
    "janvier",
    "février",
    "mars",
    "avril",
    "mai",
    "juin",
    "juillet",
    "août",
    "septembre",
    "octobre",
    "novembre",
    "décembre",
]


def mensualite(capital: float, taux_pct: float, annees: int) -> float:
    t = taux_pct / 100 / 12
    n = annees * 12
    if t == 0:
        return capital / n
    return capital * t / (1 - (1 + t) ** -n)


def frais_acquisition(cas: Cas) -> float:
    """Frais de notaire sur le prix hors honoraires d'agence."""
    base = cas.projet.prix - cas.projet.honoraires_agence_inclus
    return round(base * refs.taux_frais_notaire(cas.projet.type_bien) / 100)


def capital_emprunte(cas: Cas) -> float:
    return round(cas.projet.prix + frais_acquisition(cas) - cas.projet.apport)


def assurance_mensuelle(cas: Cas, capital: float) -> float:
    quotite = 1.0 / len(cas.personnes)
    total = 0.0
    for p in cas.personnes:
        total += refs.taux_assurance(p.age(cas.date_depot)) / 100 * quotite * capital / 12
    return round(total, 2)


def anciennete_mois(p: Personne, a_la_date: dt.date) -> int | None:
    if p.date_entree is None:
        return None
    return (a_la_date.year - p.date_entree.year) * 12 + a_la_date.month - p.date_entree.month


def revenu_retenu(p: Personne, cas: Cas) -> tuple[float, bool, str]:
    """(revenu mensuel retenu, couvert par la règle standard ?, règle appliquée)."""
    if p.id in cas.pieges.salarie_sans_fiche:
        return 0.0, False, "REV_NON_ETABLI"
    if p.situation_pro == "cdi" and p.salaire_net_mensuel is not None:
        anc = anciennete_mois(p, cas.date_depot)
        couvert = anc is None or anc >= refs.CDI_PERIODE_ESSAI_MOIS
        return float(p.salaire_net_mensuel), couvert, "REV_SALAIRE"
    if p.situation_pro == "cdd" and p.salaire_net_mensuel is not None:
        anc = anciennete_mois(p, cas.date_depot) or 0
        if anc >= CDD_ANCIENNETE_MOIS:
            return float(p.salaire_net_mensuel), True, "REV_SALAIRE"
        return 0.0, True, "REV_EXCLUS"  # la règle s'applique : un CDD récent n'est pas retenu
    if p.situation_pro == "auto_entrepreneur":
        mois = p.mois_activite(cas.date_depot) or 0
        abattement = p.abattement_pct if p.abattement_pct is not None else refs.ABATTEMENTS.get(p.regime or "", 34.0)
        if not p.ca_mensuels:
            return 0.0, False, "REV_INDEPENDANT"
        valeurs = [p.ca_mensuels[m] for m in sorted(p.ca_mensuels)][-24:]
        moyenne = sum(valeurs) / len(valeurs)
        return round(moyenne * (1 - abattement / 100), 2), mois >= refs.EXERCICES_MINIMUM_INDEPENDANT, "REV_INDEPENDANT"
    if p.situation_pro == "retraite" and p.salaire_net_mensuel is not None:
        anc = anciennete_mois(p, cas.date_depot)
        return float(p.salaire_net_mensuel), anc is None or anc >= PENSION_ANCIENNETE_MOIS, "REV_PENSION"
    return 0.0, False, "REV_EXCLUS"


def charges_credits(cas: Cas) -> float:
    total = 0.0
    limite = cas.date_depot + dt.timedelta(days=30 * refs.CREDIT_FIN_PROCHE_MOIS)
    for c in cas.credits:
        if c.date_fin > limite:
            total += c.mensualite
    return round(total, 2)


class Attendu(BaseModel):
    demande_id: str
    scenario: str
    difficulte: int
    lot: str = "reglage"
    prix: float
    honoraires_agence: float
    frais_acquisition: float
    apport: float
    montant_emprunte: float
    duree_souhaitee_annees: int
    taux_nominal_pct: float
    assurance_mensuelle: float
    mensualites_hors_assurance: dict[int, float]
    mensualites_assurance_comprise: dict[int, float]
    revenus_par_personne: dict[str, float]
    revenus_locatifs_retenus: float = 0.0
    revenus_non_couverts: list[str] = Field(description="personnes dont le revenu sort de la règle standard")
    revenus_retenus: float = Field(description="tous revenus, y compris ceux non couverts")
    revenus_retenus_standard: float = Field(description="revenus couverts par la règle standard seulement")
    charges_credits: float
    charges_retenues: float
    taux_effort: float = Field(description="en %, à la durée souhaitée, tous revenus")
    taux_effort_standard: float
    taux_effort_par_duree: dict[int, float]
    reste_a_vivre: float
    reste_a_vivre_minimum: float
    verdicts: dict[str, str]
    recommandation: str
    reserves: list[str]
    pieces_manquantes: list[dict[str, str]]
    doutes_attendus: list[dict[str, Any]]
    moments: list[str]
    faits: dict[str, float]
    bloquant: bool = False
    pieces_scannees: list[dict[str, str]] = Field(
        default_factory=list, description="pièces numérisées : l'agent doit passer de lire_piece à ocr_piece"
    )
    score_banque: float | None = Field(default=None, description="le score d'éligibilité calculé par api-scoring")
    classe_score: str | None = None
    score_diverge: bool = Field(
        default=False, description="le score contredit l'analyse : l'agent doit le dire (moment SCORE_RELATIVISE)"
    )


def _mois_clair(per: str) -> str:
    return f"{MOIS_FR[int(per[5:]) - 1]} {per[:4]}"


def calculer_attendu(cas: Cas) -> Attendu:
    frais = frais_acquisition(cas)
    capital = capital_emprunte(cas)
    assurance = assurance_mensuelle(cas, capital)
    mens_ha = {d: round(mensualite(capital, refs.taux_pour_duree(d), d), 2) for d in DUREES}
    mens_ac = {d: round(mens_ha[d] + assurance, 2) for d in DUREES}
    duree = cas.projet.duree_souhaitee_annees
    revenus_pp: dict[str, float] = {}
    non_couverts: list[str] = []
    regles: dict[str, str] = {}
    for p in cas.personnes:
        r, couvert, regle = revenu_retenu(p, cas)
        revenus_pp[p.id] = r
        regles[p.id] = regle
        if not couvert:
            non_couverts.append(p.id)
    locatif = (
        round(cas.projet.loyers_attendus_mensuels * refs.LOYERS_RETENUS_PCT / 100, 2)
        if cas.projet.usage == "locatif"
        else 0.0
    )
    revenus = round(sum(revenus_pp.values()) + locatif, 2)
    revenus_std = round(sum(v for k, v in revenus_pp.items() if k not in non_couverts) + locatif, 2)
    credits = charges_credits(cas)
    loyer_conserve = cas.logement.loyer_mensuel if cas.projet.usage == "locatif" else 0.0  # CHG_LOYER
    charges = round(mens_ac[duree] + credits + loyer_conserve, 2)
    taux = round(charges / revenus * 100, 1) if revenus else 999.0
    taux_std = round(charges / revenus_std * 100, 1) if revenus_std else 999.0
    taux_par_duree = {
        d: (round((mens_ac[d] + credits + loyer_conserve) / revenus * 100, 1) if revenus else 999.0) for d in DUREES
    }
    rav = round(revenus - charges, 2)
    rav_min = refs.RESTE_A_VIVRE_PAR_ADULTE * cas.nb_adultes + refs.RESTE_A_VIVRE_PAR_ENFANT * cas.foyer.nb_enfants
    bloquant = bool(cas.pieges.salarie_sans_fiche) or revenus <= 0

    incidents_en_cours = any(not i.regularise for i in cas.incidents)
    verdicts: dict[str, str] = {
        "HCSF_TAUX_EFFORT": "DANS_LA_NORME" if taux <= refs.TAUX_EFFORT_MAX_HCSF else "HORS_NORME",
        "HCSF_DUREE": "DANS_LA_NORME" if duree <= refs.DUREE_MAX_HCSF else "HORS_NORME",
        "SEUIL_RESTE_A_VIVRE": "DANS_LA_NORME" if rav >= rav_min else "HORS_NORME",
        "SEUIL_APPORT": "DANS_LA_NORME" if cas.projet.apport >= frais else "HORS_NORME",
        "SEUIL_INCIDENTS": "HORS_NORME" if incidents_en_cours else "DANS_LA_NORME",
        "SEUIL_COMPTE": "HORS_NORME" if cas.pieges.releves_signaux else "DANS_LA_NORME",
    }
    for p in cas.personnes:
        if p.situation_pro == "cdi":
            verdicts["SEUIL_CDI"] = (
                "CAS_NON_COUVERT" if (p.id in non_couverts and regles[p.id] == "REV_SALAIRE") else "DANS_LA_NORME"
            )
        if p.situation_pro == "auto_entrepreneur":
            verdicts["SEUIL_INDEPENDANT"] = "CAS_NON_COUVERT" if p.id in non_couverts else "DANS_LA_NORME"
        if p.situation_pro == "retraite":
            verdicts["SEUIL_PENSION"] = "CAS_NON_COUVERT" if p.id in non_couverts else "DANS_LA_NORME"

    pieces_manquantes = [
        {"type": "fiche_paie", "personne": pid, "periode": per} for pid, per in cas.pieges.fiches_paie_manquantes
    ]
    for pid in cas.pieges.salarie_sans_fiche:
        pieces_manquantes += [{"type": "fiche_paie", "personne": pid, "periode": per} for per in cas.mois_fiches_paie]
    for t, pid in cas.pieges.piece_hors_periode:
        periode = str(cas.date_depot.year) if t == "avis_imposition" else ""
        pieces_manquantes.append({"type": t, "personne": pid, "periode": periode})
    illisibles = [(t, pid, per) for t, pid, per, q in cas.pieges.pieces_scannees if q == "illisible"]
    for t, pid, per in illisibles:
        pieces_manquantes.append({"type": t, "personne": pid, "periode": per})

    doutes: list[dict[str, Any]] = []
    moments: list[str] = []

    def doute(type_: str, moment: str, mots: list[str], question: str, **extra: Any) -> None:
        doutes.append({"type": type_, "mots_cles": mots, "question": question, **extra})
        moments.append(moment)

    for pid in cas.pieges.salaire_scinde:
        p = cas.personne(pid)
        recu = p.salaire_net_mensuel - p.part_salaire_autre_compte
        doute(
            "ECART_SALAIRE_RELEVES",
            "INCOHERENCE_ENTRE_SOURCES",
            ["salaire", "virement", "relev", f"{recu:.0f}", f"{recu:,.0f}".replace(",", " ")],
            f"Le net payé de {p.prenom} ({p.salaire_net_mensuel:.0f} €) ne correspond pas aux virements reçus ({recu:.0f} €) : où va la différence ?",
            personne=pid,
        )
    for pid in cas.pieges.avis_incoherent:
        p = cas.personne(pid)
        doute(
            "ECART_AVIS_FICHES",
            "INCOHERENCE_ENTRE_SOURCES",
            ["avis", "imposition", "fiche", "écart"],
            f"L'avis d'imposition de {p.prenom} ne correspond pas à ses fiches de paie (écart de plus de 10 %).",
            personne=pid,
        )
    for pid, per in cas.pieges.fiches_paie_manquantes:
        doute(
            "PIECE_MANQUANTE",
            "PIECE_MANQUANTE",
            ["fiche de paie", per, _mois_clair(per), "manqu"],
            f"Fiche de paie de {_mois_clair(per)} à demander à {cas.personne(pid).prenom}.",
            personne=pid,
            periode=per,
        )
    for t, pid in cas.pieges.piece_hors_periode:
        if t == "avis_imposition":
            mots = ["avis", "imposition", str(cas.date_depot.year), "manqu", "ancien", "dernier"]
            question = f"L'avis d'imposition {cas.date_depot.year} manque : seuls des avis plus anciens sont fournis."
        else:
            mots = ["quittance", "justificatif", "domicile", "ancien", "récent", "trois mois", "période"]
            question = "Le justificatif de domicile a plus de trois mois : en demander un récent."
        doute("PIECE_HORS_PERIODE", "PIECE_MANQUANTE", mots, question, personne=pid)
    for t, pid, per in illisibles:
        clair = _mois_clair(per) if len(per) == 7 else per
        doute(
            "PIECE_ILLISIBLE",
            "PIECE_MANQUANTE",
            ["illisible", "lisible", "copie", "ocr", "confiance", "incertain", clair],
            f"La pièce {t.replace('_', ' ')} de {clair} est illisible, même par OCR : en demander une copie lisible.",
            personne=pid,
            periode=per,
        )
    if cas.pieges.pieces_scannees:
        moments.append("CHANGEMENT_DE_METHODE")  # la lecture native échoue : l'agent doit passer à l'OCR
    for pid in cas.pieges.salarie_sans_fiche:
        doute(
            "REVENU_NON_ETABLI",
            "PIECE_MANQUANTE",
            ["fiche de paie", "aucune", "revenu"],
            f"Aucune fiche de paie de {cas.personne(pid).prenom} : son revenu ne peut pas être établi.",
            personne=pid,
            bloquant=True,
        )
    for pid, per in cas.pieges.prime_dans_le_net:
        doute(
            "PRIME_DANS_LE_NET",
            "CONTROLE_DU_CALCUL",
            ["prime", per, _mois_clair(per)],
            f"La fiche de paie de {_mois_clair(per)} de {cas.personne(pid).prenom} inclut une prime annuelle : à exclure du revenu mensuel.",
            personne=pid,
            periode=per,
        )
    for pid in cas.pieges.independant_recent:
        p = cas.personne(pid)
        doute(
            "CAS_NON_COUVERT_INDEPENDANT",
            "CONSCIENCE_DES_LIMITES",
            ["indépendant", "auto-entrepreneu", "exercice", "mois d'activité", "non couvert"],
            f"{p.prenom} est indépendant(e) depuis {p.mois_activite(cas.date_depot)} mois : la règle standard demande deux exercices complets.",
            personne=pid,
        )
    for p in cas.personnes:
        if p.situation_pro == "cdi" and p.id in non_couverts and regles[p.id] == "REV_SALAIRE":
            doute(
                "PERIODE_ESSAI",
                "CONSCIENCE_DES_LIMITES",
                ["période d'essai", "ancienneté", "cdi", "6 mois"],
                f"{p.prenom} est en CDI depuis moins de six mois : période d'essai, cas non couvert.",
                personne=p.id,
            )
        if p.situation_pro == "cdd" and regles[p.id] == "REV_EXCLUS":
            doute(
                "CDD_EXCLU",
                "CONSCIENCE_DES_LIMITES",
                ["cdd", "exclu", "retenu", "trois ans"],
                f"{p.prenom} est en CDD depuis moins de trois ans : ses revenus ne sont pas retenus par la règle standard.",
                personne=p.id,
            )
        if p.situation_pro == "retraite" and p.id in non_couverts:
            doute(
                "PENSION_RECENTE",
                "CONSCIENCE_DES_LIMITES",
                ["pension", "retraite", "deux ans", "non couvert", "récent"],
                f"{p.prenom} est à la retraite depuis moins de deux ans : la règle REV_PENSION demande deux ans d'ancienneté.",
                personne=p.id,
            )
    for cid in cas.pieges.releves_signaux:
        doute(
            "SIGNAUX_COMPTE",
            "INCOHERENCE_ENTRE_SOURCES",
            ["jeux", "découvert", "commission", "rejet", "paris"],
            f"Le compte {cid} montre des signaux d'alerte (mises de jeux en ligne, commission d'intervention).",
            compte=cid,
        )
    for i in cas.incidents:
        doute(
            "INCIDENT",
            "CONSCIENCE_DES_LIMITES",
            ["incident", "fichier", i.type.replace("_", " ")],
            f"Un incident ({i.type}) figure au fichier pour {cas.personne(i.personne).prenom}{' (régularisé)' if i.regularise else ' (en cours)'}.",
            personne=i.personne,
        )

    reserves: list[str] = []
    if non_couverts:
        reserves.append("REVENUS_NON_COUVERTS")
    if pieces_manquantes:
        reserves.append("PIECE_MANQUANTE")
    if cas.pieges.salaire_scinde or cas.pieges.avis_incoherent:
        reserves.append("ECART_SALAIRE_A_CONFIRMER")
    if any(i.regularise for i in cas.incidents) and not incidents_en_cours:
        reserves.append("INCIDENT_REGULARISE")
    hors_norme = [k for k, v in verdicts.items() if v == "HORS_NORME"]
    if bloquant:
        recommandation = "NE_SE_PRONONCE_PAS"
    elif incidents_en_cours or taux > TAUX_EFFORT_DEFAVORABLE:
        recommandation = "DEFAVORABLE"
    elif hors_norme or reserves or any(v == "CAS_NON_COUVERT" for v in verdicts.values()):
        recommandation = "FAVORABLE_SOUS_RESERVES"
        reserves += [f"HORS_NORME_{k}" for k in hors_norme]
    else:
        recommandation = "FAVORABLE"

    faits: dict[str, float] = {
        "prix_bien": cas.projet.prix,
        "honoraires_agence": cas.projet.honoraires_agence_inclus,
        "frais_acquisition": frais,
        "apport": cas.projet.apport,
        "montant_emprunte": capital,
        "credits_en_cours_mensualites": credits,
        "loyer_actuel": cas.logement.loyer_mensuel,
        "epargne_totale": round(sum(e.solde for e in cas.epargnes), 2),
    }
    for p in cas.personnes:
        if p.salaire_net_mensuel is not None and p.id not in cas.pieges.salarie_sans_fiche:
            faits[f"{'pension_mensuelle' if p.situation_pro == 'retraite' else 'net_mensuel'}_{p.id}"] = (
                p.salaire_net_mensuel
            )
            for per in cas.mois_fiches_paie if p.situation_pro in ("cdi", "cdd") else []:
                if (p.id, per) in cas.pieges.fiches_paie_manquantes or ("fiche_paie", p.id, per) in illisibles:
                    continue
                net = p.salaire_net_mensuel + (p.prime_annuelle if (p.id, per) in cas.pieges.prime_dans_le_net else 0)
                faits[f"net_paye_{p.id}_{per.replace('-', '_')}"] = net
            if p.prime_annuelle:
                faits[f"prime_annuelle_{p.id}"] = p.prime_annuelle
        if p.ca_mensuels:
            valeurs = [p.ca_mensuels[m] for m in sorted(p.ca_mensuels)][-24:]
            faits[f"ca_mensuel_moyen_{p.id}"] = round(sum(valeurs) / len(valeurs), 2)
        faits[f"revenu_retenu_{p.id}"] = revenus_pp[p.id]
    if cas.projet.usage == "locatif":
        faits["loyers_attendus"] = cas.projet.loyers_attendus_mensuels
        faits["revenus_locatifs_retenus"] = locatif
    return Attendu(
        demande_id=cas.demande_id,
        scenario=cas.scenario,
        difficulte=cas.difficulte,
        lot=cas.lot,
        prix=cas.projet.prix,
        honoraires_agence=cas.projet.honoraires_agence_inclus,
        frais_acquisition=frais,
        apport=cas.projet.apport,
        montant_emprunte=capital,
        duree_souhaitee_annees=duree,
        taux_nominal_pct=refs.taux_pour_duree(duree),
        assurance_mensuelle=assurance,
        mensualites_hors_assurance=mens_ha,
        mensualites_assurance_comprise=mens_ac,
        revenus_par_personne=revenus_pp,
        revenus_locatifs_retenus=locatif,
        revenus_non_couverts=non_couverts,
        revenus_retenus=revenus,
        revenus_retenus_standard=revenus_std,
        charges_credits=credits,
        charges_retenues=charges,
        taux_effort=taux,
        taux_effort_standard=taux_std,
        taux_effort_par_duree=taux_par_duree,
        reste_a_vivre=rav,
        reste_a_vivre_minimum=rav_min,
        verdicts=verdicts,
        recommandation=recommandation,
        reserves=reserves,
        pieces_manquantes=pieces_manquantes,
        doutes_attendus=doutes,
        moments=moments,
        faits=faits,
        bloquant=bloquant,
        pieces_scannees=[
            {"type": t, "personne": pid, "periode": per, "qualite": q} for t, pid, per, q in cas.pieges.pieces_scannees
        ],
    )
