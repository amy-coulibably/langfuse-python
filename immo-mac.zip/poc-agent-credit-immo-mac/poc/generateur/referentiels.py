"""Lecture des référentiels chiffrés (`referentiels/*.csv`) : barème des taux, assurance, frais d'acquisition. Le générateur
(vérité terrain) et, au lot 2, l'outil `consulter_bareme` lisent les mêmes fichiers."""

from __future__ import annotations

from functools import lru_cache
from pathlib import Path

import polars as pl

from poc.config import REFERENTIELS_DIR


@lru_cache(maxsize=8)
def _csv(nom: str, dossier: str) -> pl.DataFrame:
    chemin = Path(dossier) / nom
    if not chemin.exists():
        raise FileNotFoundError(f"référentiel absent : {chemin}")
    return pl.read_csv(chemin)


def bareme_taux(dossier: Path = REFERENTIELS_DIR) -> dict[int, float]:
    df = _csv("bareme_taux.csv", str(dossier))
    return {int(r["duree_annees"]): float(r["taux_nominal_pct"]) for r in df.to_dicts()}


def taux_pour_duree(annees: int, dossier: Path = REFERENTIELS_DIR) -> float:
    bareme = bareme_taux(dossier)
    if annees in bareme:
        return bareme[annees]
    raise ValueError(f"aucun taux au barème pour {annees} ans (durées : {sorted(bareme)})")


def taux_assurance(age: int, dossier: Path = REFERENTIELS_DIR) -> float:
    """Taux annuel (en %) du barème d'assurance pour un âge."""
    for r in _csv("assurance.csv", str(dossier)).to_dicts():
        if int(r["age_min"]) <= age <= int(r["age_max"]):
            return float(r["taux_annuel_pct"])
    raise ValueError(f"aucun taux d'assurance pour {age} ans")


def taux_frais_notaire(type_bien: str, dossier: Path = REFERENTIELS_DIR) -> float:
    for r in _csv("frais_notaire.csv", str(dossier)).to_dicts():
        if r["type_bien"] == type_bien:
            return float(r["taux_pct"])
    raise ValueError(f"type de bien inconnu : {type_bien}")


def lire_referentiel_texte(nom: str, dossier: Path = REFERENTIELS_DIR) -> str:
    chemin = Path(dossier) / (nom if nom.endswith(".md") else f"{nom}.md")
    if not chemin.exists():
        raise FileNotFoundError(f"référentiel absent : {chemin}")
    return chemin.read_text(encoding="utf-8")


# ---- les seuils de la politique maison, repris de referentiels/politique_credit.md ----------------------------------------------
RESTE_A_VIVRE_PAR_ADULTE = 1000.0
RESTE_A_VIVRE_PAR_ENFANT = 400.0
EXERCICES_MINIMUM_INDEPENDANT = 24  # mois
CDI_PERIODE_ESSAI_MOIS = 6
CREDIT_FIN_PROCHE_MOIS = 6  # un crédit qui se termine dans moins de six mois n'est pas compté
TAUX_EFFORT_MAX_HCSF = 35.0
TAUX_EFFORT_DEFAVORABLE = 45.0  # au-delà, même tous revenus retenus : recommandation défavorable
CDD_ANCIENNETE_MOIS = 36  # un CDD de moins de trois ans n'est pas retenu
PENSION_ANCIENNETE_MOIS = 24  # une pension liquidée depuis moins de deux ans : cas non couvert
AVIS_ECART_MAX_PCT = 10.0  # au-delà, l'écart avis d'imposition / fiches de paie devient un doute
LOYERS_RETENUS_PCT = 70.0
DUREE_MAX_HCSF = 25
ABATTEMENTS = {"micro_bnc": 34.0, "micro_bic_services": 50.0, "micro_bic_vente": 71.0}


def constantes_des_regles() -> dict[str, float]:
    """Les seuils et taux des règles, citables dans une synthèse sous le type « regle » (nom → valeur)."""
    out: dict[str, float] = {
        "HCSF_TAUX_EFFORT_MAX": TAUX_EFFORT_MAX_HCSF,
        "HCSF_DUREE_MAX": float(DUREE_MAX_HCSF),
        "HCSF_DUREE_MAX_DIFFERE": 27.0,
        "HCSF_MARGE_DEROGATION": 20.0,
        "RESTE_A_VIVRE_PAR_ADULTE": RESTE_A_VIVRE_PAR_ADULTE,
        "RESTE_A_VIVRE_PAR_ENFANT": RESTE_A_VIVRE_PAR_ENFANT,
        "EXERCICES_MINIMUM_INDEPENDANT": float(EXERCICES_MINIMUM_INDEPENDANT),
        "CDI_PERIODE_ESSAI_MOIS": float(CDI_PERIODE_ESSAI_MOIS),
        "CREDIT_FIN_PROCHE_MOIS": float(CREDIT_FIN_PROCHE_MOIS),
        "LOYERS_RETENUS_PCT": LOYERS_RETENUS_PCT,
        "TAUX_EFFORT_DEFAVORABLE": TAUX_EFFORT_DEFAVORABLE,
        "CDD_ANCIENNETE_MOIS": float(CDD_ANCIENNETE_MOIS),
        "PENSION_ANCIENNETE_MOIS": float(PENSION_ANCIENNETE_MOIS),
        "AVIS_ECART_MAX_PCT": AVIS_ECART_MAX_PCT,
    }
    for regime, pct in ABATTEMENTS.items():
        out[f"ABATTEMENT_{regime.upper()}"] = pct
    try:
        for duree, taux in bareme_taux().items():
            out[f"TAUX_NOMINAL_{duree}_ANS"] = taux
        for r in _csv("frais_notaire.csv", str(REFERENTIELS_DIR)).to_dicts():
            out[f"FRAIS_ACQUISITION_{str(r['type_bien']).upper()}_PCT"] = float(r["taux_pct"])
    except FileNotFoundError:
        pass
    return out
