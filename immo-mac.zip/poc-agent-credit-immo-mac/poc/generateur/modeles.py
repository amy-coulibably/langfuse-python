"""La description d'un cas : ce que nous savons être vrai d'un foyer, de son projet et des pièges que nous y avons posés.

C'est la **vérité terrain** à l'état brut. Le générateur en tire ce que l'agent verra (pièces PDF, système bancaire
simulé, fichier d'incidents) et ce que l'évaluation attend (revenus à retenir, taux d'effort, doutes, recommandation).
Tout est déclaratif et lisible : un cas se relit comme une fiche de situation.
"""

from __future__ import annotations

import datetime as dt
from typing import Literal

from pydantic import BaseModel, Field

SituationPro = Literal["cdi", "cdd", "auto_entrepreneur", "retraite"]


class Personne(BaseModel):
    id: str = Field(description="Identifiant court : thomas, marie…")
    prenom: str
    nom: str
    date_naissance: dt.date
    lieu_naissance: str
    role: Literal["emprunteur", "co_emprunteur"]
    situation_pro: SituationPro
    # salarié
    employeur: str | None = None
    poste: str | None = None
    date_entree: dt.date | None = None
    salaire_net_mensuel: float | None = Field(
        default=None, description="Net payé mensuel courant (ce qui arrive sur le compte)"
    )
    net_imposable_mensuel: float | None = None
    prime_annuelle: float = 0.0
    mois_prime: int | None = Field(default=None, description="Mois de versement de la prime annuelle (1-12)")
    compte_salaire: str | None = Field(default=None, description="Compte qui reçoit le salaire")
    part_salaire_autre_compte: float = Field(
        default=0.0, description="Part du net virée sur un autre compte (piège « virement scindé »)"
    )
    compte_salaire_secondaire: str | None = None
    # indépendant
    activite: str | None = None
    debut_activite: dt.date | None = None
    regime: str | None = Field(default=None, description="micro_bnc, micro_bic_services, micro_bic_vente")
    abattement_pct: float | None = None
    ca_mensuels: dict[str, float] = Field(
        default_factory=dict, description="Chiffre d'affaires encaissé par mois, AAAA-MM"
    )
    compte_pro: str | None = None
    compte_perso: str | None = None
    remuneration_mensuelle: float | None = Field(
        default=None, description="Virement mensuel du compte pro vers le compte perso"
    )

    def age(self, a_la_date: dt.date) -> int:
        return (
            a_la_date.year
            - self.date_naissance.year
            - ((a_la_date.month, a_la_date.day) < (self.date_naissance.month, self.date_naissance.day))
        )

    @property
    def nom_complet(self) -> str:
        return f"{self.prenom} {self.nom.upper()}"

    def mois_activite(self, a_la_date: dt.date) -> int | None:
        if self.debut_activite is None:
            return None
        return (a_la_date.year - self.debut_activite.year) * 12 + a_la_date.month - self.debut_activite.month


class Foyer(BaseModel):
    situation_familiale: Literal["pacses", "maries", "concubins", "celibataire"]
    depuis: dt.date | None = None
    nb_enfants: int = 0
    adresse: str
    code_postal: str
    ville: str


class Projet(BaseModel):
    type_bien: Literal["ancien", "neuf"]
    usage: Literal["residence_principale", "locatif"]
    description_bien: str
    adresse_bien: str
    prix: float = Field(description="Prix de vente, honoraires d'agence inclus")
    honoraires_agence_inclus: float = 0.0
    apport: float
    duree_souhaitee_annees: int
    loyers_attendus_mensuels: float = Field(
        default=0.0, description="Projet locatif : loyer mensuel attendu (la politique maison en retient 70 %)"
    )
    date_compromis: dt.date
    date_limite_pret: dt.date
    vendeur: str
    agence: str
    notaire: str


class Compte(BaseModel):
    id: str
    titulaires: list[str]
    banque: str
    chez_nous: bool = Field(
        description="Vrai si le compte est tenu dans notre banque (visible par le système d'information)"
    )
    type: Literal["courant", "pro", "joint"]
    iban_masque: str
    solde_debut: float = Field(description="Solde au premier jour du premier mois de relevés")


class Epargne(BaseModel):
    id: str
    titulaire: str
    type: Literal["livret_a", "ldds", "assurance_vie", "pel"]
    banque: str
    chez_nous: bool
    solde: float
    disponible: bool = True


class Credit(BaseModel):
    id: str
    titulaire: str
    type: Literal["auto", "consommation", "renouvelable", "immobilier"]
    organisme: str
    chez_nous: bool
    date_debut: dt.date
    date_fin: dt.date
    mensualite: float
    capital_restant: float
    taux_pct: float
    compte_prelevement: str


class Logement(BaseModel):
    loyer_mensuel: float
    charges_incluses: bool
    bailleur: str
    compte_prelevement: str


class Incident(BaseModel):
    personne: str
    type: Literal["cheque_sans_provision", "retard_credit", "surendettement"]
    date: dt.date
    montant: float
    regularise: bool
    date_regularisation: dt.date | None = None


class Pieges(BaseModel):
    """Les quatre moments de réflexivité se fabriquent ici ; un cas « facile » a tous ces champs vides."""

    fiches_paie_manquantes: list[tuple[str, str]] = Field(default_factory=list, description="(personne, AAAA-MM)")
    prime_dans_le_net: list[tuple[str, str]] = Field(
        default_factory=list, description="(personne, AAAA-MM) : la fiche de ce mois inclut la prime annuelle"
    )
    salaire_scinde: list[str] = Field(
        default_factory=list, description="personnes dont le salaire arrive sur deux comptes"
    )
    independant_recent: list[str] = Field(
        default_factory=list, description="personnes indépendantes depuis moins de deux exercices"
    )
    releves_signaux: list[str] = Field(
        default_factory=list, description="comptes avec signaux d'alerte (découverts répétés, jeux en ligne…)"
    )
    piece_hors_periode: list[tuple[str, str]] = Field(
        default_factory=list, description="(type de pièce, personne) fournie trop ancienne"
    )
    avis_incoherent: list[str] = Field(
        default_factory=list,
        description="personnes dont l'avis d'imposition s'écarte des fiches de paie de plus de 10 %",
    )
    pieces_scannees: list[tuple[str, str, str, str]] = Field(
        default_factory=list,
        description="(type de pièce, personne ou '', période ou '', qualité) : la pièce est déposée numérisée. Qualité : "
        "scan (PDF sans couche texte, lisible par OCR), photo (image JPG, lisible par OCR), illisible (scan trop dégradé)",
    )
    salarie_sans_fiche: list[str] = Field(
        default_factory=list,
        description="salariés dont aucune fiche de paie n'est déposée (revenu non établi, bloquant)",
    )


class Cas(BaseModel):
    demande_id: str
    scenario: str = Field(description="Nom court du scénario : fil_rouge, couple_cdi_sain, independant_etabli…")
    difficulte: int = Field(ge=1, le=5)
    lot: Literal["facile", "reglage", "scelle"] = Field(
        default="reglage",
        description="facile : aucun piège, pour vérifier le chemin nominal ; reglage : sert à améliorer l'agent ; "
        "scelle : jamais regardé pendant le réglage, mesure la généralisation",
    )
    description: str
    date_depot: dt.date
    mois_releves: list[str] = Field(description="Les mois de relevés fournis, AAAA-MM, du plus ancien au plus récent")
    foyer: Foyer
    personnes: list[Personne]
    projet: Projet
    comptes: list[Compte]
    epargnes: list[Epargne]
    credits: list[Credit]
    logement: Logement
    pieges: Pieges = Field(default_factory=Pieges)
    incidents: list[Incident] = Field(default_factory=list)

    def personne(self, id_: str) -> Personne:
        for p in self.personnes:
            if p.id == id_:
                return p
        raise KeyError(id_)

    def compte(self, id_: str) -> Compte:
        for c in self.comptes:
            if c.id == id_:
                return c
        raise KeyError(id_)

    @property
    def nb_adultes(self) -> int:
        return len(self.personnes)

    @property
    def mois_fiches_paie(self) -> list[str]:
        """Les trois mois de fiches de paie attendus : les trois mois précédant le mois de dépôt."""
        return self.mois_releves[-3:]

    @property
    def annees_avis(self) -> list[int]:
        """Les deux derniers avis d'imposition attendus (année d'émission)."""
        return [self.date_depot.year - 1, self.date_depot.year]
