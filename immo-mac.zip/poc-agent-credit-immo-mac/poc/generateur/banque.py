"""Le système d'information de la banque, en miniature (`banque.sqlite`), et le fichier d'incidents simulé
(`incidents.sqlite`), écrits à partir d'un cas.

La banque ne connaît que ce qu'une banque connaît : ses clients, les comptes tenus chez elle et leurs mouvements, ses
propres crédits et livrets, et ce que le client a déclaré dans sa demande. Le compte joint tenu dans une autre banque et
le crédit auto souscrit ailleurs n'y figurent pas : ils n'existent que dans les pièces déposées et dans la déclaration du
client. C'est voulu, et c'est ce qui rend le recoupement nécessaire.

Tables : banque_demande, banque_demande_credit_declare, banque_client, banque_emprunteur, banque_compte, banque_mouvement,
banque_credit_en_cours, banque_epargne ; incidents_incident.
"""

from __future__ import annotations

import polars as pl

from poc.config import Config
from poc.donnees import SQLiteStore
from poc.generateur.modeles import Cas

SCHEMA_CREDIT_DECLARE = {
    "demande_id": pl.Utf8,
    "client_id": pl.Utf8,
    "type": pl.Utf8,
    "organisme": pl.Utf8,
    "mensualite_declaree": pl.Float64,
    "date_fin_declaree": pl.Utf8,
}
CLIENT_DEPUIS_FIL_ROUGE = {"thomas": "2015-09-01", "marie": "2018-02-14"}


def client_depuis(cas: Cas, personne_id: str) -> str:
    """Depuis quand la personne est cliente : fixé pour le fil rouge, déterministe (entre 2008 et 2024) pour le catalogue."""
    if cas.scenario == "fil_rouge" and personne_id in CLIENT_DEPUIS_FIL_ROUGE:
        return CLIENT_DEPUIS_FIL_ROUGE[personne_id]
    import random

    rng = random.Random(f"client:{cas.demande_id}:{personne_id}")
    return f"{rng.randint(2008, 2024)}-{rng.randint(1, 12):02d}-{rng.randint(1, 28):02d}"


def client_id(cas: Cas, personne_id: str) -> str:
    return f"CLI-{cas.demande_id[-4:]}-{personne_id.upper()}"


def _remplacer(
    store: SQLiteStore, table: str, lignes: list[dict], cle: str, valeur: str, schema: dict | None = None
) -> None:
    df = pl.DataFrame(lignes, schema_overrides=schema) if lignes else pl.DataFrame(schema=schema or {})
    if not lignes and not store.existe(table):
        store.ecrire(table, df)
        return
    if lignes:
        store.remplacer(table, df, cle, valeur)


def ecrire_banque(config: Config, cas: Cas, releves: dict[str, list[dict]]) -> None:
    store = SQLiteStore(config.sqlite_banque)
    d = cas.demande_id
    p = cas.projet
    _remplacer(
        store,
        "banque_demande",
        [
            {
                "demande_id": d,
                "date_depot": cas.date_depot.isoformat(),
                "usage": p.usage,
                "type_bien": p.type_bien,
                "description_bien": p.description_bien,
                "adresse_bien": p.adresse_bien,
                "prix": p.prix,
                "honoraires_agence_inclus": p.honoraires_agence_inclus,
                "apport": p.apport,
                "duree_souhaitee_annees": p.duree_souhaitee_annees,
                "date_compromis": p.date_compromis.isoformat(),
                "date_limite_pret": p.date_limite_pret.isoformat(),
                "situation_familiale": cas.foyer.situation_familiale,
                "nb_enfants": cas.foyer.nb_enfants,
                "loyer_actuel_declare": cas.logement.loyer_mensuel,
                "loyers_attendus_declares": p.loyers_attendus_mensuels,
                "statut": "DEPOSEE",
            }
        ],
        "demande_id",
        d,
    )
    _remplacer(
        store,
        "banque_demande_credit_declare",
        [
            {
                "demande_id": d,
                "client_id": client_id(cas, c.titulaire),
                "type": c.type,
                "organisme": c.organisme,
                "mensualite_declaree": c.mensualite,
                "date_fin_declaree": c.date_fin.isoformat(),
            }
            for c in cas.credits
        ],
        "demande_id",
        d,
        SCHEMA_CREDIT_DECLARE,  # schéma complet : la table doit exister avec ses colonnes même sans aucun crédit déclaré
    )
    clients = []
    emprunteurs = []
    for pers in cas.personnes:
        cid = client_id(cas, pers.id)
        clients.append(
            {
                "client_id": cid,
                "prenom": pers.prenom,
                "nom": pers.nom,
                "date_naissance": pers.date_naissance.isoformat(),
                "situation_familiale": cas.foyer.situation_familiale,
                "nb_enfants": cas.foyer.nb_enfants,
                "adresse": f"{cas.foyer.adresse}, {cas.foyer.code_postal} {cas.foyer.ville}",
                "situation_pro": pers.situation_pro,
                "employeur": pers.employeur,
                "poste": pers.poste,
                "date_entree": pers.date_entree.isoformat() if pers.date_entree else None,
                "activite": pers.activite,
                "debut_activite": pers.debut_activite.isoformat() if pers.debut_activite else None,
                "client_depuis": client_depuis(cas, pers.id),
            }
        )
        emprunteurs.append({"demande_id": d, "client_id": cid, "role": pers.role})
    for c in clients:
        _remplacer(store, "banque_client", [c], "client_id", c["client_id"])
    _remplacer(store, "banque_emprunteur", emprunteurs, "demande_id", d)

    comptes = []
    mouvements = []
    for compte in cas.comptes:
        if not compte.chez_nous:
            continue
        mois = releves[compte.id]
        comptes.append(
            {
                "compte_id": compte.id,
                "client_ids": ",".join(client_id(cas, t) for t in compte.titulaires),
                "type": compte.type,
                "iban_masque": compte.iban_masque,
                "solde": mois[-1]["solde_fin"],
                "date_solde": f"{mois[-1]['mois']}-{_dernier_jour(mois[-1]['mois']):02d}",
            }
        )
        for m in mois:
            for ligne in m["lignes"]:
                mouvements.append(
                    {
                        "compte_id": compte.id,
                        "date": ligne["date"].isoformat(),
                        "libelle": ligne["libelle"],
                        "montant": ligne["montant"],
                        "solde_apres": ligne["solde_apres"],
                    }
                )
    for c in comptes:
        _remplacer(store, "banque_compte", [c], "compte_id", c["compte_id"])
        _remplacer(
            store,
            "banque_mouvement",
            [m for m in mouvements if m["compte_id"] == c["compte_id"]],
            "compte_id",
            c["compte_id"],
        )
    credits = [
        {
            "credit_id": c.id,
            "client_id": client_id(cas, c.titulaire),
            "type": c.type,
            "organisme": c.organisme,
            "date_debut": c.date_debut.isoformat(),
            "date_fin": c.date_fin.isoformat(),
            "mensualite": c.mensualite,
            "capital_restant": c.capital_restant,
            "taux_pct": c.taux_pct,
        }
        for c in cas.credits
        if c.chez_nous
    ]
    schema_credit = {"mensualite": pl.Float64, "capital_restant": pl.Float64, "taux_pct": pl.Float64}
    if credits:
        for c in credits:
            _remplacer(store, "banque_credit_en_cours", [c], "credit_id", c["credit_id"], schema_credit)
    elif not store.existe("banque_credit_en_cours"):
        store.ecrire(
            "banque_credit_en_cours",
            pl.DataFrame(
                schema={
                    "credit_id": pl.Utf8,
                    "client_id": pl.Utf8,
                    "type": pl.Utf8,
                    "organisme": pl.Utf8,
                    "date_debut": pl.Utf8,
                    "date_fin": pl.Utf8,
                    **schema_credit,
                }
            ),
        )
    for e in cas.epargnes:
        if e.chez_nous:
            _remplacer(
                store,
                "banque_epargne",
                [
                    {
                        "epargne_id": e.id,
                        "client_id": client_id(cas, e.titulaire),
                        "type": e.type,
                        "solde": e.solde,
                        "date_solde": f"{cas.mois_releves[-1]}-{_dernier_jour(cas.mois_releves[-1]):02d}",
                        "disponible": int(e.disponible),
                    }
                ],
                "epargne_id",
                e.id,
            )


def ecrire_incidents(config: Config, cas: Cas) -> None:
    store = SQLiteStore(config.sqlite_incidents)
    schema = {
        "demande_id": pl.Utf8,
        "nom": pl.Utf8,
        "prenom": pl.Utf8,
        "date_naissance": pl.Utf8,
        "type": pl.Utf8,
        "date": pl.Utf8,
        "montant": pl.Float64,
        "regularise": pl.Int64,
        "date_regularisation": pl.Utf8,
    }
    lignes = []
    for i in cas.incidents:
        p = cas.personne(i.personne)
        lignes.append(
            {
                "demande_id": cas.demande_id,
                "nom": p.nom,
                "prenom": p.prenom,
                "date_naissance": p.date_naissance.isoformat(),
                "type": i.type,
                "date": i.date.isoformat(),
                "montant": i.montant,
                "regularise": int(i.regularise),
                "date_regularisation": i.date_regularisation.isoformat() if i.date_regularisation else None,
            }
        )
    if lignes:
        store.remplacer(
            "incidents_incident", pl.DataFrame(lignes, schema_overrides=schema), "demande_id", cas.demande_id
        )
    elif not store.existe("incidents_incident"):
        store.ecrire("incidents_incident", pl.DataFrame(schema=schema))


def _dernier_jour(mois: str) -> int:
    from calendar import monthrange

    annee, m = (int(x) for x in mois.split("-"))
    return monthrange(annee, m)[1]
