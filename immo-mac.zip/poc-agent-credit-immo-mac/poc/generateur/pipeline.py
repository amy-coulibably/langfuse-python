"""Du cas aux données : vérité terrain, pièces, banque, incidents. `generer_demande` traite un cas ; `generer_tout` les
cinquante cas (fil rouge et catalogue). Rejouable à l'identique : tout est déterministe."""

from __future__ import annotations

import json

import polars as pl

from poc.config import Config
from poc.donnees import SQLiteStore
from poc.generateur.attendu import Attendu, calculer_attendu
from poc.generateur.banque import ecrire_banque, ecrire_incidents
from poc.generateur.fil_rouge import tous_les_cas
from poc.generateur.modeles import Cas
from poc.generateur.mouvements import releves_du_cas
from poc.generateur.pieces import generer_pieces


def ecrire_verite_terrain(config: Config, cas: Cas, attendu: Attendu, inventaire: list[dict]) -> None:
    store = SQLiteStore(config.sqlite_verite_terrain)
    d = cas.demande_id
    store.remplacer(
        "vt_cas",
        pl.DataFrame(
            [
                {
                    "demande_id": d,
                    "scenario": cas.scenario,
                    "difficulte": cas.difficulte,
                    "lot": cas.lot,
                    "description": cas.description,
                    "cas_json": cas.model_dump_json(),
                }
            ]
        ),
        "demande_id",
        d,
    )
    simple = {
        k: v for k, v in attendu.model_dump().items() if isinstance(v, (str, int, float)) and not isinstance(v, bool)
    }
    complexe = {k: v for k, v in attendu.model_dump().items() if k not in simple}
    store.remplacer(
        "vt_attendu",
        pl.DataFrame([{**simple, "attendu_json": json.dumps(complexe, ensure_ascii=False, default=str)}]),
        "demande_id",
        d,
    )
    store.remplacer(
        "vt_faits",
        pl.DataFrame(
            [{"demande_id": d, "nom": k, "valeur": float(v)} for k, v in attendu.faits.items()],
            schema_overrides={"valeur": pl.Float64},
        ),
        "demande_id",
        d,
    )
    doutes = [
        {
            "demande_id": d,
            "type": x["type"],
            "personne": x.get("personne"),
            "periode": x.get("periode"),
            "mots_cles": json.dumps(x["mots_cles"], ensure_ascii=False),
            "question": x["question"],
        }
        for x in attendu.doutes_attendus
    ]
    if doutes:
        store.remplacer("vt_doutes", pl.DataFrame(doutes), "demande_id", d)
    verdicts = [{"demande_id": d, "regle": k, "verdict": v} for k, v in attendu.verdicts.items()]
    store.remplacer("vt_verdicts", pl.DataFrame(verdicts), "demande_id", d)
    store.remplacer(
        "vt_pieces",
        pl.DataFrame(
            [
                {
                    "demande_id": d,
                    "piece_id": p["piece_id"],
                    "type": p["type"],
                    "personne": p["personne"],
                    "periode": p["periode"],
                    "fichier": p["fichier"],
                }
                for p in inventaire
            ]
        ),
        "demande_id",
        d,
    )


def generer_demande(config: Config, cas: Cas) -> Attendu:
    config.data_dir.mkdir(parents=True, exist_ok=True)
    attendu = calculer_attendu(cas)
    releves = releves_du_cas(cas)
    ecrire_banque(config, cas, releves)
    ecrire_incidents(config, cas)
    inventaire = generer_pieces(config, cas, releves)
    completer_avec_score(config, attendu)
    ecrire_verite_terrain(config, cas, attendu, inventaire)
    return attendu


def completer_avec_score(config: Config, attendu: Attendu) -> None:
    """Le score que l'API de la banque donnera à l'agent, et s'il contredit nettement l'analyse attendue : un A sur un
    dossier qui n'est pas favorable sans réserve, un A ou un B sur un dossier défavorable ou sur lequel l'agent ne peut pas
    se prononcer, un D ou un E sur un dossier sain."""
    from poc.services.scoring import ServiceScoring

    s = ServiceScoring(config).score(attendu.demande_id)
    attendu.score_banque = float(s["score"])
    attendu.classe_score = s["classe"]
    reco, classe = attendu.recommandation, s["classe"]
    attendu.score_diverge = (
        (classe == "A" and reco != "FAVORABLE")
        or (classe in ("A", "B") and reco in ("DEFAVORABLE", "NE_SE_PRONONCE_PAS"))
        or (classe in ("D", "E") and reco == "FAVORABLE")
    )
    if attendu.score_diverge and "SCORE_RELATIVISE" not in attendu.moments:
        attendu.moments.append("SCORE_RELATIVISE")


def generer_tout(config: Config, demandes: list[str] | None = None) -> list[Attendu]:
    """Génère tous les dossiers du catalogue, ou seulement ceux dont l'identifiant est donné (tests, démonstration rapide)."""
    cas = tous_les_cas()
    if demandes is not None:
        cas = [c for c in cas if c.demande_id in set(demandes)]
    return [generer_demande(config, c) for c in cas]


def catalogue(config: Config) -> list[dict]:
    """Le catalogue tel qu'il est généré : identifiant, scénario, lot, difficulté, description, recommandation attendue."""
    store = SQLiteStore(config.sqlite_verite_terrain)
    if not config.sqlite_verite_terrain.exists() or not store.existe("vt_cas"):
        return []
    return store.requete(
        "SELECT c.demande_id, c.scenario, c.lot, c.difficulte, c.description, a.recommandation, a.taux_effort, a.montant_emprunte "
        "FROM vt_cas c JOIN vt_attendu a ON a.demande_id = c.demande_id ORDER BY c.demande_id"
    ).to_dicts()


def attendu_de(config: Config, demande_id: str) -> Attendu | None:
    store = SQLiteStore(config.sqlite_verite_terrain)
    if not store.existe("vt_attendu"):
        return None
    rows = store.requete("SELECT * FROM vt_attendu WHERE demande_id = ?", (demande_id,)).to_dicts()
    if not rows:
        return None
    r = rows[0]
    complexe = json.loads(r.pop("attendu_json"))
    for cle in ("mensualites_hors_assurance", "mensualites_assurance_comprise", "taux_effort_par_duree"):
        complexe[cle] = {int(k): v for k, v in complexe[cle].items()}
    return Attendu(**r, **complexe)


def cas_de(config: Config, demande_id: str) -> Cas | None:
    store = SQLiteStore(config.sqlite_verite_terrain)
    if not store.existe("vt_cas"):
        return None
    rows = store.requete("SELECT cas_json FROM vt_cas WHERE demande_id = ?", (demande_id,)).to_dicts()
    return Cas.model_validate_json(rows[0]["cas_json"]) if rows else None


def demandes_disponibles(config: Config) -> list[str]:
    store = SQLiteStore(config.sqlite_banque)
    if not config.sqlite_banque.exists() or not store.existe("banque_demande"):
        return []
    return store.requete("SELECT demande_id FROM banque_demande ORDER BY demande_id")["demande_id"].to_list()
