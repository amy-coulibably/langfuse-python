"""Le catalogue : quarante-neuf dossiers qui, avec le fil rouge, font les cinquante dossiers du POC.

Chaque dossier est une **recette** lisible (`RECETTES`, plus bas) : la composition du foyer, la situation de chacun, le
projet, les crédits en cours et les pièges posés. Le constructeur (`construire_cas`) transforme la recette en un cas complet
(noms fictifs, dates, comptes, épargne, relevés) de façon déterministe : deux exécutions donnent les mêmes dossiers à l'euro.

Les revenus sont **calés sur le résultat voulu** : chaque recette fixe un taux d'effort cible (ou un reste à vivre cible),
le constructeur en déduit les salaires, pensions ou chiffres d'affaires. Ainsi le catalogue couvre, à dessein, les quatre
recommandations possibles et chacun des verdicts de la politique maison.

Trois lots :

- **facile** (dix dossiers, DEM-0002 à DEM-0011) : aucun piège, tout dans la norme ; ils vérifient le chemin nominal dans
  des situations variées (célibataire, famille, retraités, indépendant établi, CDD ancien, neuf, locatif) ;
- **réglage** (trente-quatre dossiers, DEM-0012 à DEM-0045) : un à trois pièges chacun ; ce sont eux que l'on regarde pour
  améliorer les fiches et l'outillage ;
- **scellé** (cinq dossiers, DEM-0046 à DEM-0050) : jamais regardés pendant le réglage ; ils mesurent ce que l'agent a
  réellement appris, et non ce qu'on lui a appris par cœur.

Les dimensions combinées sont celles du cadrage : situation professionnelle (CDI, CDI en période d'essai, CDD ancien ou
récent, indépendant établi ou récent, retraité de longue date ou récent), foyer (une ou deux personnes, zéro à trois
enfants), projet (ancien ou neuf, résidence principale ou locatif, trois durées), apport (normal, insuffisant, fort), crédits
en cours (aucun, auto, consommation, renouvelable, un crédit qui se termine bientôt), pièces (manquante, hors période,
aucune fiche de paie), incohérence (salaire scindé, avis d'imposition en écart), comportement de compte (signaux d'alerte),
incidents (régularisé, en cours), résultat attendu.
"""

from __future__ import annotations

import datetime as dt
import random
import unicodedata
from dataclasses import dataclass, field

from poc.generateur import referentiels as refs
from poc.generateur.attendu import assurance_mensuelle, capital_emprunte, charges_credits, frais_acquisition, mensualite
from poc.generateur.modeles import (
    Cas,
    Compte,
    Credit,
    Epargne,
    Foyer,
    Incident,
    Logement,
    Personne,
    Pieges,
    Projet,
)

# ---------------------------------------------------------------------------------------------------------------------
# Réservoirs de noms fictifs
# ---------------------------------------------------------------------------------------------------------------------
PRENOMS_F = [
    "Camille",
    "Léa",
    "Inès",
    "Chloé",
    "Manon",
    "Sarah",
    "Julie",
    "Laura",
    "Emma",
    "Clara",
    "Jade",
    "Lina",
    "Zoé",
    "Louise",
    "Alice",
    "Anaïs",
    "Pauline",
    "Margaux",
    "Mathilde",
    "Océane",
    "Nina",
    "Elise",
    "Agathe",
    "Juliette",
    "Charlotte",
    "Sofia",
    "Amandine",
    "Céline",
    "Nathalie",
    "Sylvie",
    "Catherine",
    "Isabelle",
    "Monique",
    "Hélène",
    "Fatima",
    "Aïcha",
]
PRENOMS_M = [
    "Hugo",
    "Lucas",
    "Nathan",
    "Louis",
    "Gabriel",
    "Arthur",
    "Jules",
    "Adam",
    "Raphaël",
    "Paul",
    "Antoine",
    "Maxime",
    "Alexandre",
    "Nicolas",
    "Julien",
    "Romain",
    "Clément",
    "Quentin",
    "Mehdi",
    "Karim",
    "Yanis",
    "Samuel",
    "Victor",
    "Baptiste",
    "Florian",
    "Pierre",
    "Michel",
    "Philippe",
    "Alain",
    "Bernard",
    "Jean",
    "Patrick",
    "Gérard",
    "Omar",
    "Idriss",
]
NOMS = [
    "Martin",
    "Dubois",
    "Moreau",
    "Laurent",
    "Simon",
    "Michel",
    "Lefebvre",
    "Garcia",
    "Roux",
    "Fournier",
    "Girard",
    "Bonnet",
    "Lambert",
    "Fontaine",
    "Rousseau",
    "Vincent",
    "Muller",
    "Faure",
    "Andre",
    "Mercier",
    "Blanc",
    "Guerin",
    "Boyer",
    "Garnier",
    "Chevalier",
    "Francois",
    "Legrand",
    "Gauthier",
    "Perrin",
    "Robin",
    "Clement",
    "Morin",
    "Nguyen",
    "Henry",
    "Roussel",
    "Mathieu",
    "Gautier",
    "Masson",
    "Marchand",
    "Duval",
    "Denis",
    "Dumont",
    "Marie",
    "Lemaire",
    "Noel",
    "Meyer",
    "Dufour",
    "Meunier",
    "Brun",
    "Blanchard",
    "Giraud",
    "Joly",
    "Riviere",
    "Lucas",
    "Brunet",
    "Gaillard",
    "Barbier",
    "Arnaud",
    "Martinez",
    "Gerard",
    "Benali",
    "Diallo",
    "Traore",
    "Haddad",
    "Kowalski",
    "Da Silva",
    "Nakamura",
    "Okafor",
]
VILLES = [
    ("Nantes", "44000"),
    ("Rennes", "35000"),
    ("Angers", "49000"),
    ("Le Mans", "72000"),
    ("Tours", "37000"),
    ("Brest", "29200"),
    ("Vannes", "56000"),
    ("Lorient", "56100"),
    ("Saint-Nazaire", "44600"),
    ("La Roche-sur-Yon", "85000"),
    ("Laval", "53000"),
    ("Quimper", "29000"),
    ("Cholet", "49300"),
    ("Niort", "79000"),
    ("Poitiers", "86000"),
    ("Caen", "14000"),
    ("Rouen", "76000"),
    ("Orléans", "45000"),
    ("Bordeaux", "33000"),
    ("Lyon", "69003"),
    ("Lille", "59000"),
    ("Strasbourg", "67000"),
    ("Dijon", "21000"),
    ("Grenoble", "38000"),
    ("Montpellier", "34000"),
]
RUES = [
    "rue des Acacias",
    "allée des Peupliers",
    "avenue de la Gare",
    "rue du Moulin",
    "impasse des Roses",
    "boulevard Victor Hugo",
    "rue de la Fontaine",
    "chemin des Vignes",
    "rue Pasteur",
    "place du Marché",
    "rue des Écoles",
    "rue Jean Jaurès",
    "avenue des Platanes",
    "rue de Verdun",
    "rue du Château",
    "allée des Charmes",
    "rue des Lilas",
    "rue de Bretagne",
]
# (poste au masculin, poste au féminin) et employeur
EMPLOIS = [
    ("Logistique Ouest SAS", "Responsable d'exploitation", "Responsable d'exploitation"),
    ("Clinique des Cèdres", "Infirmier coordinateur", "Infirmière coordinatrice"),
    ("Mairie fictive", "Agent administratif", "Agente administrative"),
    ("Atlantique Numérique", "Développeur", "Développeuse"),
    ("Groupe Scolaire Les Hirondelles", "Professeur des écoles", "Professeure des écoles"),
    ("Cabinet Comptable Durand", "Comptable", "Comptable"),
    ("Supermarché Coopératif", "Chef de rayon", "Cheffe de rayon"),
    ("Industrie Mécanique du Val", "Technicien de maintenance", "Technicienne de maintenance"),
    ("Assurances Mutuelles Fictives", "Gestionnaire de sinistres", "Gestionnaire de sinistres"),
    ("Transports Urbains de la Métropole", "Conducteur de bus", "Conductrice de bus"),
    ("Agence Web Horizon", "Chef de projet", "Cheffe de projet"),
    ("Laboratoire Pharmaceutique Fictif", "Ingénieur qualité", "Ingénieure qualité"),
    ("Hôtel du Port", "Réceptionniste", "Réceptionniste"),
    ("Bâtiment Ouest Construction", "Conducteur de travaux", "Conductrice de travaux"),
    ("Centre Hospitalier Fictif", "Aide-soignant", "Aide-soignante"),
    ("Banque du POC", "Conseiller clientèle", "Conseillère clientèle"),
]
# (activité au masculin, au féminin, régime)
ACTIVITES = [
    ("Graphiste indépendant", "Graphiste indépendante", "micro_bnc"),
    ("Consultant en informatique", "Consultante en informatique", "micro_bnc"),
    ("Coach sportif", "Coach sportive", "micro_bic_services"),
    ("Photographe", "Photographe", "micro_bnc"),
    ("Formateur indépendant", "Formatrice indépendante", "micro_bnc"),
    ("Traducteur", "Traductrice", "micro_bnc"),
    ("Électricien", "Électricienne", "micro_bic_services"),
    ("Vente en ligne de décoration", "Vente en ligne de décoration", "micro_bic_vente"),
    ("Ostéopathe", "Ostéopathe", "micro_bnc"),
    ("Rédacteur web", "Rédactrice web", "micro_bnc"),
]
CAISSES = ["CARSAT Fictive", "CNAV Fictive", "Caisse de Retraite Imaginaire"]
BAILLEURS = ["SCI Les Tilleuls", "Habitat Social Fictif", "SCI du Port", "M. et Mme Durand", "Immobilière de l'Ouest"]
AGENCES = ["Agence Loire Habitat", "Agence du Centre", "Immo Fictif", "Cabinet Lemoine Immobilier", "Agence des Quais"]
NOTAIRES = ["Maître Garnier", "Maître Pelletier", "Maître Hoarau", "Maître Schmitt", "Maître Diop"]
VENDEURS = ["M. et Mme Lefèvre", "Mme Roy", "M. Perret", "Consorts Delmas", "SCI Les Mimosas", "Promoteur Fictif SA"]
BANQUES_AUTRES = ["Crédit Fictif", "Banque Imaginaire", "Caisse Inventée"]
DATES_DEPOT = ["2026-06-15", "2026-07-10", "2026-08-03", "2026-09-07", "2026-10-05"]


# ---------------------------------------------------------------------------------------------------------------------
# La recette d'un dossier
# ---------------------------------------------------------------------------------------------------------------------
@dataclass
class Recette:
    scenario: str
    description: str
    difficulte: int
    lot: str = "reglage"
    # le foyer : une ou deux personnes, leur sexe (pour les prénoms), leur âge au dépôt, les enfants
    situations: tuple[str, ...] = (
        "cdi",
        "cdi",
    )  # cdi | cdi_recent | cdd | cdd_recent | independant | independant_recent | retraite | retraite_recent
    sexes: tuple[str, ...] = ("m", "f")
    ages: tuple[int, ...] = (36, 34)
    parts: tuple[float, ...] = (0.55, 0.45)  # répartition des revenus retenus entre les personnes dont le revenu compte
    enfants: int = 0
    # le projet
    type_bien: str = "ancien"
    usage: str = "residence_principale"
    prix: float = 280_000
    honoraires: float = 8_000
    apport: str | float = "normal"  # normal | insuffisant | fort | un montant
    duree: int = 25
    loyers_attendus: float = 0.0  # locatif
    cible: tuple[str, float] = ("taux", 29.0)  # ("taux", %) : taux d'effort tous revenus ; ("rav", €) : reste à vivre
    # l'existant
    loyer: float = 850.0
    credits: tuple[str, ...] = ()  # auto | auto_chez_nous | conso | renouvelable | fin_proche
    joint: str | None = "ailleurs"  # compte joint : ailleurs | chez_nous | None (pas de compte joint)
    compte_ailleurs: int | None = None  # la personne dont le compte courant est tenu dans une autre banque
    # les pièges, par index de personne
    pieges: dict = field(default_factory=dict)
    # fiche_manquante: idx | prime: idx | scinde: idx | hors_periode: (type, idx) | avis_incoherent: idx | sans_fiche: idx
    # scans: [(type, idx ou None, période : m1 | m2 | m3 | compromis | avis_ancien | avis_recent, qualité : scan | photo | illisible)]
    # signaux: True | incident: (regularise | en_cours, idx)
    depot: str | None = None


def _d(s: str) -> dt.date:
    return dt.date.fromisoformat(s)


def _mois_moins(mois: str, n: int) -> str:
    annee, m = (int(x) for x in mois.split("-"))
    m -= n
    while m <= 0:
        m, annee = m + 12, annee - 1
    return f"{annee:04d}-{m:02d}"


def _mois_entre(debut: str, fin: str) -> list[str]:
    out, m = [], debut
    while m <= fin:
        out.append(m)
        annee, mm = (int(x) for x in m.split("-"))
        m = f"{annee + (mm == 12):04d}-{(mm % 12) + 1:02d}"
    return out


def _slug(prenom: str) -> str:
    s = unicodedata.normalize("NFKD", prenom).encode("ascii", "ignore").decode().lower()
    return "".join(c for c in s if c.isalpha())


def _ans_avant(date: dt.date, annees: int, rng: random.Random) -> dt.date:
    """Une date `annees` ans avant `date`, à quelques jours près, sans jamais tomber le 29 février."""
    jour = date - dt.timedelta(days=365 * annees + rng.randint(0, 300))
    return jour.replace(day=min(jour.day, 28))


def _serie(moyenne: float, mois: list[str], rng: random.Random) -> dict[str, float]:
    """Une série mensuelle qui reproduit exactement la moyenne : variations par paires opposées, dernier mois ajusté."""
    base = round(moyenne / 10) * 10
    variations = [0] * len(mois)
    for i in range(0, len(mois) - 1, 2):
        v = rng.randint(4, 45) * 10
        variations[i], variations[i + 1] = v, -v
    valeurs = [base + v for v in variations]
    valeurs[-1] += round(moyenne * len(mois)) - sum(valeurs)
    return dict(zip(mois, [float(v) for v in valeurs], strict=True))


# ---------------------------------------------------------------------------------------------------------------------
# Le constructeur
# ---------------------------------------------------------------------------------------------------------------------
def construire_cas(numero: int, r: Recette) -> Cas:
    rng = random.Random(f"catalogue:{numero}:{r.scenario}")
    demande_id = f"DEM-{numero:04d}"
    depot = _d(r.depot or DATES_DEPOT[numero % len(DATES_DEPOT)])
    mois_depot = f"{depot.year:04d}-{depot.month:02d}"
    mois_releves = [_mois_moins(mois_depot, k) for k in (3, 2, 1)]
    ville, cp = VILLES[numero % len(VILLES)]
    autre_banque = BANQUES_AUTRES[numero % len(BANQUES_AUTRES)]
    pieges = Pieges()

    # ---- les personnes
    personnes: list[Personne] = []
    noms = rng.sample(NOMS, 2)
    prenoms_pris: set[str] = set()
    for k, sit in enumerate(r.situations):
        sexe = r.sexes[k]
        choix = [
            p
            for p in (PRENOMS_F if sexe == "f" else PRENOMS_M)
            if _slug(p) not in prenoms_pris and _slug(p) not in ("thomas", "marie")
        ]
        prenom = rng.choice(choix)
        prenoms_pris.add(_slug(prenom))
        naissance = _ans_avant(depot, r.ages[k], rng)
        pid = _slug(prenom)
        p = Personne(
            id=pid,
            prenom=prenom,
            nom=noms[k] if r.situations and k < len(noms) else noms[0],
            date_naissance=naissance,
            lieu_naissance=f"{VILLES[(numero * 3 + k) % len(VILLES)][0]} ({VILLES[(numero * 3 + k) % len(VILLES)][1][:2]})",
            role="emprunteur" if k == 0 else "co_emprunteur",
            situation_pro="cdi"
            if sit in ("cdi", "cdi_recent")
            else "cdd"
            if sit in ("cdd", "cdd_recent")
            else "auto_entrepreneur"
            if sit.startswith("independant")
            else "retraite",
            compte_salaire=f"CPT-{pid.upper()}",
        )
        if p.situation_pro in ("cdi", "cdd"):
            emp = EMPLOIS[(numero * 5 + k * 7) % len(EMPLOIS)]
            p.employeur, p.poste = emp[0], emp[1] if sexe == "m" else emp[2]
            if sit == "cdi_recent":
                p.date_entree = _d(mois_releves[0] + "-01")  # trois mois d'ancienneté au dépôt : période d'essai
            elif sit == "cdd_recent":
                p.date_entree = _ans_avant(depot, 1, rng)
            elif sit == "cdd":
                p.date_entree = _ans_avant(depot, 4, rng)
            else:
                p.date_entree = _ans_avant(depot, rng.randint(3, 18), rng)
            p.salaire_net_mensuel = 0.0  # calé plus bas
        elif p.situation_pro == "auto_entrepreneur":
            act = ACTIVITES[(numero * 3 + k * 5) % len(ACTIVITES)]
            p.activite = act[0] if sexe == "m" else act[1]
            p.regime = act[2]
            p.abattement_pct = refs.ABATTEMENTS[act[2]]
            mois_debut = rng.randint(10, 20) if sit == "independant_recent" else rng.randint(30, 60)
            p.debut_activite = _d(_mois_moins(mois_depot, mois_debut) + "-01")
            p.compte_pro = f"CPT-{pid.upper()}-PRO"
            p.compte_perso = f"CPT-{pid.upper()}"
            p.compte_salaire = None
            if sit == "independant_recent":
                pieges.independant_recent.append(pid)
        else:  # retraite
            p.employeur = CAISSES[(numero + k) % len(CAISSES)]
            p.poste = "Retraité" if sexe == "m" else "Retraitée"
            p.date_entree = (
                _d(_mois_moins(mois_depot, 10) + "-01")
                if sit == "retraite_recent"
                else _ans_avant(depot, rng.randint(3, 8), rng)
            )
            p.salaire_net_mensuel = 0.0
        personnes.append(p)
    ids = [p.id for p in personnes]
    emprunteur = personnes[0]

    # ---- le foyer et le logement
    if len(personnes) == 1:
        situation = "celibataire"
    else:
        situation = ["pacses", "maries", "concubins"][numero % 3]
        if situation == "maries":
            for p in personnes:
                p.nom = noms[0]
    foyer = Foyer(
        situation_familiale=situation,
        depuis=_ans_avant(depot, rng.randint(2, 15), rng) if situation != "celibataire" else None,
        nb_enfants=r.enfants,
        adresse=f"{rng.randint(1, 60)} {RUES[numero % len(RUES)]}",
        code_postal=cp,
        ville=ville,
    )

    # ---- les comptes
    comptes: list[Compte] = []
    for k, p in enumerate(personnes):
        chez_nous = r.compte_ailleurs != k
        comptes.append(
            Compte(
                id=f"CPT-{p.id.upper()}",
                titulaires=[p.id],
                banque="Banque du POC" if chez_nous else autre_banque,
                chez_nous=chez_nous,
                type="courant",
                iban_masque=f"FR76 •••• •••• •••• {rng.randint(1000, 9999)}",
                solde_debut=round(rng.uniform(600, 3200), 2),
            )
        )
        if p.situation_pro == "auto_entrepreneur":
            comptes.append(
                Compte(
                    id=p.compte_pro,
                    titulaires=[p.id],
                    banque="Banque du POC",
                    chez_nous=True,
                    type="pro",
                    iban_masque=f"FR76 •••• •••• •••• {rng.randint(1000, 9999)}",
                    solde_debut=round(rng.uniform(2500, 7000), 2),
                )
            )
    joint = None
    if len(personnes) > 1 and r.joint:
        joint = Compte(
            id="CPT-JOINT",
            titulaires=ids,
            banque="Banque du POC" if r.joint == "chez_nous" else autre_banque,
            chez_nous=r.joint == "chez_nous",
            type="joint",
            iban_masque=f"FR14 •••• •••• •••• {rng.randint(1000, 9999)}",
            solde_debut=round(rng.uniform(300, 1500), 2),
        )
        comptes.append(joint)
    logement = Logement(
        loyer_mensuel=r.loyer,
        charges_incluses=numero % 2 == 0,
        bailleur=BAILLEURS[numero % len(BAILLEURS)],
        compte_prelevement=joint.id if joint else emprunteur.compte_salaire or f"CPT-{emprunteur.id.upper()}",
    )

    # ---- les crédits en cours
    credits: list[Credit] = []
    modeles_credit = {
        "auto": ("auto", f"{autre_banque} Auto", False, 2028, 240.0, 4.9),
        "auto_chez_nous": ("auto", "Banque du POC", True, 2029, 265.0, 4.5),
        "conso": ("consommation", f"{autre_banque} Conso", False, 2028, 160.0, 6.2),
        "renouvelable": ("renouvelable", "Crédit Renouvelable Fictif", False, 2027, 95.0, 12.9),
        "fin_proche": ("consommation", f"{autre_banque} Conso", False, None, 185.0, 5.4),
    }
    for n, nom in enumerate(r.credits):
        type_, organisme, chez_nous, annee_fin, mensualite_credit, taux = modeles_credit[nom]
        if annee_fin is None:  # se termine quatre mois après le dépôt : la règle CHG_CREDITS ne le compte pas
            date_fin = _d(_mois_moins(mois_depot, -4) + "-10")
        else:
            date_fin = dt.date(annee_fin, (numero % 12) + 1, 10)
        mois_restants = max(1, (date_fin.year - depot.year) * 12 + date_fin.month - depot.month)
        titulaire = personnes[n % len(personnes)]
        credits.append(
            Credit(
                id=f"CRD-{type_.upper()[:4]}{n + 1}",
                titulaire=titulaire.id,
                type=type_,
                organisme=organisme,
                chez_nous=chez_nous,
                date_debut=_ans_avant(date_fin, 4 if type_ != "renouvelable" else 2, rng),
                date_fin=date_fin,
                mensualite=mensualite_credit,
                capital_restant=round(mensualite_credit * mois_restants * 0.95, 2),
                taux_pct=taux,
                compte_prelevement=f"CPT-{titulaire.id.upper()}",
            )
        )

    # ---- le projet et l'apport
    description_bien = {
        (
            "ancien",
            "residence_principale",
        ): f"Appartement T{min(2 + r.enfants + (len(personnes) > 1), 5)} de {52 + 14 * r.enfants + 10 * (len(personnes) > 1)} m², résidence de {1965 + numero % 40}",
        (
            "neuf",
            "residence_principale",
        ): f"Maison neuve de {88 + 12 * r.enfants} m² avec jardin, livraison prévue en {depot.year + 1}",
        ("ancien", "locatif"): "Appartement T2 de 41 m² à louer, immeuble de 1972, proche de la gare",
        ("neuf", "locatif"): "Studio neuf de 27 m² en résidence étudiante, livraison l'an prochain",
    }[(r.type_bien, r.usage)]
    projet = Projet(
        type_bien=r.type_bien,
        usage=r.usage,
        description_bien=description_bien,
        adresse_bien=f"{rng.randint(1, 80)} {RUES[(numero * 7 + 3) % len(RUES)]}, {cp} {ville}",
        prix=float(r.prix),
        honoraires_agence_inclus=float(r.honoraires),
        apport=0.0,
        duree_souhaitee_annees=r.duree,
        loyers_attendus_mensuels=float(r.loyers_attendus),
        date_compromis=depot - dt.timedelta(days=rng.randint(6, 14)),
        date_limite_pret=depot + dt.timedelta(days=45),
        vendeur=VENDEURS[numero % len(VENDEURS)],
        agence=AGENCES[numero % len(AGENCES)],
        notaire=f"{NOTAIRES[numero % len(NOTAIRES)]}, notaire à {ville}",
    )
    cas = Cas(
        demande_id=demande_id,
        scenario=r.scenario,
        difficulte=r.difficulte,
        lot=r.lot,
        description=r.description,
        date_depot=depot,
        mois_releves=mois_releves,
        foyer=foyer,
        personnes=personnes,
        projet=projet,
        comptes=comptes,
        epargnes=[],
        credits=credits,
        logement=logement,
        pieges=pieges,
    )
    frais = frais_acquisition(cas)
    if isinstance(r.apport, (int, float)):
        apport = float(r.apport)
    elif r.apport == "insuffisant":
        apport = max(5_000.0, round((frais - 4_000) / 1000) * 1000)
    elif r.apport == "fort":
        apport = round((frais + 0.15 * r.prix) / 1000) * 1000
    else:
        apport = round((frais + 0.03 * r.prix) / 1000) * 1000
    projet.apport = apport

    # ---- l'épargne : elle couvre l'apport, avec une marge
    marge = rng.randint(2, 9) * 1000
    reste = apport + marge
    epargnes: list[Epargne] = []
    for k, p in enumerate(reversed(personnes)):
        dernier = k == len(personnes) - 1
        if not dernier:
            montant = float(min(rng.randint(3, 9) * 1000, reste - 1000))
            epargnes.append(
                Epargne(
                    id=f"EP-{p.id.upper()}-LA",
                    titulaire=p.id,
                    type="livret_a",
                    banque="Banque du POC",
                    chez_nous=True,
                    solde=montant,
                )
            )
            reste -= montant
        else:
            livret = float(min(reste, 22_950.0 if reste > 25_000 else reste))
            epargnes.append(
                Epargne(
                    id=f"EP-{p.id.upper()}-LA",
                    titulaire=p.id,
                    type="livret_a",
                    banque="Banque du POC",
                    chez_nous=True,
                    solde=livret,
                )
            )
            reste -= livret
            if reste > 0:
                epargnes.append(
                    Epargne(
                        id=f"EP-{p.id.upper()}-AV",
                        titulaire=p.id,
                        type="assurance_vie",
                        banque="Banque du POC",
                        chez_nous=True,
                        solde=float(reste),
                    )
                )
    cas.epargnes = epargnes

    # ---- les pièges
    pg = r.pieges
    if "fiche_manquante" in pg:
        pieges.fiches_paie_manquantes.append((ids[pg["fiche_manquante"]], mois_releves[-1]))
    if "prime" in pg:
        p = personnes[pg["prime"]]
        p.prime_annuelle = float(rng.randint(15, 36) * 100)
        p.mois_prime = int(mois_releves[0][5:])
        pieges.prime_dans_le_net.append((p.id, mois_releves[0]))
    if "scinde" in pg:
        p = personnes[pg["scinde"]]
        if joint is None:
            raise ValueError(f"{r.scenario} : un salaire scindé demande un compte joint")
        p.part_salaire_autre_compte = float(rng.choice([400, 500, 600]))
        p.compte_salaire_secondaire = joint.id
        pieges.salaire_scinde.append(p.id)
    if "hors_periode" in pg:
        t, idx = pg["hors_periode"]
        pieges.piece_hors_periode.append((t, ids[idx]))
    if "avis_incoherent" in pg:
        pieges.avis_incoherent.append(ids[pg["avis_incoherent"]])
    if "sans_fiche" in pg:
        pieges.salarie_sans_fiche.append(ids[pg["sans_fiche"]])
    for type_piece, idx, quand, qualite in pg.get("scans", []):
        periode = {
            "m1": mois_releves[0],
            "m2": mois_releves[1],
            "m3": mois_releves[2],
            "compromis": projet.date_compromis.isoformat(),
            "avis_ancien": str(depot.year - 1),
            "avis_recent": str(depot.year),
        }[quand]
        pieges.pieces_scannees.append((type_piece, "" if idx is None else ids[idx], periode, qualite))
    if pg.get("signaux"):
        pieges.releves_signaux.append(f"CPT-{emprunteur.id.upper()}")
    if "incident" in pg:
        nature, idx = pg["incident"]
        if nature == "regularise":
            date = _ans_avant(depot, 3, rng)
            cas.incidents.append(
                Incident(
                    personne=ids[idx],
                    type="cheque_sans_provision",
                    date=date,
                    montant=420.0,
                    regularise=True,
                    date_regularisation=date + dt.timedelta(days=21),
                )
            )
        else:
            cas.incidents.append(
                Incident(
                    personne=ids[idx],
                    type="retard_credit",
                    date=depot - dt.timedelta(days=55),
                    montant=380.0,
                    regularise=False,
                )
            )

    # ---- le calage des revenus sur la cible
    capital = capital_emprunte(cas)
    charges = (
        mensualite(capital, refs.taux_pour_duree(r.duree), r.duree)
        + assurance_mensuelle(cas, capital)
        + charges_credits(cas)
    )
    if r.usage == "locatif":
        charges += r.loyer
    if r.cible[0] == "taux":
        revenus_cible = charges / (r.cible[1] / 100)
    else:
        revenus_cible = charges + r.cible[1]
    if r.usage == "locatif":
        revenus_cible -= 0.70 * r.loyers_attendus
    retenus = [k for k, sit in enumerate(r.situations) if sit != "cdd_recent" and k != pg.get("sans_fiche")]
    total_parts = sum(r.parts[k] for k in retenus) or 1.0
    for k, p in enumerate(personnes):
        sit = r.situations[k]
        if k in retenus:
            x = revenus_cible * r.parts[k] / total_parts
        else:
            x = (
                1_750.0 if sit == "cdd_recent" else 2_300.0
            )  # un revenu existe, la règle ne le retient pas (ou ne peut l'établir)
        if p.situation_pro in ("cdi", "cdd"):
            p.salaire_net_mensuel = float(round(x / 10) * 10)
            p.net_imposable_mensuel = float(round(p.salaire_net_mensuel * 1.07 / 10) * 10)
        elif p.situation_pro == "retraite":
            p.salaire_net_mensuel = float(round(x / 10) * 10)
            p.net_imposable_mensuel = p.salaire_net_mensuel
        else:
            ca_moyen = x / (1 - p.abattement_pct / 100)
            debut = f"{p.debut_activite.year:04d}-{p.debut_activite.month:02d}"
            premier = max(debut, _mois_moins(mois_releves[-1], 39))
            mois = _mois_entre(premier, mois_releves[-1])
            p.ca_mensuels = _serie(ca_moyen, mois, rng)
            p.remuneration_mensuelle = float(round(x * 0.9 / 50) * 50)
    return cas


# ---------------------------------------------------------------------------------------------------------------------
# Les quarante-neuf recettes
# ---------------------------------------------------------------------------------------------------------------------
def _R(scenario: str, description: str, difficulte: int, **k) -> Recette:
    return Recette(scenario, description, difficulte, **k)


RECETTES: list[Recette] = [
    # ---- lot facile : aucun piège, tout dans la norme ------------------------------------------------------------------------
    _R(
        "couple_cdi_sain",
        "Couple en CDI, sans enfant, appartement ancien, dossier complet et dans la norme.",
        1,
        lot="facile",
        prix=265_000,
        honoraires=7_000,
    ),
    _R(
        "celibataire_cdi",
        "Un emprunteur seul en CDI, petit appartement, un crédit auto en cours.",
        1,
        lot="facile",
        situations=("cdi",),
        sexes=("m",),
        ages=(31,),
        parts=(1.0,),
        prix=185_000,
        honoraires=5_000,
        loyer=640,
        credits=("auto",),
        joint=None,
        cible=("taux", 30.0),
    ),
    _R(
        "famille_deux_enfants",
        "Couple en CDI avec deux enfants, grand appartement ancien.",
        1,
        lot="facile",
        enfants=2,
        ages=(39, 37),
        prix=310_000,
        honoraires=9_000,
        loyer=1_050,
        cible=("taux", 30.0),
    ),
    _R(
        "independant_etabli_couple",
        "CDI et indépendante installée depuis plus de deux ans, 20 ans.",
        1,
        lot="facile",
        situations=("cdi", "independant"),
        ages=(35, 33),
        prix=240_000,
        honoraires=6_000,
        duree=20,
        cible=("taux", 31.0),
    ),
    _R(
        "retraites_couple",
        "Couple de retraités, pensions anciennes, apport important, 15 ans.",
        1,
        lot="facile",
        situations=("retraite", "retraite"),
        ages=(66, 64),
        prix=160_000,
        honoraires=4_000,
        apport="fort",
        duree=15,
        loyer=720,
        cible=("taux", 25.0),
    ),
    _R(
        "celibataire_independante_etablie",
        "Une indépendante seule, installée depuis quatre ans.",
        1,
        lot="facile",
        situations=("independant",),
        sexes=("f",),
        ages=(38,),
        parts=(1.0,),
        prix=170_000,
        honoraires=5_000,
        loyer=690,
        joint=None,
        cible=("taux", 30.0),
    ),
    _R(
        "couple_neuf",
        "Couple en CDI, maison neuve (frais réduits), sans honoraires d'agence.",
        1,
        lot="facile",
        type_bien="neuf",
        prix=295_000,
        honoraires=0,
        ages=(33, 32),
        cible=("taux", 28.0),
    ),
    _R(
        "locatif_cdi_couple",
        "Couple en CDI qui achète un petit appartement pour le louer ; le loyer actuel reste une charge, les loyers attendus comptent à 70 %.",
        1,
        lot="facile",
        usage="locatif",
        prix=150_000,
        honoraires=5_000,
        duree=20,
        loyers_attendus=650,
        loyer=900,
        ages=(41, 40),
        cible=("taux", 32.0),
    ),
    _R(
        "couple_cdd_ancien",
        "CDI et CDD de plus de trois ans : les deux revenus se retiennent.",
        1,
        lot="facile",
        situations=("cdi", "cdd"),
        sexes=("f", "m"),
        ages=(30, 29),
        prix=230_000,
        honoraires=6_000,
        cible=("taux", 30.0),
    ),
    _R(
        "credit_auto_chez_nous",
        "Couple en CDI, crédit auto souscrit dans notre banque (visible dans le système), compte joint chez nous.",
        1,
        lot="facile",
        credits=("auto_chez_nous",),
        joint="chez_nous",
        prix=275_000,
        honoraires=8_000,
        cible=("taux", 31.0),
    ),
    # ---- lot réglage : un à trois pièges -----------------------------------------------------------------------------------------
    _R(
        "fiche_manquante_simple",
        "Couple en CDI ; la dernière fiche de paie de l'emprunteur manque.",
        2,
        pieges={"fiche_manquante": 0},
        prix=270_000,
        honoraires=7_000,
    ),
    _R(
        "prime_dans_le_net",
        "Un emprunteur seul ; sa fiche de paie la plus ancienne inclut la prime annuelle.",
        2,
        situations=("cdi",),
        sexes=("f",),
        ages=(34,),
        parts=(1.0,),
        joint=None,
        prix=190_000,
        honoraires=5_000,
        loyer=680,
        pieges={"prime": 0},
        cible=("taux", 30.0),
    ),
    _R(
        "salaire_scinde",
        "Couple ; le salaire de l'emprunteur arrive sur deux comptes, dont le joint tenu ailleurs.",
        2,
        pieges={"scinde": 0},
        prix=285_000,
        honoraires=8_000,
        cible=("taux", 30.0),
    ),
    _R(
        "independante_recente_couple",
        "CDI et indépendante depuis quinze mois : cas non couvert par la règle standard.",
        2,
        situations=("cdi", "independant_recent"),
        ages=(37, 35),
        prix=250_000,
        honoraires=7_000,
        cible=("taux", 31.0),
    ),
    _R(
        "cdi_periode_essai",
        "Couple ; la co-emprunteuse est en CDI depuis trois mois (période d'essai).",
        2,
        situations=("cdi", "cdi_recent"),
        ages=(33, 31),
        prix=260_000,
        honoraires=7_000,
        cible=("taux", 30.0),
    ),
    _R(
        "cdd_recent_exclu",
        "CDI et CDD d'un an : le revenu du CDD n'est pas retenu, et sans lui le taux dépasse 35 %.",
        3,
        situations=("cdi", "cdd_recent"),
        ages=(36, 34),
        prix=240_000,
        honoraires=6_000,
        cible=("taux", 37.5),
    ),
    _R(
        "celibataire_cdd_recent",
        "Un emprunteur seul en CDD d'un an : aucun revenu retenu, l'agent ne peut pas se prononcer.",
        3,
        situations=("cdd_recent",),
        sexes=("m",),
        ages=(27,),
        parts=(1.0,),
        joint=None,
        prix=140_000,
        honoraires=4_000,
        loyer=560,
    ),
    _R(
        "apport_insuffisant",
        "Couple en CDI ; l'apport ne couvre pas les frais d'acquisition. Le compromis est déposé en photo.",
        2,
        apport="insuffisant",
        pieges={"scans": [("compromis", None, "compromis", "photo")]},
        prix=290_000,
        honoraires=8_000,
        cible=("taux", 30.0),
    ),
    _R(
        "taux_effort_hors_norme",
        "Couple en CDI ; taux d'effort à 38 %, au-delà de la norme HCSF mais dérogeable.",
        2,
        prix=300_000,
        honoraires=9_000,
        cible=("taux", 38.0),
    ),
    _R(
        "defavorable_taux",
        "Couple en CDI ; taux d'effort à 49 %, très au-delà de la norme : recommandation défavorable attendue.",
        3,
        prix=320_000,
        honoraires=9_000,
        cible=("taux", 49.0),
    ),
    _R(
        "reste_a_vivre_juste",
        "Famille de trois enfants ; taux dans la norme mais reste à vivre sous le seuil maison.",
        3,
        enfants=3,
        ages=(42, 40),
        prix=240_000,
        honoraires=6_000,
        loyer=1_100,
        cible=("rav", 3_050.0),
    ),
    _R(
        "incident_regularise",
        "Couple en CDI ; un chèque sans provision il y a trois ans, régularisé : signalé, pas bloquant. La fiche de paie du "
        "deuxième mois de l'emprunteur est scannée.",
        2,
        pieges={"incident": ("regularise", 0), "scans": [("fiche_paie", 0, "m2", "scan")]},
        prix=255_000,
        honoraires=7_000,
    ),
    _R(
        "incident_en_cours",
        "Un emprunteur seul ; un retard de crédit non régularisé au fichier d'incidents.",
        3,
        situations=("cdi",),
        sexes=("m",),
        ages=(35,),
        parts=(1.0,),
        joint=None,
        prix=175_000,
        honoraires=5_000,
        loyer=620,
        pieges={"incident": ("en_cours", 0)},
        cible=("taux", 30.0),
    ),
    _R(
        "signaux_compte",
        "Un emprunteur seul ; ses relevés montrent des paris en ligne répétés et une commission d'intervention.",
        3,
        situations=("cdi",),
        sexes=("m",),
        ages=(29,),
        parts=(1.0,),
        joint=None,
        prix=165_000,
        honoraires=5_000,
        loyer=600,
        pieges={"signaux": True},
        cible=("taux", 31.0),
    ),
    _R(
        "avis_incoherent",
        "Couple en CDI ; l'avis d'imposition de la co-emprunteuse est en écart de plus de 10 % avec ses fiches de paie.",
        3,
        pieges={"avis_incoherent": 1},
        prix=280_000,
        honoraires=8_000,
    ),
    _R(
        "sans_fiche_de_paie",
        "Couple ; aucune fiche de paie du co-emprunteur n'est déposée : son revenu ne peut pas être établi.",
        3,
        sexes=("f", "m"),
        pieges={"sans_fiche": 1},
        prix=270_000,
        honoraires=7_000,
    ),
    _R(
        "quittance_ancienne",
        "Couple en CDI ; le justificatif de domicile a plus de trois mois.",
        2,
        pieges={"hors_periode": ("justificatif_domicile", 0)},
        prix=245_000,
        honoraires=6_000,
    ),
    _R(
        "avis_ancien",
        "Un emprunteur seul ; le dernier avis d'imposition manque, seuls des avis plus anciens sont fournis.",
        2,
        situations=("cdi",),
        sexes=("f",),
        ages=(44,),
        parts=(1.0,),
        joint=None,
        prix=200_000,
        honoraires=6_000,
        loyer=700,
        pieges={"hors_periode": ("avis_imposition", 0)},
        cible=("taux", 30.0),
    ),
    _R(
        "credit_fin_proche",
        "Couple ; un crédit à la consommation se termine quatre mois après le dépôt (ne compte pas) et un crédit auto (compte). Le compter ferait dépasser 35 %.",
        2,
        credits=("fin_proche", "auto"),
        prix=265_000,
        honoraires=7_000,
        cible=("taux", 34.0),
    ),
    _R(
        "locatif_independant",
        "Indépendant établi et CDI, investissement locatif.",
        3,
        situations=("independant", "cdi"),
        sexes=("m", "f"),
        ages=(45, 43),
        usage="locatif",
        prix=165_000,
        honoraires=5_000,
        duree=20,
        loyers_attendus=720,
        loyer=980,
        cible=("taux", 33.0),
    ),
    _R(
        "retraite_recente",
        "Couple de retraités ; l'un est à la retraite depuis dix mois : pension non couverte par la règle standard.",
        3,
        situations=("retraite", "retraite_recent"),
        ages=(67, 63),
        prix=190_000,
        honoraires=5_000,
        apport="fort",
        duree=15,
        loyer=760,
        cible=("taux", 28.0),
    ),
    _R(
        "famille_independante_recente_fiche_manquante",
        "Un enfant ; indépendante récente et fiche de paie manquante de l'emprunteur.",
        3,
        situations=("cdi", "independant_recent"),
        enfants=1,
        ages=(34, 33),
        pieges={"fiche_manquante": 0},
        prix=255_000,
        honoraires=7_000,
        cible=("taux", 31.0),
    ),
    _R(
        "prime_et_salaire_scinde",
        "Couple ; prime annuelle dans le net du premier mois et salaire scindé sur le compte joint chez nous.",
        3,
        joint="chez_nous",
        pieges={"prime": 0, "scinde": 0},
        prix=290_000,
        honoraires=8_000,
        cible=("taux", 30.0),
    ),
    _R(
        "trois_pieges_celibataire",
        "Un emprunteur seul ; prime dans le net, fiche de paie manquante et quittance trop ancienne.",
        4,
        situations=("cdi",),
        sexes=("m",),
        ages=(38,),
        parts=(1.0,),
        joint=None,
        prix=195_000,
        honoraires=6_000,
        loyer=690,
        pieges={"prime": 0, "fiche_manquante": 0, "hors_periode": ("justificatif_domicile", 0)},
        cible=("taux", 30.0),
    ),
    _R(
        "compte_ailleurs",
        "Couple en CDI ; le compte courant de la co-emprunteuse est tenu dans une autre banque : ses revenus ne se recoupent que "
        "par les pièces, et son dernier relevé est scanné.",
        2,
        compte_ailleurs=1,
        pieges={"scans": [("releve_compte", 1, "m3", "scan")]},
        prix=270_000,
        honoraires=7_000,
    ),
    _R(
        "neuf_cdd_ancien_enfant",
        "Maison neuve, un enfant, CDI et CDD ancien, deux crédits en cours. La dernière fiche de paie du co-emprunteur est un "
        "scan illisible, même par OCR : il faut la redemander.",
        3,
        situations=("cdi", "cdd"),
        pieges={"scans": [("fiche_paie", 1, "m3", "illisible")]},
        enfants=1,
        type_bien="neuf",
        prix=310_000,
        honoraires=0,
        credits=("auto", "conso"),
        ages=(36, 35),
        cible=("taux", 30.0),
    ),
    _R(
        "couple_independants",
        "Deux indépendants établis.",
        3,
        situations=("independant", "independant"),
        ages=(40, 38),
        prix=235_000,
        honoraires=6_000,
        cible=("taux", 32.0),
    ),
    _R(
        "hors_norme_taux_et_apport",
        "Couple ; taux à 37 % et apport insuffisant : deux réserves.",
        3,
        apport="insuffisant",
        prix=295_000,
        honoraires=8_000,
        cible=("taux", 37.0),
    ),
    _R(
        "incident_regularise_et_signaux",
        "Couple ; incident ancien régularisé et signaux d'alerte sur le compte de l'emprunteur.",
        4,
        pieges={"incident": ("regularise", 1), "signaux": True},
        prix=260_000,
        honoraires=7_000,
    ),
    _R(
        "defavorable_incident_et_taux",
        "Couple ; incident en cours et taux à 40 % : défavorable.",
        3,
        pieges={"incident": ("en_cours", 0)},
        prix=300_000,
        honoraires=9_000,
        cible=("taux", 40.0),
    ),
    _R(
        "independante_recente_seule",
        "Une indépendante seule depuis quatorze mois : revenu retenu mais cas non couvert.",
        3,
        situations=("independant_recent",),
        sexes=("f",),
        ages=(32,),
        parts=(1.0,),
        joint=None,
        prix=160_000,
        honoraires=5_000,
        loyer=640,
        cible=("taux", 32.0),
    ),
    _R(
        "vingt_ans_prime_avis",
        "Couple sur 20 ans ; prime dans le net de la co-emprunteuse, avis d'imposition de l'emprunteur en écart.",
        4,
        duree=20,
        pieges={"prime": 1, "avis_incoherent": 0},
        prix=250_000,
        honoraires=7_000,
        cible=("taux", 31.0),
    ),
    _R(
        "locatif_apport_insuffisant_fiche",
        "Locatif ; apport insuffisant et fiche de paie manquante.",
        4,
        usage="locatif",
        apport="insuffisant",
        prix=140_000,
        honoraires=4_000,
        duree=20,
        loyers_attendus=600,
        loyer=950,
        pieges={"fiche_manquante": 1},
        cible=("taux", 32.0),
    ),
    _R(
        "retraite_et_cdi_renouvelable",
        "Retraité de longue date et CDI, un crédit renouvelable en cours. L'attestation de pension est déposée en photo.",
        2,
        situations=("retraite", "cdi"),
        pieges={"scans": [("attestation_pension", 0, "m3", "photo")]},
        ages=(64, 58),
        credits=("renouvelable",),
        prix=210_000,
        honoraires=6_000,
        duree=15,
        cible=("taux", 30.0),
    ),
    # ---- lot scellé : jamais regardé pendant le réglage ---------------------------------------------------------------------------
    _R(
        "scelle_scinde_independante_fiche",
        "Variante du fil rouge avec d'autres chiffres : salaire scindé, indépendante récente, fiche manquante.",
        3,
        lot="scelle",
        situations=("cdi", "independant_recent"),
        ages=(35, 33),
        pieges={"scinde": 0, "fiche_manquante": 0},
        prix=305_000,
        honoraires=9_000,
        cible=("taux", 33.0),
    ),
    _R(
        "scelle_famille_rav_prime",
        "Deux enfants, prime dans le net, reste à vivre sous le seuil.",
        4,
        lot="scelle",
        enfants=2,
        ages=(38, 36),
        pieges={"prime": 0},
        prix=230_000,
        honoraires=6_000,
        loyer=1_000,
        cible=("rav", 2_750.0),
    ),
    _R(
        "scelle_celibataire_sain",
        "Un emprunteur seul en CDI, dossier complet et dans la norme ; sa fiche de paie la plus ancienne est scannée.",
        1,
        lot="scelle",
        pieges={"scans": [("fiche_paie", 0, "m1", "scan")]},
        situations=("cdi",),
        sexes=("f",),
        ages=(36,),
        parts=(1.0,),
        joint=None,
        prix=180_000,
        honoraires=5_000,
        loyer=650,
        cible=("taux", 29.0),
    ),
    _R(
        "scelle_incident_en_cours_cdd",
        "CDI et CDD récent, incident en cours : défavorable.",
        3,
        lot="scelle",
        situations=("cdi", "cdd_recent"),
        ages=(33, 30),
        pieges={"incident": ("en_cours", 1)},
        prix=235_000,
        honoraires=6_000,
        cible=("taux", 33.0),
    ),
    _R(
        "scelle_avis_quittance_fin_proche",
        "Avis d'imposition en écart, quittance ancienne, crédit qui se termine bientôt.",
        4,
        lot="scelle",
        credits=("fin_proche",),
        pieges={"avis_incoherent": 0, "hors_periode": ("justificatif_domicile", 1)},
        prix=275_000,
        honoraires=8_000,
        cible=("taux", 31.0),
    ),
]


def cas_du_catalogue() -> list[Cas]:
    """Les quarante-neuf dossiers du catalogue, DEM-0002 à DEM-0050."""
    return [construire_cas(i + 2, r) for i, r in enumerate(RECETTES)]


def resume_lots(cas: list[Cas]) -> dict[str, int]:
    out: dict[str, int] = {}
    for c in cas:
        out[c.lot] = out.get(c.lot, 0) + 1
    return out


__all__ = ["RECETTES", "Recette", "cas_du_catalogue", "construire_cas", "resume_lots"]
