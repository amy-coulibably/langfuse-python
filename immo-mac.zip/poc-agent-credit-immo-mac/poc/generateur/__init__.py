"""Le générateur de données synthétiques : un cas (vérité terrain) → pièces PDF, banque simulée, fichier d'incidents,
tables de vérité terrain pour l'évaluation."""

from poc.generateur.attendu import Attendu, calculer_attendu
from poc.generateur.catalogue import RECETTES, cas_du_catalogue
from poc.generateur.fil_rouge import cas_fil_rouge, tous_les_cas
from poc.generateur.modeles import Cas
from poc.generateur.pieces import deposer_piece
from poc.generateur.pipeline import attendu_de, cas_de, catalogue, demandes_disponibles, generer_demande, generer_tout

__all__ = [
    "RECETTES",
    "Attendu",
    "Cas",
    "attendu_de",
    "calculer_attendu",
    "cas_de",
    "cas_du_catalogue",
    "cas_fil_rouge",
    "catalogue",
    "demandes_disponibles",
    "deposer_piece",
    "generer_demande",
    "generer_tout",
    "tous_les_cas",
]
