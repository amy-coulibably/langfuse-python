"""Les lignes de relevés bancaires d'un cas, mois par mois et compte par compte : salaires, loyer, crédits, virements
entre comptes, dépenses du quotidien. Déterministes (graine dérivée du cas, du compte et du mois), réalistes dans leurs
libellés, et porteuses des pièges du cas : un salaire scindé sur deux comptes, une prime dans le net d'un mois, des
signaux d'alerte si le cas en prévoit.
"""

from __future__ import annotations

import datetime as dt
import random
from calendar import monthrange

from poc.generateur.modeles import Cas, Compte

COMMERCES = ["CARREFOUR MARKET", "U EXPRESS", "BIOCOOP", "LIDL", "MONOPRIX"]
RESTAURANTS = ["LE PETIT BOUCHON", "SUSHI TIME", "PIZZA ROMA", "CAFE DU COMMERCE"]
CLIENTS_INDEPENDANT = [
    "AGENCE KOALA",
    "EDITIONS DU PORT",
    "STUDIO MELIA",
    "MAIRIE DE VERTOU",
    "BRASSERIE LA DUNE",
    "ASSOCIATION TERRE NEUVE",
]


def _date(mois: str, jour: int) -> dt.date:
    annee, m = (int(x) for x in mois.split("-"))
    return dt.date(annee, m, min(jour, monthrange(annee, m)[1]))


def _mois_precedents(mois: str, n: int) -> list[str]:
    annee, m = (int(x) for x in mois.split("-"))
    out = []
    for _ in range(n):
        m -= 1
        if m == 0:
            m, annee = 12, annee - 1
        out.append(f"{annee:04d}-{m:02d}")
    return list(reversed(out))


def _rng(cas: Cas, compte: Compte, mois: str) -> random.Random:
    return random.Random(f"{cas.demande_id}:{compte.id}:{mois}")


def mouvements_du_mois(cas: Cas, compte: Compte, mois: str) -> list[dict]:
    """Les lignes d'un compte pour un mois : liste de {date, libelle, montant} triée par date."""
    rng = _rng(cas, compte, mois)
    lignes: list[dict] = []
    mm = mois[5:] + "/" + mois[:4]

    def ajouter(jour: int, libelle: str, montant: float) -> None:
        lignes.append({"date": _date(mois, jour), "libelle": libelle, "montant": round(montant, 2)})

    titulaires = [cas.personne(t) for t in compte.titulaires]

    # ---- salaires et revenus
    for p in cas.personnes:
        if p.salaire_net_mensuel is not None and p.compte_salaire == compte.id:
            net = p.salaire_net_mensuel - p.part_salaire_autre_compte
            if (p.id, mois) in cas.pieges.prime_dans_le_net:
                net += p.prime_annuelle
            nature = "PENSION" if p.situation_pro == "retraite" else "SALAIRE"
            ajouter(28 if nature == "SALAIRE" else 9, f"VIR SEPA {p.employeur.upper()} {nature} {mm}", net)
        if p.part_salaire_autre_compte and p.compte_salaire_secondaire == compte.id:
            ajouter(28, f"VIR SEPA {p.employeur.upper()} SALAIRE {mm}", p.part_salaire_autre_compte)
        if p.situation_pro == "auto_entrepreneur" and p.compte_pro == compte.id and mois in p.ca_mensuels:
            ca = p.ca_mensuels[mois]
            parts = [0.45, 0.35, 0.20] if ca > 1500 else [0.6, 0.4]
            clients = rng.sample(CLIENTS_INDEPENDANT, len(parts))
            reste = ca
            for i, (part, client) in enumerate(zip(parts, clients, strict=True)):
                montant = round(ca * part) if i < len(parts) - 1 else reste
                reste -= montant
                ajouter(4 + i * 8, f"VIR SEPA {client} FACTURE {mois.replace('-', '')}-{rng.randint(10, 99)}", montant)
            if mois[5:] in ("01", "04", "07", "10"):
                trimestre = sum(p.ca_mensuels.get(m, 0.0) for m in _mois_precedents(mois, 3))
                if trimestre:
                    ajouter(
                        30,
                        f"PRLV SEPA URSSAF COTISATIONS MICRO-ENTREPRENEUR T{(int(mois[5:]) - 1) // 3 or 4}",
                        -round(trimestre * 0.22),
                    )
            ajouter(
                1, f"VIR VERS {p.nom_complet.upper()} CPT PERSO REMUNERATION {mm}", -(p.remuneration_mensuelle or 0)
            )
            ajouter(15, "PRLV SEPA LOGICIELS PRO ABONNEMENT", -59.99)
            ajouter(27, "FRAIS TENUE DE COMPTE PRO", -9.00)
        if p.situation_pro == "auto_entrepreneur" and p.compte_perso == compte.id:
            ajouter(1, f"VIR DE {p.nom_complet.upper()} EI REMUNERATION {mm}", p.remuneration_mensuelle or 0)

    # ---- charges fixes
    if cas.logement.compte_prelevement == compte.id:
        ajouter(3, f"PRLV SEPA {cas.logement.bailleur.upper()} LOYER {mm}", -cas.logement.loyer_mensuel)
    for c in cas.credits:
        if c.compte_prelevement == compte.id:
            ajouter(10, f"PRLV SEPA {c.organisme.upper()} ECH {mm}", -c.mensualite)

    # ---- virements entre comptes du foyer
    joint = next((c for c in cas.comptes if c.type == "joint"), None)
    if compte.type == "courant" and joint is not None:
        ajouter(2, "VIR PERMANENT VERS CPT JOINT", -400.0)
    if compte.type == "joint":
        for t in titulaires:
            ajouter(2 if t.role == "emprunteur" else 3, f"VIR PERMANENT DE {t.nom_complet.upper()}", 400.0)
        ajouter(8, "PRLV SEPA EDF ELECTRICITE", -round(rng.uniform(68, 92), 2))
        ajouter(12, "PRLV SEPA ORANGE INTERNET", -39.99)
        ajouter(16, "PRLV SEPA ASSUR HABITAT MUTUELLE", -22.40)
        for jour in (6, 20):
            ajouter(jour, f"CB {rng.choice(COMMERCES)}", -round(rng.uniform(70, 130), 2))
    if compte.type == "courant":
        for p in titulaires:
            if any(e.titulaire == p.id and e.type == "livret_a" for e in cas.epargnes):
                ajouter(5, "VIR PERMANENT LIVRET A", -150.0 if p.role == "emprunteur" else -100.0)
        ajouter(
            14,
            f"PRLV SEPA {'BOUYGUES' if titulaires[0].role == 'emprunteur' else 'FREE'} MOBILE",
            -24.99 if titulaires[0].role == "emprunteur" else -19.99,
        )
        ajouter(18, "PRLV SEPA MUTUELLE SANTE", -38.20)
        for jour in sorted(rng.sample(range(2, 28), 4)):
            ajouter(jour, f"CB {rng.choice(COMMERCES)}", -round(rng.uniform(32, 118), 2))
        for jour in sorted(rng.sample(range(2, 28), 2)):
            ajouter(jour, f"CB {rng.choice(RESTAURANTS)}", -round(rng.uniform(18, 64), 2))
        ajouter(rng.randint(5, 25), "RETRAIT DAB", -float(rng.choice([40, 60, 80])))
        if titulaires[0].role == "emprunteur":
            ajouter(9, "CB TOTAL ENERGIES CARBURANT", -round(rng.uniform(52, 71), 2))
            ajouter(23, "CB TOTAL ENERGIES CARBURANT", -round(rng.uniform(52, 71), 2))
            ajouter(21, "PRLV SEPA ASSUR AUTO FICTIVE", -48.30)
        else:
            ajouter(11, f"PRLV SEPA SALLE DE SPORT {cas.foyer.ville.upper()}", -32.00)
            ajouter(19, f"CB {rng.choice(['ZARA', 'DECATHLON', 'FNAC'])}", -round(rng.uniform(25, 90), 2))

    # ---- signaux d'alerte (cas qui le prévoient)
    if compte.id in cas.pieges.releves_signaux:
        for jour in (7, 17, 26):
            ajouter(jour, "CB WINAMAX PARIS EN LIGNE", -round(rng.uniform(40, 120), 2))
        ajouter(29, "COMMISSION INTERVENTION DEPASSEMENT DECOUVERT", -8.00)

    return sorted(lignes, key=lambda x: (x["date"], x["libelle"]))


def releves_du_cas(cas: Cas) -> dict[str, list[dict]]:
    """Pour chaque compte : une liste par mois {mois, solde_debut, lignes (avec solde_apres), solde_fin}."""
    out: dict[str, list[dict]] = {}
    for compte in cas.comptes:
        solde = compte.solde_debut
        mois_list = []
        for mois in cas.mois_releves:
            lignes = mouvements_du_mois(cas, compte, mois)
            debut = solde
            for ligne in lignes:
                solde = round(solde + ligne["montant"], 2)
                ligne["solde_apres"] = solde
            mois_list.append({"mois": mois, "solde_debut": debut, "lignes": lignes, "solde_fin": solde})
        out[compte.id] = mois_list
    return out
