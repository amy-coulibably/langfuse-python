"""L'adaptateur : entre l'agent et la brique `ml_utils.observability`.

Il ouvre les spans par la façade de la brique (`observe_span`), qui assure transport, échantillonnage, redaction et
fail-open, puis complète chaque span avec les attributs OpenInference que la brique n'émet pas (messages du modèle, outils,
appels d'outils, nœuds du graphe), posés directement sur le span OpenTelemetry courant. Quatre sortes de spans :

- `session` (racine, kind AGENT) : une par session de l'agent, `session.id` = identifiant de session, `user.id` haché ;
- `etape` (AGENT) : un par nœud du parcours, avec `graph.node.id` / `graph.node.parent_id` ;
- `appel_modele` (LLM) : un par appel au modèle, messages, outils proposés, appels d'outils, tokens, coût si connu ;
- `appel_outil` (TOOL) : un par appel d'outil, nom, paramètres, résultat ou code d'erreur ; `garde_fou` (GUARDRAIL) pour
  les refus de l'atelier, les arrêts de boucle et, aux lots suivants, les verdicts des garde-fous de synthèse.

Inactif (configuration `active: false` ou brique absente), chaque méthode est un passe-plat qui ne coûte rien.

Correctifs hérités du premier POC et conservés ici : sonde du collecteur au démarrage (un message, pas des reprises sans
fin), plafond d'attributs par span relevé et conversation bornée (plus d'attributs jetés), exportateur silencieux sur les
reprises, fermeture tolérante à l'interruption, sortie toujours renseignée, pas de coût émis quand le prix est inconnu.
"""

from __future__ import annotations

import atexit
import hashlib
import json
import logging
import os
import sys
import threading
from collections.abc import Iterator
from contextlib import contextmanager
from dataclasses import dataclass, field
from typing import Any

from poc.observabilite import semconv as sc
from poc.observabilite.config import ConfigObservabilite, charger_config_observabilite, vers_config_ml_utils

logger = logging.getLogger(__name__)

NOM_AGENT = "agent-credit-immo"
NOM_AFFICHE = "Agent de pré-instruction crédit immobilier"
MASQUE = "[contenu masqué : contenu_messages=false]"

_VERROU = threading.Lock()
_INSTANCE: Observabilite | None = None


@dataclass
class Enregistreur:
    """Ce que le code appelant renseigne pendant un span (sortie, mesures, erreur) ; l'adaptateur le pose à la fermeture."""

    observation: Any = None
    attributs: dict[str, Any] = field(default_factory=dict)
    trace_id: str = ""  # identifiants OpenTelemetry (hexadécimal), pour annoter le span ensuite
    span_id: str = ""
    masquer: bool = False  # contenu_messages=false : la sortie est remplacée par sa seule taille

    def sortie(self, valeur: Any) -> None:
        if self.observation is None:
            return
        if valeur in (None, {}, [], ""):
            self.observation.output = {"vide": True}
        elif self.masquer:
            self.observation.output = {
                "contenu_masque": True,
                "taille": len(json.dumps(valeur, ensure_ascii=False, default=str)),
            }
        else:
            self.observation.output = valeur

    def attribut(self, cle: str, valeur: Any) -> None:
        self.attributs[cle] = valeur

    def erreur(self, code: str, message: str = "") -> None:
        self.attributs[sc.POC_ERREUR_CODE] = code
        if message:
            self.attributs["poc.erreur_message"] = message[:600]
        if self.observation is not None:
            self.observation.error = True


class Observabilite:
    def __init__(self, config: ConfigObservabilite, manager: Any = None) -> None:
        self.config = config
        self.manager = manager

    # ---- cycle de vie ------------------------------------------------------------------------------------------------------
    @property
    def actif(self) -> bool:
        return self.manager is not None

    @property
    def tracer_provider(self):
        """Le fournisseur de traces OpenTelemetry de la brique (privé chez elle : lu avec précaution), pour les instrumenteurs."""
        backend = getattr(self.manager, "_backend", None)
        return getattr(backend, "_provider", None)

    def vider(self) -> None:
        """Pousse les spans en attente (avant d'annoter une trace, ou à la fin d'un appel servi par MCP)."""
        if self.manager is not None:
            try:
                self.manager.flush()
            except Exception:  # noqa: BLE001
                logger.debug("vidage des traces impossible", exc_info=True)

    def fermer(self) -> None:
        if self.manager is None:
            return
        try:
            self.manager.flush()
            self.manager.close()
        except BaseException:  # noqa: BLE001 — fail-open jusqu'au bout, y compris un Ctrl+C pendant l'envoi des derniers spans
            logger.debug("fermeture de l'observabilité interrompue (ignorée)", exc_info=True)
        self.manager = None

    # ---- spans -----------------------------------------------------------------------------------------------------------------
    @contextmanager
    def session(
        self, session_id: str, demande_id: str, metadata: dict[str, Any] | None = None
    ) -> Iterator[Enregistreur]:
        with self._span("agent", NOM_AGENT) as rec:
            if rec.observation is not None:
                rec.observation.session_id = session_id
                rec.observation.user_id = hashlib.sha256(self.config.utilisateur.encode()).hexdigest()[:16]
                rec.observation.tags = {
                    "demande_id": demande_id,
                    **{k: v for k, v in (metadata or {}).items() if isinstance(v, (str, int, bool))},
                }
                rec.observation.metadata = {"demande_id": demande_id, "session_id": session_id, **(metadata or {})}
                rec.observation.input = {"demande_id": demande_id, "session_id": session_id}
            rec.attributs.update(
                {
                    sc.GRAPH_NODE_ID: "agent",
                    sc.GRAPH_NODE_DISPLAY_NAME: NOM_AFFICHE,
                    sc.AGENT_NAME: NOM_AGENT,
                    sc.POC_SESSION: session_id,
                    sc.POC_DEMANDE: demande_id,
                }
            )
            yield rec

    @contextmanager
    def etape(self, nom: str, session_id: str, demande_id: str) -> Iterator[Enregistreur]:
        with self._span("agent", nom) as rec:
            if rec.observation is not None:
                rec.observation.session_id = session_id
                rec.observation.input = {"etape": nom, "demande_id": demande_id}
            rec.attributs.update(
                {
                    sc.GRAPH_NODE_ID: nom,
                    sc.GRAPH_NODE_PARENT_ID: "agent",
                    sc.GRAPH_NODE_DISPLAY_NAME: nom.replace("_", " "),
                    sc.AGENT_NAME: nom,
                    sc.POC_ETAPE: nom,
                    sc.POC_SESSION: session_id,
                    sc.POC_DEMANDE: demande_id,
                }
            )
            yield rec

    @contextmanager
    def appel_modele(
        self, modele: Any, systeme: str, messages: list[Any], outils: list[dict] | None, etape: str, session_id: str
    ) -> Iterator[Enregistreur]:
        with self._span("llm", f"llm.{etape}") as rec:
            if rec.observation is not None:
                rec.observation.session_id = session_id
                rec.observation.input = (
                    self._texte(systeme) if self.config.contenu_messages else f"[{len(messages)} messages]"
                )
            attrs: dict[str, Any] = {
                sc.LLM_MODEL_NAME: getattr(modele, "nom", str(modele)),
                sc.LLM_PROVIDER: self._fournisseur(modele),
                sc.LLM_SYSTEM: self._fournisseur(modele),
                sc.LLM_INVOCATION_PARAMETERS: json.dumps(
                    {
                        "temperature": getattr(modele, "temperature", None),
                        "max_tokens": getattr(modele, "max_tokens", None),
                    }
                ),
                sc.POC_MODELE_LOGIQUE: getattr(modele, "nom_logique", ""),
                sc.POC_ETAPE: etape,
                sc.POC_SESSION: session_id,
            }
            # Messages d'entrée : le système puis la conversation de l'étape. Un span a un plafond d'attributs
            # (OpenTelemetry) ; au-delà, le SDK jette les **plus anciens**, c'est-à-dire le genre de span et la session
            # posés en premier. On garde donc le système et les messages les plus récents qui tiennent dans le budget.
            budget = budget_attributs() - len(attrs) - len(outils or []) - RESERVE_SORTIE
            par_message = [self._attributs_message(m) for m in messages]
            retenus: list[dict[str, Any]] = []
            cout = 2  # le message système
            for d in reversed(par_message):
                if cout + len(d) > budget:
                    break
                retenus.insert(0, d)
                cout += len(d)
            omis = len(par_message) - len(retenus)
            attrs[f"{sc.LLM_INPUT_MESSAGES}.0.{sc.MESSAGE_ROLE}"] = "system"
            attrs[f"{sc.LLM_INPUT_MESSAGES}.0.{sc.MESSAGE_CONTENT}"] = self._contenu(systeme)
            for i, d in enumerate(retenus, start=1):
                for cle, valeur in d.items():
                    attrs[f"{sc.LLM_INPUT_MESSAGES}.{i}.{cle}"] = valeur
            if omis:
                attrs["poc.messages_omis"] = omis  # les plus anciens, absents du span (pas de la conversation réelle)
            for k, o in enumerate(outils or []):
                attrs[f"{sc.LLM_TOOLS}.{k}.{sc.TOOL_JSON_SCHEMA}"] = json.dumps(
                    {
                        "type": "function",
                        "function": {
                            "name": o["name"],
                            "description": o["description"],
                            "parameters": o["input_schema"],
                        },
                    },
                    ensure_ascii=False,
                )
            rec.attributs.update(attrs)
            yield rec

    def _attributs_message(self, m: Any) -> dict[str, Any]:
        d: dict[str, Any] = {sc.MESSAGE_ROLE: m.role}
        if m.contenu:
            d[sc.MESSAGE_CONTENT] = self._contenu(m.contenu)
        if m.role == "tool" and m.appel_id:
            d[sc.MESSAGE_TOOL_CALL_ID] = m.appel_id
        for j, a in enumerate(getattr(m, "appels", []) or []):
            d[f"{sc.MESSAGE_TOOL_CALLS}.{j}.{sc.TOOL_CALL_ID}"] = a.id
            d[f"{sc.MESSAGE_TOOL_CALLS}.{j}.{sc.TOOL_CALL_FUNCTION_NAME}"] = a.nom
            d[f"{sc.MESSAGE_TOOL_CALLS}.{j}.{sc.TOOL_CALL_FUNCTION_ARGUMENTS}"] = self._contenu(
                json.dumps(a.parametres, ensure_ascii=False)
            )
        return d

    def reponse_modele(self, rec: Enregistreur, rep: Any, cout_euros: float | None) -> None:
        """À appeler avec la réponse du modèle : messages de sortie, appels d'outils, tokens, coût si le prix est connu."""
        prefixe = f"{sc.LLM_OUTPUT_MESSAGES}.0"
        rec.attributs[f"{prefixe}.{sc.MESSAGE_ROLE}"] = "assistant"
        if rep.texte:
            rec.attributs[f"{prefixe}.{sc.MESSAGE_CONTENT}"] = self._contenu(rep.texte)
        for j, a in enumerate(rep.appels):
            rec.attributs[f"{prefixe}.{sc.MESSAGE_TOOL_CALLS}.{j}.{sc.TOOL_CALL_ID}"] = a.id
            rec.attributs[f"{prefixe}.{sc.MESSAGE_TOOL_CALLS}.{j}.{sc.TOOL_CALL_FUNCTION_NAME}"] = a.nom
            rec.attributs[f"{prefixe}.{sc.MESSAGE_TOOL_CALLS}.{j}.{sc.TOOL_CALL_FUNCTION_ARGUMENTS}"] = self._contenu(
                json.dumps(a.parametres, ensure_ascii=False)
            )
        rec.attributs[sc.LLM_TOKEN_PROMPT] = int(rep.tokens_entree)
        rec.attributs[sc.LLM_TOKEN_COMPLETION] = int(rep.tokens_sortie)
        rec.attributs[sc.LLM_TOKEN_TOTAL] = int(rep.tokens_entree + rep.tokens_sortie)
        if (
            cout_euros is not None
        ):  # un coût inconnu n'est pas un coût nul : la grille de coûts de la plateforme fera le calcul
            rec.attributs[sc.LLM_COST_TOTAL] = float(cout_euros)
        rec.attributs["poc.fin"] = rep.fin
        if rec.observation is not None:
            from ml_utils.observability.contracts import Usage

            rec.observation.usage = Usage(
                prompt_tokens=int(rep.tokens_entree),
                completion_tokens=int(rep.tokens_sortie),
                cost_usd=float(cout_euros) if cout_euros is not None else None,
            )
            rec.observation.output = (
                {
                    "texte": self._texte(rep.texte),
                    "appels": [{"outil": a.nom, "parametres": a.parametres} for a in rep.appels],
                }
                if self.config.contenu_messages
                else {"appels": [a.nom for a in rep.appels], "fin": rep.fin}
            )

    @contextmanager
    def appel_outil(
        self, nom: str, params: dict, etape: str, session_id: str, serveur: str = "direct", schema: dict | None = None
    ) -> Iterator[Enregistreur]:
        with self._span("tool", nom) as rec:
            if rec.observation is not None:
                rec.observation.session_id = session_id
                if self.config.contenu_messages:
                    rec.observation.input = ({k: v for k, v in params.items() if k != "code"} or {"outil": nom}) | (
                        {"code": params["code"]} if "code" in params else {}
                    )
                else:
                    rec.observation.input = {"outil": nom, "parametres": sorted(params)}
            rec.attributs.update(
                {
                    sc.TOOL_NAME: nom,
                    sc.TOOL_PARAMETERS: self._contenu(
                        json.dumps(
                            {k: v for k, v in params.items() if k != "session_id"}, ensure_ascii=False, default=str
                        )
                    ),
                    sc.POC_SERVEUR_MCP: serveur,
                    sc.POC_ETAPE: etape,
                    sc.POC_SESSION: session_id,
                }
            )
            if schema is not None:
                rec.attributs[sc.TOOL_JSON_SCHEMA] = json.dumps(schema, ensure_ascii=False)
            yield rec

    def garde_fou(self, nom: str, verdict: str, detail: Any, etape: str, session_id: str) -> None:
        """Un span GUARDRAIL fermé aussitôt : refus de l'atelier, arrêt de boucle, verdict d'un garde-fou de synthèse."""
        with self._span("guardrail", nom) as rec:
            if rec.observation is not None:
                rec.observation.session_id = session_id
                rec.observation.input = {"etape": etape}
                rec.observation.output = {"verdict": verdict, "detail": detail}
                rec.observation.error = False  # un refus est un fonctionnement normal du garde-fou, pas une panne
            rec.attributs.update({sc.POC_VERDICT: verdict, sc.POC_ETAPE: etape, sc.POC_SESSION: session_id})

    # ---- internes ---------------------------------------------------------------------------------------------------------------
    @contextmanager
    def _span(self, kind: str, nom: str) -> Iterator[Enregistreur]:
        if self.manager is None:
            yield Enregistreur()
            return
        from ml_utils.observability import SpanKind, observe_span

        with observe_span(SpanKind(kind), name=nom) as observation:
            rec = Enregistreur(observation=observation, masquer=not self.config.contenu_messages)
            try:
                from opentelemetry import trace

                ctx = trace.get_current_span().get_span_context()
                if ctx.is_valid:
                    rec.trace_id = format(ctx.trace_id, "032x")
                    rec.span_id = format(ctx.span_id, "016x")
            except Exception:  # noqa: BLE001
                pass
            try:
                yield rec
            except BaseException as exc:
                # un span interrompu garde une sortie lisible (et la brique ne signale plus de sortie manquante)
                if observation.output is None:
                    observation.output = {"interrompu": type(exc).__name__, "message": str(exc)[:300]}
                raise
            finally:
                if observation.output is None:
                    observation.output = {"vide": True}
                self._poser(rec.attributs)

    def _poser(self, attributs: dict[str, Any]) -> None:
        """Pose les attributs sur le span OpenTelemetry courant, qui est celui ouvert par la brique."""
        if not attributs:
            return
        try:
            from opentelemetry import trace

            span = trace.get_current_span()
            for cle, valeur in attributs.items():
                v = valeur
                if isinstance(v, (dict, list)):
                    v = json.dumps(v, ensure_ascii=False, default=str)
                if isinstance(v, str):
                    v = self._texte(v)
                if v is None:
                    continue
                span.set_attribute(cle, v)
        except Exception:  # noqa: BLE001 — l'observabilité ne doit jamais faire tomber l'agent
            logger.debug("attributs non posés", exc_info=True)

    def _contenu(self, valeur: Any) -> str:
        """Un contenu (message, argument d'outil) : en clair, tronqué, ou masqué si `contenu_messages` est faux."""
        return self._texte(valeur) if self.config.contenu_messages else MASQUE

    def _texte(self, valeur: Any) -> str:
        t = valeur if isinstance(valeur, str) else json.dumps(valeur, ensure_ascii=False, default=str)
        n = self.config.taille_max_attribut
        return t if len(t) <= n else t[:n] + f"… [{len(t) - n} caractères tronqués]"

    @staticmethod
    def _fournisseur(modele: Any) -> str:
        f = getattr(modele, "fournisseur", "")
        if f == "anthropic":
            return "anthropic"
        if f == "factice":
            return "factice"
        url = getattr(modele, "url", "") or ""
        for cle, nom in (
            ("mistral", "mistral"),
            ("groq", "groq"),
            ("googleapis", "google"),
            ("openai.com", "openai"),
            ("11434", "ollama"),
        ):
            if cle in url:
                return nom
        return "openai_compatible"


# ---------------------------------------------------------------------------------------------------------------------
# Instance de processus
# ---------------------------------------------------------------------------------------------------------------------
def demarrer(config: ConfigObservabilite | None = None) -> Observabilite:
    """Construit (une fois) l'observabilité du processus depuis la configuration. Fail-open : en cas d'erreur, inactif."""
    global _INSTANCE  # noqa: PLW0603
    with _VERROU:
        if _INSTANCE is not None:
            return _INSTANCE
        cfg = config or charger_config_observabilite()
        manager = None
        if cfg.effective:
            try:
                from ml_utils.observability import ArizeManager

                from poc.observabilite.sonde import collecteur_joignable, sonder_collecteur

                poser_autorite_interne()
                code, detail = sonder_collecteur(cfg, delai_s=5.0) if cfg.verifier_collecteur else (200, "")
                if not collecteur_joignable(code):
                    # un seul message, plutôt que des dizaines de reprises de l'exportateur pendant la session
                    print(
                        f"[observabilité] désactivée pour cette session : collecteur {cfg.backend} ({cfg.endpoint}) — {detail}",
                        file=sys.stderr,
                    )
                else:
                    _calmer_exportateur()
                    # le fournisseur de traces lit ce plafond à sa création : à poser avant de construire la brique
                    os.environ.setdefault("OTEL_SPAN_ATTRIBUTE_COUNT_LIMIT", str(LIMITE_ATTRIBUTS_SPAN))
                    manager = ArizeManager(vers_config_ml_utils(cfg))
                    logger.info("observabilité active : backend %s, projet %s", cfg.backend, cfg.projet)
            except Exception:  # noqa: BLE001
                logger.exception("observabilité indisponible : l'agent continue sans traces")
                manager = None
        _INSTANCE = Observabilite(cfg, manager)
        atexit.register(_INSTANCE.fermer)
        return _INSTANCE


def poser_autorite_interne() -> None:
    """L'exportateur OTLP de la brique lit son autorité de certification dans OTEL_EXPORTER_OTLP_CERTIFICATE, en chemin
    absolu (leçon du premier POC sur Mac) : on la pose depuis POC_CA_BUNDLE (relatif accepté) avant de construire la brique."""
    from poc.observabilite.config import autorite_interne

    if os.environ.get("OTEL_EXPORTER_OTLP_TRACES_CERTIFICATE") or os.environ.get("OTEL_EXPORTER_OTLP_CERTIFICATE"):
        return
    ca, _ = autorite_interne()
    if ca is not None and ca.is_file():
        os.environ["OTEL_EXPORTER_OTLP_CERTIFICATE"] = str(ca)


LIMITE_ATTRIBUTS_SPAN = (
    1024  # plafond OpenTelemetry par span posé au démarrage (128 par défaut, trop peu pour un appel LLM)
)
MARGE_BRIQUE = 40  # attributs posés par la brique et par les mesures de l'adaptateur
RESERVE_SORTIE = 60  # messages de sortie et appels d'outils posés après la réponse du modèle


def budget_attributs() -> int:
    """Attributs disponibles pour un span LLM, d'après le plafond effectif du SDK (variable d'environnement ou défaut 128)."""
    try:
        plafond = int(
            os.environ.get("OTEL_SPAN_ATTRIBUTE_COUNT_LIMIT") or os.environ.get("OTEL_ATTRIBUTE_COUNT_LIMIT") or 128
        )
    except ValueError:
        plafond = 128
    return max(20, plafond - MARGE_BRIQUE)


def _calmer_exportateur() -> None:
    """Les reprises de l'exportateur OTLP (« Transient error … retrying ») passent en silence ; un échec définitif
    (« Failed to export spans batch ») reste affiché."""
    import logging as _logging

    for nom in (
        "opentelemetry.exporter.otlp.proto.http.trace_exporter",
        "opentelemetry.exporter.otlp.proto.http._common",
    ):
        _logging.getLogger(nom).setLevel(_logging.ERROR)


def obtenir() -> Observabilite:
    return _INSTANCE if _INSTANCE is not None else demarrer()


def reinitialiser() -> None:
    """Pour les tests : ferme et oublie l'instance de processus."""
    global _INSTANCE  # noqa: PLW0603
    with _VERROU:
        if _INSTANCE is not None:
            _INSTANCE.fermer()
        _INSTANCE = None


def instrumenter_mcp(obs: Observabilite) -> bool:
    """Branche la propagation de contexte MCP (client ou serveur) sur le fournisseur de traces de la brique."""
    if not obs.actif or not obs.config.propagation_mcp or obs.tracer_provider is None:
        return False
    try:
        from openinference.instrumentation.mcp import MCPInstrumentor

        MCPInstrumentor().instrument(tracer_provider=obs.tracer_provider)
        return True
    except Exception:  # noqa: BLE001
        logger.debug("instrumentation MCP non branchée", exc_info=True)
        return False
