"""Sonde du collecteur de traces : une requête OTLP vide (protobuf vide = requête valide), avec les en-têtes et la
vérification TLS de l'exportateur. Distingue réseau, certificat, authentification et chemin, sans rien laisser derrière.

Sert à `poc obs sante` (diagnostic) et au démarrage de l'observabilité : un collecteur injoignable désactive les traces
avec un seul message, au lieu de laisser l'exportateur réessayer et remplir le terminal pendant toute la session.
"""

from __future__ import annotations

from poc.observabilite.config import ConfigObservabilite, autorite_interne


def sonder_collecteur(cfg: ConfigObservabilite, delai_s: float = 10.0) -> tuple[int | None, str]:
    """(code HTTP ou None, explication lisible)."""
    import requests

    if not cfg.endpoint:
        return None, "aucune adresse de collecteur (OBS_ENDPOINT)"
    if "<" in cfg.endpoint:
        return None, f"adresse d'exemple ({cfg.endpoint}) : renseigner OBS_ENDPOINT dans .env"
    en_tetes = {"content-type": "application/x-protobuf"}
    if cfg.backend == "arize" and cfg.api_key:
        en_tetes.update(
            {
                "authorization": f"Bearer {cfg.api_key}",
                "api_key": cfg.api_key,
                "space_id": cfg.space_id or "",
                "arize-space-id": cfg.space_id or "",
            }
        )
    ca, variable = autorite_interne()
    if ca is not None and not ca.is_file():
        return None, f"autorité interne introuvable : {ca} (indiquée par {variable})"
    verification: str | bool = str(ca) if ca is not None else True
    try:
        rep = requests.post(cfg.endpoint, data=b"", headers=en_tetes, timeout=delai_s, verify=verification)
    except requests.exceptions.SSLError as exc:
        return None, (
            f"certificat refusé ({str(exc)[:160]}). Indiquer l'autorité interne dans .env : POC_CA_BUNDLE=ca-bundle.crt "
            "(fichier PEM, chemin relatif à la racine du projet ou absolu)."
        )
    except requests.exceptions.ConnectionError:
        aide = " Phoenix est-il lancé (`poc obs phoenix`) ?" if cfg.backend == "phoenix" else ""
        return None, f"connexion refusée ou hôte injoignable.{aide}"
    except requests.exceptions.RequestException as exc:
        return None, f"réseau : {type(exc).__name__} — {str(exc)[:200]}"
    aide = {
        401: "clé API refusée (OBS_API_KEY)",
        403: "accès refusé : clé ou espace incorrect (OBS_API_KEY, OBS_SPACE_ID)",
        404: "chemin introuvable : l'adresse doit se terminer par /v1/traces",
        500: "erreur du collecteur (projet vide ou non routable ?)",
    }.get(rep.status_code, rep.text[:200])
    return rep.status_code, f"HTTP {rep.status_code} : {aide}"


def collecteur_joignable(code: int | None) -> bool:
    return code is not None and 200 <= code < 300
