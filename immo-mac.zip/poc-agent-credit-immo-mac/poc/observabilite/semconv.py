"""Les clés d'attributs OpenInference que la brique ml_utils n'émet pas et que l'agent pose lui-même.

Elles suivent les conventions sémantiques OpenInference (paquet `openinference-semantic-conventions`) ; les littéraux sont
repris ici pour que le module ne dépende pas de l'import du paquet, et pour documenter d'un coup ce que lit Arize AX :

- `llm.input_messages.{i}.message.role` / `.content` et `llm.output_messages.{i}.message.*` : la conversation vue par le
  modèle, dont les appels d'outils (`...message.tool_calls.{j}.tool_call.function.name` / `.arguments`) ; base des
  évaluations de trajectoire et d'appel d'outils ;
- `llm.tools.{i}.tool.json_schema` : les outils proposés au modèle ;
- `llm.model_name`, `llm.provider`, `llm.invocation_parameters`, `llm.token_count.*` : identité de l'appel et comptage, base
  du suivi des coûts ;
- `tool.name`, `tool.parameters`, `tool.json_schema` : l'appel d'outil tel que l'agent l'a demandé ;
- `graph.node.id`, `graph.node.parent_id`, `graph.node.display_name`, `agent.name` : le graphe de l'agent.
"""

from __future__ import annotations

SPAN_KIND = "openinference.span.kind"
INPUT_VALUE = "input.value"
OUTPUT_VALUE = "output.value"

LLM_MODEL_NAME = "llm.model_name"
LLM_PROVIDER = "llm.provider"
LLM_SYSTEM = "llm.system"
LLM_INVOCATION_PARAMETERS = "llm.invocation_parameters"
LLM_INPUT_MESSAGES = "llm.input_messages"
LLM_OUTPUT_MESSAGES = "llm.output_messages"
LLM_TOOLS = "llm.tools"
LLM_TOKEN_PROMPT = "llm.token_count.prompt"
LLM_TOKEN_COMPLETION = "llm.token_count.completion"
LLM_TOKEN_TOTAL = "llm.token_count.total"
LLM_COST_TOTAL = "llm.cost.total"

MESSAGE_ROLE = "message.role"
MESSAGE_CONTENT = "message.content"
MESSAGE_TOOL_CALLS = "message.tool_calls"
MESSAGE_TOOL_CALL_ID = "message.tool_call_id"
TOOL_CALL_ID = "tool_call.id"
TOOL_CALL_FUNCTION_NAME = "tool_call.function.name"
TOOL_CALL_FUNCTION_ARGUMENTS = "tool_call.function.arguments"
TOOL_JSON_SCHEMA = "tool.json_schema"

TOOL_NAME = "tool.name"
TOOL_DESCRIPTION = "tool.description"
TOOL_PARAMETERS = "tool.parameters"

GRAPH_NODE_ID = "graph.node.id"
GRAPH_NODE_PARENT_ID = "graph.node.parent_id"
GRAPH_NODE_DISPLAY_NAME = "graph.node.display_name"
AGENT_NAME = "agent.name"

SESSION_ID = "session.id"
USER_ID = "user.id"
METADATA = "metadata"

# Clés propres au POC (préfixe `poc.`), filtrables dans Arize comme toute autre clé.
POC_DEMANDE = "poc.demande_id"
POC_SESSION = "poc.session_id"
POC_ETAPE = "poc.etape"
POC_MODELE_LOGIQUE = "poc.modele_logique"
POC_MODE_OUTILS = "poc.mode_outils"
POC_SERVEUR_MCP = "poc.serveur_mcp"
POC_ERREUR_CODE = "poc.erreur_code"
POC_VERDICT = "poc.verdict"
POC_TOURS = "metric.tours"
POC_APPELS = "metric.appels_outils"
POC_TOKENS = "metric.tokens"
POC_COUT = "metric.cout_euros"
POC_ARRET = "poc.arret"
