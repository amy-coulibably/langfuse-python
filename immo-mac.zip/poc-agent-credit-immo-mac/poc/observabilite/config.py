"""Configuration de l'observabilité : `config/observabilite.yaml` + variables `OBS_*` de la brique ml_utils.

Le fichier porte les réglages lisibles (actif, backend, projet, redaction, détail des messages) ; l'environnement porte les
secrets et peut surcharger chaque coordonnée (`OBS_ENABLED`, `OBS_BACKEND`, `OBS_ENDPOINT`, `OBS_PROJECT`, `OBS_API_KEY`,
`OBS_SPACE_ID`, `OBS_ENV`, `OBS_SAMPLE_RATE`), ce qui permet de basculer de Phoenix à Arize AX sans toucher au dépôt.
"""

from __future__ import annotations

import os
from pathlib import Path
from typing import Any, Literal

import yaml
from pydantic import BaseModel, Field

from poc.config import CONFIG_DIR

CHEMIN_DEFAUT = CONFIG_DIR / "observabilite.yaml"


class ConfigObservabilite(BaseModel):
    active: bool = False
    backend: Literal["noop", "phoenix", "arize"] = "noop"
    endpoint: str | None = None
    projet: str = "agent-credit-immo"
    model_id: str = "agent-credit-immo"
    environnement: Literal["dev", "pprod", "prod"] = "dev"
    utilisateur: str = "conseiller-poc"
    taux_echantillonnage: float = Field(default=1.0, ge=0.0, le=1.0)
    redaction: Literal["none", "mask_pii", "mask_identifiers"] = "none"
    contenu_messages: bool = True
    taille_max_attribut: int = Field(default=20_000, ge=200)
    propagation_mcp: bool = True
    verifier_collecteur: bool = True  # sonde le collecteur au démarrage ; injoignable = traces désactivées
    attente_ingestion_s: int = Field(default=150, ge=0)  # Arize : attente maximale du span racine avant d'évaluer
    api_key: str | None = None  # jamais dans le yaml : OBS_API_KEY
    space_id: str | None = None  # OBS_SPACE_ID
    records_uri: str | None = None  # OBS_RECORDS_URI : porte records d'Arize ; absente = pas de records
    arize_hote: str | None = None  # OBS_ARIZE_HOTE : hôte du SDK Arize (évaluations) ; défaut = hôte de OBS_ENDPOINT
    arize_port: int | None = None  # OBS_ARIZE_PORT : port du SDK Arize ; défaut = port de OBS_ENDPOINT

    @property
    def effective(self) -> bool:
        return self.active and self.backend != "noop"


def _bool(valeur: str | None, defaut: bool) -> bool:
    if valeur is None:
        return defaut
    return valeur.strip().lower() in {"1", "true", "yes", "on", "oui"}


def charger_config_observabilite(chemin: Path | None = None, env: dict[str, str] | None = None) -> ConfigObservabilite:
    environ = os.environ if env is None else env
    chemin = chemin or Path(environ.get("POC_OBS_CONFIG", str(CHEMIN_DEFAUT)))
    brut: dict[str, Any] = {}
    if chemin.exists():
        with chemin.open(encoding="utf-8") as f:
            brut = yaml.safe_load(f) or {}
    cfg = ConfigObservabilite(**brut)
    # l'environnement prime : coordonnées de plateforme et secrets
    maj: dict[str, Any] = {"active": _bool(environ.get("OBS_ENABLED"), cfg.active)}
    if environ.get("OBS_BACKEND"):
        maj["backend"] = environ["OBS_BACKEND"].strip().lower()
    if environ.get("OBS_ENDPOINT"):
        maj["endpoint"] = environ["OBS_ENDPOINT"]
    if environ.get("OBS_PROJECT"):
        maj["projet"] = environ["OBS_PROJECT"]
    if environ.get("OBS_ENV"):
        maj["environnement"] = environ["OBS_ENV"].strip().lower()
    if environ.get("OBS_SAMPLE_RATE"):
        maj["taux_echantillonnage"] = float(environ["OBS_SAMPLE_RATE"])
    if environ.get("OBS_API_KEY"):
        maj["api_key"] = environ["OBS_API_KEY"]
    if environ.get("OBS_SPACE_ID"):
        maj["space_id"] = environ["OBS_SPACE_ID"]
    if environ.get("OBS_RECORDS_URI"):
        maj["records_uri"] = environ["OBS_RECORDS_URI"]
    if environ.get("OBS_ATTENTE_INGESTION_S"):
        maj["attente_ingestion_s"] = int(environ["OBS_ATTENTE_INGESTION_S"])
    if environ.get("OBS_CONTENU_MESSAGES"):
        maj["contenu_messages"] = _bool(environ["OBS_CONTENU_MESSAGES"], cfg.contenu_messages)
    if environ.get("OBS_REDACTION"):
        maj["redaction"] = environ["OBS_REDACTION"].strip().lower()
    if environ.get("OBS_ARIZE_HOTE"):
        maj["arize_hote"] = environ["OBS_ARIZE_HOTE"].strip()
    if environ.get("OBS_ARIZE_PORT"):
        maj["arize_port"] = int(environ["OBS_ARIZE_PORT"])
    return cfg.model_copy(update=maj)


VARIABLES_AUTORITE = (
    "OBS_CA_BUNDLE",
    "OTEL_EXPORTER_OTLP_TRACES_CERTIFICATE",
    "OTEL_EXPORTER_OTLP_CERTIFICATE",
    "POC_CA_BUNDLE",
    "REQUESTS_CA_BUNDLE",
)


def autorite_interne(environ: dict[str, str] | None = None) -> tuple[Path | None, str | None]:
    """Le fichier PEM de l'autorité interne qui signe le certificat de l'instance Arize (et souvent de la passerelle LLM) :
    (chemin absolu, variable qui l'indique). Un chemin relatif part de la racine du projet. Une seule variable suffit dans
    `.env` (POC_CA_BUNDLE) : elle sert à l'exportateur des traces, à la sonde et au SDK Arize."""
    from poc.config import RACINE

    env = os.environ if environ is None else environ
    for variable in VARIABLES_AUTORITE:
        valeur = (env.get(variable) or "").strip()
        if valeur:
            chemin = Path(valeur).expanduser()
            return (chemin if chemin.is_absolute() else RACINE / chemin), variable
    return None, None


def vers_config_ml_utils(cfg: ConfigObservabilite):
    """Traduit notre configuration en `ObservabilityConfig` de la brique (famille générative, multi-étapes, transport API).

    `model_version` reste volontairement vide : la brique recopie cette valeur dans `llm.model_name` de chaque span, ce qui
    fausserait le suivi des coûts d'Arize ; le nom réel du modèle est posé par l'adaptateur sur les seuls spans LLM."""
    from ml_utils.observability import Family, ObservabilityConfig, Topology, Transport
    from ml_utils.observability.contracts import DeploymentEnv, RedactionPolicy
    from pydantic import SecretStr

    return ObservabilityConfig(
        family=Family.GENERATIVE,
        transport=Transport.API,
        topology=Topology.MULTISTEP,
        model_id=cfg.model_id,
        model_version=None,
        backend=cfg.backend if cfg.effective else "noop",
        endpoint=cfg.endpoint,
        api_key=SecretStr(cfg.api_key) if cfg.api_key else None,
        space_id=cfg.space_id,
        project=cfg.projet,
        records_uri=cfg.records_uri,
        records_flight_host=environ_hote(cfg.records_uri),
        environment=DeploymentEnv(cfg.environnement),
        enabled=cfg.effective,
        sample_rate=cfg.taux_echantillonnage,
        redaction=RedactionPolicy(cfg.redaction),
    )


def environ_hote(uri: str | None) -> str | None:
    if not uri:
        return None
    from urllib.parse import urlparse

    return urlparse(uri).hostname
