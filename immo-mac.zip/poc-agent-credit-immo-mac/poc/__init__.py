"""POC : un agent qui prépare un dossier de crédit immobilier pour un conseiller, sur données synthétiques, en local."""

__version__ = "0.1.0"
