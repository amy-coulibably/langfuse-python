"""Accès aux bases SQLite par nom de table, sans SQL dispersé dans le code métier.

Une table par nom logique (`agent_sessions`, `banque_compte`, `vt_attendu`…). `ecrire` remplace ou ajoute, `remplacer`
réécrit les seules lignes d'une clé, `requete` et `executer` sont réservés aux services et aux tests : l'agent ne voit
jamais de SQL. Remplacer SQLite par une autre base ne touche que ce module.
"""

from __future__ import annotations

import sqlite3
from pathlib import Path

import polars as pl


class SQLiteStore:
    def __init__(self, chemin: Path) -> None:
        self.chemin = Path(chemin)
        self.chemin.parent.mkdir(parents=True, exist_ok=True)
        self._wal_active = False

    def _connexion(self) -> sqlite3.Connection:
        con = sqlite3.connect(self.chemin, timeout=30)
        if not self._wal_active:
            con.execute("PRAGMA journal_mode=WAL")
            self._wal_active = True
        return con

    def lire(self, nom: str) -> pl.DataFrame:
        if not self.existe(nom):
            raise FileNotFoundError(f"Table absente de la base {self.chemin.name} : {nom}")
        return self.requete(f'SELECT * FROM "{nom}"')

    def ecrire(self, nom: str, df: pl.DataFrame, *, ajouter: bool = False) -> None:
        with self._connexion() as con:
            if not ajouter:
                con.execute(f'DROP TABLE IF EXISTS "{nom}"')
            if not ajouter or not self._existe_con(con, nom):
                self._creer(con, nom, df)
            else:
                self._completer_colonnes(con, nom, df)
            self._inserer(con, nom, df)
            con.commit()

    def remplacer(self, nom: str, df: pl.DataFrame, cle: str, valeur: str) -> None:
        """Remplace les lignes d'une clé (par exemple un `session_id`) sans toucher au reste de la table."""
        with self._connexion() as con:
            if not self._existe_con(con, nom):
                self._creer(con, nom, df)
                if cle in df.columns:
                    con.execute(f'CREATE INDEX IF NOT EXISTS "idx_{nom}_{cle}" ON "{nom}" ("{cle}")')
            else:
                self._completer_colonnes(con, nom, df)
                con.execute(f'DELETE FROM "{nom}" WHERE "{cle}" = ?', (valeur,))
            self._inserer(con, nom, df)
            con.commit()

    def requete(self, sql: str, parametres: tuple = ()) -> pl.DataFrame:
        """Réservé aux services, aux API et aux tests ; jamais exposé à l'agent."""
        with self._connexion() as con:
            curseur = con.execute(sql, parametres)
            colonnes = [d[0] for d in curseur.description]
            lignes = curseur.fetchall()
        if not lignes:
            return pl.DataFrame({c: [] for c in colonnes})
        return pl.DataFrame(lignes, schema=colonnes, orient="row")

    def executer(self, sql: str, parametres: tuple = ()) -> None:
        """Écriture ponctuelle (mise à jour d'un statut) ; réservé aux services, jamais exposé à l'agent."""
        with self._connexion() as con:
            con.execute(sql, parametres)
            con.commit()

    def existe(self, nom: str) -> bool:
        with self._connexion() as con:
            return self._existe_con(con, nom)

    def lister(self) -> list[str]:
        with self._connexion() as con:
            return sorted(r[0] for r in con.execute("SELECT name FROM sqlite_master WHERE type='table'"))

    @staticmethod
    def _existe_con(con: sqlite3.Connection, nom: str) -> bool:
        r = con.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name=?", (nom,)).fetchone()
        return r is not None

    @staticmethod
    def _creer(con: sqlite3.Connection, nom: str, df: pl.DataFrame) -> None:
        colonnes = ", ".join(f'"{c}" {_type_sqlite(dt)}' for c, dt in df.schema.items())
        con.execute(f'CREATE TABLE "{nom}" ({colonnes})')

    @staticmethod
    def _completer_colonnes(con: sqlite3.Connection, nom: str, df: pl.DataFrame) -> None:
        existantes = {r[1] for r in con.execute(f'PRAGMA table_info("{nom}")')}
        for c, dt in df.schema.items():
            if c not in existantes:
                con.execute(f'ALTER TABLE "{nom}" ADD COLUMN "{c}" {_type_sqlite(dt)}')

    @staticmethod
    def _inserer(con: sqlite3.Connection, nom: str, df: pl.DataFrame) -> None:
        if not df.height:
            return
        colonnes = ", ".join(f'"{c}"' for c in df.columns)
        marque = ", ".join("?" for _ in df.columns)
        con.executemany(f'INSERT INTO "{nom}" ({colonnes}) VALUES ({marque})', _lignes_sqlite(df))


def _type_sqlite(dtype: pl.DataType) -> str:
    if dtype.is_integer() or dtype == pl.Boolean:
        return "INTEGER"
    if dtype.is_float():
        return "REAL"
    return "TEXT"


def _lignes_sqlite(df: pl.DataFrame) -> list[tuple]:
    """Convertit dates et booléens en texte / entier pour SQLite."""
    df2 = df.with_columns(
        [pl.col(c).cast(pl.Utf8) for c, dt in df.schema.items() if dt in (pl.Date, pl.Datetime)]
        + [pl.col(c).cast(pl.Int64) for c, dt in df.schema.items() if dt == pl.Boolean]
    )
    return df2.rows()
