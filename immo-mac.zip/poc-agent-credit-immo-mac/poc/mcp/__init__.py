"""MCP : les outils servis par des processus séparés (serveurs stdio) et découverts par le client."""

from poc.mcp.client import BackendMCP
from poc.mcp.serveur import SERVEURS, creer_serveur, outils_du_serveur

__all__ = ["SERVEURS", "BackendMCP", "creer_serveur", "outils_du_serveur"]
