"""`BackendMCP` : le client. Au démarrage il lance les serveurs (processus stdio), leur demande la liste de leurs outils
(découverte dynamique), puis route chaque appel vers le serveur qui publie l'outil.

Le protocole est asynchrone ; l'agent et le registre sont synchrones. Le client tient donc une boucle d'événements dans un
fil dédié et y soumet chaque opération. Un `with BackendMCP(...) as b:` ouvre et ferme les serveurs ; sans `with`, `fermer()`.
"""

from __future__ import annotations

import asyncio
import json
import os
import sys
import threading
from concurrent.futures import Future
from typing import Any

from poc.config import RACINE
from poc.outils.backend import ErreurOutil

DELAI_APPEL_S = 120.0
SERVEURS_PAR_DEFAUT = ("coffre", "banque", "conseiller")


class BackendMCP:
    """Même rôle que `BackendLocal`, mais les outils servis à distance sont appelés par leur nom MCP.

    `executer_outil` du registre détecte `appeler_outil` et passe par lui pour les outils qui ont un serveur ; les mains
    propres de l'agent (fiches, atelier, feuille de calcul) et les opérations de l'orchestrateur (sessions, journal, traces)
    passent par le backend classique."""

    def __init__(
        self,
        orchestrateur: Any = None,
        serveurs: tuple[str, ...] = SERVEURS_PAR_DEFAUT,
        python: str | None = None,
        cwd: str | None = None,
        env: dict[str, str] | None = None,
    ) -> None:
        if orchestrateur is None:
            from poc.config import charger_config
            from poc.outils.backend import BackendLocal

            orchestrateur = BackendLocal(charger_config())
        self.orchestrateur = orchestrateur
        self._serveurs = serveurs
        self._python = python or sys.executable
        self._cwd = cwd or str(RACINE)
        # le transport stdio n'hérite pas de l'environnement du parent : on le transmet (données, clés LLM, OBS_*)
        self._env = env if env is not None else dict(os.environ)
        self._boucle = asyncio.new_event_loop()
        self._fil = threading.Thread(target=self._boucle.run_forever, name="mcp-client", daemon=True)
        self._fil.start()
        self._sessions: dict[str, Any] = {}
        self._piles: dict[str, Any] = {}
        self.outils: dict[str, dict] = {}  # nom -> {"serveur", "description", "input_schema"}
        self._soumettre(self._ouvrir()).result(timeout=60)

    # ---- cycle de vie -------------------------------------------------------------------------------------------------------
    def _soumettre(self, coro) -> Future:
        return asyncio.run_coroutine_threadsafe(coro, self._boucle)

    async def _ouvrir(self) -> None:
        from contextlib import AsyncExitStack

        from poc.observabilite import instrumenter_mcp, obtenir

        instrumenter_mcp(obtenir())  # relie les spans des serveurs à la trace du client (sans effet si inactif)

        from mcp import ClientSession
        from mcp.client.stdio import StdioServerParameters, stdio_client

        for serveur in self._serveurs:
            pile = AsyncExitStack()
            params = StdioServerParameters(
                command=self._python, args=["-m", "poc.mcp.serveur", serveur], cwd=self._cwd, env=self._env
            )
            lecture, ecriture = await pile.enter_async_context(stdio_client(params))
            session = await pile.enter_async_context(ClientSession(lecture, ecriture))
            await session.initialize()
            reponse = await session.list_tools()
            for t in reponse.tools:
                self.outils[t.name] = {
                    "serveur": serveur,
                    "description": t.description or "",
                    "input_schema": t.input_schema,
                }
            self._sessions[serveur] = session
            self._piles[serveur] = pile

    async def _fermer(self) -> None:
        for pile in reversed(list(self._piles.values())):
            try:
                await pile.aclose()
            except Exception:  # noqa: BLE001 — la fermeture d'un processus déjà parti ne doit pas lever
                pass
        self._piles.clear()
        self._sessions.clear()

    def fermer(self) -> None:
        if self._boucle.is_closed():
            return
        try:
            self._soumettre(self._fermer()).result(timeout=30)
        finally:
            self._boucle.call_soon_threadsafe(self._boucle.stop)
            self._fil.join(timeout=5)
            self._boucle.close()

    def __enter__(self) -> BackendMCP:
        return self

    def __exit__(self, *exc) -> None:
        self.fermer()

    # ---- appels -------------------------------------------------------------------------------------------------------------
    def outils_decouverts(self) -> list[str]:
        return sorted(self.outils)

    def serveurs_ouverts(self) -> list[str]:
        return list(self._sessions)

    def appeler_outil(self, nom: str, params: dict) -> Any:
        if nom not in self.outils:
            raise ErreurOutil(
                "OUTIL_INCONNU", f"aucun serveur MCP ne publie l'outil {nom} ; publiés : {self.outils_decouverts()}"
            )
        serveur = self.outils[nom]["serveur"]
        resultat = self._soumettre(
            self._sessions[serveur].call_tool(nom, params, read_timeout_seconds=DELAI_APPEL_S)
        ).result(timeout=DELAI_APPEL_S + 5)
        texte = "".join(getattr(c, "text", "") for c in (resultat.content or []))
        if getattr(resultat, "is_error", False):
            try:
                d = json.loads(texte[texte.index("{") : texte.rindex("}") + 1])
                raise ErreurOutil(d.get("code", "ERREUR"), d.get("message", texte))
            except (ValueError, KeyError):
                raise ErreurOutil("ERREUR_MCP", texte[:600]) from None
        try:
            return json.loads(texte)  # le serveur renvoie toujours un seul bloc de texte JSON
        except json.JSONDecodeError:
            return texte

    # ---- opérations de l'orchestrateur et mains propres : par le backend classique ---------------------------------------------
    def lire(self, route: str, **params: Any) -> Any:
        return self.orchestrateur.lire(route, **params)

    def ecrire(self, route: str, corps: dict) -> Any:
        return self.orchestrateur.ecrire(route, corps)
