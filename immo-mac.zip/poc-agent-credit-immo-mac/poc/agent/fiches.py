"""Les fiches de méthode (`fiches/*.md`) et l'assemblage de la consigne d'une étape.

Une fiche est un fichier Markdown avec un en-tête facultatif (`---` nom, description `---`) puis un corps en français. La
consigne d'une étape = les règles communes, les fiches de l'étape (en entier), puis le contexte de travail : la question,
les identifiants, les outils visibles, la sortie attendue, le format de fin d'étape, et les synthèses des étapes passées.
Les autres fiches sont listées avec leur résumé : l'agent les lit à la demande avec `consulter_fiche`.
"""

from __future__ import annotations

import json
import re
from pathlib import Path

from poc.config import FICHES_DIR
from poc.etapes import Etape, charger_parcours

FICHE_COMMUNE = "00-regles-communes"

FORMAT_FIN_ETAPE = {
    "resume": "ce que l'étape a établi, en deux ou trois phrases à la première personne",
    "points_cles": ["les faits ou décisions marquants, un par entrée"],
    "doutes": ["ce qui reste incertain et devra être signalé au conseiller"],
    "bloquant": False,
}


def _chemin(nom: str, dossier: Path) -> Path:
    nom = nom[:-3] if nom.endswith(".md") else nom
    return dossier / f"{nom}.md"


def lire_fiche(nom: str, dossier: Path = FICHES_DIR) -> str:
    chemin = _chemin(nom, dossier)
    if not chemin.exists():
        raise FileNotFoundError(f"fiche de méthode absente : {chemin.name} (dossier {dossier})")
    return chemin.read_text(encoding="utf-8")


def _en_tete(texte: str) -> tuple[dict[str, str], str]:
    """Sépare l'en-tête `---` (clé: valeur) du corps ; sans en-tête, le titre de niveau 1 sert de nom."""
    m = re.match(r"^---\s*\n(.*?)\n---\s*\n", texte, flags=re.S)
    meta: dict[str, str] = {}
    corps = texte
    if m:
        for ligne in m.group(1).splitlines():
            if ":" in ligne:
                k, v = ligne.split(":", 1)
                meta[k.strip()] = v.strip().strip('"')
        corps = texte[m.end() :]
    if "titre" not in meta:
        t = re.search(r"^#\s+(.+)$", corps, flags=re.M)
        meta["titre"] = t.group(1).strip() if t else ""
    if "description" not in meta:
        paragraphes = [p.strip() for p in re.split(r"\n\s*\n", corps) if p.strip() and not p.strip().startswith("#")]
        meta["description"] = (paragraphes[0][:200] if paragraphes else "").replace("\n", " ")
    return meta, corps


def lister_fiches(dossier: Path = FICHES_DIR) -> list[dict[str, str]]:
    """Toutes les fiches présentes : nom (sans extension), titre, description courte."""
    out = []
    for chemin in sorted(dossier.glob("*.md")):
        if chemin.stem.upper() == "README":
            continue
        meta, _ = _en_tete(chemin.read_text(encoding="utf-8"))
        out.append({"nom": chemin.stem, "titre": meta.get("titre", ""), "description": meta.get("description", "")})
    return out


def fiches_manquantes(dossier: Path = FICHES_DIR) -> list[str]:
    """Les fiches que le parcours déclare et qui n'existent pas encore (lot 3), règles communes comprises."""
    attendues = [FICHE_COMMUNE] + [f for e in charger_parcours().etapes for f in e.fiches]
    vues: list[str] = []
    for f in attendues:
        if f not in vues and not _chemin(f, dossier).exists():
            vues.append(f)
    return vues


SITUATIONS = {"cdi": "CDI", "cdd": "CDD", "auto_entrepreneur": "indépendant(e)", "retraite": "retraité(e)"}


def _emprunteur_en_bref(e: dict) -> str:
    """Une personne en une ligne, avec ce que la banque sait d'elle : situation, âge et ancienneté au dépôt."""
    sit = SITUATIONS.get(str(e.get("situation_pro")), str(e.get("situation_pro") or ""))
    morceaux = [
        f"{e.get('prenom', '')} {e.get('nom', '')} ({e.get('role', '')}, identifiant client `{e.get('client_id', '')}`"
    ]
    if e.get("age_au_depot") is not None:
        morceaux.append(f"{e['age_au_depot']} ans au dépôt")
    detail = sit
    if e.get("situation_pro") in ("cdi", "cdd") and e.get("employeur"):
        detail += f" chez {e['employeur']} depuis le {e.get('date_entree')}"
    elif e.get("situation_pro") == "auto_entrepreneur" and e.get("debut_activite"):
        detail += f", {e.get('activite') or 'activité'} depuis le {e['debut_activite']}"
    elif e.get("situation_pro") == "retraite" and e.get("date_entree"):
        detail += f", pension liquidée le {e['date_entree']}"
    if e.get("anciennete_mois_au_depot") is not None:
        detail += f", soit {e['anciennete_mois_au_depot']} mois au dépôt"
    morceaux.append(detail + ")")
    return ", ".join(morceaux)


def consigne_systeme(
    etape: Etape,
    demande_id: str,
    session_id: str,
    syntheses: dict[str, dict],
    outils: list[dict],
    dossier: Path = FICHES_DIR,
    demande: dict | None = None,
) -> str:
    """La consigne complète d'une étape. `demande` : la demande telle que la banque la donne (emprunteurs et identifiants
    clients, projet), rappelée à chaque étape pour que l'agent n'ait pas à la retrouver dans l'historique."""
    parties: list[str] = [lire_fiche(FICHE_COMMUNE, dossier)]
    for nom in etape.fiches:
        try:
            parties.append(lire_fiche(nom, dossier))
        except FileNotFoundError:
            parties.append(
                f"# Fiche « {nom} »\n\n(fiche de méthode à écrire : en son absence, appliquer les règles communes avec prudence)"
            )
    autres = [f for f in lister_fiches(dossier) if f["nom"] not in etape.fiches and f["nom"] != FICHE_COMMUNE]
    contexte = [
        "# Contexte de travail",
        "",
        f"- Étape en cours : **{etape.titre}** (`{etape.nom}`)",
        f"- Question de l'étape : {etape.question}",
        f"- demande_id : `{demande_id}`",
        f"- session_id : `{session_id}` (à passer aux outils qui le demandent)",
        "- Outils disponibles à cette étape : " + (", ".join(o["name"] for o in outils) or "aucun"),
        f"- Ce que l'étape doit laisser derrière elle : {etape.sortie}" if etape.sortie else "",
    ]
    if demande:
        emprunteurs = " ; ".join(_emprunteur_en_bref(e) for e in demande.get("emprunteurs", []))
        mois = demande.get("mois_attendus_fiches_et_releves") or []
        contexte += [
            "",
            "# La demande, en bref (rappel identique à chaque étape)",
            "",
            f"- Emprunteurs : {emprunteurs or 'inconnus'}",
            f"- Projet : {demande.get('description_bien', '')}, {demande.get('adresse_bien', '')} ; prix {demande.get('prix', '')} € "
            f"(dont honoraires d'agence {demande.get('honoraires_agence_inclus', '')} €), apport {demande.get('apport', '')} €, "
            f"durée souhaitée {demande.get('duree_souhaitee_annees', '')} ans, usage {demande.get('usage', '')}, bien {demande.get('type_bien', '')}",
            f"- Foyer : {demande.get('situation_familiale', '')}, {demande.get('nb_enfants', 0)} enfant(s) ; loyer actuel déclaré {demande.get('loyer_actuel_declare', '')} € ; "
            f"date de dépôt {demande.get('date_depot', '')} ; condition suspensive jusqu'au {demande.get('date_limite_pret', '')}",
            f"- Crédits déclarés par le client : {len(demande.get('credits_declares_par_le_client') or [])}, "
            f"total {demande.get('total_mensualites_credits_declares', 0)} € par mois (champ `total_mensualites_credits_declares` de la demande, "
            "à noter comme fait `credits_en_cours_mensualites`, source demande)",
            (
                f"- Mois attendus pour les fiches de paie et les relevés (les trois mois avant le dépôt) : {', '.join(mois)} ; "
                f"déclarations de chiffre d'affaires jusqu'à {mois[-1]}. Ne demande pas d'autres mois."
            )
            if mois
            else "",
            "- Les âges et anciennetés ci-dessus sont calculés par la banque à partir des dates : utilise-les tels quels (le simulateur "
            "prend les âges de la demande si tu ne lui en donnes pas) ; ils ne s'enregistrent pas comme faits et ne font pas douter.",
        ]
    if autres:
        contexte += ["", "Autres fiches consultables avec `consulter_fiche` :"] + [
            f"- `{f['nom']}` : {f['description']}" for f in autres
        ]
    contexte += [
        "",
        "# Fin d'étape",
        "",
        "Commence par dire en une phrase ce que tu vas faire. Quand l'étape est terminée, réponds sans appel d'outil avec un "
        "seul objet JSON de cette forme :",
        "```json",
        json.dumps(FORMAT_FIN_ETAPE, ensure_ascii=False, indent=1),
        "```",
    ]
    if syntheses:
        contexte += ["", "# Synthèses des étapes précédentes", ""]
        for e, s in syntheses.items():
            contexte.append(f"## {e}")
            contexte.append(json.dumps(s, ensure_ascii=False, indent=1))
            contexte.append("")
    return "\n\n".join(parties + ["\n".join(ligne for ligne in contexte if ligne is not None)])
