"""Le pilote de session : faire avancer l'agent étape par étape, s'arrêter avant la remise au conseiller, reprendre.

`lancer_agent` déroule les sept étapes d'un trait. Pour la démonstration, on veut pouvoir s'arrêter à chaque étape et
commenter, et marquer un vrai temps d'arrêt avant la remise. LangGraph le permet nativement : le graphe est compilé avec
des **interruptions avant** certains nœuds ; chaque `invoke` s'arrête à la prochaine interruption, l'état est sauvegardé
(checkpoints SQLite), et un nouvel `invoke(None)` reprend là où il s'était arrêté.

Le pilote fait tourner tous les `invoke` dans un seul fil de travail, pour que la trace d'observabilité (un span racine
par session) reste d'un seul tenant ; l'interface interroge son état et la base de l'agent, sans jamais bloquer.
"""

from __future__ import annotations

import queue
import threading
import time
from typing import Any

from poc.agent.graphe import construire_graphe
from poc.agent.harnais import (
    ResultatSession,
    _clore,
    attributs_de_session,
    conclure_racine,
    memoriser_trace,
    preparer_contexte,
)
from poc.config import Config
from poc.etapes import noms_etapes
from poc.llm import ConfigLLM, charger_config_llm
from poc.observabilite import obtenir
from poc.outils import Backend


class PiloteSession:
    def __init__(
        self,
        config: Config,
        demande_id: str,
        modele: str | None = None,
        config_llm: ConfigLLM | None = None,
        pas_a_pas: bool = False,
        arret_avant_remise: bool = True,
        scenario_factice=None,
        backend: Backend | None = None,
        verbeux: bool = False,
    ) -> None:
        self.config = config
        self.demande_id = demande_id
        self.modele = modele
        self.config_llm = config_llm or charger_config_llm()
        self.pas_a_pas = pas_a_pas
        self.arret_avant_remise = arret_avant_remise
        self.scenario_factice = scenario_factice
        self.backend = backend
        self.verbeux = verbeux
        self.session_id: str | None = None
        self.prochaine_etape: str | None = None
        self.etape_en_cours: str | None = None
        self.erreur: str | None = None
        self.resultat: ResultatSession | None = None
        self.en_cours = False
        self.termine = False
        self._commandes: queue.Queue[str] = queue.Queue()
        self._fil: threading.Thread | None = None
        self._debut = 0.0

    # ---- cycle de vie ---------------------------------------------------------------------------------------------------------
    def interruptions(self) -> list[str]:
        noms = noms_etapes()
        avant: list[str] = list(noms[1:]) if self.pas_a_pas else []
        if self.arret_avant_remise and noms[-1] not in avant:
            avant.append(noms[-1])
        return avant

    def demarrer(self) -> str:
        if self.session_id is not None:
            raise RuntimeError("session déjà démarrée")
        self._debut = time.time()
        self.ctx = preparer_contexte(
            self.config, self.config_llm, self.backend, self.verbeux, self.modele, self.scenario_factice
        )
        mode = "mcp" if hasattr(self.ctx.backend, "appeler_outil") else "direct"
        nom_modele = self.ctx.config_llm.modele_pour(None, self.modele).nom_logique + ("+mcp" if mode == "mcp" else "")
        self.session_id = self.ctx.backend.ecrire("sessions", {"demande_id": self.demande_id, "modele": nom_modele})[
            "session_id"
        ]
        self.graphe = construire_graphe(self.ctx, self.config.checkpoints, interrupt_before=self.interruptions())
        self._cfg = {"configurable": {"thread_id": self.session_id}}
        self._entree: dict | None = {
            "demande_id": self.demande_id,
            "session_id": self.session_id,
            "syntheses": {},
            "bilans": [],
            "doutes": [],
            "modele_surcharge": self.modele,
            "statut": "EN_COURS",
            "termine": False,
        }
        self.prochaine_etape = noms_etapes()[0]
        self._fil = threading.Thread(target=self._travailler, name=f"pilote-{self.session_id}", daemon=True)
        self._fil.start()
        self.continuer()
        return self.session_id

    def continuer(self) -> None:
        """Lance l'étape suivante (ou toutes jusqu'à la prochaine interruption)."""
        if self.termine or self.en_cours or self.session_id is None:
            return
        self.en_cours = True
        self.etape_en_cours = self.prochaine_etape
        self._commandes.put("continuer")

    def arreter(self) -> None:
        if self.session_id and not self.termine:
            self._commandes.put("stop")
            if self._fil is not None:
                self._fil.join(timeout=10)

    def attendre(self, delai_s: float = 600.0) -> None:
        """Bloque jusqu'à la fin de l'étape en cours (tests, ligne de commande)."""
        fin = time.time() + delai_s
        while self.en_cours and time.time() < fin:
            time.sleep(0.05)

    # ---- le fil de travail ------------------------------------------------------------------------------------------------------
    def _travailler(self) -> None:
        sid = self.session_id or ""
        mode = "mcp" if hasattr(self.ctx.backend, "appeler_outil") else "direct"
        with obtenir().session(
            sid,
            self.demande_id,
            {"modele": self.modele or self.ctx.config_llm.defaut, "mode_outils": mode, "pas_a_pas": self.pas_a_pas},
        ) as span:
            for cle, val in attributs_de_session(self.config, self.ctx, self.demande_id, self.modele).items():
                span.attribut(cle, val)
            etat: dict[str, Any] = dict(self._entree or {})
            while True:
                cmd = self._commandes.get()
                if cmd == "stop":
                    self.ctx.backend.ecrire("session", {"session_id": sid, "statut": "INTERROMPUE"})
                    self.en_cours = False
                    break
                try:
                    etat = self.graphe.invoke(self._entree, self._cfg)
                    self._entree = None  # les invocations suivantes reprennent l'état sauvegardé
                    instantane = self.graphe.get_state(self._cfg)
                    suivantes = tuple(instantane.next) if instantane.next else ()
                    self.prochaine_etape = suivantes[0] if suivantes else None
                    if not suivantes:
                        self.resultat = _clore(self.ctx, sid, self.demande_id, etat, self._debut)
                        conclure_racine(span, self.ctx, sid, self.resultat, {"pas_a_pas": self.pas_a_pas})
                        self.termine = True
                        self.en_cours = False
                        break
                except Exception as exc:  # noqa: BLE001 — l'erreur est montrée, la session marquée, le fil s'arrête proprement
                    self.erreur = f"{type(exc).__name__} : {exc}"
                    try:
                        self.ctx.backend.ecrire("session", {"session_id": sid, "statut": "ECHEC"})
                    except Exception:  # noqa: BLE001
                        pass
                    self.en_cours = False
                    break
                self.en_cours = False
                self.etape_en_cours = None
        if span.span_id:
            memoriser_trace(self.config, sid, span.trace_id, span.span_id)


def reprendre_session(
    config: Config,
    session_id: str,
    depuis: str,
    modele: str | None = None,
    config_llm: ConfigLLM | None = None,
    scenario_factice=None,
    backend: Backend | None = None,
    verbeux: bool = False,
) -> ResultatSession:
    """Reprend une session sauvegardée à partir d'une étape, avec l'état tel qu'il était juste avant cette étape (retour dans le
    temps LangGraph : on repart du checkpoint pris avant le nœud, et le graphe rejoue la suite). Sert à « reprendre avec la
    pièce reçue » : on dépose la pièce, on repart de l'étape « vérifier ». Les faits, doutes et calculs précédents restent
    en base ; les nouveaux s'y ajoutent et le dernier l'emporte."""
    if depuis not in noms_etapes():
        raise ValueError(f"étape inconnue : {depuis} ; attendues : {noms_etapes()}")
    debut = time.time()
    config_llm = config_llm or charger_config_llm()
    ctx = preparer_contexte(config, config_llm, backend, verbeux, modele, scenario_factice)
    session = ctx.backend.lire("session", session_id=session_id)
    graphe = construire_graphe(ctx, config.checkpoints)  # sans interruption : on déroule jusqu'au bout
    cfg = {"configurable": {"thread_id": session_id}}
    point = None
    for instantane in graphe.get_state_history(cfg):
        if tuple(instantane.next or ()) == (depuis,):
            point = instantane.config
            break
    if point is None:
        raise LookupError(
            f"aucun point de sauvegarde avant l'étape {depuis} pour la session {session_id} (session lancée sans checkpoints ?)"
        )
    ctx.backend.ecrire("session", {"session_id": session_id, "statut": "EN_COURS", "etape": depuis})
    ctx.consigner(session_id, depuis, "systeme", f"Reprise de la session depuis l'étape « {depuis} »")
    with obtenir().session(
        session_id, session["demande_id"], {"modele": modele or config_llm.defaut, "reprise_depuis": depuis}
    ) as span:
        for cle, val in attributs_de_session(config, ctx, session["demande_id"], modele).items():
            span.attribut(cle, val)
        span.attribut("poc.reprise_depuis", depuis)
        etat = graphe.invoke(None, point)
        resultat = _clore(ctx, session_id, session["demande_id"], etat, debut)
        conclure_racine(span, ctx, session_id, resultat, {"reprise_depuis": depuis})
    if span.span_id:
        memoriser_trace(config, session_id, span.trace_id, span.span_id)
    return resultat
