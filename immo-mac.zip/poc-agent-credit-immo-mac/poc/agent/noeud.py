"""Le nœud générique du parcours : une étape = une question, des fiches, des outils, une boucle d'appels au modèle.

À chaque tour, le modèle reçoit la consigne de l'étape et l'historique de la conversation de l'étape ; s'il demande des outils,
ils sont exécutés par le registre et leurs résultats lui sont renvoyés ; s'il répond sans outil, sa réponse doit contenir le
JSON de fin d'étape. Garde-fous appliqués par le programme : nombre de tours, nombre d'appels d'outils, budget de tokens de
la session, boucle d'appels identiques. Tout ce que l'agent dit ou fait va dans le journal de raisonnement (ce que
l'interface affiche) et dans les traces (ce que l'observabilité envoie).
"""

from __future__ import annotations

import json
import re
import time
from dataclasses import dataclass, field
from typing import Any

from poc.agent.fiches import consigne_systeme
from poc.etapes import Etape
from poc.llm.client import ClientLLM, Message
from poc.llm.config import ConfigLLM
from poc.observabilite import obtenir
from poc.outils import OUTILS, Backend, ErreurOutil, executer_outil, schema_outils

TAILLE_MAX_RESULTAT = 40_000  # caractères renvoyés au modèle pour un résultat d'outil
CLES_SYNTHESE = ("resume", "synthese")
SEUIL_RECADRAGE = 3  # refus consécutifs d'un même outil avant un message de recadrage
SEUIL_RETRAIT = 6  # refus consécutifs avant de retirer l'outil pour l'étape
GARDE_FOUS = {
    "calculer": "atelier",
    "noter_fait": "fait",
    "enregistrer_synthese": "synthese",
    "enregistrer_recommandation": "recommandation",
}


@dataclass
class ContexteAgent:
    config_llm: ConfigLLM
    backend: Backend
    clients: dict[str, ClientLLM]
    verbeux: bool = False
    journal: list[str] = field(default_factory=list)
    tokens_consommes: int = 0  # cumul sur la session, pour le budget

    def dire(self, texte: str) -> None:
        self.journal.append(texte)
        if self.verbeux:
            print(texte, flush=True)

    def consigner(self, session_id: str, etape: str, type_: str, texte: str) -> None:
        """Une ligne du journal de raisonnement : en base (pour l'interface et le rejeu) et à l'écran si verbeux."""
        texte = texte.strip()
        if not texte:
            return
        try:
            self.backend.ecrire(
                "journal", {"session_id": session_id, "etape": etape, "type": type_, "texte": texte[:4000]}
            )
        except Exception:  # noqa: BLE001 — le journal ne doit jamais arrêter l'agent
            pass
        self.dire(f"[{etape}] {texte}" if type_ != "etape" else texte)


@dataclass
class BilanEtape:
    etape: str
    synthese: dict
    tours: int
    appels_outils: int
    tokens_entree: int
    tokens_sortie: int
    cout_euros: float | None
    duree_ms: int
    bloquant: bool
    erreurs: list[str]


def _extraire_json(texte: str) -> dict | None:
    """Le dernier objet JSON du texte portant une clé de synthèse (le modèle peut l'entourer de phrases ou de balises)."""
    candidats = re.findall(r"\{(?:[^{}]|\{(?:[^{}]|\{[^{}]*\})*\})*\}", texte, flags=re.S)
    for c in reversed(candidats):
        try:
            d = json.loads(c)
            if isinstance(d, dict) and any(k in d for k in CLES_SYNTHESE):
                return d
        except json.JSONDecodeError:
            continue
    return None


def fenetre_historique(messages: list[Message], garder: int, taille: int) -> list[Message]:
    """Fenêtre glissante sur les résultats d'outils : les `garder` derniers sont envoyés complets, les plus anciens sont réduits à
    leurs `taille` premiers caractères suivis d'un rappel. Les messages originaux ne sont pas modifiés."""
    indices = [i for i, m in enumerate(messages) if m.role == "tool" and len(m.contenu) > taille]
    anciens = set(indices[:-garder]) if garder > 0 else set(indices)
    if not anciens:
        return messages
    out = []
    for i, m in enumerate(messages):
        if i in anciens:
            tete = m.contenu[:taille]
            out.append(
                Message(
                    role="tool",
                    appel_id=m.appel_id,
                    erreur_outil=m.erreur_outil,
                    contenu=tete
                    + f"\n… [résultat déjà exploité : {len(m.contenu) - taille} caractères retirés de l'historique ; rappeler l'outil si nécessaire]",
                )
            )
        else:
            out.append(m)
    return out


def _tronquer(texte: str) -> str:
    if len(texte) <= TAILLE_MAX_RESULTAT:
        return texte
    return (
        texte[:TAILLE_MAX_RESULTAT]
        + f"\n… [résultat tronqué : {len(texte) - TAILLE_MAX_RESULTAT} caractères omis ; filtrer]"
    )


def _resume_params(params: dict) -> str:
    return ", ".join(f"{k}={str(v)[:40]}" for k, v in params.items() if k != "session_id")


def _additionner_cout(total: float | None, cout: float | None) -> float | None:
    if cout is None:
        return total
    return (total or 0.0) + cout


def executer_etape(
    etape: Etape,
    demande_id: str,
    session_id: str,
    syntheses: dict[str, dict],
    ctx: ContexteAgent,
    modele_surcharge: str | None = None,
) -> BilanEtape:
    debut = time.time()
    gf = ctx.config_llm.agent
    modele = ctx.config_llm.modele_pour(etape.nom, modele_surcharge)
    client = ctx.clients[modele.nom_logique]
    outils = schema_outils(etape.nom)
    publies = getattr(ctx.backend, "outils", None)  # mode MCP : outils découverts au démarrage
    if publies is not None:
        outils = [o for o in outils if o["name"] in publies or not OUTILS[o["name"]].serveur_mcp]
    noms_outils = {o["name"] for o in outils}
    try:
        demande = ctx.backend.lire("demande", demande_id=demande_id)
    except Exception:  # noqa: BLE001 — pas de données (tests, modèle factice) : la consigne s'en passe
        demande = None
    systeme = consigne_systeme(etape, demande_id, session_id, syntheses, outils, demande=demande)
    messages: list[Message] = [
        Message(
            role="user",
            contenu=f"Commence l'étape « {etape.titre} » pour la demande {demande_id} (session {session_id}). "
            "Dis ce que tu vas faire, appelle les outils nécessaires, puis termine par le JSON de fin d'étape.",
        )
    ]
    ctx.backend.ecrire("session", {"session_id": session_id, "etape": etape.nom})
    ctx.consigner(session_id, etape.nom, "etape", f"=== {etape.titre} : {etape.question}")
    tokens_e = tokens_s = appels = 0
    cout: float | None = None
    erreurs: list[str] = []
    synthese: dict | None = None
    tours = 0
    reprises = 0
    dernier_appel: tuple[str, str] | None = None
    repetitions = 0
    refus_consecutifs: dict[str, int] = {}  # refus d'affilée par outil : recadrage à 3, retrait de l'outil à 6
    outils_retires: set[str] = set()
    arret_force: str | None = None  # un outil retiré qu'on appelle encore : on arrête l'étape
    for tours in range(1, gf.max_tours_par_etape + 1):
        if ctx.tokens_consommes >= gf.budget_tokens_par_dossier:
            erreurs.append(
                f"budget de tokens de la session épuisé ({ctx.tokens_consommes} ≥ {gf.budget_tokens_par_dossier}) : étape interrompue"
            )
            tours -= 1
            break
        fenetre = fenetre_historique(messages, gf.resultats_complets_conserves, gf.taille_resultat_ancien)
        try:
            with obtenir().appel_modele(modele, systeme, fenetre, outils, etape.nom, session_id) as span_llm:
                rep = client.appeler(systeme, fenetre, outils)
                cout_appel = client.cout_euros(rep.tokens_entree, rep.tokens_sortie)
                obtenir().reponse_modele(span_llm, rep, cout_appel)
        except Exception as exc:  # noqa: BLE001 — l'échec du modèle est repris une fois, puis arrête l'étape proprement
            erreurs.append(f"modèle : {exc}")
            ctx.consigner(session_id, etape.nom, "systeme", f"erreur du modèle : {str(exc)[:300]}")
            if reprises < 1 and "413" not in str(exc):
                reprises += 1
                messages.append(
                    Message(
                        role="user",
                        contenu="Ta dernière réponse a été rejetée par le fournisseur du modèle : "
                        f"{str(exc)[:300]}. Reprends en n'utilisant que les outils listés, avec leurs noms exacts.",
                    )
                )
                continue
            break
        tokens_e += rep.tokens_entree
        tokens_s += rep.tokens_sortie
        ctx.tokens_consommes += rep.tokens_entree + rep.tokens_sortie
        cout = _additionner_cout(cout, cout_appel)
        ctx.backend.ecrire(
            "traces",
            {
                "session_id": session_id,
                "etape": etape.nom,
                "type": "modele",
                "nom": modele.nom,
                "duree_ms": rep.duree_ms,
                "tokens_entree": rep.tokens_entree,
                "tokens_sortie": rep.tokens_sortie,
                "cout_euros": cout_appel,
                "detail": {"tour": tours, "fin": rep.fin, "appels": [a.nom for a in rep.appels]},
            },
        )
        messages.append(rep.message_assistant())
        if rep.texte and rep.appels:
            ctx.consigner(session_id, etape.nom, "pensee", rep.texte)  # ce que l'agent dit avant d'agir
        if not rep.appels:
            synthese = _extraire_json(rep.texte)
            if synthese is None:
                if tours < gf.max_tours_par_etape:
                    messages.append(
                        Message(
                            role="user",
                            contenu="Ta réponse ne contient pas le JSON de fin d'étape attendu. Termine l'étape avec un seul objet JSON : "
                            '{"resume": "...", "points_cles": [...], "doutes": [...], "bloquant": false}',
                        )
                    )
                    continue
                synthese = {
                    "resume": rep.texte[:2000],
                    "points_cles": [],
                    "doutes": [],
                    "bloquant": False,
                    "avertissement": "synthèse non structurée",
                }
            break
        # un message de recadrage attend la fin du tour : les fournisseurs refusent un message « user » glissé entre deux
        # résultats d'outils d'une même réponse (Mistral : « Unexpected role 'tool' after role 'user' »)
        recadrages: list[Message] = []
        for appel in rep.appels:
            appels += 1
            params = dict(appel.parametres)
            if appel.nom in OUTILS and "session_id" in OUTILS[appel.nom].schema.model_fields:
                params.setdefault("session_id", session_id)
            if appel.nom in OUTILS and "demande_id" in OUTILS[appel.nom].schema.model_fields:
                params.setdefault("demande_id", demande_id)
            if appel.nom in OUTILS and "etape" in OUTILS[appel.nom].schema.model_fields:
                params.setdefault("etape", etape.nom)
            signature = (appel.nom, json.dumps(params, sort_keys=True, default=str))
            repetitions = repetitions + 1 if signature == dernier_appel else 1
            dernier_appel = signature
            if appels > gf.max_appels_outils_par_etape or repetitions >= gf.max_appels_identiques or arret_force:
                motif = arret_force or (
                    "trop d'appels d'outils : étape interrompue"
                    if appels > gf.max_appels_outils_par_etape
                    else f"boucle : {repetitions} appels identiques consécutifs à {appel.nom} : étape interrompue"
                )
                if motif not in erreurs:
                    erreurs.append(motif)
                    obtenir().garde_fou(
                        "boucle" if "boucle" in motif else "limite_appels", "ARRET", motif, etape.nom, session_id
                    )
                    ctx.consigner(session_id, etape.nom, "garde_fou", motif)
                messages.append(
                    Message(
                        role="tool",
                        appel_id=appel.id,
                        contenu=json.dumps(
                            {"erreur": "LIMITE_APPELS", "message": motif + " ; termine par le JSON de fin d'étape"}
                        ),
                        erreur_outil=True,
                    )
                )
                continue
            t0 = time.time()
            serveur_outil = f"mcp-{publies[appel.nom]['serveur']}" if publies and appel.nom in publies else "direct"
            with obtenir().appel_outil(appel.nom, params, etape.nom, session_id, serveur_outil) as span_outil:
                if appel.nom in outils_retires:
                    resultat = {
                        "erreur": "OUTIL_RETIRE",
                        "message": f"{appel.nom} a été retiré pour cette étape après des refus répétés : termine l'étape par le JSON de fin d'étape",
                    }
                    erreur = True
                elif appel.nom not in noms_outils:
                    resultat: Any = {
                        "erreur": "OUTIL_NON_DISPONIBLE",
                        "message": f"l'outil {appel.nom} n'est pas disponible à l'étape {etape.nom} ; outils : {sorted(noms_outils)}",
                    }
                    erreur = True
                else:
                    try:
                        resultat = executer_outil(ctx.backend, appel.nom, params)
                        erreur = False
                    except ErreurOutil as exc:
                        resultat = {"erreur": exc.code, "message": exc.message}
                        erreur = True
                    except ValueError as exc:  # paramètres refusés par le schéma
                        resultat = {"erreur": "PARAMETRES_INVALIDES", "message": str(exc)[:600]}
                        erreur = True
                if erreur:
                    span_outil.erreur(str(resultat.get("erreur")), str(resultat.get("message", "")))
                    if appel.nom in GARDE_FOUS and str(resultat.get("erreur")) not in (
                        "INTROUVABLE",
                        "PARAMETRES_INVALIDES",
                    ):
                        # refus d'un garde-fou (atelier, source d'un fait, vérificateur de synthèse, recommandation) : un
                        # fonctionnement normal, tracé comme tel, et dit au journal pour que le public le voie
                        obtenir().garde_fou(
                            GARDE_FOUS[appel.nom],
                            str(resultat.get("erreur")),
                            resultat.get("message", ""),
                            etape.nom,
                            session_id,
                        )
                        ctx.consigner(
                            session_id,
                            etape.nom,
                            "garde_fou",
                            f"{GARDE_FOUS[appel.nom]} : {resultat.get('erreur')} — {str(resultat.get('message', ''))[:300]}",
                        )
                else:
                    span_outil.sortie(resultat if isinstance(resultat, (dict, list)) else str(resultat)[:2000])
                    if appel.nom in ("enregistrer_synthese", "enregistrer_recommandation"):
                        obtenir().garde_fou(
                            GARDE_FOUS[appel.nom],
                            "ACCEPTE",
                            {k: v for k, v in resultat.items() if k != "verification"}
                            if isinstance(resultat, dict)
                            else "",
                            etape.nom,
                            session_id,
                        )
            if erreur:
                refus_consecutifs[appel.nom] = refus_consecutifs.get(appel.nom, 0) + 1
                n_refus = refus_consecutifs[appel.nom]
                if n_refus == SEUIL_RECADRAGE:
                    texte = (
                        f"L'outil {appel.nom} a refusé {n_refus} appels de suite ({resultat.get('erreur')}). N'insiste pas : "
                        "relis le message d'erreur, change d'approche (autre source, autre nom, ou retire l'élément), "
                        "ou passe à la suite et termine l'étape par le JSON de fin d'étape."
                    )
                    recadrages.append(Message(role="user", contenu=texte))
                    ctx.consigner(session_id, etape.nom, "garde_fou", f"recadrage : {texte}")
                    obtenir().garde_fou(
                        "recadrage", "REFUS_REPETES", {"outil": appel.nom, "refus": n_refus}, etape.nom, session_id
                    )
                elif n_refus == SEUIL_RETRAIT:
                    outils_retires.add(appel.nom)
                    ctx.consigner(
                        session_id,
                        etape.nom,
                        "garde_fou",
                        f"{appel.nom} retiré pour cette étape après {n_refus} refus consécutifs",
                    )
                elif n_refus >= SEUIL_RETRAIT + SEUIL_RECADRAGE:
                    arret_force = f"boucle : {appel.nom} appelé {n_refus - SEUIL_RETRAIT} fois après son retrait : étape interrompue"
            else:
                refus_consecutifs[appel.nom] = 0
            duree = int((time.time() - t0) * 1000)
            ctx.backend.ecrire(
                "traces",
                {
                    "session_id": session_id,
                    "etape": etape.nom,
                    "type": "outil",
                    "nom": appel.nom,
                    "duree_ms": duree,
                    "detail": {
                        "parametres": {k: v for k, v in params.items() if k not in ("code",)},
                        "erreur": erreur,
                        "serveur": serveur_outil,
                    },
                },
            )
            ctx.consigner(
                session_id,
                etape.nom,
                "outil",
                f"{appel.nom}({_resume_params(params)}) -> {'ERREUR ' + str(resultat.get('erreur')) if erreur else 'ok'} ({duree} ms)",
            )
            messages.append(
                Message(
                    role="tool",
                    appel_id=appel.id,
                    contenu=_tronquer(json.dumps(resultat, ensure_ascii=False, default=str, separators=(",", ":"))),
                    erreur_outil=erreur,
                )
            )
        messages.extend(recadrages)
    if synthese is None:
        synthese = {
            "resume": "Étape interrompue avant la synthèse.",
            "points_cles": [],
            "doutes": [],
            "bloquant": False,
            "avertissement": "; ".join(erreurs) or "tours épuisés",
        }
    if "resume" not in synthese and "synthese" in synthese:
        synthese["resume"] = synthese.pop("synthese")
    ctx.consigner(session_id, etape.nom, "constat", str(synthese.get("resume", ""))[:1500])
    for d in synthese.get("doutes") or []:
        ctx.consigner(session_id, etape.nom, "doute", str(d)[:600])
    return BilanEtape(
        etape.nom,
        synthese,
        tours,
        appels,
        tokens_e,
        tokens_s,
        None if cout is None else round(cout, 6),
        int((time.time() - debut) * 1000),
        bool(synthese.get("bloquant")),
        erreurs,
    )


def resume_bilan(b: BilanEtape) -> dict[str, Any]:
    return {
        "etape": b.etape,
        "tours": b.tours,
        "appels_outils": b.appels_outils,
        "tokens": b.tokens_entree + b.tokens_sortie,
        "cout_euros": b.cout_euros,
        "duree_s": round(b.duree_ms / 1000, 1),
        "bloquant": b.bloquant,
        "erreurs": b.erreurs,
    }
