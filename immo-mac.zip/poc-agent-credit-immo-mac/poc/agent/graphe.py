"""Le graphe LangGraph : un nœud par étape du parcours (config/etapes.yaml), un état typé, une sauvegarde SQLite après
chaque nœud. Au lot 0 les étapes s'enchaînent dans l'ordre ; les retours en arrière (pièce manquante, calcul douteux,
relecture) viendront avec les lots suivants, sans changer le nœud générique.

Les étapes de type `code` ne font pas appel au modèle : `remettre` clôt la session et la met en attente du conseiller.
"""

from __future__ import annotations

import sqlite3
from pathlib import Path
from typing import Any, TypedDict

from langgraph.checkpoint.sqlite import SqliteSaver
from langgraph.graph import END, StateGraph

from poc.agent.noeud import ContexteAgent, executer_etape, resume_bilan
from poc.etapes import Etape, charger_parcours
from poc.observabilite import obtenir


class EtatAgent(TypedDict, total=False):
    demande_id: str
    session_id: str
    syntheses: dict[str, dict]
    bilans: list[dict]
    doutes: list[str]
    modele_surcharge: str | None
    statut: str
    termine: bool


def _noeud_modele(etape: Etape, ctx: ContexteAgent):
    def f(etat: EtatAgent) -> dict[str, Any]:
        with obtenir().etape(etape.nom, etat["session_id"], etat["demande_id"]) as span_etape:
            bilan = executer_etape(
                etape,
                etat["demande_id"],
                etat["session_id"],
                etat.get("syntheses", {}),
                ctx,
                etat.get("modele_surcharge"),
            )
            span_etape.sortie(bilan.synthese)
            for cle, val in (
                ("metric.tours", bilan.tours),
                ("metric.appels_outils", bilan.appels_outils),
                ("metric.tokens", bilan.tokens_entree + bilan.tokens_sortie),
                ("metric.cout_euros", bilan.cout_euros),
                ("metric.duree_s", round(bilan.duree_ms / 1000, 1)),
                ("poc.bloquant", bilan.bloquant),
                ("poc.erreurs", "; ".join(bilan.erreurs)[:600]),
            ):
                if val is not None:
                    span_etape.attribut(cle, val)
        doutes = [*etat.get("doutes", []), *[str(d) for d in (bilan.synthese.get("doutes") or [])]]
        return {
            "syntheses": {**etat.get("syntheses", {}), etape.nom: bilan.synthese},
            "bilans": [*etat.get("bilans", []), resume_bilan(bilan)],
            "doutes": doutes,
        }

    return f


def _remettre(etape: Etape, ctx: ContexteAgent):
    """L'étape de remise : pas de modèle. La session passe en REMISE, le journal le dit, le workflow s'arrête."""

    def f(etat: EtatAgent) -> dict[str, Any]:
        sid = etat["session_id"]
        with obtenir().etape(etape.nom, sid, etat["demande_id"]) as span_etape:
            doutes = etat.get("doutes", [])
            texte = (
                f"Dossier {etat['demande_id']} remis au conseiller : {len(etat.get('bilans', []))} étape(s) parcourue(s), "
                f"{len(doutes)} doute(s) à examiner. La décision appartient au conseiller."
            )
            ctx.consigner(sid, etape.nom, "etape", f"=== {etape.titre} : {etape.question}")
            ctx.consigner(sid, etape.nom, "constat", texte)
            ctx.backend.ecrire("session", {"session_id": sid, "etape": etape.nom})
            remise = ctx.backend.ecrire("remettre", {"session_id": sid})
            synthese = {
                "resume": texte,
                "points_cles": [
                    f"recommandation : {remise.get('recommandation') or 'aucune'}",
                    f"synthèse : {'présente' if remise.get('synthese_presente') else 'absente'}",
                ],
                "doutes": doutes,
                "bloquant": False,
            }
            span_etape.sortie(synthese)
            span_etape.attribut("poc.statut", "REMISE")
        return {
            "syntheses": {**etat.get("syntheses", {}), etape.nom: synthese},
            "bilans": [
                *etat.get("bilans", []),
                {
                    "etape": etape.nom,
                    "tours": 0,
                    "appels_outils": 0,
                    "tokens": 0,
                    "cout_euros": None,
                    "duree_s": 0.0,
                    "bloquant": False,
                    "erreurs": [],
                },
            ],
            "statut": "REMISE",
            "termine": True,
        }

    return f


NOEUDS_CODE = {"remettre": _remettre}


def construire_graphe(
    ctx: ContexteAgent, chemin_checkpoints: Path | None = None, interrupt_before: list[str] | None = None
):
    parcours = charger_parcours()
    g = StateGraph(EtatAgent)
    for etape in parcours.etapes:
        if etape.type == "code":
            if etape.nom not in NOEUDS_CODE:
                raise ValueError(
                    f"étape de type code sans implémentation : {etape.nom} (connues : {sorted(NOEUDS_CODE)})"
                )
            g.add_node(etape.nom, NOEUDS_CODE[etape.nom](etape, ctx))
        else:
            g.add_node(etape.nom, _noeud_modele(etape, ctx))
    noms = parcours.noms
    g.set_entry_point(noms[0])
    for a, b in zip(noms, noms[1:], strict=False):
        g.add_edge(a, b)
    g.add_edge(noms[-1], END)
    if chemin_checkpoints is not None:
        chemin_checkpoints.parent.mkdir(parents=True, exist_ok=True)
        con = sqlite3.connect(chemin_checkpoints, check_same_thread=False)
        return g.compile(checkpointer=SqliteSaver(con), interrupt_before=interrupt_before or [])
    if interrupt_before:
        raise ValueError("les interruptions demandent des checkpoints (chemin_checkpoints)")
    return g.compile()
