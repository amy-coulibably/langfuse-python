"""Client unifié des modèles de langage.

Une seule interface pour l'orchestrateur : `appeler(systeme, messages, outils) -> ReponseLLM`, avec le texte, les appels
d'outils demandés et la consommation. Trois implémentations : l'API Messages d'Anthropic, les API au format « chat
completions » (OpenAI, Mistral, Groq, Gemini, Azure, passerelles internes, modèles locaux), et un modèle factice piloté
par un scénario pour les tests. Aucun SDK : des appels HTTP directs, lisibles et sans dépendance, ce qui compte dans un
réseau fermé où seule une passerelle est joignable.
"""

from __future__ import annotations

import json
import time
from collections.abc import Callable
from dataclasses import dataclass, field
from typing import Any

import httpx

from poc.llm.config import ModeleLLM


@dataclass
class AppelOutil:
    id: str
    nom: str
    parametres: dict
    extra: dict = field(
        default_factory=dict
    )  # champs propres au fournisseur, renvoyés tels quels (Gemini 3 : thought_signature)


@dataclass
class Message:
    """Un message de la conversation, au format interne (indépendant du fournisseur).

    role : user | assistant | tool. Pour `tool`, `appel_id` identifie l'appel auquel on répond et `contenu` est le résultat
    (texte JSON). Pour `assistant`, `appels` porte les appels d'outils demandés.
    """

    role: str
    contenu: str = ""
    appels: list[AppelOutil] = field(default_factory=list)
    appel_id: str | None = None
    erreur_outil: bool = False


@dataclass
class ReponseLLM:
    texte: str
    appels: list[AppelOutil]
    tokens_entree: int
    tokens_sortie: int
    duree_ms: int
    modele: str
    fin: str = ""  # end_turn | tool_use | max_tokens | …
    brut: dict = field(default_factory=dict)

    @property
    def veut_des_outils(self) -> bool:
        return bool(self.appels)

    def message_assistant(self) -> Message:
        return Message(role="assistant", contenu=self.texte, appels=list(self.appels))


def _attente(retry_after: str | None, tentative: int) -> float:
    if retry_after:
        try:
            return min(60.0, max(1.0, float(retry_after)))
        except ValueError:
            pass
    return min(60.0, 10.0 * (2**tentative))


class ClientLLM:
    """Interface commune. `appeler` est la seule méthode que l'orchestrateur utilise."""

    def __init__(self, modele: ModeleLLM) -> None:
        self.modele = modele

    def appeler(
        self, systeme: str, messages: list[Message], outils: list[dict] | None = None
    ) -> ReponseLLM:  # pragma: no cover
        raise NotImplementedError

    def cout_euros(self, tokens_entree: int, tokens_sortie: int) -> float | None:
        """Le coût de l'appel, ou None si le prix du modèle n'est pas connu (rien n'est alors émis)."""
        m = self.modele
        if not m.prix_connu:
            return None
        return (
            tokens_entree * (m.prix_entree_par_million or 0) + tokens_sortie * (m.prix_sortie_par_million or 0)
        ) / 1_000_000

    def _verification(self):
        """Ce que httpx doit vérifier : rien si `verifier_certificat` est faux ; sinon les autorités publiques (certifi)
        **plus** l'autorité interne éventuelle. Additif : la passerelle interne et les API publiques restent joignables.
        httpx ne lit pas REQUESTS_CA_BUNDLE (variable de la bibliothèque requests) : d'où ce contexte explicite."""
        if not self.modele.verifier_certificat:
            return False
        import ssl

        import certifi

        contexte = ssl.create_default_context(cafile=certifi.where())
        chemin = self.modele.chemin_certificat_ca()
        if chemin is not None:
            contexte.load_verify_locations(cafile=str(chemin))
        return contexte

    def _requete(self, methode: str, url: str, en_tetes: dict, corps: dict) -> dict:
        """Un appel HTTP avec reprise : sur 429 (débit) ou 5xx, attend (Retry-After s'il est fourni, sinon 10 s, 20 s, 40 s…
        plafonné à 60 s) puis réessaie, autant de fois que `tentatives` le permet."""
        derniere: Exception | None = None
        verification = self._verification()
        for tentative in range(1 + (self.modele.tentatives or 0)):
            try:
                with httpx.Client(timeout=self.modele.timeout_s, verify=verification) as client:
                    rep = client.request(methode, url, headers=en_tetes, json=corps)
                if rep.status_code in (429, 500, 502, 503, 504) and tentative < (self.modele.tentatives or 0):
                    time.sleep(_attente(rep.headers.get("retry-after"), tentative))
                    continue
                if rep.status_code >= 400:
                    raise RuntimeError(
                        f"{self.modele.nom_logique} ({self.modele.nom}) : HTTP {rep.status_code} : {rep.text[:500]}"
                    )
                return rep.json()
            except httpx.HTTPError as exc:
                derniere = exc
                if tentative < (self.modele.tentatives or 0):
                    time.sleep(1.5 * (tentative + 1))
                    continue
                aide = ""
                if "CERTIFICATE_VERIFY_FAILED" in str(exc) or "certificate verify failed" in str(exc):
                    ca = self.modele.chemin_certificat_ca()
                    aide = (
                        f" — autorités utilisées : publiques (certifi) + {ca}"
                        if ca
                        else " — aucune autorité interne configurée : renseigner `certificat_ca` dans config/llm.yaml"
                        " ou POC_CA_BUNDLE / REQUESTS_CA_BUNDLE dans .env (chemin du fichier PEM)"
                    )
                raise RuntimeError(
                    f"{self.modele.nom_logique} ({self.modele.nom}) : erreur réseau {type(exc).__name__} : {exc}{aide}"
                ) from exc
        raise RuntimeError(str(derniere))


# ---------------------------------------------------------------------------------------------------------------------
# Anthropic (API Messages)
# ---------------------------------------------------------------------------------------------------------------------
class ClientAnthropic(ClientLLM):
    def appeler(self, systeme: str, messages: list[Message], outils: list[dict] | None = None) -> ReponseLLM:
        corps: dict[str, Any] = {
            "model": self.modele.nom,
            "max_tokens": self.modele.max_tokens,
            "temperature": self.modele.temperature,
            "system": systeme,
            "messages": self._convertir(messages),
        }
        if outils:
            corps["tools"] = [
                {"name": o["name"], "description": o["description"], "input_schema": o["input_schema"]} for o in outils
            ]
        en_tetes = {
            "x-api-key": self.modele.cle_api(),
            "anthropic-version": "2023-06-01",
            "content-type": "application/json",
            **self.modele.en_tetes,
        }
        debut = time.time()
        rep = self._requete("POST", f"{self.modele.url.rstrip('/')}/v1/messages", en_tetes, corps)
        texte, appels = "", []
        for bloc in rep.get("content", []):
            if bloc.get("type") == "text":
                texte += bloc.get("text", "")
            elif bloc.get("type") == "tool_use":
                appels.append(AppelOutil(id=bloc["id"], nom=bloc["name"], parametres=bloc.get("input") or {}))
        usage = rep.get("usage", {})
        return ReponseLLM(
            texte=texte,
            appels=appels,
            tokens_entree=int(usage.get("input_tokens", 0)),
            tokens_sortie=int(usage.get("output_tokens", 0)),
            duree_ms=int((time.time() - debut) * 1000),
            modele=rep.get("model", self.modele.nom),
            fin=rep.get("stop_reason", ""),
            brut=rep,
        )

    @staticmethod
    def _convertir(messages: list[Message]) -> list[dict]:
        out: list[dict] = []
        i = 0
        while i < len(messages):
            m = messages[i]
            if m.role == "user":
                out.append({"role": "user", "content": m.contenu})
            elif m.role == "assistant":
                contenu: list[dict] = []
                if m.contenu:
                    contenu.append({"type": "text", "text": m.contenu})
                for a in m.appels:
                    contenu.append({"type": "tool_use", "id": a.id, "name": a.nom, "input": a.parametres})
                out.append({"role": "assistant", "content": contenu or [{"type": "text", "text": ""}]})
            elif m.role == "tool":
                # Anthropic attend tous les résultats d'outils d'un même tour dans un seul message utilisateur
                resultats = []
                while i < len(messages) and messages[i].role == "tool":
                    t = messages[i]
                    resultats.append(
                        {
                            "type": "tool_result",
                            "tool_use_id": t.appel_id,
                            "content": t.contenu,
                            "is_error": t.erreur_outil,
                        }
                    )
                    i += 1
                out.append({"role": "user", "content": resultats})
                continue
            i += 1
        return out


# ---------------------------------------------------------------------------------------------------------------------
# API compatibles OpenAI (chat completions)
# ---------------------------------------------------------------------------------------------------------------------
class ClientOpenAICompatible(ClientLLM):
    def appeler(self, systeme: str, messages: list[Message], outils: list[dict] | None = None) -> ReponseLLM:
        corps: dict[str, Any] = {
            "model": self.modele.nom,
            "max_tokens": self.modele.max_tokens,
            "temperature": self.modele.temperature,
            "messages": [{"role": "system", "content": systeme}] + self._convertir(messages),
        }
        if outils:
            corps["tools"] = [
                {
                    "type": "function",
                    "function": {"name": o["name"], "description": o["description"], "parameters": o["input_schema"]},
                }
                for o in outils
            ]
            corps["tool_choice"] = "auto"
        en_tetes = {"content-type": "application/json", **self.modele.en_tetes}
        cle = self.modele.cle_api()
        if cle:
            en_tetes["authorization"] = f"Bearer {cle}"
        debut = time.time()
        rep = self._requete("POST", f"{self.modele.url.rstrip('/')}/chat/completions", en_tetes, corps)
        choix = (rep.get("choices") or [{}])[0]
        message = choix.get("message", {})
        appels = []
        for a in message.get("tool_calls") or []:
            fn = a.get("function", {})
            try:
                params = json.loads(fn.get("arguments") or "{}")
            except json.JSONDecodeError:
                params = {"_arguments_illisibles": fn.get("arguments")}
            extra = {k: v for k, v in a.items() if k not in ("id", "type", "function", "index")}
            appels.append(
                AppelOutil(
                    id=a.get("id", f"call_{len(appels)}"), nom=fn.get("name", ""), parametres=params, extra=extra
                )
            )
        usage = rep.get("usage", {})
        return ReponseLLM(
            texte=message.get("content") or "",
            appels=appels,
            tokens_entree=int(usage.get("prompt_tokens", 0)),
            tokens_sortie=int(usage.get("completion_tokens", 0)),
            duree_ms=int((time.time() - debut) * 1000),
            modele=rep.get("model", self.modele.nom),
            fin=choix.get("finish_reason", ""),
            brut=rep,
        )

    @staticmethod
    def _convertir(messages: list[Message]) -> list[dict]:
        out: list[dict] = []
        for m in messages:
            if m.role == "user":
                out.append({"role": "user", "content": m.contenu})
            elif m.role == "assistant":
                d: dict[str, Any] = {"role": "assistant", "content": m.contenu or None}
                if m.appels:
                    d["tool_calls"] = [
                        {
                            "id": a.id,
                            "type": "function",
                            "function": {"name": a.nom, "arguments": json.dumps(a.parametres, ensure_ascii=False)},
                            **a.extra,
                        }
                        for a in m.appels
                    ]
                out.append(d)
            elif m.role == "tool":
                out.append({"role": "tool", "tool_call_id": m.appel_id, "content": m.contenu})
        return out


# ---------------------------------------------------------------------------------------------------------------------
# Modèle factice : réponses scénarisées
# ---------------------------------------------------------------------------------------------------------------------
SYNTHESE_FACTICE = {
    "resume": "Étape parcourue par le modèle factice : les outils visibles ont été appelés une fois chacun.",
    "points_cles": [],
    "doutes": [],
    "bloquant": False,
}


class ClientFactice(ClientLLM):
    """Rejoue un scénario : une fonction reçoit (système, messages, outils) et renvoie la prochaine réponse.

    Par défaut, le scénario « conformiste » : à chaque tour, s'il reste des outils visibles jamais appelés dont les
    paramètres obligatoires se déduisent du contexte, il appelle le premier d'entre eux ; puis il termine par le JSON de
    synthèse. Il sert à tester le parcours, les traces et les garde-fous sans réseau.
    """

    def __init__(
        self, modele: ModeleLLM, scenario: Callable[[str, list[Message], list[dict] | None], ReponseLLM] | None = None
    ) -> None:
        super().__init__(modele)
        self.scenario = scenario or self._conformiste
        self.compteur = 0

    def appeler(self, systeme: str, messages: list[Message], outils: list[dict] | None = None) -> ReponseLLM:
        self.compteur += 1
        rep = self.scenario(systeme, messages, outils)
        rep.modele = rep.modele or "factice"
        return rep

    def _conformiste(self, systeme: str, messages: list[Message], outils: list[dict] | None) -> ReponseLLM:
        deja = {a.nom for m in messages if m.role == "assistant" for a in m.appels}
        contexte = messages[0].contenu if messages else ""
        connus = {
            "demande_id": _extraire(contexte, "demande_id") or _extraire(systeme, "demande_id"),
            "session_id": _extraire(contexte, "session_id") or _extraire(systeme, "session_id"),
        }
        par_outil = {
            "consulter_fiche": {"nom": "00-regles-communes"},
            "consulter_politique": {"nom": "politique_credit"},
        }
        for o in outils or []:
            if o["name"] in deja or o["name"] in (
                "calculer",
                "enregistrer_synthese",
                "enregistrer_recommandation",
                "noter_fait",
                "noter_doute",
                "demander_piece",
                "enregistrer_verdict",
                "simuler_pret",
                "remettre_dossier",
            ):
                continue
            schema = o["input_schema"]
            props = schema.get("properties", {})
            params = {k: v for k, v in {**connus, **par_outil.get(o["name"], {})}.items() if k in props and v}
            if any(r not in params for r in schema.get("required", [])):
                continue  # paramètres obligatoires inconnus : le factice n'invente rien
            return ReponseLLM(
                texte=f"Je consulte {o['name']}.",
                appels=[AppelOutil(id=f"f{self.compteur}", nom=o["name"], parametres=params)],
                tokens_entree=100,
                tokens_sortie=20,
                duree_ms=1,
                modele="factice",
                fin="tool_use",
            )
        return ReponseLLM(
            texte=json.dumps(SYNTHESE_FACTICE, ensure_ascii=False),
            appels=[],
            tokens_entree=100,
            tokens_sortie=30,
            duree_ms=1,
            modele="factice",
            fin="end_turn",
        )


def _extraire(texte: str, cle: str) -> str:
    for ligne in texte.splitlines():
        brut = ligne.strip().lstrip("-").strip()
        if brut.lower().startswith(cle) and ":" in brut:
            morceaux = brut.split(":", 1)[-1].split()
            return morceaux[0].strip("`") if morceaux else ""
    return ""


def creer_client(modele: ModeleLLM, scenario_factice: Callable | None = None) -> ClientLLM:
    if modele.fournisseur == "anthropic":
        return ClientAnthropic(modele)
    if modele.fournisseur == "openai_compatible":
        return ClientOpenAICompatible(modele)
    return ClientFactice(modele, scenario_factice)
