"""Lecture et validation de `config/llm.yaml`. Les clés d'API sont lues dans l'environnement au moment de l'appel, jamais
stockées dans la configuration chargée.

Toute valeur du fichier peut renvoyer à l'environnement (donc au fichier `.env`) :

- `${VAR}` : la valeur de VAR ; si VAR est absente ou vide et que la valeur entière est `${VAR}`, le réglage est **absent**
  (None : le défaut s'applique) ;
- `${VAR:-défaut}` : la valeur de VAR, sinon `défaut` (`${VAR:-}` donne une chaîne vide).

C'est ce qui permet de ne renseigner que le `.env` sur un nouveau poste : adresse, nom et clé de la passerelle LLM,
autorité de certification, prix (voir `.env.example`).
"""

from __future__ import annotations

import json
import os
import re
from pathlib import Path
from typing import Any, Literal

import yaml
from pydantic import BaseModel, Field, field_validator, model_validator

from poc.config import CONFIG_DIR, RACINE
from poc.etapes import noms_etapes

CHEMIN_DEFAUT = CONFIG_DIR / "llm.yaml"
VARIABLES_CA = ("POC_CA_BUNDLE", "REQUESTS_CA_BUNDLE", "CA_BUNDLE", "SSL_CERT_FILE")
MOTIF_VARIABLE = re.compile(r"\$\{([A-Za-z_][A-Za-z0-9_]*)(?::-([^}]*))?\}")


def interpoler(valeur: Any, environ: dict[str, str] | None = None) -> Any:
    """Remplace `${VAR}` et `${VAR:-défaut}` dans les valeurs (pas les clés) d'une structure YAML lue."""
    env = os.environ if environ is None else environ
    if isinstance(valeur, dict):
        return {k: interpoler(v, env) for k, v in valeur.items()}
    if isinstance(valeur, list):
        return [interpoler(v, env) for v in valeur]
    if not isinstance(valeur, str) or "${" not in valeur:
        return valeur
    entier = MOTIF_VARIABLE.fullmatch(valeur.strip())
    if entier and not env.get(entier.group(1)) and entier.group(2) is None:
        return None  # ${VAR} seul, VAR absente : réglage absent, le défaut s'applique

    def remplacer(m: re.Match) -> str:
        v = env.get(m.group(1))
        return v if v else (m.group(2) or "")

    return MOTIF_VARIABLE.sub(remplacer, valeur)


class Communs(BaseModel):
    temperature: float = 0.0
    max_tokens: int = 8000
    timeout_s: float = 120.0
    tentatives: int = 2
    prix_entree_par_million: float | None = None  # None = prix inconnu : aucun coût n'est calculé ni émis
    prix_sortie_par_million: float | None = None
    certificat_ca: str | None = None  # autorité de certification supplémentaire (fichier PEM), pour tous les modèles


class ModeleLLM(BaseModel):
    nom_logique: str = ""
    fournisseur: Literal["anthropic", "openai_compatible", "factice"]
    nom: str
    url: str = ""
    cle_api_env: str = ""
    temperature: float | None = None
    max_tokens: int | None = None
    timeout_s: float | None = None
    tentatives: int | None = None
    prix_entree_par_million: float | None = None
    prix_sortie_par_million: float | None = None
    en_tetes: dict[str, str] = Field(default_factory=dict)
    verifier_certificat: bool = True
    certificat_ca: str | None = None  # fichier PEM de l'autorité interne ; relatif = depuis la racine du projet

    @field_validator("en_tetes", mode="before")
    @classmethod
    def _en_tetes(cls, v: Any) -> Any:
        """Les en-têtes peuvent venir du .env sous forme JSON : `LLM_EN_TETES={"X-Application": "poc"}`."""
        if v is None or v == "":
            return {}
        if isinstance(v, str):
            try:
                lu = json.loads(v)
            except json.JSONDecodeError as exc:
                raise ValueError(
                    f'en_tetes : JSON attendu, par exemple {{"X-Application": "poc"}} ; reçu {v!r}'
                ) from exc
            if not isinstance(lu, dict):
                raise ValueError("en_tetes : un objet JSON {nom: valeur} est attendu")
            return {str(k): str(x) for k, x in lu.items()}
        return v

    @field_validator("verifier_certificat", mode="before")
    @classmethod
    def _verifier(cls, v: Any) -> Any:
        return True if v is None or v == "" else v

    @property
    def prix_connu(self) -> bool:
        """Vrai si un prix a été renseigné : sinon le coût n'est ni calculé ni envoyé à l'observabilité (leçon du premier
        POC : un coût à zéro écrase la grille de coûts de la plateforme)."""
        return bool(self.prix_entree_par_million or self.prix_sortie_par_million)

    def chemin_certificat_ca(self) -> Path | None:
        """Le fichier d'autorité à ajouter aux autorités publiques : `certificat_ca` du modèle (ou des réglages communs),
        sinon la première variable d'environnement renseignée parmi POC_CA_BUNDLE, REQUESTS_CA_BUNDLE, CA_BUNDLE,
        SSL_CERT_FILE. Un chemin relatif part de la racine du projet, pas du répertoire courant."""
        valeur = self.certificat_ca
        source = "certificat_ca"
        if not valeur:
            for variable in VARIABLES_CA:
                if os.getenv(variable):
                    valeur, source = os.environ[variable], variable
                    break
        if not valeur:
            return None
        chemin = Path(valeur).expanduser()
        if not chemin.is_absolute():
            chemin = RACINE / chemin
        if not chemin.is_file():
            raise ValueError(f"certificat d'autorité introuvable : {chemin} (indiqué par {source})")
        return chemin

    def cle_api(self) -> str:
        """La clé est lue dans l'environnement ; vide si le modèle n'en demande pas."""
        if not self.cle_api_env:
            return ""
        valeur = os.getenv(self.cle_api_env, "")
        if not valeur and self.fournisseur != "factice":
            raise ValueError(
                f"Le modèle « {self.nom_logique} » attend la clé dans la variable d'environnement {self.cle_api_env}, qui est vide. "
                f"Renseignez-la dans le fichier .env (voir .env.example) ou exportez-la avant de lancer l'agent."
            )
        return valeur

    def cle_disponible(self) -> bool:
        return self.fournisseur == "factice" or not self.cle_api_env or bool(os.getenv(self.cle_api_env))


class GardeFous(BaseModel):
    max_appels_outils_par_etape: int = 40
    max_tours_par_etape: int = 25
    budget_tokens_par_dossier: int = 1_500_000
    max_appels_identiques: int = 3  # appels consécutifs identiques (même outil, mêmes paramètres) tolérés avant arrêt
    mode_outils: Literal["direct", "mcp"] = "direct"
    resultats_complets_conserves: int = 2  # fenêtre glissante : résultats d'outils envoyés complets au modèle
    taille_resultat_ancien: int = 900  # caractères conservés des résultats plus anciens


class ConfigLLM(BaseModel):
    defaut: str
    communs: Communs = Field(default_factory=Communs)
    modeles: dict[str, ModeleLLM]
    roles: dict[str, str] = Field(default_factory=dict)
    agent: GardeFous = Field(default_factory=GardeFous)

    @model_validator(mode="after")
    def _coherence(self) -> ConfigLLM:
        if self.defaut not in self.modeles:
            raise ValueError(
                f"`defaut` vaut « {self.defaut} » mais ce modèle n'est pas défini dans `modeles` ({sorted(self.modeles)})"
            )
        etapes = noms_etapes()
        for etape, nom in self.roles.items():
            if etape not in etapes:
                raise ValueError(f"rôle inconnu dans `roles` : {etape} ; étapes du parcours : {etapes}")
            if nom not in self.modeles:
                raise ValueError(f"le rôle {etape} renvoie au modèle « {nom} » qui n'est pas défini")
        for nom, m in self.modeles.items():
            m.nom_logique = nom
            for champ in (
                "temperature",
                "max_tokens",
                "timeout_s",
                "tentatives",
                "prix_entree_par_million",
                "prix_sortie_par_million",
                "certificat_ca",
            ):
                if getattr(m, champ) is None:
                    setattr(m, champ, getattr(self.communs, champ))
            if m.fournisseur != "factice" and not m.url:
                raise ValueError(f"le modèle « {nom} » n'a pas d'URL")
        return self

    def modele_pour(self, etape: str | None = None, surcharge: str | None = None) -> ModeleLLM:
        """Le modèle d'une étape : surcharge explicite, sinon le rôle, sinon le défaut."""
        nom = surcharge or (self.roles.get(etape) if etape else None) or self.defaut
        if nom not in self.modeles:
            raise ValueError(f"modèle inconnu : {nom} ; définis : {sorted(self.modeles)}")
        return self.modeles[nom]

    def modeles_disponibles(self) -> list[str]:
        """Les modèles dont la clé est présente dans l'environnement (ou qui n'en demandent pas)."""
        return [n for n, m in self.modeles.items() if m.cle_disponible()]


def charger_config_llm(chemin: Path | None = None) -> ConfigLLM:
    chemin = chemin or Path(os.getenv("POC_LLM_CONFIG", str(CHEMIN_DEFAUT)))
    if not chemin.exists():
        raise FileNotFoundError(f"Configuration des modèles absente : {chemin}. Copier config/llm.yaml et l'adapter.")
    with chemin.open(encoding="utf-8") as f:
        brut = yaml.safe_load(f) or {}
    return ConfigLLM(**interpoler(brut))


def config_factice(**garde_fous) -> ConfigLLM:
    """Une configuration réduite au modèle factice, pour les tests et les démonstrations hors ligne."""
    return ConfigLLM(
        defaut="factice",
        modeles={"factice": ModeleLLM(fournisseur="factice", nom="factice")},
        agent=GardeFous(**garde_fous),
    )


def premier_modele_operationnel(cfg: ConfigLLM, exclure: tuple[str, ...] = ()) -> str:
    """Le premier modèle réel dont la clé est présente ET qui répond à un appel minimal ; sinon « factice »."""
    from poc.llm.client import Message, creer_client

    for nom in cfg.modeles_disponibles():
        m = cfg.modeles[nom]
        if m.fournisseur == "factice" or nom in exclure:
            continue
        essai = m.model_copy(update={"tentatives": 0, "timeout_s": 20.0, "max_tokens": 16})
        try:
            creer_client(essai).appeler("Réponds par un mot.", [Message(role="user", contenu="Dis : ok")])
            return nom
        except Exception:  # noqa: BLE001 — indisponible : on passe au suivant
            continue
    return "factice"
