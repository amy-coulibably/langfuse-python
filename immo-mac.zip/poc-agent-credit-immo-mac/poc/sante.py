"""Vérification rapide de l'installation : configuration des étapes et des modèles, fiches, registre d'outils, base de
l'agent, atelier qui calcule et refuse ce qu'il doit refuser, brique d'observabilité importable. Un seul écran, vert ou rouge.
Les contrôles des lots suivants (données, guichets, vérité terrain) viendront s'y ajouter."""

from __future__ import annotations

from dataclasses import dataclass

from poc.config import Config


@dataclass
class Controle:
    nom: str
    ok: bool
    detail: str = ""


def verifier_installation(config: Config, http: bool = False) -> list[Controle]:
    out: list[Controle] = []

    def ajouter(nom: str, ok: bool, detail: str = "") -> None:
        out.append(Controle(nom, ok, detail))

    # ---- le parcours
    try:
        from poc.etapes import charger_parcours

        parcours = charger_parcours()
        modele = [e.nom for e in parcours.etapes if e.type == "modele"]
        ajouter(
            "config/etapes.yaml",
            len(parcours.etapes) >= 2,
            f"{len(parcours.etapes)} étapes : {' → '.join(parcours.noms)} ({len(modele)} avec modèle)",
        )
    except Exception as exc:  # noqa: BLE001
        ajouter("config/etapes.yaml", False, str(exc)[:200])
        return out

    # ---- les modèles
    try:
        from poc.llm import charger_config_llm

        cfg_llm = charger_config_llm()
        reels = [n for n in cfg_llm.modeles_disponibles() if cfg_llm.modeles[n].fournisseur != "factice"]
        ajouter(
            "config/llm.yaml",
            True,
            f"défaut « {cfg_llm.defaut} » ; modèles réels utilisables : {reels or 'aucun (factice seulement)'}",
        )
    except Exception as exc:  # noqa: BLE001
        ajouter("config/llm.yaml", False, str(exc)[:200])

    # ---- les fiches
    from poc.agent.fiches import FICHE_COMMUNE, fiches_manquantes, lister_fiches

    presentes = lister_fiches(config.fiches_dir)
    manquantes = fiches_manquantes(config.fiches_dir)
    ajouter(
        "fiches de méthode",
        FICHE_COMMUNE not in manquantes,
        f"{len(presentes)} présente(s)"
        + (f" ; à écrire (lot 3) : {len(manquantes)}" if manquantes else " ; toutes les fiches du parcours sont là"),
    )

    # ---- le registre d'outils
    from poc.outils import OUTILS, outils_pour_etape, outils_prevus_absents

    visibles = {e.nom: [o.nom for o in outils_pour_etape(e.nom)] for e in parcours.etapes if e.type == "modele"}
    prevus = {e.nom: outils_prevus_absents(e.nom) for e in parcours.etapes if e.type == "modele"}
    n_prevus = len({o for v in prevus.values() for o in v})
    ajouter(
        "registre d'outils",
        all(visibles.values()),
        f"{len(OUTILS)} outil(s) au registre ; chaque étape en voit au moins un"
        + (f" ; {n_prevus} outil(s) déclarés dans le parcours restent à livrer (lots 2 et 5)" if n_prevus else ""),
    )

    # ---- la base de l'agent, l'atelier
    from poc.outils import BackendLocal, ErreurOutil, executer_outil

    config.data_dir.mkdir(parents=True, exist_ok=True)
    backend = BackendLocal(config)
    try:
        session = backend.ecrire("sessions", {"demande_id": "DEM-SANTE", "modele": "sante"})
        sid = session["session_id"]
        r = executer_outil(
            backend,
            "calculer",
            {
                "session_id": sid,
                "etape": "calculer",
                "sorties": ["taux"],
                "code": "taux = mensualite / revenus * 100",
                "entrees": [
                    {
                        "nom": "mensualite",
                        "origine": {"type": "constante", "valeur": 1500, "justification": "contrôle de santé"},
                    },
                    {
                        "nom": "revenus",
                        "origine": {"type": "constante", "valeur": 4480, "justification": "contrôle de santé"},
                    },
                ],
                "unite": "pourcentage",
            },
        )
        ajouter("atelier : un calcul archivé", abs(r[0]["valeur"] - 33.4821) < 0.01, f"taux = {r[0]['valeur']:.2f} %")
        for code, attendu, libelle in (
            ("import os\nx = 1", "CODE_REFUSE", "refus du code dangereux"),
            ("x = 320000 * 0.35", "CHIFFRE_RECOPIE", "refus d'un montant recopié dans la formule"),
        ):
            try:
                executer_outil(
                    backend,
                    "calculer",
                    {"session_id": sid, "etape": "calculer", "sorties": ["x"], "code": code, "entrees": []},
                )
                ajouter(f"atelier : {libelle}", False, "accepté à tort")
            except ErreurOutil as exc:
                ajouter(f"atelier : {libelle}", exc.code == attendu, exc.code)
        backend.ecrire("session", {"session_id": sid, "statut": "REMISE"})
        ajouter("base de l'agent (agent.sqlite)", True, str(config.sqlite_agent))
    except Exception as exc:  # noqa: BLE001
        ajouter("base de l'agent (agent.sqlite)", False, f"{type(exc).__name__} : {str(exc)[:200]}")

    # ---- l'observabilité
    try:
        import ml_utils.observability  # noqa: F401

        from poc.observabilite import charger_config_observabilite

        cfg_obs = charger_config_observabilite()
        ajouter(
            "observabilité (brique ml_utils)",
            True,
            f"brique importable ; {'active' if cfg_obs.effective else 'inactive'} ({cfg_obs.backend}, projet {cfg_obs.projet})",
        )
    except Exception as exc:  # noqa: BLE001
        ajouter(
            "observabilité (brique ml_utils)", False, f"{type(exc).__name__} : {str(exc)[:160]} (pip install -e vendor)"
        )

    # ---- les données synthétiques (lot 1)
    if config.sqlite_banque.exists() and config.sqlite_verite_terrain.exists():
        from poc.donnees import SQLiteStore
        from poc.generateur import attendu_de, catalogue, demandes_disponibles

        demandes = demandes_disponibles(config)
        a = attendu_de(config, demandes[0]) if demandes else None
        coffres = [d for d in demandes if (config.coffre_dir / d / "inventaire.json").exists()]
        lots: dict[str, int] = {}
        for c in catalogue(config):
            lots[c["lot"]] = lots.get(c["lot"], 0) + 1
        ajouter(
            "données synthétiques",
            bool(demandes) and a is not None and len(coffres) == len(demandes),
            f"{len(demandes)} demande(s), {len(coffres)} coffre(s) de pièces ; lots : {lots} ; {demandes[0]} : taux d'effort attendu {a.taux_effort} %"
            if a
            else "bases présentes mais vides",
        )
        vt = SQLiteStore(config.sqlite_verite_terrain).lister()
        banque = SQLiteStore(config.sqlite_banque).lister()
        ajouter(
            "vérité terrain séparée",
            all(t.startswith("vt_") for t in vt)
            and not any(t.startswith("vt_") for t in banque)
            and config.sqlite_incidents.exists(),
            f"{len(vt)} tables vt_* ; {len(banque)} tables banque_* ; fichier d'incidents présent",
        )
    else:
        ajouter("données synthétiques", False, "absentes : lancer `poc donnees generer`")
        return out

    # ---- les guichets et les mains (lot 2) : chaque outil de lecture répond sur la première demande
    from poc.outils import BackendLocal, ErreurOutil, executer_outil

    backend = BackendLocal(config)
    demande = demandes[0]
    try:
        d = backend.lire("demande", demande_id=demande)
        client = d["emprunteurs"][0]["client_id"]
        compte = backend.lire("comptes", client_id=client)[0]["compte_id"]
        piece = backend.lire("pieces", demande_id=demande)[0]["piece_id"]
        appels = {
            "lire_demande": {"demande_id": demande},
            "consulter_client": {"client_id": client},
            "lister_pieces": {"demande_id": demande},
            "lire_piece": {"demande_id": demande, "piece": piece},
            "consulter_comptes": {"client_id": client},
            "consulter_mouvements": {"compte_id": compte, "limite": 5},
            "consulter_credits": {"client_id": client},
            "consulter_epargne": {"client_id": client},
            "consulter_incidents": {"client_id": client},
            "consulter_bareme": {},
            "consulter_politique": {"nom": "politique_credit"},
            "consulter_fiche": {"nom": "00-regles-communes"},
        }
        erreurs = []
        for nom, params in appels.items():
            try:
                executer_outil(backend, nom, params)
            except ErreurOutil as exc:
                erreurs.append(f"{nom}: {exc.code}")
        ajouter(
            f"outils de lecture ({len(appels)}) sur {demande}",
            not erreurs,
            "tous répondent" if not erreurs else f"erreurs : {erreurs}",
        )
    except Exception as exc:  # noqa: BLE001
        ajouter("outils de lecture", False, f"{type(exc).__name__} : {str(exc)[:160]}")

    # ---- les garde-fous du conseiller : ils refusent ce qu'ils doivent refuser
    try:
        sid = backend.ecrire("sessions", {"demande_id": demande, "modele": "sante"})["session_id"]
        refus = {}
        try:
            executer_outil(
                backend,
                "noter_fait",
                {"session_id": sid, "nom": "x", "valeur": 999999, "source": {"type": "demande", "champ": "apport"}},
            )
        except ErreurOutil as exc:
            refus["fait"] = exc.code
        texte = (
            "## Synthèse de contrôle\n"
            + "Ce dossier est examiné. " * 10
            + "La mensualité serait de 1 234,56 € par mois."
        )
        try:
            executer_outil(backend, "enregistrer_synthese", {"session_id": sid, "texte": texte, "chiffres": []})
        except ErreurOutil as exc:
            refus["synthese"] = exc.code
        try:
            executer_outil(
                backend,
                "enregistrer_recommandation",
                {
                    "session_id": sid,
                    "position": "FAVORABLE",
                    "motifs": [{"texte": "x", "type": "fait", "nom": "inexistant"}],
                },
            )
        except ErreurOutil as exc:
            refus["recommandation"] = exc.code
        backend.ecrire("session", {"session_id": sid, "statut": "REMISE"})
        attendu = {"fait": "VALEUR_HORS_EXTRAIT", "synthese": "CHIFFRE_ORPHELIN", "recommandation": "MOTIF_SANS_SOURCE"}
        ajouter("garde-fous du conseiller", refus == attendu, str(refus))
    except Exception as exc:  # noqa: BLE001
        ajouter("garde-fous du conseiller", False, f"{type(exc).__name__} : {str(exc)[:160]}")

    # ---- les deux guichets ajoutés : le score de la banque et le service OCR
    try:
        from poc.services.scoring import ServiceScoring

        s = ServiceScoring(config).score(demande)
        ajouter(
            f"api-scoring sur {demande}",
            True,
            f"score {s['score']}/1000, classe {s['classe']} (indicateur consultatif)",
        )
    except Exception as exc:  # noqa: BLE001
        ajouter("api-scoring", False, f"{type(exc).__name__} : {str(exc)[:160]}")
    from poc.services.ocr import ServiceOCR, description_moteur

    moteur = description_moteur()
    if not moteur["disponible"]:
        ajouter(
            "moteur OCR (Tesseract)",
            True,
            "absent : les pièces numérisées seront redemandées au client (installer Tesseract, langue fra, ou POC_TESSERACT)",
        )
    else:
        scannee = next(
            (
                p["piece_id"]
                for p in backend.lire("pieces", demande_id=demande)
                if p["format"] != "pdf" or p["type"] == "avis_imposition" and p["periode"] == "2025"
            ),
            None,
        )
        detail = f"{moteur['moteur']} ({moteur['langue']})"
        ok = True
        if scannee:
            try:
                r = ServiceOCR(config).ocr_piece(demande, scannee)
                detail += f" ; {scannee} de {demande} : {r['statut']}, confiance moyenne {r['confiance_moyenne']}"
                ok = r["statut"] == "LISIBLE"
            except Exception as exc:  # noqa: BLE001
                ok, detail = False, f"{detail} ; {type(exc).__name__} : {str(exc)[:120]}"
        ajouter("moteur OCR (Tesseract)", ok, detail)

    # ---- les guichets HTTP, si demandé
    if http:
        import httpx

        from poc.outils.backend import PORTS

        for nom, port in PORTS.items():
            url = f"http://127.0.0.1:{port}"
            try:
                rep = httpx.get(f"{url}/sante", timeout=3.0)
                ajouter(f"api-{nom} joignable", rep.status_code == 200, f"{url}/docs")
            except httpx.HTTPError as exc:
                ajouter(f"api-{nom} joignable", False, f"{url} : {type(exc).__name__} (lancer `poc api lancer tout`)")
    return out
