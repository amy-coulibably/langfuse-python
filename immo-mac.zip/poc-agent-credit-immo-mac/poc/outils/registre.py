"""Le registre des outils : les mains de l'agent.

Chaque outil a un nom, une description en français (c'est elle que lit le modèle), un schéma d'entrée Pydantic (converti
en JSON Schema pour le modèle et pour MCP), une fonction qui l'exécute via un `Backend`, et le serveur MCP qui le servira
au lot 5 (`None` = une main propre de l'agent). La visibilité par étape n'est pas décidée ici mais dans `config/etapes.yaml`.

Aucun outil ne porte de règle métier : « combien d'exercices pour un indépendant ? » est dans la politique de crédit et
dans une fiche de méthode, pas dans le code de `consulter_politique`. Les garde-fous (sources vérifiées, chiffres sourcés,
recommandation contrôlée) sont dans les services du conseiller.
"""

from __future__ import annotations

from collections.abc import Callable
from dataclasses import dataclass, field
from typing import Any, Literal

from pydantic import AliasChoices, BaseModel, Field, ValidationError

from poc.etapes import charger_parcours
from poc.outils.backend import Backend, ErreurOutil
from poc.schemas import Entree

COFFRE, BANQUE, CONSEILLER = "mcp-coffre", "mcp-banque", "mcp-conseiller"


# ---------------------------------------------------------------------------------------------------------------------
# Schémas d'entrée
# ---------------------------------------------------------------------------------------------------------------------
class ParamsVide(BaseModel):
    pass


class ParamsFiche(BaseModel):
    nom: str = Field(
        description="Nom de la fiche, sans extension, tel que listé dans la consigne (ex. 03-lire-une-fiche-de-paie)"
    )


class ParamsSession(BaseModel):
    session_id: str = Field(description="Identifiant de la session en cours (donné dans la consigne)")


class ParamsDemande(BaseModel):
    demande_id: str = Field(description="Identifiant de la demande, ex. DEM-0001")


class ParamsClient(BaseModel):
    client_id: str = Field(description="Identifiant du client, tel que donné par lire_demande (emprunteurs)")


class ParamsPiece(ParamsDemande):
    piece: str = Field(description="Identifiant de la pièce (P03) ou nom de fichier, tel que donné par lister_pieces")
    page: int | None = Field(default=None, description="Numéro de page à lire ; absent = toutes les pages")


class ParamsMouvements(BaseModel):
    compte_id: str = Field(description="Identifiant du compte, tel que donné par consulter_comptes")
    du: str | None = Field(default=None, description="Date de début AAAA-MM-JJ (ou AAAA-MM)")
    au: str | None = Field(default=None, description="Date de fin AAAA-MM-JJ (ou AAAA-MM)")
    motif: str | None = Field(default=None, description="Filtre sur le libellé (ex. SALAIRE, LOYER, PRLV)")
    limite: int = Field(default=200, le=500, description="Nombre maximal de lignes renvoyées")


class ParamsBareme(BaseModel):
    duree_annees: int | None = Field(default=None, description="Durée du prêt en années, pour ne renvoyer que ce taux")
    age: int | None = Field(default=None, description="Âge d'un emprunteur, pour ne renvoyer que son taux d'assurance")


class ParamsPolitique(BaseModel):
    nom: Literal["politique_credit", "norme_hcsf", "pieces_attendues", "grille_score"] = Field(
        description="Le texte à lire (grille_score : la grille du score de la banque, ce qu'il voit et ne voit pas)"
    )


class ParamsSimuler(ParamsSession):
    montant: float = Field(description="Capital emprunté, en euros")
    duree_annees: int = Field(description="Durée en années (15, 20 ou 25 au barème)")
    taux_nominal_pct: float | None = Field(
        default=None, description="Taux nominal en % ; absent = taux du barème pour la durée"
    )
    ages: list[int] = Field(
        default_factory=list,
        description="Âges des emprunteurs au dépôt, pour l'assurance (quotités égales) ; absent = ceux de la demande, calculés par la banque",
    )
    etape: str = Field(default="calculer", description="Étape en cours (pour la feuille de calcul)")


class SourceFait(BaseModel):
    type: Literal["piece", "mouvement", "demande", "client", "credit_declare", "epargne", "calcul"] = Field(
        description="piece : une ligne d'une pièce (piece + extrait copié tel quel) ; mouvement : une ligne de relevé (compte_id, date, montant) ; "
        "demande : un champ de la demande (champ) ; client : un champ de la fiche client (client_id, champ) ; credit_declare : un crédit déclaré "
        "(organisme) ; epargne : un livret (epargne_id) ; calcul : un résultat de la feuille de calcul (nom_resultat)"
    )
    piece: str | None = Field(default=None, description="Pour piece : P03 ou nom de fichier")
    extrait: str | None = Field(
        default=None,
        description="Pour piece : le texte de la ligne, copié tel quel depuis lire_piece, qui contient la valeur",
    )
    compte_id: str | None = None
    date: str | None = Field(default=None, description="Pour mouvement : AAAA-MM-JJ")
    montant: float | None = Field(default=None, description="Pour mouvement : le montant de la ligne (signé)")
    champ: str | None = Field(default=None, description="Pour demande ou client : le nom du champ")
    client_id: str | None = None
    organisme: str | None = None
    epargne_id: str | None = None
    nom_resultat: str | None = None


class ParamsFait(ParamsSession):
    nom: str = Field(description="Nom du fait, identifiant Python (ex. net_paye_thomas_2026_07, prix_bien, apport)")
    valeur: float = Field(
        description="La valeur, en nombre uniquement (pas de date, pas de texte : ils ne sont pas des faits)"
    )
    unite: str = Field(default="euros", description="euros, pourcentage, mois, annees, nombre")
    source: SourceFait
    commentaire: str = Field(default="", description="Ce que représente ce fait, en une phrase")


class ParamsScore(ParamsSession):
    demande_id: str = Field(description="Identifiant de la demande, ex. DEM-0001")
    etape: str = Field(default="confronter", description="Étape en cours (pour la feuille de calcul)")


class ParamsDoute(ParamsSession):
    objet: str = Field(
        description="Ce qui fait douter, en une phrase (ex. écart entre la fiche de paie et les virements de salaire)"
    )
    hypotheses: list[str] = Field(
        description="Les explications possibles, au moins une",
        validation_alias=AliasChoices("hypotheses", "hypothèses"),
    )
    question: str = Field(default="", description="La question à poser au conseiller ou au client")
    pieces_concernees: list[str] = Field(default_factory=list, description="Identifiants des pièces concernées (P03…)")
    faits_concernes: list[str] = Field(default_factory=list, description="Noms des faits concernés")
    bloquant: bool = Field(default=False, description="Vrai si la suite de l'analyse est impossible sans réponse")
    etape: str = Field(default="", description="Étape en cours")


class ParamsDemanderPiece(ParamsSession):
    piece: str = Field(description="La pièce demandée, en clair (ex. fiche de paie d'août 2026)")
    personne: str = Field(description="À qui on la demande (prénom)")
    periode: str | None = Field(default=None, description="Période concernée, AAAA-MM si pertinent")
    motif: str = Field(default="", description="Pourquoi on la demande, en une phrase")


class ParamsVerdict(ParamsSession):
    regle: str = Field(description="Code de la règle (ex. HCSF_TAUX_EFFORT, SEUIL_RESTE_A_VIVRE, SEUIL_INDEPENDANT)")
    verdict: Literal["DANS_LA_NORME", "HORS_NORME", "CAS_NON_COUVERT"]
    valeur: str | None = Field(default=None, description="La valeur constatée (ex. 33,5 %)")
    seuil: str | None = Field(default=None, description="Le seuil de la règle (ex. 35 %)")
    justification: str = Field(description="Pourquoi ce verdict, en une phrase")
    references: list[str] = Field(default_factory=list, description="Faits ou calculs qui fondent le verdict")


class ChiffreCite(BaseModel):
    texte: str = Field(description="Le chiffre tel qu'il apparaît dans la synthèse (ex. « 1 571,42 € », « 33,5 % »)")
    type: Literal["fait", "calcul", "regle", "doute"] = Field(
        description="fait ou calcul (par leur nom) ; regle : un seuil ou taux d'une règle (HCSF_TAUX_EFFORT_MAX, "
        "ABATTEMENT_MICRO_BNC, RESTE_A_VIVRE_PAR_ADULTE…) ; doute : un écart constaté, cité par l'identifiant ou l'objet du doute"
    )
    nom: str = Field(
        description="Le nom du fait, du résultat de calcul, de la constante de règle, ou l'identifiant du doute"
    )


class ParamsSynthese(ParamsSession):
    texte: str = Field(
        description="La synthèse en Markdown, au plan de la fiche de rédaction ; sans avis d'octroi (la recommandation est à part)"
    )
    chiffres: list[ChiffreCite] = Field(
        description="Un élément par chiffre de la synthèse (montants, pourcentages, nombres ≥ 100)"
    )


class Motif(BaseModel):
    texte: str = Field(description="Le motif, en une phrase")
    type: Literal["fait", "calcul", "verdict"]
    nom: str = Field(description="Le fait, le résultat ou la règle (code) qui fonde le motif")


class Reserve(BaseModel):
    code: str = Field(
        description="Code court en majuscules (ex. REVENUS_NON_COUVERTS, PIECE_MANQUANTE, ECART_SALAIRE_A_CONFIRMER)"
    )
    texte: str = Field(description="La réserve, en une phrase")


class ParamsRecommandation(ParamsSession):
    position: Literal["FAVORABLE", "FAVORABLE_SOUS_RESERVES", "DEFAVORABLE", "NE_SE_PRONONCE_PAS"]
    motifs: list[Motif] = Field(description="Au moins un motif, chacun lié à un fait, un calcul ou un verdict")
    reserves: list[Reserve] = Field(default_factory=list, description="Obligatoires pour une position sous réserves")
    conditions: list[str] = Field(default_factory=list, description="Ce qui doit être obtenu ou vérifié avant décision")


class ParamsCalculer(ParamsSession):
    etape: str = Field(description="Étape du parcours en cours")
    entrees: list[Entree] = Field(
        description="Les données d'entrée, désignées par leur origine : un fait enregistré, un résultat antérieur, une hypothèse déclarée"
    )
    code: str = Field(
        description="Code Python : affectations et arithmétique ; math et statistics disponibles ; les entrées sont des variables"
    )
    sorties: list[str] = Field(description="Noms des variables à enregistrer dans la feuille de calcul")
    unite: str | dict[str, str] = Field(
        default="euros",
        description="euros, pourcentage, ratio, mois, annees ; ou un dictionnaire {sortie: unité} si les sorties ont des unités différentes",
    )
    commentaire: str = Field(default="", description="Ce que calcule ce bloc, en une phrase")


# ---------------------------------------------------------------------------------------------------------------------
# Registre
# ---------------------------------------------------------------------------------------------------------------------
@dataclass
class OutilSpec:
    nom: str
    description: str
    schema: type[BaseModel]
    executer: Callable[[Backend, dict], Any]
    serveur_mcp: str | None = None
    ecriture: bool = False
    exemples: list[str] = field(default_factory=list)


def _lire(route: str) -> Callable[[Backend, dict], Any]:
    return lambda backend, params: backend.lire(route, **params)


def _ecrire(route: str) -> Callable[[Backend, dict], Any]:
    return lambda backend, params: backend.ecrire(route, params)


def _calculer(backend: Backend, params: dict) -> Any:
    sid = params.pop("session_id")
    return backend.ecrire("calculs", {"session_id": sid, "demande": params})


def _simuler(backend: Backend, params: dict) -> Any:
    sid, etape = params.pop("session_id"), params.pop("etape", "calculer")
    ages_de_la_demande = False
    if not params.get("ages"):
        session = backend.lire("session", session_id=sid)
        params["ages"] = backend.lire("demande", demande_id=session["demande_id"]).get("ages_au_depot", [])
        ages_de_la_demande = True
    r = backend.lire("simulateur", **params)
    r["ages_utilises"] = params.get("ages") or []
    r["ages_source"] = "demande (dates de naissance, à la date de dépôt)" if ages_de_la_demande else "paramètre"
    d = r["duree_annees"]
    archives = backend.ecrire(
        "calcul_externe",
        {
            "session_id": sid,
            "etape": etape,
            "resultats": {
                f"mensualite_hors_assurance_{d}": r["mensualite_hors_assurance"],
                f"assurance_mensuelle_{d}": r["assurance_mensuelle"],
                f"mensualite_{d}": r["mensualite_assurance_comprise"],
            },
            "unite": "euros",
            "code": f"simulateur_pret(montant={r['montant']}, duree_annees={d}, taux_nominal_pct={r['taux_nominal_pct']}, ages={params.get('ages') or []})",
            "entrees": {"montant": r["montant"], "duree_annees": d, "taux_nominal_pct": r["taux_nominal_pct"]},
            "commentaire": f"Simulation du prêt sur {d} ans, assurance comprise",
        },
    )
    return {
        **r,
        "resultats_archives": [a["nom_resultat"] for a in archives],
        "note": f"mensualite_{d} est citable comme résultat de calcul",
    }


def _score(backend: Backend, params: dict) -> Any:
    sid, etape = params.pop("session_id"), params.pop("etape", "confronter")
    r = backend.lire("score", demande_id=params["demande_id"])
    backend.ecrire(
        "calcul_externe",
        {
            "session_id": sid,
            "etape": etape,
            "resultats": {"score_eligibilite": r["score"]},
            "unite": "points",
            "code": f"api_scoring(demande_id={params['demande_id']}, grille={r['version_grille']})",
            "entrees": {"demande_id": params["demande_id"], "version_grille": r["version_grille"]},
            "commentaire": f"Score d'éligibilité de la banque, classe {r['classe']} (indicateur consultatif)",
        },
    )
    return {
        **r,
        "resultat_archive": "score_eligibilite",
        "note": "score_eligibilite est citable dans la synthèse comme résultat de calcul ; jamais comme motif de la recommandation",
    }


def _fait(backend: Backend, params: dict) -> Any:
    return backend.ecrire("fait", params)


OUTILS: dict[str, OutilSpec] = {
    # ---- mains propres de l'agent ------------------------------------------------------------------------------------------
    "consulter_fiche": OutilSpec(
        "consulter_fiche",
        "Lit une fiche de méthode en entier (le savoir-faire du conseiller : quoi chercher, comment calculer, quelles règles appliquer). "
        "La consigne liste les fiches de l'étape ; à lire avant d'agir quand on ne connaît pas la méthode.",
        ParamsFiche,
        _lire("fiche"),
    ),
    "calculer": OutilSpec(
        "calculer",
        "Pose un calcul dans l'atelier : les entrées sont désignées par leur origine (fait enregistré, résultat antérieur, hypothèse "
        "déclarée avec sa justification), le code est du Python arithmétique, les résultats nommés sont enregistrés dans la feuille de "
        "calcul avec leur formule. Aucun montant ne doit être tapé dans le code : déclarer une entrée.",
        ParamsCalculer,
        _calculer,
        ecriture=True,
    ),
    "lire_calculs": OutilSpec(
        "lire_calculs",
        "Relit la feuille de calcul de la session : chaque résultat nommé avec sa valeur, son unité, sa formule et ses entrées.",
        ParamsSession,
        _lire("calculs"),
    ),
    # ---- coffre ---------------------------------------------------------------------------------------------------------------
    "lister_pieces": OutilSpec(
        "lister_pieces",
        "L'inventaire des pièces déposées par le client pour la demande : identifiant, type (fiche_paie, releve_compte, avis_imposition…), "
        "personne, période, fichier. À comparer à la liste des pièces attendues.",
        ParamsDemande,
        _lire("pieces"),
        COFFRE,
    ),
    "lire_piece": OutilSpec(
        "lire_piece",
        "Le texte d'une pièce, ligne par ligne avec un numéro de ligne, pour trouver un chiffre et le citer (pièce et extrait). "
        "Lire une pièce à la fois ; filtrer par page si elle est longue.",
        ParamsPiece,
        _lire("piece"),
        COFFRE,
    ),
    "ocr_piece": OutilSpec(
        "ocr_piece",
        "Lit une pièce par reconnaissance de caractères (OCR), quand lire_piece a échoué : TEXTE_ABSENT (PDF scanné, sans "
        "couche texte) ou FORMAT_NON_LISIBLE (photo). Renvoie le texte ligne par ligne avec une confiance de 0 à 1 et un statut : "
        "LISIBLE (cite les lignes dans noter_fait comme pour lire_piece ; une ligne sous 0,80 de confiance sera refusée) ou "
        "LECTURE_INCERTAINE (pièce inutilisable : la redemander au client). Plus lent que lire_piece : toujours essayer lire_piece d'abord.",
        ParamsPiece,
        _lire("ocr"),
        COFFRE,
    ),
    # ---- banque ---------------------------------------------------------------------------------------------------------------
    "lire_demande": OutilSpec(
        "lire_demande",
        "La demande déposée : projet (bien, prix, honoraires, apport, durée souhaitée, compromis), foyer, emprunteurs (avec leur "
        "identifiant client, leur âge et leur ancienneté au dépôt), crédits en cours déclarés par le client et leur total mensuel "
        "(champ total_mensualites_credits_declares, 0 s'il n'y en a pas), loyer actuel déclaré, mois attendus des fiches de paie "
        "et des relevés. À appeler en premier.",
        ParamsDemande,
        _lire("demande"),
        BANQUE,
    ),
    "consulter_client": OutilSpec(
        "consulter_client",
        "La fiche d'un client de la banque : identité, situation familiale et professionnelle déclarées (employeur, poste, date d'entrée, "
        "activité, début d'activité), ancienneté dans la banque.",
        ParamsClient,
        _lire("client"),
        BANQUE,
    ),
    "consulter_comptes": OutilSpec(
        "consulter_comptes",
        "Les comptes qu'un client détient dans la banque, avec leur solde. Les comptes tenus ailleurs n'y figurent pas : voir les relevés déposés.",
        ParamsClient,
        _lire("comptes"),
        BANQUE,
    ),
    "consulter_mouvements": OutilSpec(
        "consulter_mouvements",
        "Les lignes d'un compte sur une période, filtrables par libellé (SALAIRE, LOYER, PRLV…), avec les totaux. Sert à recouper "
        "les revenus, repérer les charges récurrentes, les crédits non déclarés et les signaux d'alerte.",
        ParamsMouvements,
        _lire("mouvements"),
        BANQUE,
    ),
    "consulter_credits": OutilSpec(
        "consulter_credits",
        "Les crédits en cours d'un client : ceux de la banque, et ceux qu'il a déclarés dans sa demande (souscrits ailleurs).",
        ParamsClient,
        _lire("credits"),
        BANQUE,
    ),
    "consulter_epargne": OutilSpec(
        "consulter_epargne",
        "Les livrets et contrats d'épargne d'un client dans la banque : type, solde, disponibilité.",
        ParamsClient,
        _lire("epargne"),
        BANQUE,
    ),
    "consulter_bareme": OutilSpec(
        "consulter_bareme",
        "Le barème : taux nominal par durée, taux d'assurance par âge, frais d'acquisition par type de bien.",
        ParamsBareme,
        _lire("bareme"),
        BANQUE,
    ),
    "consulter_score": OutilSpec(
        "consulter_score",
        "Le score d'éligibilité interne de la banque (sur 1 000, classe A à E), critère par critère, avec la liste de ce qu'il ne "
        "voit pas. Un indicateur consultatif calculé sur le seul système d'information : à restituer dans la synthèse avec ses "
        "limites, jamais un motif de la recommandation (refusé : SCORE_NON_DECISIONNEL). Archive score_eligibilite dans la feuille de calcul.",
        ParamsScore,
        _score,
        BANQUE,
    ),
    "simuler_pret": OutilSpec(
        "simuler_pret",
        "Le simulateur de la banque : mensualité hors assurance, assurance, mensualité totale et coût du crédit pour un montant, une "
        "durée et les âges des emprunteurs. Les résultats sont archivés dans la feuille de calcul (mensualite_<durée>…) et citables.",
        ParamsSimuler,
        _simuler,
        BANQUE,
        ecriture=True,
    ),
    "consulter_politique": OutilSpec(
        "consulter_politique",
        "Le texte d'une règle de référence : la politique de crédit maison (revenus et charges retenus, seuils, verdicts, recommandation), "
        "la norme HCSF, ou la liste des pièces attendues.",
        ParamsPolitique,
        _lire("politique"),
        BANQUE,
    ),
    "consulter_incidents": OutilSpec(
        "consulter_incidents",
        "Interroge le fichier d'incidents (externe) pour un client : incidents connus, en cours ou régularisés. Décrire, ne pas conclure.",
        ParamsClient,
        _lire("incidents"),
        BANQUE,
    ),
    # ---- conseiller -----------------------------------------------------------------------------------------------------------
    "noter_fait": OutilSpec(
        "noter_fait",
        "Enregistre un chiffre extrait avec sa source vérifiée : une ligne de pièce (extrait copié tel quel), un mouvement de compte, un "
        "champ de la demande ou du client, un crédit déclaré, une épargne, un calcul. Refusé si la source ne contient pas la valeur, "
        "ou si la valeur contredit un fait déjà enregistré sans doute posé. Seuls les faits enregistrés peuvent entrer dans un calcul ou une synthèse.",
        ParamsFait,
        _fait,
        CONSEILLER,
        ecriture=True,
        exemples=[
            'noter_fait(nom="net_paye_thomas_2026_07", valeur=3200, source={"type": "piece", "piece": "P03", "extrait": "NET PAYÉ 3 200,00 €"})'
        ],
    ),
    "lire_faits": OutilSpec(
        "lire_faits",
        "Relit les faits enregistrés dans la session, avec leur source.",
        ParamsSession,
        _lire("faits"),
        CONSEILLER,
    ),
    "noter_doute": OutilSpec(
        "noter_doute",
        "Enregistre une hésitation : ce qui ne colle pas, les hypothèses possibles, la question pour le conseiller. Obligatoire quand deux "
        "sources divergent, quand une pièce manque, quand un cas sort des règles. Les doutes finissent tels quels dans la synthèse.",
        ParamsDoute,
        _ecrire("doute"),
        CONSEILLER,
        ecriture=True,
    ),
    "lire_doutes": OutilSpec(
        "lire_doutes", "Relit les doutes enregistrés dans la session.", ParamsSession, _lire("doutes"), CONSEILLER
    ),
    "demander_piece": OutilSpec(
        "demander_piece",
        "Envoie au client un message demandant une pièce manquante ou illisible (boîte aux lettres simulée). On n'attend pas la réponse : "
        "l'analyse se poursuit et la synthèse signale le dossier incomplet.",
        ParamsDemanderPiece,
        _ecrire("message"),
        CONSEILLER,
        ecriture=True,
    ),
    "enregistrer_verdict": OutilSpec(
        "enregistrer_verdict",
        "Enregistre une ligne de la grille de conformité : règle (code de la politique maison ou de la norme HCSF), verdict "
        "(DANS_LA_NORME, HORS_NORME, CAS_NON_COUVERT), valeur constatée, seuil, justification, faits ou calculs de référence.",
        ParamsVerdict,
        _ecrire("verdict"),
        CONSEILLER,
        ecriture=True,
    ),
    "lire_dossier_travail": OutilSpec(
        "lire_dossier_travail",
        "Tout ce que la session a produit, d'un coup : faits, feuille de calcul, doutes, messages au client, verdicts, synthèse, recommandation. "
        "À relire avant de rédiger et avant de recommander.",
        ParamsSession,
        _lire("dossier_travail"),
        CONSEILLER,
    ),
    "enregistrer_synthese": OutilSpec(
        "enregistrer_synthese",
        "Dépose la synthèse pour le conseiller. Chaque chiffre du texte doit être justifié par un fait ou un calcul (liste `chiffres`) ; "
        "le vérificateur refuse un chiffre sans source, une citation fausse, et tout avis d'octroi dans le texte (la recommandation est à part).",
        ParamsSynthese,
        _ecrire("synthese"),
        CONSEILLER,
        ecriture=True,
    ),
    "enregistrer_recommandation": OutilSpec(
        "enregistrer_recommandation",
        "Dépose la recommandation : une position parmi quatre, des motifs liés chacun à un fait, un calcul ou un verdict, des réserves, des "
        "conditions. Refusée si un motif n'a pas de source, ou si elle tranche (favorable / défavorable) alors qu'un cas non couvert ou un "
        "doute bloquant subsiste. La décision appartient au conseiller.",
        ParamsRecommandation,
        _ecrire("recommandation"),
        CONSEILLER,
        ecriture=True,
    ),
    "remettre_dossier": OutilSpec(
        "remettre_dossier",
        "Clôt la session et met le dossier en attente de la décision du conseiller.",
        ParamsSession,
        _ecrire("remettre"),
        CONSEILLER,
        ecriture=True,
    ),
}


def outils_pour_etape(etape: str) -> list[OutilSpec]:
    """Les outils visibles à une étape : ceux que le parcours déclare ET que le registre connaît (dans cet ordre)."""
    return [OUTILS[n] for n in charger_parcours().outils_de(etape) if n in OUTILS]


def outils_prevus_absents(etape: str) -> list[str]:
    """Les outils que le parcours déclare pour une étape mais que le registre ne connaît pas encore."""
    return [n for n in charger_parcours().outils_de(etape) if n not in OUTILS]


def schema_outils(etape: str | None = None) -> list[dict]:
    """Définitions d'outils au format attendu par les modèles (nom, description, JSON Schema des paramètres)."""
    specs = outils_pour_etape(etape) if etape else list(OUTILS.values())
    return [{"name": o.nom, "description": o.description, "input_schema": o.schema.model_json_schema()} for o in specs]


def executer_outil(backend: Backend, nom: str, params: dict) -> Any:
    """Valide les paramètres contre le schéma de l'outil puis l'exécute. Les erreurs remontent en `ErreurOutil`."""
    if nom not in OUTILS:
        raise ValueError(f"outil inconnu : {nom}")
    spec = OUTILS[nom]
    try:
        valides = spec.schema(**params).model_dump(mode="json", exclude_none=True)
    except ValidationError as exc:
        details = "; ".join(f"{'.'.join(str(x) for x in e['loc'])}: {e['msg']}" for e in exc.errors()[:4])
        raise ErreurOutil("PARAMETRES_INVALIDES", f"{nom} : {details}") from exc
    if hasattr(backend, "appeler_outil") and spec.serveur_mcp:  # mode MCP : l'outil est servi par un serveur
        return backend.appeler_outil(nom, valides)
    return spec.executer(backend, valides)
