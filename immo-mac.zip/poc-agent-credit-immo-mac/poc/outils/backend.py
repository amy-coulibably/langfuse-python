"""Comment les outils atteignent les guichets.

`Backend` est l'interface : `lire(route, **params)` et `ecrire(route, corps)`, avec des routes logiques. Trois
implémentations, même interface, mêmes réponses :

- `BackendLocal` : appelle les services en mémoire (mode direct, le plus simple à déboguer) ;
- `BackendHTTP` : client des six API locales (`poc api lancer tout`) : coffre (8001), banque (8002), incidents (8003),
  conseiller (8004), scoring (8005), ocr (8006) ; c'est le mode « guichets » du cadrage ;
- `BackendMCP` (poc/mcp) : les outils servis à distance passent par les serveurs MCP, le reste par l'un des deux ci-dessus.
"""

from __future__ import annotations

from typing import Any, Protocol

from poc.config import Config
from poc.donnees import SQLiteStore
from poc.schemas import DemandeCalcul
from poc.services.atelier import ErreurAtelier
from poc.services.conseiller import ServiceConseiller
from poc.services.erreurs import ErreurService
from poc.services.incidents import ServiceIncidents
from poc.services.scoring import ServiceScoring
from poc.services.sessions import SessionIntrouvable

PORTS = {"coffre": 8001, "banque": 8002, "incidents": 8003, "conseiller": 8004, "scoring": 8005, "ocr": 8006}


class ErreurOutil(RuntimeError):
    """Erreur renvoyée à l'agent sous forme lisible (code et message), jamais une pile d'appels."""

    def __init__(self, code: str, message: str) -> None:
        super().__init__(f"{code}: {message}")
        self.code = code
        self.message = message


class Backend(Protocol):
    def lire(self, route: str, **params: Any) -> Any: ...

    def ecrire(self, route: str, corps: Any) -> Any: ...


class BackendLocal:
    """Appelle les services en mémoire. Les routes portent les mêmes noms que dans `BackendHTTP`."""

    def __init__(self, config: Config) -> None:
        self.config = config
        store = SQLiteStore(config.sqlite_agent)
        self.conseiller = ServiceConseiller(config, store)
        self.sessions = self.conseiller.sessions
        self.coffre = self.conseiller.coffre
        self.banque = self.conseiller.banque
        self.incidents = ServiceIncidents(config)
        self.ocr = self.conseiller.ocr
        self.scoring = ServiceScoring(config)

    def lire(self, route: str, **p: Any) -> Any:
        s, c, b = self.sessions, self.conseiller, self.banque
        try:
            match route:
                # orchestrateur
                case "session":
                    return s.session(p["session_id"]).model_dump(mode="json")
                case "sessions":
                    return [x.model_dump(mode="json") for x in s.sessions(p.get("demande_id"), p.get("n"))]
                case "journal":
                    return [e.model_dump(mode="json") for e in s.journal(p["session_id"])]
                case "traces":
                    return [t.model_dump(mode="json") for t in s.traces(p["session_id"])]
                case "calculs":
                    return [x.model_dump(mode="json") for x in s.atelier.feuille(p["session_id"])]
                case "fiches":
                    from poc.agent.fiches import lister_fiches

                    return lister_fiches(self.config.fiches_dir)
                case "fiche":
                    from poc.agent.fiches import lire_fiche

                    try:
                        return {"nom": p["nom"], "contenu": lire_fiche(p["nom"], self.config.fiches_dir)}
                    except FileNotFoundError as exc:
                        raise ErreurOutil("FICHE_INTROUVABLE", str(exc)) from exc
                # coffre
                case "pieces":
                    return self.coffre.lister_pieces(p["demande_id"])
                case "piece":
                    return self.coffre.lire_piece(p["demande_id"], p["piece"], p.get("page"))
                case "ocr":
                    return self.ocr.ocr_piece(p["demande_id"], p["piece"])
                case "score":
                    return self.scoring.score(p["demande_id"])
                # banque
                case "demande":
                    return b.demande(p["demande_id"])
                case "client":
                    return b.client(p["client_id"])
                case "comptes":
                    return b.comptes(p["client_id"])
                case "mouvements":
                    return b.mouvements(p["compte_id"], p.get("du"), p.get("au"), p.get("motif"), p.get("limite", 200))
                case "credits":
                    return b.credits(p["client_id"])
                case "epargne":
                    return b.epargne(p["client_id"])
                case "bareme":
                    return b.bareme(p.get("duree_annees"), p.get("age"))
                case "simulateur":
                    return b.simuler(p["montant"], p["duree_annees"], p.get("taux_nominal_pct"), p.get("ages"))
                case "politique":
                    return b.politique(p["nom"])
                # incidents (identité résolue par la banque)
                case "incidents":
                    return self.incidents.rechercher(**b.identite(p["client_id"]))
                # conseiller
                case "faits":
                    return c.faits(p["session_id"])
                case "doutes":
                    return c.doutes(p["session_id"])
                case "messages":
                    return c.messages(p["session_id"])
                case "verdicts":
                    return c.verdicts(p["session_id"])
                case "dossier_travail":
                    return c.dossier_travail(p["session_id"])
        except SessionIntrouvable as exc:
            raise ErreurOutil("INTROUVABLE", str(exc)) from exc
        except ErreurService as exc:
            raise ErreurOutil(exc.code, exc.message) from exc
        raise ErreurOutil("ROUTE_INCONNUE", route)

    def ecrire(self, route: str, corps: Any) -> Any:
        s, c = self.sessions, self.conseiller
        sid = corps.get("session_id")
        try:
            match route:
                case "sessions":
                    return s.creer_session(corps["demande_id"], corps.get("modele", "sans_modele")).model_dump(
                        mode="json"
                    )
                case "session":
                    return s.mettre_a_jour(sid, corps.get("statut"), corps.get("etape")).model_dump(mode="json")
                case "journal":
                    return s.journaliser(sid, corps["etape"], corps["type"], corps["texte"]).model_dump(mode="json")
                case "traces":
                    return s.tracer(
                        sid,
                        corps["etape"],
                        corps["type"],
                        corps["nom"],
                        corps["duree_ms"],
                        corps.get("tokens_entree", 0),
                        corps.get("tokens_sortie", 0),
                        corps.get("cout_euros"),
                        corps.get("detail"),
                    ).model_dump(mode="json")
                case "calculs":
                    s.session(sid)
                    return [
                        r.model_dump(mode="json") for r in s.atelier.calculer(sid, DemandeCalcul(**corps["demande"]))
                    ]
                case "calcul_externe":
                    return c.archiver_calcul_externe(
                        sid,
                        corps["etape"],
                        corps["resultats"],
                        corps["unite"],
                        corps["code"],
                        corps["entrees"],
                        corps.get("commentaire", ""),
                    )
                case "fait":
                    return c.noter_fait(
                        sid,
                        corps["nom"],
                        corps["valeur"],
                        corps.get("unite", "euros"),
                        corps["source"],
                        corps.get("commentaire", ""),
                    )
                case "doute":
                    return c.noter_doute(
                        sid,
                        corps.get("etape", ""),
                        corps["objet"],
                        corps["hypotheses"],
                        corps["question"],
                        corps.get("pieces_concernees", []),
                        corps.get("faits_concernes", []),
                        corps.get("bloquant", False),
                    )
                case "message":
                    return c.demander_piece(
                        sid, corps["piece"], corps["personne"], corps.get("periode"), corps.get("motif", "")
                    )
                case "verdict":
                    return c.enregistrer_verdict(
                        sid,
                        corps["regle"],
                        corps["verdict"],
                        corps.get("valeur"),
                        corps.get("seuil"),
                        corps.get("justification", ""),
                        corps.get("references", []),
                    )
                case "synthese":
                    return c.enregistrer_synthese(sid, corps["texte"], corps.get("chiffres", []))
                case "recommandation":
                    return c.enregistrer_recommandation(
                        sid,
                        corps["position"],
                        corps.get("motifs", []),
                        corps.get("reserves", []),
                        corps.get("conditions", []),
                    )
                case "remettre":
                    return c.remettre(sid)
        except SessionIntrouvable as exc:
            raise ErreurOutil("INTROUVABLE", str(exc)) from exc
        except ErreurAtelier as exc:
            raise ErreurOutil(exc.code, exc.message) from exc
        except ErreurService as exc:
            raise ErreurOutil(exc.code, exc.message) from exc
        raise ErreurOutil("ROUTE_INCONNUE", route)


class BackendHTTP:
    """Client des six API locales. Les chemins reprennent exactement ceux des applications FastAPI (`poc api lancer tout`)."""

    def __init__(
        self,
        hote: str = "http://127.0.0.1",
        ports: dict[str, int] | None = None,
        delai_s: float = 30.0,
        clients: dict[str, Any] | None = None,
    ) -> None:
        import httpx

        ports = ports or PORTS
        clients = clients or {}
        self.clients = {
            nom: clients.get(nom) or httpx.Client(base_url=f"{hote}:{port}", timeout=delai_s)
            for nom, port in ports.items()
        }

    @staticmethod
    def _reponse(r) -> Any:
        if r.status_code >= 400:
            try:
                detail = r.json().get("detail")
            except ValueError:
                detail = r.text
            if isinstance(detail, dict):
                raise ErreurOutil(detail.get("code", "ERREUR"), detail.get("message", str(detail)))
            raise ErreurOutil("INTROUVABLE" if r.status_code == 404 else "ERREUR", str(detail)[:600])
        return r.json()

    def _get(self, api: str, chemin: str, **params: Any) -> Any:
        return self._reponse(self.clients[api].get(chemin, params={k: v for k, v in params.items() if v is not None}))

    def _post(self, api: str, chemin: str, corps: dict) -> Any:
        return self._reponse(self.clients[api].post(chemin, json=corps))

    def lire(self, route: str, **p: Any) -> Any:
        sid = p.get("session_id")
        match route:
            case "session":
                return self._get("conseiller", f"/sessions/{sid}")
            case "sessions":
                return self._get("conseiller", "/sessions", demande_id=p.get("demande_id"), n=p.get("n"))
            case "journal" | "traces" | "calculs" | "faits" | "doutes" | "messages" | "verdicts":
                return self._get("conseiller", f"/sessions/{sid}/{route}")
            case "dossier_travail":
                return self._get("conseiller", f"/sessions/{sid}/dossier-travail")
            case "fiches":
                return self._get("conseiller", "/fiches")
            case "fiche":
                return self._get("conseiller", f"/fiches/{p['nom']}")
            case "pieces":
                return self._get("coffre", f"/demandes/{p['demande_id']}/pieces")
            case "piece":
                return self._get("coffre", f"/demandes/{p['demande_id']}/pieces/{p['piece']}", page=p.get("page"))
            case "ocr":
                return self._get("ocr", f"/demandes/{p['demande_id']}/pieces/{p['piece']}/ocr")
            case "score":
                return self._get("scoring", f"/demandes/{p['demande_id']}/score")
            case "demande":
                return self._get("banque", f"/demandes/{p['demande_id']}")
            case "client":
                return self._get("banque", f"/clients/{p['client_id']}")
            case "comptes" | "credits" | "epargne":
                return self._get("banque", f"/clients/{p['client_id']}/{route}")
            case "mouvements":
                return self._get(
                    "banque",
                    f"/comptes/{p['compte_id']}/mouvements",
                    du=p.get("du"),
                    au=p.get("au"),
                    motif=p.get("motif"),
                    limite=p.get("limite"),
                )
            case "bareme":
                return self._get("banque", "/bareme", duree_annees=p.get("duree_annees"), age=p.get("age"))
            case "simulateur":
                return self._post("banque", "/simulateur", {k: v for k, v in p.items() if v is not None})
            case "politique":
                return self._get("banque", f"/politique/{p['nom']}")
            case "incidents":
                identite = self._get("banque", f"/clients/{p['client_id']}/identite")
                return self._get("incidents", "/incidents", **identite)
        raise ErreurOutil("ROUTE_INCONNUE", route)

    def ecrire(self, route: str, corps: Any) -> Any:
        sid = corps.get("session_id")
        reste = {k: v for k, v in corps.items() if k != "session_id"}
        match route:
            case "sessions":
                return self._post("conseiller", "/sessions", corps)
            case "session":
                return self._reponse(self.clients["conseiller"].patch(f"/sessions/{sid}", json=reste))
            case (
                "journal"
                | "traces"
                | "calculs"
                | "fait"
                | "doute"
                | "message"
                | "verdict"
                | "synthese"
                | "recommandation"
            ):
                chemin = {
                    "journal": "journal",
                    "traces": "traces",
                    "calculs": "calculs",
                    "fait": "faits",
                    "doute": "doutes",
                    "message": "messages",
                    "verdict": "verdicts",
                    "synthese": "syntheses",
                    "recommandation": "recommandations",
                }[route]
                return self._post(
                    "conseiller",
                    f"/sessions/{sid}/{chemin}",
                    reste.get("demande", reste) if route == "calculs" else reste,
                )
            case "calcul_externe":
                return self._post("conseiller", f"/sessions/{sid}/calculs-externes", reste)
            case "remettre":
                return self._post("conseiller", f"/sessions/{sid}/remettre", {})
        raise ErreurOutil("ROUTE_INCONNUE", route)
