"""Reconstruit toutes les données synthétiques (vérité terrain, pièces PDF, banque simulée, fichier d'incidents) :
`python scripts/reconstruire_donnees.py`. Équivalent de `poc donnees generer --forcer`. Déterministe : deux exécutions
donnent les mêmes données."""

from __future__ import annotations

import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from poc.config import charger_config  # noqa: E402
from poc.generateur import generer_tout  # noqa: E402


def main() -> None:
    config = charger_config()
    debut = time.time()
    attendus = generer_tout(config)
    for a in attendus:
        print(
            f"{a.demande_id} ({a.scenario}) : taux d'effort attendu {a.taux_effort} %, recommandation {a.recommandation}"
        )
    print(f"{len(attendus)} demande(s) générée(s) dans {config.data_dir} en {time.time() - debut:.1f} s")


if __name__ == "__main__":
    main()
