"""Compile les verrous de dépendances du poste Mac : une version exacte par paquet, pour chaque architecture (Apple Silicon,
Intel) et chaque Python (3.11, 3.12, 3.13), **en roues binaires uniquement**.

Pourquoi six fichiers et pas un : le premier portage sur Mac a échoué deux fois à l'installation du verrou. (1) `pip freeze`
sous Windows avait figé des paquets propres à Windows ; (2) des versions sans roue Mac (cryptography 50 sur Intel, pyarrow 17
en Python 3.13, compilé depuis les sources puis en échec sur `pkg_resources`). Ici, chaque verrou est résolu par `uv` pour
sa plateforme cible, avec `--only-binary :all:` : une ligne du verrou = une roue qui existe pour ce Mac et ce Python.

Ce qui est verrouillé : le POC avec les extras `dev`, `api`, `documents`, `interface`, `arize`, et les dépendances de la
brique d'observabilité (`vendor/`). Pas Phoenix (incompatible avec le SDK arize : wrapt). Les deux paquets locaux (le POC et
la brique) s'installent ensuite sans dépendances (`pip install --no-deps -e . -e vendor`).

    python scripts/compiler_verrous.py                 # écrit requirements/mac-*.txt (uv requis : pip install uv)
    python scripts/compiler_verrous.py --plateforme x86_64-pc-windows-msvc --sortie /tmp/verrous   # répétition Windows
"""

from __future__ import annotations

import argparse
import os
import shutil
import subprocess
import sys
import tempfile
import tomllib
from pathlib import Path

RACINE = Path(__file__).resolve().parents[1]
EXTRAS = ("dev", "api", "documents", "interface", "arize")
PYTHONS = ("3.11", "3.12", "3.13")
CIBLES_MAC = {"arm64": "aarch64-apple-darwin", "x86_64": "x86_64-apple-darwin"}
MACOS_MINIMUM = "13.0"  # roues compatibles macOS 13 (Ventura) et suivants


def entrees() -> list[str]:
    projet = tomllib.loads((RACINE / "pyproject.toml").read_text(encoding="utf-8"))["project"]
    brique = tomllib.loads((RACINE / "vendor" / "pyproject.toml").read_text(encoding="utf-8"))["project"]
    lignes = list(projet["dependencies"])
    for extra in EXTRAS:
        lignes += projet["optional-dependencies"][extra]
    lignes += brique["dependencies"]
    return sorted(set(lignes), key=str.lower)


def uv() -> list[str]:
    if shutil.which("uv"):
        return ["uv"]
    return [sys.executable, "-m", "uv"]


def compiler(fichier_in: Path, sortie: Path, plateforme: str, python: str) -> None:
    env = {**os.environ, "MACOSX_DEPLOYMENT_TARGET": MACOS_MINIMUM}
    commande = uv() + [
        "pip",
        "compile",
        str(fichier_in),
        "--python-version",
        python,
        "--python-platform",
        plateforme,
        "--only-binary",
        ":all:",
        "--no-annotate",
        "--no-header",
        "--quiet",
        "-o",
        str(sortie),
    ]
    r = subprocess.run(commande, env=env, capture_output=True, text=True)
    if r.returncode != 0:
        raise SystemExit(f"échec de la résolution {plateforme} Python {python} :\n{r.stderr[-3000:]}")
    corps = sortie.read_text(encoding="utf-8")
    entete = (
        f"# Verrou {plateforme}, CPython {python}, roues binaires uniquement (macOS {MACOS_MINIMUM}+ pour les cibles Mac).\n"
        "# Généré par scripts/compiler_verrous.py depuis pyproject.toml (extras "
        + ", ".join(EXTRAS)
        + ") et vendor/pyproject.toml.\n"
        "# Ne pas modifier à la main : relancer le script. Installé par amorcer_mac.sh avec pip --only-binary :all:.\n"
    )
    sortie.write_text(entete + corps.replace("\r\n", "\n"), encoding="utf-8", newline="\n")


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--sortie", type=Path, default=RACINE / "requirements")
    parser.add_argument(
        "--plateforme", help="une seule plateforme uv (ex. x86_64-pc-windows-msvc), pour une répétition"
    )
    parser.add_argument("--python", choices=PYTHONS, help="une seule version de Python")
    args = parser.parse_args()
    args.sortie.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory() as tmp:
        fichier_in = Path(tmp) / "entrees.in"
        fichier_in.write_text("\n".join(entrees()) + "\n", encoding="utf-8")
        cibles = {args.plateforme: args.plateforme} if args.plateforme else CIBLES_MAC
        for nom, plateforme in cibles.items():
            for python in [args.python] if args.python else PYTHONS:
                prefixe = f"mac-{nom}" if not args.plateforme else nom
                sortie = args.sortie / f"{prefixe}-py{python.replace('.', '')}.txt"
                compiler(fichier_in, sortie, plateforme, python)
                n = sum(
                    1
                    for ligne in sortie.read_text(encoding="utf-8").splitlines()
                    if ligne and not ligne.startswith("#")
                )
                print(
                    f"{sortie.relative_to(args.sortie.parent) if args.sortie.is_relative_to(RACINE) else sortie} : {n} paquets"
                )


if __name__ == "__main__":
    main()
