"""Les serveurs MCP : chaque outil du registre devient un outil MCP, avec le même nom, la même description et le même schéma.

Deux serveurs, découpés par source comme le serait un vrai SI :

- `mcp-dossier` : les outils de lecture (couche dossier, base sectorielle, référentiels, et `requeter_si` pour la variante) ;
- `mcp-note` : l'espace de travail de l'agent (atelier de calcul, vérificateur, décisions, sections, feuille de calcul, export).

Aucune duplication : le serveur lit `OUTILS` et exécute chaque appel par le même `BackendLocal` que le mode direct (ou par
`BackendHTTP` si l'on veut qu'il passe par les API). Transport stdio : le serveur est un processus lancé par le client,
qui lui parle sur son entrée et sa sortie standard ; il n'ouvre aucun port et n'a aucun accès sortant.

Lancement manuel : `poc mcp dossier` ou `poc mcp note` (ou `python -m poc.mcp.serveur dossier`).
"""

from __future__ import annotations

import inspect
import json
import sys
from typing import Any

from mcp.server.mcpserver import MCPServer
from mcp.server.mcpserver.exceptions import ToolError

from poc.config import Config, charger_config
from poc.outils import OUTILS, Backend, BackendHTTP, BackendLocal, OutilSpec, executer_outil
from poc.outils.backend import ErreurOutil

SERVEURS = {
    "dossier": {
        "nom_mcp": "mcp-dossier",
        "description": "Lecture du dossier de crédit, de la base sectorielle et des référentiels",
    },
    "note": {
        "nom_mcp": "mcp-note",
        "description": "Espace de travail de l'agent : atelier de calcul, vérificateur, décisions, sections, export",
    },
}


class ErreurOutilMCP(ToolError):
    """Transporte le code et le message d'une `ErreurOutil` dans le texte d'erreur MCP, en JSON, pour que le client les retrouve."""

    def __init__(self, code: str, message: str) -> None:
        super().__init__(json.dumps({"code": code, "message": message}, ensure_ascii=False))


def _fonction_outil(spec: OutilSpec, backend: Backend):
    """Une fonction Python dont la signature reproduit le schéma Pydantic de l'outil : le SDK en déduit le JSON Schema publié."""
    champs = spec.schema.model_fields

    def f(**kwargs: Any) -> Any:
        params = {k: v for k, v in kwargs.items() if v is not None or champs[k].is_required()}
        from poc.observabilite import obtenir

        obs = obtenir()
        try:
            # côté serveur : un span TOOL « exécution » qui, grâce à la propagation MCP, se range sous le span TOOL du client
            with obs.appel_outil(
                spec.nom, params, "serveur", str(params.get("session_id", "")), spec.serveur_mcp
            ) as span:
                try:
                    # un seul bloc de texte JSON, quel que soit le type du résultat (une liste serait sinon éclatée en plusieurs blocs)
                    resultat = executer_outil(backend, spec.nom, params)
                    span.sortie(resultat if isinstance(resultat, (dict, list)) else str(resultat)[:2000])
                    return json.dumps(resultat, ensure_ascii=False, default=str)
                except ErreurOutil as exc:
                    span.erreur(exc.code, exc.message)
                    raise ErreurOutilMCP(exc.code, exc.message) from exc
                except ValueError as exc:  # paramètres refusés par le schéma
                    span.erreur("PARAMETRES_INVALIDES", str(exc)[:600])
                    raise ErreurOutilMCP("PARAMETRES_INVALIDES", str(exc)[:600]) from exc
        finally:
            # Le client MCP arrête le serveur deux secondes après avoir fermé son entrée, sans laisser l'exportateur vider
            # son dernier lot : on exporte donc le span de chaque appel tout de suite (quelques millisecondes en local).
            if obs.actif:
                obs.manager.flush()

    parametres = []
    for nom, info in champs.items():
        defaut = info if not info.is_required() else inspect.Parameter.empty
        parametres.append(
            inspect.Parameter(nom, inspect.Parameter.KEYWORD_ONLY, default=defaut, annotation=info.annotation)
        )
    f.__signature__ = inspect.Signature(parametres)  # type: ignore[attr-defined]
    f.__annotations__ = {nom: info.annotation for nom, info in champs.items()}
    f.__name__ = spec.nom
    f.__doc__ = spec.description
    return f


def outils_du_serveur(serveur: str) -> list[OutilSpec]:
    nom_mcp = SERVEURS[serveur]["nom_mcp"]
    return [o for o in OUTILS.values() if o.serveur_mcp == nom_mcp]


def creer_serveur(serveur: str, backend: Backend | None = None, config: Config | None = None) -> MCPServer:
    if serveur not in SERVEURS:
        raise ValueError(f"serveur inconnu : {serveur} (attendu : {sorted(SERVEURS)})")
    backend = backend or BackendLocal(config or charger_config())
    s = MCPServer(
        name=SERVEURS[serveur]["nom_mcp"],
        description=SERVEURS[serveur]["description"],
        version="0.1.0",
        log_level="WARNING",
    )
    for spec in outils_du_serveur(serveur):
        s.add_tool(_fonction_outil(spec, backend), name=spec.nom, description=spec.description, structured_output=False)
    return s


def main(argv: list[str] | None = None) -> None:
    """`python -m poc.mcp.serveur dossier|note [--http]` : lance le serveur sur stdio (le client parle au processus)."""
    args = list(sys.argv[1:] if argv is None else argv)
    if not args or args[0] not in SERVEURS:
        print(f"usage : python -m poc.mcp.serveur {'|'.join(SERVEURS)} [--http]", file=sys.stderr)
        sys.exit(2)
    backend = BackendHTTP() if "--http" in args else None
    from poc.observabilite import instrumenter_mcp, obtenir

    instrumenter_mcp(obtenir())  # le serveur rejoint la trace du client (sans effet si l'observabilité est inactive)
    creer_serveur(args[0], backend).run("stdio")


if __name__ == "__main__":
    main()
