"""Configuration de l'observabilité : `config/observabilite.yaml` + variables `OBS_*` de la brique ml_utils.

Le fichier porte les réglages lisibles (actif, backend, projet, redaction, détail des messages) ; l'environnement porte les
secrets et peut surcharger chaque coordonnée (`OBS_ENABLED`, `OBS_BACKEND`, `OBS_ENDPOINT`, `OBS_PROJECT`, `OBS_API_KEY`,
`OBS_SPACE_ID`, `OBS_ENV`, `OBS_SAMPLE_RATE`), ce qui permet de basculer de Phoenix à Arize AX sans toucher au dépôt.
"""

from __future__ import annotations

import os
from pathlib import Path
from typing import Any, Literal

import yaml
from pydantic import BaseModel, Field

from poc.config import RACINE

CHEMIN_DEFAUT = RACINE / "config" / "observabilite.yaml"


class ConfigObservabilite(BaseModel):
    active: bool = False
    backend: Literal["noop", "phoenix", "arize"] = "noop"
    endpoint: str | None = None
    projet: str = "agent-analyse-financiere"
    model_id: str = "agent-analyse-financiere"
    environnement: Literal["dev", "pprod", "prod"] = "dev"
    utilisateur: str = "analyste-poc"
    taux_echantillonnage: float = Field(default=1.0, ge=0.0, le=1.0)
    redaction: Literal["none", "mask_pii", "mask_identifiers"] = "none"
    contenu_messages: bool = True
    taille_max_attribut: int = Field(default=20_000, ge=200)
    propagation_mcp: bool = True
    verifier_collecteur: bool = True  # sonde le collecteur au démarrage ; injoignable = traces désactivées
    api_key: str | None = None  # jamais dans le yaml : OBS_API_KEY
    space_id: str | None = None  # OBS_SPACE_ID
    records_uri: str | None = (
        None  # OBS_RECORDS_URI : porte records d'Arize (édition AX-ML & CV) ; absente = pas de records
    )

    @property
    def effective(self) -> bool:
        return self.active and self.backend != "noop"


def _bool(valeur: str | None, defaut: bool) -> bool:
    if valeur is None:
        return defaut
    return valeur.strip().lower() in {"1", "true", "yes", "on", "oui"}


def charger_config_observabilite(chemin: Path | None = None, env: dict[str, str] | None = None) -> ConfigObservabilite:
    environ = os.environ if env is None else env
    chemin = chemin or Path(environ.get("POC_OBS_CONFIG", str(CHEMIN_DEFAUT)))
    brut: dict[str, Any] = {}
    if chemin.exists():
        with chemin.open(encoding="utf-8") as f:
            brut = yaml.safe_load(f) or {}
    cfg = ConfigObservabilite(**brut)
    # l'environnement prime : coordonnées de plateforme et secrets
    maj: dict[str, Any] = {}
    maj["active"] = _bool(environ.get("OBS_ENABLED"), cfg.active)
    if environ.get("OBS_BACKEND"):
        maj["backend"] = environ["OBS_BACKEND"].strip().lower()
    if environ.get("OBS_ENDPOINT"):
        maj["endpoint"] = environ["OBS_ENDPOINT"]
    if environ.get("OBS_PROJECT"):
        maj["projet"] = environ["OBS_PROJECT"]
    if environ.get("OBS_ENV"):
        maj["environnement"] = environ["OBS_ENV"].strip().lower()
    if environ.get("OBS_SAMPLE_RATE"):
        maj["taux_echantillonnage"] = float(environ["OBS_SAMPLE_RATE"])
    if environ.get("OBS_API_KEY"):
        maj["api_key"] = environ["OBS_API_KEY"]
    if environ.get("OBS_SPACE_ID"):
        maj["space_id"] = environ["OBS_SPACE_ID"]
    if environ.get("OBS_RECORDS_URI"):
        maj["records_uri"] = environ["OBS_RECORDS_URI"]
    return cfg.model_copy(update=maj)


def vers_config_ml_utils(cfg: ConfigObservabilite):
    """Traduit notre configuration en `ObservabilityConfig` de la brique (famille générative, multi-étapes, transport API).

    `model_version` reste volontairement vide : la brique recopie cette valeur dans `llm.model_name` de chaque span, ce qui
    fausserait le suivi des coûts d'Arize ; le nom réel du modèle est posé par l'adaptateur sur les seuls spans LLM."""
    from ml_utils.observability import Family, ObservabilityConfig, Topology, Transport
    from ml_utils.observability.contracts import DeploymentEnv, RedactionPolicy
    from pydantic import SecretStr

    return ObservabilityConfig(
        family=Family.GENERATIVE,
        transport=Transport.API,
        topology=Topology.MULTISTEP,
        model_id=cfg.model_id,
        model_version=None,
        backend=cfg.backend if cfg.effective else "noop",
        endpoint=cfg.endpoint,
        api_key=SecretStr(cfg.api_key) if cfg.api_key else None,
        space_id=cfg.space_id,
        project=cfg.projet,
        records_uri=cfg.records_uri,
        records_flight_host=environ_hote(cfg.records_uri),
        environment=DeploymentEnv(cfg.environnement),
        enabled=cfg.effective,
        sample_rate=cfg.taux_echantillonnage,
        redaction=RedactionPolicy(cfg.redaction),
    )


def environ_hote(uri: str | None) -> str | None:
    if not uri:
        return None
    from urllib.parse import urlparse

    return urlparse(uri).hostname
