"""Observabilité : la brique ml_utils reçoit, pour une session factice, l'arbre de spans attendu par Arize AX (session,
étapes avec graphe, appels LLM avec messages et outils, appels d'outils, garde-fous), sans réseau : exportateur en mémoire.
Inactive, l'observabilité est un passe-plat qui ne change rien au comportement de l'agent."""

from __future__ import annotations

import json

import pytest

from poc.agent import lancer_agent
from poc.config import Config
from poc.donnees import ParquetStore, SQLiteStore
from poc.generateur.marche import construire_base_sectorielle
from poc.generateur.pipeline import generer_dossier
from poc.llm import ConfigLLM
from poc.llm.config import ModeleLLM
from poc.observabilite import (
    ConfigObservabilite,
    Observabilite,
    adaptateur,
    charger_config_observabilite,
    reinitialiser,
)
from poc.observabilite.config import vers_config_ml_utils
from poc.referentiels import charger_referentiels

ml_utils = pytest.importorskip("ml_utils.observability")
from opentelemetry.sdk.trace.export import SimpleSpanProcessor  # noqa: E402
from opentelemetry.sdk.trace.export.in_memory_span_exporter import InMemorySpanExporter  # noqa: E402


@pytest.fixture(scope="module")
def config(tmp_path_factory):
    cfg = Config(data_dir=tmp_path_factory.mktemp("obs"), unite_safir="euros")
    refs = charger_referentiels()
    generer_dossier(cfg, "croissance_saine", 1, refs=refs)
    construire_base_sectorielle(
        refs, ParquetStore(cfg.si_simule_dir), SQLiteStore(cfg.sqlite_dossier), n_par_secteur=40
    )
    return cfg


from ml_utils.observability.backends._otel import OtelSpanBackend  # noqa: E402


class BackendMemoire(OtelSpanBackend):
    """Le backend OTel de la brique, dont l'exportateur réseau est remplacé par une mémoire : on relit les spans."""

    def __init__(self) -> None:
        from opentelemetry.sdk.resources import Resource
        from opentelemetry.sdk.trace import TracerProvider

        self.exporteur = InMemorySpanExporter()
        self._provider = TracerProvider(resource=Resource.create({"openinference.project.name": "test"}))
        self._processor = SimpleSpanProcessor(self.exporteur)
        self._provider.add_span_processor(self._processor)
        self._tracer = self._provider.get_tracer("test")

    def emit_records(self, records):  # pas de records dans ces tests
        return None


@pytest.fixture()
def obs_memoire(monkeypatch):
    from ml_utils.observability import ArizeManager

    reinitialiser()
    cfg = ConfigObservabilite(
        active=True, backend="phoenix", endpoint="http://memoire/v1/traces", projet="test", contenu_messages=True
    )
    backend = BackendMemoire()
    manager = ArizeManager(vers_config_ml_utils(cfg), backend=backend)
    obs = Observabilite(cfg, manager)
    monkeypatch.setattr(adaptateur, "_INSTANCE", obs)
    yield obs, backend.exporteur
    manager.close()
    reinitialiser()


def _attrs(span) -> dict:
    return dict(span.attributes or {})


def test_config_du_depot_inactive_par_defaut(monkeypatch):
    for v in ("OBS_ENABLED", "OBS_BACKEND", "OBS_ENDPOINT", "OBS_API_KEY", "OBS_SPACE_ID"):
        monkeypatch.delenv(v, raising=False)
    cfg = charger_config_observabilite()
    assert cfg.active is False and cfg.effective is False
    monkeypatch.setenv("OBS_ENABLED", "true")
    monkeypatch.setenv("OBS_BACKEND", "arize")
    monkeypatch.setenv("OBS_ENDPOINT", "https://arize.interne/v1/traces")
    monkeypatch.setenv("OBS_API_KEY", "secret")
    cfg2 = charger_config_observabilite()
    assert cfg2.effective and cfg2.backend == "arize" and cfg2.api_key == "secret"
    mlc = vers_config_ml_utils(cfg2)
    assert mlc.backend == "arize" and mlc.api_key.get_secret_value() == "secret" and mlc.model_version is None
    assert "secret" not in repr(mlc)


def test_inactive_est_un_passe_plat(config):
    reinitialiser()
    adaptateur._INSTANCE = Observabilite(ConfigObservabilite(), None)
    cfg = ConfigLLM(defaut="factice", modeles={"factice": ModeleLLM(fournisseur="factice", nom="factice")})
    d = SQLiteStore(config.sqlite_verite_terrain).requete("SELECT dossier_id FROM vt_etiquette")["dossier_id"][0]
    r = lancer_agent(config, d, config_llm=cfg, checkpoints=False)
    assert len(r.bilans) >= 5 and not any(b["erreurs"] for b in r.bilans)
    reinitialiser()


def test_session_factice_produit_l_arbre_de_spans_attendu(config, obs_memoire):
    obs, exporteur = obs_memoire
    cfg = ConfigLLM(defaut="factice", modeles={"factice": ModeleLLM(fournisseur="factice", nom="factice")})
    d = SQLiteStore(config.sqlite_verite_terrain).requete("SELECT dossier_id FROM vt_etiquette")["dossier_id"][0]
    r = lancer_agent(config, d, config_llm=cfg, checkpoints=False)
    spans = exporteur.get_finished_spans()
    assert spans, "aucun span exporté"
    par_kind: dict[str, list] = {}
    for s in spans:
        par_kind.setdefault(_attrs(s).get("openinference.span.kind"), []).append(s)
    # racine de session
    racines = [s for s in par_kind["AGENT"] if _attrs(s).get("graph.node.id") == "agent"]
    assert len(racines) == 1
    racine = racines[0]
    a = _attrs(racine)
    assert a["session.id"] == r.session_id and a["user.id"] and a["poc.dossier_id"] == d
    assert racine.parent is None
    assert a["metric.tokens"] == r.tokens and "poc.arret" in a
    # étapes : un span AGENT par étape, fils de la racine, avec le graphe
    etapes = [s for s in par_kind["AGENT"] if _attrs(s).get("graph.node.parent_id") == "agent"]
    assert [_attrs(s)["graph.node.id"] for s in sorted(etapes, key=lambda s: s.start_time)] == [
        b["etape"] for b in r.bilans
    ]
    assert all(s.parent is not None and s.parent.span_id == racine.context.span_id for s in etapes)
    assert all("metric.tours" in _attrs(s) for s in etapes)
    # appels LLM : messages, outils proposés, tokens, nom du modèle réel
    llms = par_kind["LLM"]
    assert len(llms) == sum(b["tours"] for b in r.bilans)
    a0 = _attrs(llms[0])
    assert a0["llm.model_name"] == "factice" and a0["llm.provider"] == "factice"
    assert (
        a0["llm.input_messages.0.message.role"] == "system"
        and "Règles" in a0["llm.input_messages.0.message.content"]
        or a0["llm.input_messages.0.message.content"]
    )
    assert any(k.startswith("llm.tools.0.tool.json_schema") for k in a0)
    assert a0["llm.token_count.prompt"] == 100 and a0["llm.token_count.total"] == 120
    avec_appel = [s for s in llms if "llm.output_messages.0.message.tool_calls.0.tool_call.function.name" in _attrs(s)]
    assert avec_appel, "aucun appel d'outil structuré en sortie de LLM"
    assert all(s.parent is not None for s in llms)
    # un span LLM est fils d'un span d'étape
    parents_etapes = {s.context.span_id for s in etapes}
    assert all(s.parent.span_id in parents_etapes for s in llms)
    # appels d'outils
    tools = par_kind["TOOL"]
    assert len(tools) == sum(b["appels_outils"] for b in r.bilans)
    noms = {_attrs(s)["tool.name"] for s in tools}
    assert {"lire_dossier", "lire_comptes"} <= noms
    t0 = next(s for s in tools if _attrs(s)["tool.name"] == "lire_dossier")
    assert json.loads(_attrs(t0)["tool.parameters"])["dossier_id"] == d
    assert _attrs(t0)["poc.serveur_mcp"] == "direct" and "output.value" in _attrs(t0)
    # garde-fous : le conformiste n'appelle pas le vérificateur ; un refus d'outil hors étape ne crée pas de garde-fou
    assert "GUARDRAIL" not in par_kind or all(_attrs(s)["poc.verdict"] for s in par_kind["GUARDRAIL"])


def test_garde_fou_et_erreur_d_outil(config, obs_memoire):
    obs, exporteur = obs_memoire
    from poc.llm import AppelOutil, ReponseLLM

    def scenario(systeme, messages, outils):
        deja = [a.nom for m in messages if m.role == "assistant" for a in m.appels]
        etape = next(ligne.split("**")[1] for ligne in systeme.splitlines() if "Étape en cours" in ligne)
        if etape == "retraitements_calculs" and "calculer" not in deja:
            return ReponseLLM(
                texte="",
                appels=[
                    AppelOutil(
                        id="c",
                        nom="calculer",
                        parametres={"etape": etape, "sorties": ["x"], "code": "import os", "entrees": []},
                    )
                ],
                tokens_entree=1,
                tokens_sortie=1,
                duree_ms=1,
                modele="factice",
                fin="tool_use",
            )
        return ReponseLLM(
            texte='{"synthese": "ok", "points_cles": [], "arret": false, "motif_arret": ""}',
            appels=[],
            tokens_entree=1,
            tokens_sortie=1,
            duree_ms=1,
            modele="factice",
            fin="end_turn",
        )

    cfg = ConfigLLM(defaut="factice", modeles={"factice": ModeleLLM(fournisseur="factice", nom="factice")})
    d = SQLiteStore(config.sqlite_verite_terrain).requete("SELECT dossier_id FROM vt_etiquette")["dossier_id"][0]
    lancer_agent(config, d, config_llm=cfg, scenario_factice=scenario, checkpoints=False)
    spans = exporteur.get_finished_spans()
    tool = next(s for s in spans if _attrs(s).get("tool.name") == "calculer")
    assert _attrs(tool)["poc.erreur_code"] == "CODE_REFUSE" and _attrs(tool).get("error") is True
    gardes = [s for s in spans if _attrs(s).get("openinference.span.kind") == "GUARDRAIL"]
    assert gardes and _attrs(gardes[0])["poc.verdict"] == "CODE_REFUSE"


def test_attributs_tronques_et_contenu_masquable():
    cfg = ConfigObservabilite(taille_max_attribut=200, contenu_messages=False)
    obs = Observabilite(cfg, None)
    t = obs._texte("x" * 1000)
    assert len(t) < 260 and "tronqués" in t
    assert (
        obs._fournisseur(ModeleLLM(fournisseur="openai_compatible", nom="m", url="https://api.mistral.ai/v1"))
        == "mistral"
    )
    assert obs._fournisseur(ModeleLLM(fournisseur="anthropic", nom="m", url="https://api.anthropic.com")) == "anthropic"


def test_collecteur_injoignable_desactive_proprement(capsys):
    """Collecteur absent : observabilité inactive dès le démarrage, un seul message, l'agent n'est pas gêné."""
    reinitialiser()
    cfg = ConfigObservabilite(active=True, backend="phoenix", endpoint="http://127.0.0.1:9/v1/traces", projet="test")
    obs = adaptateur.demarrer(cfg)
    assert not obs.actif
    assert "désactivée" in capsys.readouterr().err
    with obs.session("S", "D") as s:  # passe-plat
        s.sortie({"ok": True})
    reinitialiser()


def test_span_interrompu_garde_une_sortie(obs_memoire):
    obs, exporteur = obs_memoire
    with pytest.raises(KeyboardInterrupt):
        with obs.etape("analyse", "S", "D"):
            raise KeyboardInterrupt
    with obs.etape("collecte", "S", "D"):
        pass
    sorties = {s.name: _attrs(s).get("output.value") for s in exporteur.get_finished_spans()}
    assert "KeyboardInterrupt" in sorties["analyse"] and "vide" in sorties["collecte"]
