"""Ligne de commande du POC : `poc <commande>`."""

from __future__ import annotations

import typer
from rich.console import Console
from rich.table import Table

from poc.config import charger_config
from poc.referentiels import charger_referentiels
from poc.referentiels.chargement import charger_dans_sqlite, valider_referentiels

app = typer.Typer(help="POC agent d'analyse financière : référentiels, génération, corpus, inspection, démonstrations.")
referentiels_app = typer.Typer(help="Référentiels de codes.")
demo_app = typer.Typer(help="Rejoue la démonstration de fin d'un lot.")
corpus_app = typer.Typer(help="Corpus de dossiers : plan, génération par lots, scellement, tableau de contrôle.")
secteur_app = typer.Typer(help="Base sectorielle et de marché locale (quartiles, taux, stress, notes).")
app.add_typer(referentiels_app, name="referentiels")
app.add_typer(demo_app, name="demo")
app.add_typer(corpus_app, name="corpus")
app.add_typer(secteur_app, name="secteur")
console = Console()


def _afficher_df(df, titre: str, max_lignes: int = 60) -> None:
    table = Table(title=titre)
    for c in df.columns:
        table.add_column(str(c))
    for row in df.head(max_lignes).iter_rows():
        table.add_row(*["" if v is None else str(v) for v in row])
    console.print(table)


@referentiels_app.command("valider")
def referentiels_valider() -> None:
    """Vérifie les référentiels (codes uniques, libellés présents, formules couvertes)."""
    refs = charger_referentiels()
    anomalies = valider_referentiels(refs)
    table = Table(title="Référentiels")
    table.add_column("Nom")
    table.add_column("Lignes", justify="right")
    for nom, df in refs.tables.items():
        table.add_row(nom, str(df.height))
    console.print(table)
    if anomalies:
        for a in anomalies:
            console.print(f"[red]Anomalie :[/red] {a}")
        raise typer.Exit(code=1)
    console.print("[green]Aucune anomalie.[/green]")


@referentiels_app.command("charger")
def referentiels_charger() -> None:
    """Charge les référentiels dans la base SQLite de la couche dossier (tables referentiel_*)."""
    config = charger_config()
    refs = charger_referentiels()
    anomalies = valider_referentiels(refs)
    if anomalies:
        for a in anomalies:
            console.print(f"[red]Anomalie :[/red] {a}")
        raise typer.Exit(code=1)
    charger_dans_sqlite(refs, config.sqlite_dossier)
    console.print(f"[green]{len(refs.tables)} référentiels chargés dans {config.sqlite_dossier}[/green]")


@app.command("scenarios")
def scenarios() -> None:
    """Liste les scénarios de diagnostic et leur conclusion attendue."""
    from poc.generateur.scenarios import CONCLUSIONS, SCENARIOS

    table = Table(title="Scénarios")
    table.add_column("Scénario")
    table.add_column("Conclusion attendue")
    for sc in SCENARIOS:
        table.add_row(sc, CONCLUSIONS.get(sc, ("", ""))[0])
    console.print(table)


@app.command("generer")
def generer(
    profil: str = typer.Option("sain", help="Scénario : sain, derive_clients, dette_cachee… (voir `poc scenarios`)."),
    seed: int = typer.Option(1, help="Graine aléatoire : la même graine redonne le même dossier."),
    nom: str = typer.Option("", help="Nom de l'entreprise (facultatif, sinon tiré au sort)."),
    secteur: str = typer.Option(
        "",
        help="Secteur POC (industrie_mecanique, agroalimentaire, construction, commerce, transport, hotellerie_restauration, "
        "services_numerique, sante) ; sinon tiré au sort.",
    ),
) -> None:
    """Génère un dossier : couche SI simulé (parquet) puis couche dossier (SQLite), avec sa vérité terrain."""
    from poc.generateur.pipeline import generer_dossier

    config = charger_config()
    resultat = generer_dossier(config, profil=profil, seed=seed, nom=nom or None, secteur=secteur or None)
    e = resultat.etiquette
    console.print(
        f"[green]Dossier {resultat.dossier_id} généré[/green] : {resultat.entreprise.nom} (SIREN {resultat.entreprise.siren}), "
        f"scénario {resultat.scenario}, {e.get('taille')} {e.get('secteur')}, structure {e.get('structure')} ({e.get('nb_entites')} entités), "
        f"difficulté {e.get('difficulte')}/5, {len(resultat.exercices)} exercices, {resultat.nb_vues} vues écrites dans {config.si_simule_dir}, "
        f"couche dossier dans {config.sqlite_dossier}."
    )
    for nom_ctrl, ok in resultat.controles.items():
        attendu = " (échec attendu par le scénario)" if nom_ctrl in resultat.echecs_attendus else ""
        console.print(f"  {'[green]OK[/green]' if ok else '[yellow]KO[/yellow]'} {nom_ctrl}{attendu}")


@app.command("inspecter")
def inspecter(
    dossier_id: str = typer.Argument(..., help="Identifiant du dossier (org_i_demande)."),
    scelles: bool = typer.Option(False, help="Lire dans le répertoire des scellés."),
) -> None:
    """Affiche les tableaux bruts d'un dossier de la couche dossier."""
    from poc.corpus.generation import config_lot
    from poc.generateur.inspection import afficher_dossier

    config = charger_config()
    afficher_dossier(config_lot(config, "scelle") if scelles else config, dossier_id, console)


@secteur_app.command("construire")
def secteur_construire(n: int = typer.Option(500, help="Profils générés par secteur pour les quartiles.")) -> None:
    """Construit la base sectorielle locale : quartiles par secteur et taille, courbes de taux, chocs de stress, notes sectorielles."""
    from poc.donnees import ParquetStore, SQLiteStore
    from poc.generateur.marche import construire_base_sectorielle

    config = charger_config()
    refs = charger_referentiels()
    with console.status("Génération de la population sectorielle et calcul des quartiles…"):
        lignes = construire_base_sectorielle(
            refs, ParquetStore(config.si_simule_dir), SQLiteStore(config.sqlite_dossier), n_par_secteur=n
        )
    for nom, nb in lignes.items():
        console.print(f"  {nom} : {nb} lignes")
    console.print(
        f"[green]Base sectorielle écrite dans {config.si_simule_dir / 'ap_ref_refined_view'} et {config.sqlite_dossier}[/green]"
    )


@corpus_app.command("plan")
def corpus_plan() -> None:
    """Affiche et écrit le plan du corpus (200 dossiers : 50 de réglage, 20 scellés, 130 de charge)."""
    from poc.corpus.plan import ecrire_plan, plan_corpus, plan_vers_df

    config = charger_config()
    plan = plan_corpus()
    ecrire_plan(plan, config.data_dir / "corpus" / "plan_corpus.csv")
    df = plan_vers_df(plan)
    _afficher_df(
        df.group_by(["lot", "scenario"]).agg(__import__("polars").len().alias("n")).sort(["lot", "scenario"]),
        "Plan du corpus",
        max_lignes=80,
    )
    console.print(f"{len(plan)} dossiers planifiés ; plan écrit dans {config.data_dir / 'corpus' / 'plan_corpus.csv'}")


@corpus_app.command("generer")
def corpus_generer(
    lot: str = typer.Option(
        "reglage,charge", help="Lots à générer : reglage, charge, scelle (séparés par des virgules)."
    ),
    sceller_apres: bool = typer.Option(
        True, help="Verrouille le répertoire des scellés après génération du lot scelle."
    ),
) -> None:
    """Génère les dossiers du corpus pour les lots demandés et écrit le journal de génération."""
    from poc.corpus.generation import generer_corpus, sceller
    from poc.corpus.plan import plan_corpus

    config = charger_config()
    lots = tuple(x.strip() for x in lot.split(",") if x.strip())
    plan = plan_corpus()

    def progression(n, total, ligne, resultat, erreur):
        etat = (
            "[red]ERREUR[/red] " + erreur
            if erreur
            else ("[green]ok[/green]" if resultat and resultat.conforme else "[yellow]non conforme[/yellow]")
        )
        console.print(f"[{n:3d}/{total}] {ligne.lot:8s} {ligne.scenario:24s} graine {ligne.seed:7d} {etat}")

    journal = generer_corpus(config, plan, lots, progression)
    conformes = int(journal["conforme"].sum())
    console.print(
        f"[green]{journal.height} dossiers générés, {conformes} conformes[/green] ; journal dans {config.data_dir / 'corpus'}"
    )
    if "scelle" in lots and sceller_apres:
        chemin = sceller(config)
        console.print(f"[green]Lot scellé[/green] : {chemin}")


@corpus_app.command("controler")
def corpus_controler() -> None:
    """Tableau de contrôle du corpus : couverture des dimensions, discrimination des scénarios, cohérence, difficulté."""
    from poc.corpus.controle import tableau_controle

    config = charger_config()
    tc = tableau_controle(config)
    console.print(f"{tc.n_dossiers} dossiers dans la vérité terrain ({config.sqlite_verite_terrain})")
    for dim in [
        "scenario",
        "taille",
        "secteur",
        "structure",
        "forme_juridique",
        "mois_cloture",
        "relation_bancaire",
        "difficulte",
    ]:
        if dim in tc.couverture:
            _afficher_df(tc.couverture[dim], f"Couverture : {dim}")
    _afficher_df(tc.sain_reference, "Référence : indicateurs du cas sain (dernier exercice)")
    _afficher_df(tc.discrimination, "Discrimination des scénarios")
    _afficher_df(tc.coherence, "Cohérence : contrôles de génération")
    tc.ecrire(config.data_dir / "corpus" / "controle")
    non = tc.discrimination.filter(tc.discrimination["discrimine"] == "NON")
    if non.height:
        console.print(f"[yellow]{non.height} scénario(s) non discriminé(s) : {non['scenario'].to_list()}[/yellow]")
    else:
        console.print("[green]Tous les scénarios sont discriminés.[/green]")
    console.print(f"Tableaux écrits dans {config.data_dir / 'corpus' / 'controle'}")


@corpus_app.command("verifier-scelle")
def corpus_verifier_scelle() -> None:
    """Vérifie que le lot scellé n'a pas été modifié depuis son scellement."""
    from poc.corpus.generation import verifier_scelle

    modifies = verifier_scelle(charger_config())
    if modifies:
        console.print(f"[red]Scellé altéré :[/red] {modifies}")
        raise typer.Exit(code=1)
    console.print("[green]Scellé intact.[/green]")


api_app = typer.Typer(help="API locales : dossier-api (lecture) et note-api (espace de travail de l'agent).")
outils_app = typer.Typer(help="Outils de l'agent : registre, schémas, exécution en mode direct.")
app.add_typer(api_app, name="api")
app.add_typer(outils_app, name="outils")


@api_app.command("dossier")
def api_dossier(port: int = typer.Option(8001, help="Port d'écoute."), hote: str = typer.Option("127.0.0.1")) -> None:
    """Lance dossier-api (lecture seule de la couche dossier)."""
    import uvicorn

    from poc.api import creer_app_dossier

    uvicorn.run(creer_app_dossier(charger_config()), host=hote, port=port)


@api_app.command("note")
def api_note(port: int = typer.Option(8002, help="Port d'écoute."), hote: str = typer.Option("127.0.0.1")) -> None:
    """Lance note-api (sessions, atelier de calcul, vérificateur, sections, export)."""
    import uvicorn

    from poc.api import creer_app_note

    uvicorn.run(creer_app_note(charger_config()), host=hote, port=port)


@outils_app.command("lister")
def outils_lister(
    etape: str = typer.Option(
        "", help="Filtrer par étape : collecte, retraitements_calculs, analyse, previsionnel_stress, redaction."
    ),
) -> None:
    """Liste les outils de l'agent, leurs étapes et leur serveur MCP cible."""
    from poc.outils import OUTILS, outils_pour_etape

    specs = outils_pour_etape(etape) if etape else list(OUTILS.values())
    table = Table(title="Outils de l'agent")
    for c in ("outil", "étapes", "serveur MCP", "écriture", "description"):
        table.add_column(c)
    for s in specs:
        table.add_row(
            s.nom,
            ", ".join(s.etapes),
            s.serveur_mcp,
            "oui" if s.ecriture else "non",
            s.description[:90] + ("…" if len(s.description) > 90 else ""),
        )
    console.print(table)


@outils_app.command("appeler")
def outils_appeler(
    nom: str = typer.Argument(..., help="Nom de l'outil (voir `poc outils lister`)."),
    parametres: str = typer.Argument(
        "{}", help="Paramètres en JSON ; les guillemets simples et les clés nues sont acceptés."
    ),
    param: list[str] | None = typer.Option(  # noqa: B008
        None, "--param", "-p", help="Paramètre clé=valeur, répétable ; évite les guillemets JSON sous Windows."
    ),
    http: bool = typer.Option(False, help="Passer par les API locales plutôt qu'en mode direct."),
) -> None:
    """Exécute un outil en mode direct (ou HTTP) et affiche la réponse JSON.

    Exemples : `poc outils appeler lire_dossier -p dossier_id=DEM2026000001` ou
    `poc outils appeler lire_comptes -p dossier_id=DEM2026000001 -p exercice=2024 -p perimetre=social`.
    """
    import json
    import re

    from poc.outils import BackendHTTP, BackendLocal, executer_outil
    from poc.outils.backend import ErreurOutil

    def parser_json_tolerant(texte: str) -> dict:
        texte = texte.strip() or "{}"
        try:
            return json.loads(texte)
        except json.JSONDecodeError:
            repare = texte.replace("'", '"')
            repare = re.sub(r"([{,]\s*)([A-Za-z_][A-Za-z0-9_]*)\s*:", r'\1"\2":', repare)
            repare = re.sub(r":\s*([A-Za-z_][A-Za-z0-9_-]*)(\s*[,}])", r': "\1"\2', repare)
            try:
                return json.loads(repare)
            except json.JSONDecodeError as exc:
                raise typer.BadParameter(
                    f"paramètres illisibles : {texte!r}. Sous Windows, préférez --param cle=valeur. ({exc.msg})"
                ) from exc

    def convertir(valeur: str):
        bas = valeur.lower()
        if bas in ("true", "vrai", "oui"):
            return True
        if bas in ("false", "faux", "non"):
            return False
        if re.fullmatch(r"-?\d+", valeur):
            return int(valeur)
        if re.fullmatch(r"-?\d+\.\d+", valeur):
            return float(valeur)
        if valeur[:1] in "[{":
            return parser_json_tolerant(valeur)
        return valeur

    params = parser_json_tolerant(parametres)
    for kv in param or []:
        if "=" not in kv:
            raise typer.BadParameter(f"--param attend cle=valeur, reçu {kv!r}")
        k, v = kv.split("=", 1)
        params[k.strip()] = convertir(v.strip())
    backend = BackendHTTP() if http else BackendLocal(charger_config())
    try:
        reponse = executer_outil(backend, nom, params)
    except ErreurOutil as exc:
        console.print(f"[red]{exc.code}[/red] : {exc.message}")
        raise typer.Exit(code=1) from exc
    except ValueError as exc:
        console.print(f"[red]Paramètres refusés[/red] : {exc}")
        raise typer.Exit(code=1) from exc
    console.print_json(json.dumps(reponse, ensure_ascii=False, default=str))


@app.command("sante")
def sante(
    http: bool = typer.Option(False, help="Vérifie aussi que les deux API répondent (elles doivent être lancées)."),
) -> None:
    """Vérification rapide : bases, tables, référentiels, outils, atelier, vérificateur, API."""
    from poc.sante import verifier_installation

    controles = verifier_installation(charger_config(), http=http)
    table = Table(title="État de l'installation")
    table.add_column("Contrôle")
    table.add_column("Résultat")
    table.add_column("Détail")
    for c in controles:
        table.add_row(c.nom, "[green]OK[/green]" if c.ok else "[red]KO[/red]", c.detail)
    console.print(table)
    if not all(c.ok for c in controles):
        raise typer.Exit(code=1)


@demo_app.command("lot-0")
def demo_lot_0() -> None:
    """Lot 0 : référentiels validés et chargés, couverture des formules affichée."""
    referentiels_valider()
    referentiels_charger()
    refs = charger_referentiels()
    table = Table(title="Dictionnaire des postes de liasse")
    table.add_column("Formulaire")
    table.add_column("Postes", justify="right")
    table.add_column("dont codes observés dans pdo", justify="right")
    import polars as pl

    for f, grp in sorted(refs.postes.group_by("formulaire"), key=lambda x: str(x[0])):
        table.add_row(str(f[0]), str(grp.height), str(grp.filter(pl.col("code_observe") == "1").height))
    console.print(table)
    console.print(f"{len(refs.formules('agregat'))} agrégats et {len(refs.formules('controle'))} contrôles définis.")


@demo_app.command("lot-1")
def demo_lot_1() -> None:
    """Lot 1 : génère le dossier sain (graine 1), vérifie les propriétés et l'affiche."""
    from poc.generateur.inspection import afficher_dossier
    from poc.generateur.pipeline import generer_dossier

    config = charger_config()
    resultat = generer_dossier(config, profil="sain", seed=1)
    console.print(f"[green]Dossier {resultat.dossier_id} généré[/green] : {resultat.entreprise.nom}")
    for nom_ctrl, ok in resultat.controles.items():
        console.print(f"  {'[green]OK[/green]' if ok else '[red]KO[/red]'} {nom_ctrl}")
    afficher_dossier(config, resultat.dossier_id, console)


@demo_app.command("lot-2")
def demo_lot_2(n_quartiles: int = typer.Option(500, help="Profils par secteur pour les quartiles.")) -> None:
    """Lot 2 : un dossier par scénario, base sectorielle, tableau de contrôle (sur les dossiers présents)."""
    from poc.generateur.pipeline import generer_dossier
    from poc.generateur.scenarios import SCENARIOS

    config = charger_config()
    refs = charger_referentiels()
    table = Table(title="Un dossier par scénario (graine 1)")
    for c in [
        "scénario",
        "dossier",
        "entreprise",
        "taille",
        "secteur",
        "structure",
        "entités",
        "difficulté",
        "conforme",
        "discriminant",
    ]:
        table.add_column(c)
    for sc in SCENARIOS:
        r = generer_dossier(config, sc, 1, refs=refs)
        e = r.etiquette
        table.add_row(
            sc,
            r.dossier_id,
            r.entreprise.nom[:26],
            e["taille"],
            e["secteur"][:14],
            e["structure"],
            str(e["nb_entites"]),
            str(e["difficulte"]),
            "oui" if r.conforme else "non",
            f"{e['discriminant_cle']}={e['discriminant_valeur']}",
        )
    console.print(table)
    secteur_construire(n_quartiles)
    corpus_controler()


@demo_app.command("lot-3")
def demo_lot_3() -> None:
    """Lot 3 : sans modèle de langage, un développeur fait travailler les outils sur le premier dossier : lecture, atelier, vérificateur, section, export."""
    import json

    from poc.outils import BackendLocal, executer_outil, schema_outils
    from poc.outils.backend import ErreurOutil

    config = charger_config()
    backend = BackendLocal(config)
    dossiers = backend.dossier.dossiers_disponibles()
    if not dossiers:
        console.print(
            "[red]Aucun dossier dans la couche dossier : lancez d'abord `poc generer` ou `poc corpus generer`.[/red]"
        )
        raise typer.Exit(code=1)
    d = dossiers[0]["dossier_id"]
    console.rule(f"Dossier {d}")
    dossier = executer_outil(backend, "lire_dossier", {"dossier_id": d})
    console.print(
        f"Demande : {dossier['objet']} {dossier['montant_euros']:,} € ; pièces manquantes : {dossier['pieces_manquantes'] or 'aucune'}".replace(
            ",", " "
        )
    )
    comptes = executer_outil(backend, "lire_comptes", {"dossier_id": d})
    ex = int(comptes["date_fin_exercice"][:4])
    console.print(
        f"Liasse {ex} : {len(comptes['postes'])} postes ; exercices disponibles {comptes['exercices_disponibles']}"
    )
    console.print(
        f"{len(schema_outils())} outils au registre, dont {len(schema_outils('redaction'))} visibles à l'étape rédaction."
    )
    session = backend.ecrire("sessions", {"dossier_id": d, "modele": "demo-lot-3"})
    sid = session["session_id"]
    r = executer_outil(
        backend,
        "calculer",
        {
            "session_id": sid,
            "etape": "retraitements_calculs",
            "sorties": ["caf", "caf_m"],
            "unite": "euros",
            "commentaire": "CAF additive simplifiée : résultat net + dotations - reprises",
            "code": "caf = resultat_net + dotations - reprises\ncaf_m = round(caf / 1e6, 1)",
            "entrees": [
                {"nom": "resultat_net", "origine": {"type": "poste", "cle": "HN", "exercice": ex}},
                {"nom": "dotations", "origine": {"type": "poste", "cle": "GA", "exercice": ex}},
                {"nom": "reprises", "origine": {"type": "poste", "cle": "FP", "exercice": ex}},
            ],
        },
    )
    caf = r[0]["valeur"]
    console.print(f"Atelier : caf = {caf:,.0f} € (enregistré avec sa formule et ses entrées)".replace(",", " "))
    try:
        executer_outil(
            backend,
            "calculer",
            {"session_id": sid, "etape": "analyse", "sorties": ["x"], "code": "import os\nx = 1", "entrees": []},
        )
    except ErreurOutil as exc:
        console.print(f"Atelier : code dangereux refusé -> {exc.code}")
    texte_caf = f"{caf / 1e6:.1f}".replace(".", ",")
    bon = executer_outil(
        backend,
        "verifier_citations",
        {
            "session_id": sid,
            "paragraphe": f"La CAF atteint {texte_caf} M€ en {ex}.",
            "citations": [{"texte": f"{texte_caf} M€", "nom_resultat": "caf"}],
        },
    )
    faux = executer_outil(
        backend,
        "verifier_citations",
        {
            "session_id": sid,
            "paragraphe": "La CAF atteint 9,9 M€.",
            "citations": [{"texte": "9,9 M€", "nom_resultat": "caf"}],
        },
    )
    sans = executer_outil(
        backend,
        "verifier_citations",
        {
            "session_id": sid,
            "paragraphe": f"La CAF atteint {texte_caf} M€ et progresse de 12 %.",
            "citations": [{"texte": f"{texte_caf} M€", "nom_resultat": "caf"}],
        },
    )
    console.print(
        f"Vérificateur : paragraphe juste -> {bon['verdict']} ; chiffre faux -> {faux['verdict']} ({faux['message']}) ; chiffre non cité -> {sans['verdict']}"
    )
    executer_outil(
        backend,
        "enregistrer_section",
        {
            "session_id": sid,
            "ordre": 1,
            "titre": "Capacité d'autofinancement",
            "paragraphe": f"La CAF atteint {texte_caf} M€ en {ex}.",
            "citations": [{"texte": f"{texte_caf} M€", "nom_resultat": "caf"}],
        },
    )
    export = executer_outil(backend, "exporter_note", {"session_id": sid})
    console.print(export["contenu"])
    console.print(json.dumps(backend.lire("session", session_id=sid), ensure_ascii=False))


# ---------------------------------------------------------------------------------------------------------------------
# Lot 4 : modèles de langage et agent
# ---------------------------------------------------------------------------------------------------------------------
llm_app = typer.Typer(
    help="Modèles de langage : configuration (config/llm.yaml), disponibilité des clés, test d'appel."
)
agent_app = typer.Typer(
    help="L'agent LangGraph : lancer une session sur un dossier, l'évaluer contre la vérité terrain."
)
app.add_typer(llm_app, name="llm")
app.add_typer(agent_app, name="agent")


@llm_app.command("lister")
def llm_lister() -> None:
    """Affiche les modèles configurés, le rôle de chacun et si leur clé est présente dans l'environnement."""
    import os

    from poc.llm import charger_config_llm

    cfg = charger_config_llm()
    table = Table(title="config/llm.yaml")
    for col in ("nom logique", "fournisseur", "modèle", "url", "clé (variable)", "clé présente", "rôles"):
        table.add_column(col)
    roles_par_modele: dict[str, list[str]] = {}
    for etape, nom in cfg.roles.items():
        roles_par_modele.setdefault(nom, []).append(etape)
    for nom, m in cfg.modeles.items():
        if m.fournisseur == "factice":
            presente = "—"
        elif not m.cle_api_env:
            presente = "sans clé"
        else:
            presente = "oui" if os.environ.get(m.cle_api_env) else "[red]non[/red]"
        roles = ", ".join(roles_par_modele.get(nom, [])) + (" (défaut)" if nom == cfg.defaut else "")
        table.add_row(nom, m.fournisseur, m.nom, m.url or "—", m.cle_api_env or "—", presente, roles)
    console.print(table)
    console.print(
        f"Modèle par défaut : [bold]{cfg.defaut}[/bold] ; utilisables maintenant : {cfg.modeles_disponibles()}"
    )
    gf = cfg.agent
    console.print(
        f"Garde-fous : {gf.max_tours_par_etape} tours et {gf.max_appels_outils_par_etape} appels d'outils par étape, "
        f"{gf.budget_tokens_par_dossier:,} tokens par dossier.".replace(",", " ").replace("étape ", "étape, ")
    )


@llm_app.command("tester")
def llm_tester(
    modele: str = typer.Option(None, "--modele", "-m", help="Nom logique (défaut : le modèle par défaut)."),
) -> None:
    """Envoie une question courte au modèle, avec un outil factice, pour vérifier url, clé et appel d'outils."""
    from poc.llm import Message, charger_config_llm, creer_client

    cfg = charger_config_llm()
    m = cfg.modele_pour(None, modele)
    client = creer_client(m)
    outil = {
        "name": "additionner",
        "description": "Additionne deux entiers.",
        "input_schema": {
            "type": "object",
            "properties": {"a": {"type": "integer"}, "b": {"type": "integer"}},
            "required": ["a", "b"],
        },
    }
    try:
        rep = client.appeler(
            "Tu es un assistant de test. Utilise l'outil fourni.",
            [Message(role="user", contenu="Combien font 17 + 25 ? Utilise l'outil.")],
            [outil],
        )
    except Exception as exc:  # noqa: BLE001
        console.print(f"[red]Échec de l'appel à {m.nom_logique} ({m.nom} @ {m.url}) : {exc}[/red]")
        raise typer.Exit(code=1) from exc
    appel = f"{rep.appels[0].nom}({rep.appels[0].parametres})" if rep.appels else "aucun appel d'outil"
    console.print(
        f"[green]OK[/green] {m.nom_logique} -> {rep.modele} en {rep.duree_ms} ms ; {rep.tokens_entree}+{rep.tokens_sortie} tokens ; "
        f"coût {client.cout_euros(rep.tokens_entree, rep.tokens_sortie):.5f} € ; fin={rep.fin} ; {appel}"
    )
    if rep.texte:
        console.print(f"Texte : {rep.texte[:300]}")


def _afficher_bilans(r) -> None:
    table = Table(title=f"Session {r.session_id} — dossier {r.dossier_id}")
    for col in ("étape", "tours", "appels d'outils", "tokens", "coût €", "durée s", "erreurs"):
        table.add_column(col)
    for b in r.bilans:
        table.add_row(
            b["etape"],
            str(b["tours"]),
            str(b["appels_outils"]),
            str(b["tokens"]),
            f"{b['cout_euros']:.4f}",
            str(b["duree_s"]),
            ("; ".join(b["erreurs"]))[:160],
        )
    console.print(table)
    if r.arret:
        console.print(f"[yellow]Analyse arrêtée à la collecte : {r.motif_arret}[/yellow]")
    console.print(f"Total : {r.tokens} tokens, {r.cout_euros:.4f} €, {r.duree_s} s")


@agent_app.command("lancer")
def agent_lancer(
    dossier: str = typer.Option(..., "--dossier", "-d", help="Identifiant du dossier (DEM2025000010…)."),
    modele: str = typer.Option(
        None, "--modele", "-m", help="Nom logique du modèle pour toutes les étapes (défaut : rôles de config/llm.yaml)."
    ),
    collecte_autonome: bool = typer.Option(
        False, "--collecte-autonome", help="Variante : la collecte lit le SI simulé en SQL (requeter_si)."
    ),
    verbeux: bool = typer.Option(True, "--verbeux/--silencieux", help="Affiche chaque appel d'outil."),
    evaluer: bool = typer.Option(
        True, "--evaluer/--sans-evaluation", help="Compare ensuite la feuille de calcul à la vérité terrain."
    ),
    http: bool = typer.Option(
        False, "--http", help="Passe par les deux API locales (à lancer avant) au lieu du mode direct."
    ),
    mcp: bool = typer.Option(
        False, "--mcp", help="Outils découverts et appelés par les deux serveurs MCP locaux (lancés automatiquement)."
    ),
) -> None:
    """Lance l'agent sur un dossier : cinq étapes, traces et note dans data/agent.sqlite, note Markdown affichée."""
    import json

    from poc.agent import evaluer_session, lancer_agent
    from poc.agent.harnais import resume_evaluation
    from poc.outils import BackendHTTP

    config = charger_config()
    backend = BackendHTTP() if http else None
    r = lancer_agent(
        config,
        dossier,
        modele=modele,
        collecte_autonome=collecte_autonome,
        verbeux=verbeux,
        backend=backend,
        mcp=True if mcp else None,
    )
    _afficher_bilans(r)
    console.rule("Note")
    console.print(r.note_markdown)
    if evaluer:
        console.rule("Évaluation contre la vérité terrain")
        try:
            ev = evaluer_session(config, r.session_id)
        except LookupError as exc:
            console.print(f"[yellow]{exc}[/yellow]")
            return
        console.print(json.dumps(resume_evaluation(ev), ensure_ascii=False, indent=1))
        from poc.agent.harnais import publier

        pub = publier(config, ev, r)
        if pub["span"] or pub["record"]:
            console.print(
                f"Observabilité : {pub['span']} annotation(s) sur la trace, {pub['session']} sur la session, record {'émis' if pub['record'] else 'non émis'}."
            )


@agent_app.command("evaluer")
def agent_evaluer(session: str = typer.Argument(..., help="Identifiant de session (S-DEM…-xxxxxx).")) -> None:
    """Compare les résultats nommés de la feuille de calcul d'une session aux indicateurs de la vérité terrain."""
    import json

    from poc.agent import evaluer_session
    from poc.agent.harnais import resume_evaluation

    config = charger_config()
    ev = evaluer_session(config, session)
    console.print(json.dumps(resume_evaluation(ev), ensure_ascii=False, indent=1))
    from poc.agent.harnais import publier

    pub = publier(config, ev)
    if pub["span"] or pub["record"]:
        console.print(
            f"Observabilité : {pub['span']} annotation(s) sur la trace, {pub['session']} sur la session, record {'émis' if pub['record'] else 'non émis'}."
        )


@agent_app.command("sessions")
def agent_sessions(n: int = typer.Option(20, help="Nombre de sessions affichées.")) -> None:
    """Liste les dernières sessions de l'agent (statut, modèle, tokens, coût, sections vérifiées)."""
    from poc.donnees import SQLiteStore

    store = SQLiteStore(charger_config().sqlite_agent)
    if not store.existe("agent_sessions"):
        console.print("Aucune session.")
        return
    df = store.requete(
        "SELECT s.session_id, s.dossier_id, s.modele, s.statut, s.etape_courante, "
        "(SELECT COUNT(*) FROM agent_sections x WHERE x.session_id = s.session_id AND x.statut = 'VERIFIEE') AS sections, "
        "(SELECT COALESCE(SUM(tokens_entree + tokens_sortie), 0) FROM agent_traces t WHERE t.session_id = s.session_id) AS tokens, "
        "(SELECT ROUND(COALESCE(SUM(cout_euros), 0), 4) FROM agent_traces t WHERE t.session_id = s.session_id) AS cout "
        "FROM agent_sessions s ORDER BY s.creation DESC LIMIT ?",
        (n,),
    )
    _afficher_df(df, "Sessions de l'agent")


@demo_app.command("lot-4")
def demo_lot_4(
    dossier: str = typer.Option(
        None, "--dossier", "-d", help="Dossier (défaut : le premier dossier « croissance_saine » de la couche dossier)."
    ),
    modele: str = typer.Option(
        None,
        "--modele",
        "-m",
        help="Nom logique (défaut : le premier modèle réel dont la clé est présente, sinon factice).",
    ),
) -> None:
    """Lot 4 : l'agent déroule ses cinq étapes sur une entreprise saine, puis le harnais compare sa feuille de calcul à la vérité terrain."""
    from poc.donnees import SQLiteStore
    from poc.llm import charger_config_llm

    config = charger_config()
    cfg = charger_config_llm()
    if modele is None:
        from poc.llm import premier_modele_operationnel

        modele = premier_modele_operationnel(cfg)
        console.print(f"Modèle retenu : [bold]{modele}[/bold] (premier modèle configuré qui répond ; factice si aucun)")
    if dossier is None:
        vt = SQLiteStore(config.sqlite_verite_terrain)
        sains = vt.requete(
            "SELECT dossier_id FROM vt_etiquette WHERE scenario = 'croissance_saine' ORDER BY dossier_id LIMIT 1"
        )
        dossier = sains["dossier_id"][0] if sains.height else None
        if dossier is None:
            console.print("[red]Aucun dossier croissance_saine : lancez `poc corpus generer`.[/red]")
            raise typer.Exit(code=1)
    agent_lancer(
        dossier=dossier, modele=modele, collecte_autonome=False, verbeux=True, evaluer=True, http=False, mcp=False
    )


# ---------------------------------------------------------------------------------------------------------------------
# Lot 5 : serveurs MCP
# ---------------------------------------------------------------------------------------------------------------------
mcp_app = typer.Typer(
    help="Serveurs MCP locaux : mcp-dossier (lecture) et mcp-note (atelier, vérificateur, sections, export)."
)
app.add_typer(mcp_app, name="mcp")


@mcp_app.command("dossier")
def mcp_dossier(
    http: bool = typer.Option(False, "--http", help="Le serveur appelle dossier-api au lieu des services en mémoire."),
) -> None:
    """Lance mcp-dossier sur l'entrée/sortie standard (transport stdio : à brancher sur un client MCP)."""
    from poc.mcp.serveur import creer_serveur
    from poc.outils import BackendHTTP

    creer_serveur("dossier", BackendHTTP() if http else None).run("stdio")


@mcp_app.command("note")
def mcp_note(
    http: bool = typer.Option(False, "--http", help="Le serveur appelle note-api au lieu des services en mémoire."),
) -> None:
    """Lance mcp-note sur l'entrée/sortie standard (transport stdio : à brancher sur un client MCP)."""
    from poc.mcp.serveur import creer_serveur
    from poc.outils import BackendHTTP

    creer_serveur("note", BackendHTTP() if http else None).run("stdio")


@mcp_app.command("lister")
def mcp_lister() -> None:
    """Démarre les deux serveurs, découvre leurs outils par le protocole et les affiche (ce que voit l'agent en mode MCP)."""
    from poc.mcp import BackendMCP
    from poc.outils import OUTILS

    with BackendMCP() as b:
        table = Table(title="Outils découverts par MCP")
        for col in ("serveur", "outil", "paramètres requis", "au registre", "description"):
            table.add_column(col)
        for nom in b.outils_decouverts():
            o = b.outils[nom]
            table.add_row(
                f"mcp-{o['serveur']}",
                nom,
                ", ".join(o["input_schema"].get("required", [])),
                "oui" if nom in OUTILS else "[red]non[/red]",
                o["description"][:70] + ("…" if len(o["description"]) > 70 else ""),
            )
        console.print(table)
        console.print(f"{len(b.outils)} outils découverts ; {len(OUTILS)} au registre.")


# ---------------------------------------------------------------------------------------------------------------------
# Lot 5 : reprise, campagne, export Word, interface, démonstration
# ---------------------------------------------------------------------------------------------------------------------
@agent_app.command("reprendre")
def agent_reprendre(
    session: str = typer.Argument(..., help="Identifiant de session (S-DEM…-xxxxxx)."),
    depuis: str = typer.Option("redaction", "--depuis", help="Étape à partir de laquelle le graphe est relancé."),
    modele: str = typer.Option(
        None, "--modele", "-m", help="Nom logique du modèle (défaut : rôles de config/llm.yaml)."
    ),
    verbeux: bool = typer.Option(True, "--verbeux/--silencieux"),
) -> None:
    """Relance une session sauvegardée depuis une étape (les étapes antérieures sont conservées) ; utilisé par l'interface de relecture."""
    from poc.agent import reprendre_session

    r = reprendre_session(charger_config(), session, depuis, modele=modele, verbeux=verbeux)
    _afficher_bilans(r)
    console.rule("Note")
    console.print(r.note_markdown)


@agent_app.command("campagne")
def agent_campagne(
    scenarios: str = typer.Option(
        None, "--scenarios", "-s", help="Scénarios séparés par des virgules (défaut : tous ceux de la vérité terrain)."
    ),
    n: int = typer.Option(1, "--n", help="Dossiers par scénario."),
    modele: str = typer.Option(None, "--modele", "-m"),
    mcp: bool = typer.Option(False, "--mcp", help="Outils par les serveurs MCP."),
    collecte_autonome: bool = typer.Option(False, "--collecte-autonome"),
) -> None:
    """Lance l'agent sur un dossier par scénario et dresse le tableau : diagnostic concordant, indicateurs exacts, sections, tokens."""
    import polars as pl

    from poc.agent import campagne

    lignes = campagne(
        charger_config(),
        scenarios.split(",") if scenarios else None,
        modele=modele,
        n_par_scenario=n,
        collecte_autonome=collecte_autonome,
        mcp=True if mcp else None,
        verbeux=False,
    )
    if not lignes:
        console.print("[yellow]Aucun dossier pour ces scénarios.[/yellow]")
        return
    df = pl.DataFrame(lignes)
    _afficher_df(df.drop("session"), "Campagne", max_lignes=100)
    concordants = sum(1 for x in lignes if x["concordant"])
    codes = sum(1 for x in lignes if x["conclusion_agent"])
    console.print(
        f"{len(lignes)} sessions · diagnostics concordants {concordants}/{codes} codés · indicateurs exacts "
        f"{sum(x['exacts'] for x in lignes)}/{sum(x['compares'] for x in lignes)} comparés · {sum(x['tokens'] for x in lignes):,} tokens · "
        f"{sum(x['cout_euros'] for x in lignes):.4f} €".replace(",", " ")
    )


note_app = typer.Typer(help="La note produite : export Markdown ou Word d'une session.")
app.add_typer(note_app, name="note")


@note_app.command("exporter")
def note_exporter(
    session: str = typer.Argument(..., help="Identifiant de session."),
    format: str = typer.Option("docx", "--format", "-f", help="docx | markdown"),  # noqa: A002
) -> None:
    """Exporte la note d'une session : Word (data/notes/<session>.docx) ou Markdown affiché."""
    from poc.outils import BackendLocal, executer_outil

    r = executer_outil(BackendLocal(charger_config()), "exporter_note", {"session_id": session, "format": format})
    if format == "docx":
        console.print(f"[green]Document Word écrit :[/green] {r['fichier_docx']}")
    else:
        console.print(r["contenu"])


@app.command("interface")
def interface(port: int = typer.Option(8501, help="Port de l'interface Streamlit.")) -> None:
    """Ouvre l'interface de relecture locale (Streamlit) : feuille de calcul et décisions à gauche, note et citations à droite."""
    import subprocess
    import sys

    from poc.config import RACINE

    chemin = RACINE / "poc" / "interface" / "relecture.py"
    subprocess.run(
        [
            sys.executable,
            "-m",
            "streamlit",
            "run",
            str(chemin),
            "--server.port",
            str(port),
            "--server.headless",
            "true",
        ],
        cwd=str(RACINE),
        check=False,
    )


@demo_app.command("lot-5")
def demo_lot_5(
    modele: str = typer.Option(
        None, "--modele", "-m", help="Nom logique (défaut : premier modèle réel disponible, sinon factice)."
    ),
) -> None:
    """Lot 5 : découverte des outils par MCP, session complète en mode MCP avec auto-revue, export Word, évaluation."""
    import json

    from poc.agent import evaluer_session, lancer_agent
    from poc.agent.harnais import resume_evaluation
    from poc.donnees import SQLiteStore
    from poc.llm import charger_config_llm
    from poc.mcp import BackendMCP
    from poc.outils import OUTILS, BackendLocal, executer_outil

    config = charger_config()
    cfg = charger_config_llm()
    if modele is None:
        from poc.llm import premier_modele_operationnel

        modele = premier_modele_operationnel(cfg)
        console.print(f"Modèle retenu : [bold]{modele}[/bold] (premier modèle configuré qui répond ; factice si aucun)")
    vt = SQLiteStore(config.sqlite_verite_terrain)
    sains = vt.requete(
        "SELECT dossier_id FROM vt_etiquette WHERE scenario = 'croissance_saine' ORDER BY dossier_id LIMIT 1"
    )
    if not sains.height:
        console.print("[red]Aucun dossier croissance_saine : lancez `poc corpus generer`.[/red]")
        raise typer.Exit(code=1)
    d = sains["dossier_id"][0]
    console.rule("1. Découverte des outils par MCP")
    with BackendMCP(orchestrateur=BackendLocal(config)) as b:
        par_serveur = {s: sorted(n for n, o in b.outils.items() if o["serveur"] == s) for s in ("dossier", "note")}
        for s, noms in par_serveur.items():
            console.print(f"mcp-{s} ({len(noms)}) : {', '.join(noms)}")
        console.print(
            f"{len(b.outils)} outils découverts, {len(OUTILS)} au registre, aucun écart."
            if set(b.outils) == set(OUTILS)
            else "[red]écart registre / serveurs[/red]"
        )
        console.rule(f"2. Session en mode MCP sur {d} (six étapes dont l'auto-revue)")
        r = lancer_agent(config, d, modele=modele, verbeux=True, backend=b)
    _afficher_bilans(r)
    console.rule("3. Export Word")
    docx = executer_outil(BackendLocal(config), "exporter_note", {"session_id": r.session_id, "format": "docx"})[
        "fichier_docx"
    ]
    console.print(f"Document : {docx}")
    console.rule("4. Évaluation contre la vérité terrain")
    try:
        console.print(
            json.dumps(resume_evaluation(evaluer_session(config, r.session_id)), ensure_ascii=False, indent=1)[:3000]
        )
    except LookupError as exc:
        console.print(f"[yellow]{exc}[/yellow]")
    console.print(
        "Interface de relecture : `poc interface` ; campagne multi-scénarios : `poc agent campagne -s croissance_saine,dette_cachee`."
    )


# ---------------------------------------------------------------------------------------------------------------------
# Observabilité (brique ml_utils.observability → Phoenix / Arize AX)
# ---------------------------------------------------------------------------------------------------------------------
obs_app = typer.Typer(help="Observabilité : configuration, trace de test, Phoenix local.")
app.add_typer(obs_app, name="obs")


@obs_app.command("sante")
def obs_sante() -> None:
    """Affiche la configuration effective, construit la brique et envoie une trace de test (session, étape, appel LLM, outil)."""
    from poc.observabilite import charger_config_observabilite, demarrer, reinitialiser

    cfg = charger_config_observabilite()
    table = Table(title="Observabilité")
    table.add_column("réglage")
    table.add_column("valeur")
    for k in (
        "active",
        "backend",
        "endpoint",
        "projet",
        "model_id",
        "environnement",
        "taux_echantillonnage",
        "redaction",
        "contenu_messages",
        "propagation_mcp",
    ):
        table.add_row(k, str(getattr(cfg, k)))
    table.add_row("clé API", "présente" if cfg.api_key else "absente")
    table.add_row("space_id", "présent" if cfg.space_id else "absent")
    console.print(table)
    if not cfg.effective:
        console.print(
            "[yellow]Inactive : aucune trace ne part. Activer avec `active: true` dans config/observabilite.yaml ou OBS_ENABLED=true.[/yellow]"
        )
        return
    reinitialiser()
    obs = demarrer(cfg)
    if not obs.actif:
        console.print("[red]La brique n'a pas démarré (voir les journaux) : backend dégradé en noop.[/red]")
        raise typer.Exit(code=1)
    from poc.llm import Message, ReponseLLM
    from poc.llm.config import ModeleLLM

    modele = ModeleLLM(nom_logique="factice", fournisseur="factice", nom="factice")
    with obs.session("S-TEST-000000", "DEM0000000000", {"modele": "factice", "mode_outils": "direct"}) as s:
        with obs.etape("collecte", "S-TEST-000000", "DEM0000000000") as e:
            with obs.appel_modele(
                modele, "consigne de test", [Message(role="user", contenu="bonjour")], [], "collecte", "S-TEST-000000"
            ) as llm:
                obs.reponse_modele(
                    llm,
                    ReponseLLM(
                        texte="ok",
                        appels=[],
                        tokens_entree=10,
                        tokens_sortie=2,
                        duree_ms=1,
                        modele="factice",
                        fin="end_turn",
                    ),
                    0.0,
                )
            with obs.appel_outil("lire_dossier", {"dossier_id": "DEM0000000000"}, "collecte", "S-TEST-000000") as o:
                o.sortie({"ok": True})
            obs.garde_fou("verificateur", "ACCEPTE", "test", "collecte", "S-TEST-000000")
            e.sortie({"synthese": "test"})
        s.sortie({"test": True})
    obs.manager.flush()
    # L'export est asynchrone et fail-open : « remis » ne veut pas dire « reçu ». On interroge donc le collecteur
    # directement, avec les mêmes en-têtes et la même vérification TLS que l'exportateur OTLP.
    code, detail = _sonder_collecteur(cfg)
    if code is not None and 200 <= code < 300:
        console.print(
            f"[green]Collecteur joignable[/green] ({cfg.endpoint}, HTTP {code}) : trace de test S-TEST-000000 (5 spans) envoyée au projet « {cfg.projet} »."
        )
        console.print(
            "Phoenix : http://localhost:6006 ; Arize : projet › Traces (délai d'affichage possible d'une à deux minutes)."
        )
        return
    console.print(f"[red]Collecteur non joignable ou refus[/red] ({cfg.endpoint}) : {detail}")
    raise typer.Exit(code=1)


def _sonder_collecteur(cfg) -> tuple[int | None, str]:
    from poc.observabilite.sonde import sonder_collecteur

    return sonder_collecteur(cfg)


@obs_app.command("phoenix")
def obs_phoenix(port: int = typer.Option(6006, help="Port de l'interface Phoenix.")) -> None:
    """Lance Phoenix en local (banc d'essai recommandé par la brique) : interface sur http://localhost:<port>, OTLP sur /v1/traces."""
    import os
    import subprocess
    import sys

    env = {**os.environ, "PHOENIX_PORT": str(port)}
    console.print(
        f"Phoenix : http://localhost:{port} — Ctrl+C pour arrêter. Envoyer les traces vers http://localhost:{port}/v1/traces."
    )
    subprocess.run([sys.executable, "-m", "phoenix.server.main", "serve"], env=env, check=False)


@obs_app.command("annoter")
def obs_annoter(
    session: str = typer.Argument(..., help="Identifiant de session."),
    nom: str = typer.Option("qualite_note", "--nom", help="Nom de l'avis (préfixé analyste_)."),
    label: str = typer.Option(None, "--label", help="Étiquette (ex. ACCEPTABLE, A_REPRENDRE)."),
    score: float = typer.Option(None, "--score", help="Note numérique (ex. 1 à 5)."),
    commentaire: str = typer.Option(None, "--commentaire", "-c", help="Commentaire libre."),
) -> None:
    """Dépose l'avis de l'analyste sur la trace de la session (annotation HUMAN), comme le ferait une file de relecture."""
    from poc.agent.harnais import trace_de_session
    from poc.observabilite import obtenir
    from poc.observabilite.evaluations import publier_avis_analyste

    config = charger_config()
    trace = trace_de_session(config, session)
    if trace is None:
        console.print(
            "[yellow]Aucune trace mémorisée pour cette session (observabilité inactive au moment de la session).[/yellow]"
        )
        raise typer.Exit(code=1)
    n = publier_avis_analyste(obtenir().config, trace, session, nom, label, score, commentaire)
    console.print(
        f"{n} annotation(s) déposée(s) sur la trace {trace['trace_id'][:8]}… (projet {trace['projet']}, backend {trace['backend']})."
    )


@obs_app.command("dataset")
def obs_dataset(
    nom: str = typer.Option("corpus-poc", "--nom", help="Nom du jeu de données."),
    scenarios: str = typer.Option(
        None, "--scenarios", "-s", help="Scénarios retenus, séparés par des virgules (défaut : tous)."
    ),
) -> None:
    """Exporte le corpus (un dossier par ligne : entrées, conclusion attendue, indicateurs vrais) en CSV et, sur Phoenix, en dataset."""
    from poc.observabilite import obtenir
    from poc.observabilite.dataset import construire_dataset, exporter_csv, publier_phoenix

    config = charger_config()
    df = construire_dataset(config, scenarios.split(",") if scenarios else None)
    chemin = exporter_csv(df, config, nom)
    console.print(f"{df.height} dossiers, {df.width} colonnes → {chemin}")
    ident = publier_phoenix(df, obtenir().config, nom)
    if ident:
        console.print(f"[green]Dataset créé dans Phoenix[/green] : {ident}")
    else:
        console.print(
            "Dataset non publié (backend Phoenix inactif) : charger le CSV dans la plateforme (Datasets › Upload)."
        )


if __name__ == "__main__":
    app()
