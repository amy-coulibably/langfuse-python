"""Phase C : les résultats du harnais et les avis de l'analyste deviennent des annotations dans la plateforme d'observabilité.

Deux puits, choisis par le backend configuré :

- **Phoenix** (banc d'essai) : client `phoenix.client`, annotations de span (`annotator_kind` CODE pour le harnais, HUMAN pour
  l'analyste) et de session ;
- **Arize AX** : SDK `arize` (version 8) et sa méthode `spans.update_annotations` sur une table `context.span_id` +
  `annotation.<nom>.label|score`, telle que la documente la page « Human annotations ». Le SDK n'est pas installé dans cet
  environnement (il est incompatible avec Phoenix sur la dépendance `wrapt`) : ce puits est écrit d'après la documentation et
  reste à valider sur l'instance de la banque.

Tout est fail-open : une plateforme injoignable produit un avertissement, jamais une exception dans le harnais.
Les annotations portent le préfixe `eval_` quand elles viennent du harnais (code) et `analyste_` quand elles viennent d'un
humain, pour les retrouver d'un filtre dans Arize.
"""

from __future__ import annotations

import logging
import re
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Protocol

from poc.observabilite.config import ConfigObservabilite

logger = logging.getLogger(__name__)


@dataclass(frozen=True)
class Annotation:
    nom: str
    label: str | None = None
    score: float | None = None
    explication: str | None = None
    annotateur: str = "CODE"  # CODE | HUMAN | LLM


class PuitsAnnotations(Protocol):
    def annoter_span(self, span_id: str, annotations: list[Annotation]) -> int: ...

    def annoter_session(self, session_id: str, annotations: list[Annotation]) -> int: ...


def nom_annotation(nom: str) -> str:
    """Arize n'accepte dans un nom d'annotation que lettres, chiffres, soulignés et espaces (`annotation.<nom>.label`)."""
    return re.sub(r"[^A-Za-z0-9_ ]", "_", nom)


class PuitsInactif:
    def annoter_span(self, span_id: str, annotations: list[Annotation]) -> int:
        return 0

    def annoter_session(self, session_id: str, annotations: list[Annotation]) -> int:
        return 0


class PuitsPhoenix:
    def __init__(self, base_url: str, projet: str) -> None:
        from phoenix.client import Client

        self.client = Client(base_url=base_url)
        self.projet = projet

    def annoter_span(self, span_id: str, annotations: list[Annotation]) -> int:
        n = 0
        for a in annotations:
            try:
                self.client.spans.add_span_annotation(
                    span_id=span_id,
                    annotation_name=a.nom,
                    annotator_kind=a.annotateur,  # type: ignore[arg-type]
                    label=a.label,
                    score=a.score,
                    explanation=(a.explication or "")[:2000] or None,
                    sync=True,
                )
                n += 1
            except Exception:  # noqa: BLE001
                logger.warning("annotation %s non envoyée à Phoenix", a.nom, exc_info=True)
        return n

    def annoter_session(self, session_id: str, annotations: list[Annotation]) -> int:
        n = 0
        for a in annotations:
            try:
                self.client.sessions.add_session_annotation(
                    session_id=session_id,
                    annotation_name=a.nom,
                    annotator_kind=a.annotateur,  # type: ignore[arg-type]
                    label=a.label,
                    score=a.score,
                    explanation=(a.explication or "")[:2000] or None,
                    sync=True,
                )
                n += 1
            except Exception:  # noqa: BLE001
                logger.warning("annotation de session %s non envoyée à Phoenix", a.nom, exc_info=True)
        return n


class PuitsArize:
    """Annotations de spans par le SDK Arize v8 (documentation « Human annotations ») ; non testé sur une instance."""

    def __init__(self, config: ConfigObservabilite) -> None:
        from arize import ArizeClient  # type: ignore[import-not-found]

        options: dict[str, Any] = {"api_key": config.api_key}
        ca = _autorite_interne()
        if ca:
            options["ssl_ca_cert"] = ca  # envoi Flight (gRPC) vers une instance signée par l'autorité interne
        if config.endpoint:
            from urllib.parse import urlparse

            u = urlparse(config.endpoint)
            if u.hostname:
                options["single_host"] = u.hostname
            if u.port:
                options["single_port"] = u.port
            if u.scheme in ("http", "https"):
                options["api_scheme"] = u.scheme
        self.client = ArizeClient(**options)
        self.space_id = config.space_id
        self.projet = config.projet

    def annoter_span(self, span_id: str, annotations: list[Annotation]) -> int:
        import pandas as pd

        ligne: dict[str, Any] = {"context.span_id": span_id}
        for a in annotations:
            nom = nom_annotation(a.nom)
            if a.label is not None:
                ligne[f"annotation.{nom}.label"] = str(a.label)
            if a.score is not None:
                ligne[f"annotation.{nom}.score"] = float(a.score)
            ligne[f"annotation.{nom}.updated_by"] = a.annotateur.lower()
        explications = [f"{a.nom} : {a.explication}" for a in annotations if a.explication]
        if explications:
            ligne["annotation.notes"] = "\n".join(explications)[
                :4000
            ]  # une note par span : on regroupe les explications
        try:
            self.client.spans.update_annotations(
                dataframe=pd.DataFrame([ligne]), project_name=self.projet, space_id=self.space_id
            )
            return len(annotations)
        except Exception:  # noqa: BLE001
            logger.warning("annotations non envoyées à Arize", exc_info=True)
            return 0

    def annoter_session(self, session_id: str, annotations: list[Annotation]) -> int:
        logger.info(
            "Arize : les annotations de session se font dans l'interface (vue Sessions) ; %d annotation(s) non envoyées",
            len(annotations),
        )
        return 0


def puits_pour(config: ConfigObservabilite) -> PuitsAnnotations:
    if not config.effective:
        return PuitsInactif()
    try:
        if config.backend == "phoenix":
            return PuitsPhoenix(base_url_depuis_endpoint(config.endpoint), config.projet)
        if config.backend == "arize":
            return PuitsArize(config)
    except Exception:  # noqa: BLE001
        logger.warning(
            "puits d'annotations indisponible (%s) : évaluations non publiées", config.backend, exc_info=True
        )
    return PuitsInactif()


def base_url_depuis_endpoint(endpoint: str | None) -> str:
    """`http://hote:6006/v1/traces` → `http://hote:6006`."""
    if not endpoint:
        return "http://localhost:6006"
    for suffixe in ("/v1/traces", "/v1/traces/"):
        if endpoint.endswith(suffixe):
            return endpoint[: -len(suffixe)]
    return endpoint.rstrip("/")


# ---------------------------------------------------------------------------------------------------------------------
# Du harnais aux annotations
# ---------------------------------------------------------------------------------------------------------------------
def annotations_evaluation(ev: Any) -> list[Annotation]:
    """Traduit une `Evaluation` du harnais en annotations lisibles dans la plateforme."""
    ecarts = [i for i in ev.indicateurs if i["statut"] == "ECART"]
    absents = [i["indicateur"] for i in ev.indicateurs if i["statut"] == "ABSENT"]
    taux = (ev.nb_exacts / ev.nb_compares) if ev.nb_compares else 0.0
    explication = (
        f"{ev.nb_exacts}/{ev.nb_compares} indicateurs comparés exacts à 1 % ({ev.nb_attendus} attendus). "
        + (
            f"Écarts : {', '.join(f'{e["indicateur"]} agent={e["valeur_agent"]:.4g} vrai={e["valeur_vraie"]:.4g}' for e in ecarts[:6])}. "
            if ecarts
            else ""
        )
        + (f"Absents : {', '.join(absents[:8])}." if absents else "")
    )
    out = [
        Annotation(
            "eval_exactitude_indicateurs",
            label="EXACT" if ev.nb_compares and ev.nb_exacts == ev.nb_compares else "ECARTS",
            score=round(taux, 3),
            explication=explication,
        ),
        Annotation(
            "eval_couverture_indicateurs",
            label=f"{ev.nb_compares}/{ev.nb_attendus}",
            score=round(ev.nb_compares / ev.nb_attendus, 3) if ev.nb_attendus else 0.0,
            explication="part des indicateurs clés de la vérité terrain posés dans la feuille de calcul",
        ),
        Annotation(
            "eval_diagnostic_concordant",
            label="NON_CODE" if ev.diagnostic_concordant is None else ("OUI" if ev.diagnostic_concordant else "NON"),
            score=None if ev.diagnostic_concordant is None else float(ev.diagnostic_concordant),
            explication=f"attendu {ev.conclusion_attendue} ; agent {ev.conclusion_agent or '(non codée)'}",
        ),
        Annotation(
            "eval_sections_verifiees",
            label=str(ev.sections_verifiees),
            score=float(ev.sections_verifiees),
            explication=f"{ev.sections_refusees} refusée(s) par le vérificateur",
        ),
        Annotation("eval_note_produite", label="OUI" if ev.note_presente else "NON", score=float(ev.note_presente)),
    ]
    return out


def publier_evaluation(config: ConfigObservabilite, ev: Any, trace: dict | None) -> dict[str, int]:
    """Annote le span racine (et la session) de la plateforme avec l'évaluation du harnais. Renvoie les compteurs d'envoi."""
    puits = puits_pour(config)
    if isinstance(puits, PuitsInactif) or not trace or not trace.get("span_id"):
        return {"span": 0, "session": 0}
    annotations = annotations_evaluation(ev)
    n_span = puits.annoter_span(trace["span_id"], annotations)
    n_session = puits.annoter_session(
        ev.session_id,
        [a for a in annotations if a.nom in ("eval_exactitude_indicateurs", "eval_diagnostic_concordant")],
    )
    return {"span": n_span, "session": n_session}


def publier_avis_analyste(
    config: ConfigObservabilite,
    trace: dict | None,
    session_id: str,
    nom: str,
    label: str | None,
    score: float | None,
    commentaire: str | None,
) -> int:
    """Un avis humain (file de relecture) : annotation HUMAN `analyste_<nom>` sur le span racine."""
    puits = puits_pour(config)
    if isinstance(puits, PuitsInactif) or not trace or not trace.get("span_id"):
        return 0
    a = Annotation(
        f"analyste_{nom_annotation(nom)}", label=label, score=score, explication=commentaire, annotateur="HUMAN"
    )
    n = puits.annoter_span(trace["span_id"], [a])
    puits.annoter_session(session_id, [a])
    return n


def _autorite_interne() -> str | None:
    """Le fichier PEM de l'autorité interne, s'il est indiqué (mêmes variables que l'exportateur OTLP et le client LLM)."""
    import os

    from poc.config import RACINE

    for variable in (
        "OTEL_EXPORTER_OTLP_CERTIFICATE",
        "POC_CA_BUNDLE",
        "REQUESTS_CA_BUNDLE",
        "CA_BUNDLE",
        "SSL_CERT_FILE",
    ):
        valeur = os.environ.get(variable)
        if valeur:
            chemin = Path(valeur).expanduser()
            chemin = chemin if chemin.is_absolute() else RACINE / chemin
            if chemin.is_file():
                return str(chemin)
    return None
