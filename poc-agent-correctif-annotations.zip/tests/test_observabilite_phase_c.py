"""Phase C : traduction de l'évaluation du harnais en annotations, record de session, dataset du corpus, mémorisation du
lien session → trace. Sans plateforme : puits factice et brique avec exportateur en mémoire."""

from __future__ import annotations

import pytest

from poc.agent import evaluer_session, lancer_agent
from poc.agent.harnais import publier, trace_de_session
from poc.config import Config
from poc.donnees import ParquetStore, SQLiteStore
from poc.generateur.marche import construire_base_sectorielle
from poc.generateur.pipeline import generer_dossier
from poc.llm import ConfigLLM
from poc.llm.config import ModeleLLM
from poc.observabilite import ConfigObservabilite, Observabilite, adaptateur, reinitialiser
from poc.observabilite import evaluations as ev_mod
from poc.observabilite.config import vers_config_ml_utils
from poc.observabilite.dataset import ENTREES, SORTIES, construire_dataset, exporter_csv
from poc.observabilite.evaluations import (
    Annotation,
    annotations_evaluation,
    base_url_depuis_endpoint,
    publier_evaluation,
)
from poc.observabilite.records import features_session
from poc.referentiels import charger_referentiels

ml_utils = pytest.importorskip("ml_utils.observability")


@pytest.fixture(scope="module")
def config(tmp_path_factory):
    cfg = Config(data_dir=tmp_path_factory.mktemp("obsc"), unite_safir="euros")
    refs = charger_referentiels()
    generer_dossier(cfg, "croissance_saine", 1, refs=refs)
    generer_dossier(cfg, "dette_cachee", 2, refs=refs)
    construire_base_sectorielle(
        refs, ParquetStore(cfg.si_simule_dir), SQLiteStore(cfg.sqlite_dossier), n_par_secteur=40
    )
    return cfg


class PuitsFactice:
    def __init__(self) -> None:
        self.spans: list[tuple[str, Annotation]] = []
        self.sessions: list[tuple[str, Annotation]] = []

    def annoter_span(self, span_id, annotations):
        self.spans += [(span_id, a) for a in annotations]
        return len(annotations)

    def annoter_session(self, session_id, annotations):
        self.sessions += [(session_id, a) for a in annotations]
        return len(annotations)


@pytest.fixture()
def obs_memoire(monkeypatch):
    from ml_utils.observability import ArizeManager

    from tests.test_observabilite import BackendMemoire

    reinitialiser()
    cfg = ConfigObservabilite(active=True, backend="phoenix", endpoint="http://memoire:6006/v1/traces", projet="test")
    backend = BackendMemoire()
    manager = ArizeManager(vers_config_ml_utils(cfg), backend=backend)
    obs = Observabilite(cfg, manager)
    monkeypatch.setattr(adaptateur, "_INSTANCE", obs)
    puits = PuitsFactice()
    monkeypatch.setattr(ev_mod, "puits_pour", lambda config: puits)
    yield obs, backend.exporteur, puits
    manager.close()
    reinitialiser()


def test_base_url():
    assert base_url_depuis_endpoint("http://h:6006/v1/traces") == "http://h:6006"
    assert base_url_depuis_endpoint("https://arize.interne/") == "https://arize.interne"
    assert base_url_depuis_endpoint(None) == "http://localhost:6006"


def test_session_memorise_sa_trace_et_l_evaluation_est_publiee(config, obs_memoire):
    obs, exporteur, puits = obs_memoire
    cfg = ConfigLLM(defaut="factice", modeles={"factice": ModeleLLM(fournisseur="factice", nom="factice")})
    d = SQLiteStore(config.sqlite_verite_terrain).requete(
        "SELECT dossier_id FROM vt_etiquette WHERE scenario = 'croissance_saine'"
    )["dossier_id"][0]
    r = lancer_agent(config, d, config_llm=cfg, checkpoints=False)
    trace = trace_de_session(config, r.session_id)
    assert trace and len(trace["trace_id"]) == 32 and len(trace["span_id"]) == 16 and trace["backend"] == "phoenix"
    racine = next(s for s in exporteur.get_finished_spans() if s.parent is None)
    assert format(racine.context.span_id, "016x") == trace["span_id"]
    ev = evaluer_session(config, r.session_id)
    compte = publier(config, ev, r)
    assert compte["span"] == 5 and compte["session"] == 2
    noms = {a.nom for _, a in puits.spans}
    assert noms == {
        "eval_exactitude_indicateurs",
        "eval_couverture_indicateurs",
        "eval_diagnostic_concordant",
        "eval_sections_verifiees",
        "eval_note_produite",
    }
    assert all(sid == trace["span_id"] for sid, _ in puits.spans)
    concordant = next(a for _, a in puits.spans if a.nom == "eval_diagnostic_concordant")
    assert concordant.label == "NON_CODE" and concordant.score is None  # le conformiste ne code pas de conclusion
    assert all(a.annotateur == "CODE" for _, a in puits.spans)
    # record : pas de porte records (OBS_RECORDS_URI absent) → False, sans exception
    assert compte["record"] is False


def test_annotations_evaluation_traduit_les_ecarts():
    class Ev:
        session_id = "S"
        dossier_id = "D"
        indicateurs = [
            {"indicateur": "EBE", "statut": "EXACT", "valeur_agent": 1.0, "valeur_vraie": 1.0},
            {"indicateur": "DSCR_AJUSTE", "statut": "ECART", "valeur_agent": 2.0, "valeur_vraie": 1.8},
            {"indicateur": "BFR", "statut": "ABSENT", "valeur_agent": None, "valeur_vraie": 5.0},
        ]
        nb_exacts, nb_compares, nb_attendus = 1, 2, 3
        sections_verifiees, sections_refusees = 7, 4
        conclusion_attendue, conclusion_agent, diagnostic_concordant = (
            "CAPACITE_SATISFAISANTE",
            "CAPACITE_SATISFAISANTE",
            True,
        )
        note_presente = True
        tokens, cout_euros = 1000, 0.1

    a = {x.nom: x for x in annotations_evaluation(Ev())}
    assert a["eval_exactitude_indicateurs"].score == 0.5 and a["eval_exactitude_indicateurs"].label == "ECARTS"
    assert (
        "DSCR_AJUSTE" in a["eval_exactitude_indicateurs"].explication
        and "BFR" in a["eval_exactitude_indicateurs"].explication
    )
    assert a["eval_diagnostic_concordant"].label == "OUI" and a["eval_diagnostic_concordant"].score == 1.0
    assert a["eval_sections_verifiees"].score == 7.0
    assert publier_evaluation(ConfigObservabilite(), Ev(), None) == {"span": 0, "session": 0}
    assert features_session(Ev(), None, {"scenario": "x", "difficulte": 2, "timestamp": "interdit"})["scenario"] == "x"
    assert "timestamp" not in features_session(Ev(), None, {"timestamp": 1})


def test_dataset_du_corpus(config):
    df = construire_dataset(config)
    assert df.height == 2 and set(ENTREES) <= set(df.columns) and set(SORTIES) <= set(df.columns)
    assert df["vrai_ebe"].null_count() == 0 and set(df["conclusion_attendue"].to_list()) >= {"CAPACITE_SATISFAISANTE"}
    chemin = exporter_csv(df, config, "test")
    assert chemin.exists() and chemin.read_text(encoding="utf-8").startswith("dossier_id")
    assert construire_dataset(config, ["dette_cachee"]).height == 1


def test_sans_observabilite_rien_ne_part(config):
    reinitialiser()
    adaptateur._INSTANCE = Observabilite(ConfigObservabilite(), None)
    cfg = ConfigLLM(defaut="factice", modeles={"factice": ModeleLLM(fournisseur="factice", nom="factice")})
    d = SQLiteStore(config.sqlite_verite_terrain).requete("SELECT dossier_id FROM vt_etiquette")["dossier_id"][0]
    r = lancer_agent(config, d, config_llm=cfg, checkpoints=False)
    assert publier(config, evaluer_session(config, r.session_id), r) == {"span": 0, "session": 0, "record": False}
    reinitialiser()


def test_noms_d_annotations_au_format_arize():
    """Format imposé par le SDK Arize : annotation.<nom>.label|score|text|updated_by|updated_at, nom en [A-Za-z0-9_ ]."""
    import re

    from poc.observabilite.evaluations import nom_annotation

    motif = re.compile(r"^[A-Za-z0-9_\s]+$")

    class Ev:
        indicateurs, nb_exacts, nb_compares, nb_attendus = [], 0, 0, 17
        sections_verifiees, sections_refusees, note_presente = 0, 0, False
        conclusion_attendue, conclusion_agent, diagnostic_concordant = "X", "", None

    assert all(motif.match(a.nom) for a in annotations_evaluation(Ev()))
    assert nom_annotation("analyste.qualité-note") == "analyste_qualit__note"
